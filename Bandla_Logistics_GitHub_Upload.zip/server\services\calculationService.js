const { getDb } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

/**
 * Calculates shift stop pay, excess parcel pay, top-up guarantee and gross shift total.
 * Dynamic Base Pay & Excess Parcel bonus (Â£0.05).
 */
async function calculateShift(shiftInput) {
  const db = getDb();
  let baseRate = Number(shiftInput.appliedBaseRate || 0);
  let excessRate = Number(shiftInput.appliedExcessRate || 0.05);

  // If applied rates not provided, look up from route_rates table
  if (!baseRate && (shiftInput.routeCode || shiftInput.routeId)) {
    const query = shiftInput.routeId 
      ? `SELECT * FROM route_rates WHERE id = '${shiftInput.routeId}' LIMIT 1`
      : `SELECT * FROM route_rates WHERE route_code = '${shiftInput.routeCode}' ${shiftInput.depotId ? `AND depot_id = '${shiftInput.depotId}'` : ''} LIMIT 1`;
    
    const { rows } = await db.session.client.query(query);
    if (rows && rows.length > 0) {
      baseRate = Number(rows[0].base_rate_per_stop);
      excessRate = Number(rows[0].excess_parcel_rate || 0.05);
    } else {
      // Default base rate fallback if route not configured
      baseRate = 1.0000;
    }
  }

  const paidStops = Math.max(0, parseInt(shiftInput.paidStops || 0, 10));
  const dispatchedStops = Math.max(paidStops, parseInt(shiftInput.dispatchedStops || 0, 10));
  const totalParcels = Math.max(0, parseInt(shiftInput.totalParcels || 0, 10));
  const topUpCancelled = Boolean(shiftInput.topUpCancelled || shiftInput.isTopUpCancelled);

  // Excess parcels = max(0, Total Parcels - Paid Stops)
  const excessParcels = shiftInput.excessParcels !== undefined 
    ? Math.max(0, parseInt(shiftInput.excessParcels, 10)) 
    : Math.max(0, totalParcels - paidStops);

  // Dynamic Base Stop Pay: Use explicit Stop pay if provided (from CSV Stop column), else calculate paidStops * baseRate
  const calculatedStopPay = shiftInput.calculatedStopPay !== undefined && !isNaN(parseFloat(shiftInput.calculatedStopPay)) && parseFloat(shiftInput.calculatedStopPay) > 0
    ? Number(parseFloat(shiftInput.calculatedStopPay).toFixed(2))
    : Number((paidStops * (baseRate || 1.0000)).toFixed(2));

  // Excess Parcel Bonus: Â£0.05 per excess parcel
  const calculatedParcelPay = shiftInput.calculatedParcelPay !== undefined && !isNaN(parseFloat(shiftInput.calculatedParcelPay))
    ? Number(parseFloat(shiftInput.calculatedParcelPay).toFixed(2))
    : Number((excessParcels * excessRate).toFixed(2));

  // Top-Up Guarantee: 100 stops minimum guarantee
  let topUpStops = 0;
  let topUpPay = 0;
  if (paidStops > 0 && paidStops < 100 && !topUpCancelled) {
    topUpStops = 100 - paidStops;
    topUpPay = Number((topUpStops * (baseRate || 1.0000)).toFixed(2));
  }

  // Gross Shift Total = Stop Pay + Parcel Bonus + Top-Up Subsidy
  const grossShiftTotal = Number((calculatedStopPay + calculatedParcelPay + topUpPay).toFixed(2));

  return {
    ...shiftInput,
    dispatchedStops,
    paidStops,
    totalParcels,
    excessParcels,
    appliedBaseRate: baseRate ? baseRate.toFixed(4) : '1.0000',
    appliedExcessRate: excessRate.toFixed(4),
    calculatedStopPay: calculatedStopPay.toFixed(2),
    calculatedParcelPay: calculatedParcelPay.toFixed(2),
    topUpStops,
    topUpPay: topUpPay.toFixed(2),
    topUpCancelled,
    isTopUpCancelled: topUpCancelled,
    grossShiftTotal: grossShiftTotal.toFixed(2)
  };
}

/**
 * Reconciles unbilled shifts & deductions, computes contractor payroll invoice,
 * applies VAT to Net Subtotal if VAT-registered, and enforces Invoice Locking.
 */
async function generateMonthlyInvoice({
  driverId,
  billingMonth,
  billingStartDate,
  billingEndDate,
  invoiceDate = new Date().toISOString().split('T')[0]
}) {
  const db = getDb();
  const client = db.session.client;

  // 1. Fetch driver details
  const driverRes = await client.query(`SELECT * FROM drivers WHERE id = $1`, [driverId]);
  if (!driverRes.rows || driverRes.rows.length === 0) {
    throw new Error('Driver not found');
  }
  const driver = driverRes.rows[0];

  // 2. Fetch un-invoiced shifts for this driver within or matching the billing period
  const shiftsRes = await client.query(`
    SELECT * FROM daily_shifts 
    WHERE driver_id = $1 
      AND invoice_id IS NULL
      AND shift_date >= $2 
      AND shift_date <= $3
    ORDER BY shift_date ASC
  `, [driverId, billingStartDate, billingEndDate]);
  
  const shifts = shiftsRes.rows || [];

  // 3. Fetch un-invoiced charges & deductions for this driver for this billing period
  const chargesRes = await client.query(`
    SELECT * FROM charges_and_deductions 
    WHERE driver_id = $1 
      AND invoice_id IS NULL
      AND (billing_period = $2 OR (charge_date >= $3 AND charge_date <= $4))
    ORDER BY charge_date ASC
  `, [driverId, billingMonth, billingStartDate, billingEndDate]);
  
  const charges = chargesRes.rows || [];

  // 4. Compute Totals
  let totalStopsDispatched = 0;
  let totalPaidStops = 0;
  let totalStopPay = 0;
  let totalExcessParcelPay = 0;
  let totalTopUpPay = 0;
  let grossEarnings = 0;

  shifts.forEach(s => {
    totalStopsDispatched += parseInt(s.dispatched_stops || 0, 10);
    totalPaidStops += parseInt(s.paid_stops || 0, 10);
    totalStopPay += parseFloat(s.calculated_stop_pay || 0);
    totalExcessParcelPay += parseFloat(s.calculated_parcel_pay || 0);
    totalTopUpPay += parseFloat(s.top_up_pay || 0);
    grossEarnings += parseFloat(s.gross_shift_total || 0);
  });

  let totalDeductions = 0;
  charges.forEach(c => {
    totalDeductions += parseFloat(c.amount || 0);
  });

  // Subtotal = Gross Earnings - Total Deductions
  const subtotal = Number((grossEarnings - totalDeductions).toFixed(2));

  // VAT (20%) on Net Subtotal for VAT Registered contractors
  const vatRate = driver.is_vat_registered ? 0.20 : 0.00;
  const vatApplied = Number((subtotal * vatRate).toFixed(2));
  const netPayable = Number((subtotal + vatApplied).toFixed(2));

  // 5. Generate Invoice Number (e.g. INV-2026-08-001)
  const countRes = await client.query(`SELECT COUNT(*) FROM payroll_invoices`);
  const invSeq = parseInt(countRes.rows[0].count, 10) + 1;
  const monthCode = billingMonth.replace(/\s+/g, '-').toUpperCase();
  const invoiceNumber = `INV-${monthCode}-${String(invSeq).padStart(3, '0')}`;

  const invoiceId = uuidv4();

  // 6. Insert Payroll Invoice
  await client.query(`
    INSERT INTO payroll_invoices (
      id, invoice_number, driver_id, billing_month, billing_start_date, billing_end_date,
      invoice_date, days_worked, total_stops_dispatched, total_paid_stops,
      total_stop_pay, total_excess_parcel_pay, total_top_up_pay, gross_earnings,
      total_deductions, subtotal, vat_rate, vat_applied, net_payable, payment_status, status
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21)
  `, [
    invoiceId, invoiceNumber, driverId, billingMonth, billingStartDate, billingEndDate,
    invoiceDate, shifts.length, totalStopsDispatched, totalPaidStops,
    totalStopPay.toFixed(2), totalExcessParcelPay.toFixed(2), totalTopUpPay.toFixed(2), grossEarnings.toFixed(2),
    totalDeductions.toFixed(2), subtotal.toFixed(2), vatRate.toFixed(2), vatApplied.toFixed(2), netPayable.toFixed(2), 'Draft', 'Draft'
  ]);

  // 7. INVOICE LOCKING: Stamp invoice_id on all participating shifts & charges
  if (shifts.length > 0) {
    const shiftIds = shifts.map(s => `'${s.id}'`).join(',');
    await client.query(`UPDATE daily_shifts SET invoice_id = '${invoiceId}' WHERE id IN (${shiftIds})`);
  }

  if (charges.length > 0) {
    const chargeIds = charges.map(c => `'${c.id}'`).join(',');
    await client.query(`UPDATE charges_and_deductions SET invoice_id = '${invoiceId}', is_settled = TRUE WHERE id IN (${chargeIds})`);
  }

  return {
    id: invoiceId,
    invoiceNumber,
    driver,
    billingMonth,
    daysWorked: shifts.length,
    totalStopsDispatched,
    totalPaidStops,
    totalStopPay: totalStopPay.toFixed(2),
    totalExcessParcelPay: totalExcessParcelPay.toFixed(2),
    totalTopUpPay: totalTopUpPay.toFixed(2),
    grossEarnings: grossEarnings.toFixed(2),
    totalDeductions: totalDeductions.toFixed(2),
    subtotal: subtotal.toFixed(2),
    vatRate,
    vatApplied: vatApplied.toFixed(2),
    netPayable: netPayable.toFixed(2),
    shiftsCount: shifts.length,
    chargesCount: charges.length
  };
}

module.exports = {
  calculateShift,
  generateMonthlyInvoice
};