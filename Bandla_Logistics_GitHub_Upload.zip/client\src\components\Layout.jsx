import React from 'react';
import { useAuth } from '../context/AuthContext';
import ThemeToggle from './ThemeToggle';
import { 
  LayoutDashboard, 
  CalendarDays, 
  Calendar,
  Users, 
  Truck, 
  Receipt, 
  CreditCard, 
  Navigation, 
  Wrench, 
  Database,
  Cloud,
  LogOut,
  ShieldCheck,
  Gauge
} from 'lucide-react';

export default function Layout({ activeTab, setActiveTab, children }) {
  const { user, isAdmin, isShiftManager, logout } = useAuth();

  const allNavItems = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard, adminOnly: true },
    { id: 'analytics', label: 'Performance & Cost/KM', icon: Gauge, adminOnly: true },
    { id: 'planner', label: 'Weekly Route Planner', icon: Calendar, adminOnly: false },
    { id: 'shifts', label: 'Daily Route Logs & Ingestion', icon: CalendarDays, adminOnly: false },
    { id: 'fleet', label: 'Fleet & Compliance', icon: Truck, adminOnly: false },
    { id: 'drivers', label: 'Driver & Holiday Register', icon: Users, adminOnly: true },
    { id: 'invoices', label: 'Payroll & Invoicing', icon: Receipt, adminOnly: true },
    { id: 'charges', label: 'Charges & Deductions', icon: CreditCard, adminOnly: true },
    { id: 'audit', label: 'Financial Audit Trails', icon: ShieldCheck, adminOnly: true },
    { id: 'routes', label: 'Route Rates', icon: Navigation, adminOnly: true },
    { id: 'maintenance', label: 'Maintenance CRM & Fleet', icon: Wrench, adminOnly: true },
    { id: 'users', label: 'User Roles & Privileges', icon: ShieldCheck, adminOnly: true },
    { id: 'system', label: 'Migration & Status', icon: Database, adminOnly: true },
  ];

  // RBAC Navigation Filtering: Dynamically shows tabs matching Admin role OR Manager's delegated privileges!
  const userPerms = Array.isArray(user?.permissions) ? user.permissions : [];
  const visibleNavItems = allNavItems.filter(item => {
    if (isAdmin) return true;
    if (isShiftManager) {
      if (!item.adminOnly) return true;
      if (item.id === 'drivers' && userPerms.includes('manage_drivers')) return true;
      if (item.id === 'invoices' && (userPerms.includes('view_payroll') || userPerms.includes('manage_payroll'))) return true;
      if (item.id === 'charges' && userPerms.includes('manage_deductions')) return true;
      if (item.id === 'routes' && userPerms.includes('manage_rate_cards')) return true;
      if (item.id === 'maintenance' && userPerms.includes('manage_maintenance')) return true;
      if (item.id === 'analytics' && (userPerms.includes('view_dashboard') || userPerms.includes('manage_maintenance'))) return true;
      if (item.id === 'dashboard' && userPerms.includes('view_dashboard')) return true;
      return false;
    }
    return true;
  });

  return (
    <div className="flex h-screen bg-slate-100 text-slate-900 dark:bg-slate-950 dark:text-slate-100 overflow-hidden font-sans transition-colors duration-200">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 dark:bg-slate-900 dark:border-slate-800 flex flex-col justify-between shrink-0 transition-colors duration-200 shadow-sm dark:shadow-none">
        <div>
          {/* Official Company Logo / Header with Theme Toggle */}
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 bg-slate-50/70 dark:bg-slate-950/40">
            <div className="flex items-center gap-3 min-w-0">
              <img 
                src="/logo.jpg" 
                alt="Bandla Logistics" 
                className="w-10 h-10 rounded-xl object-contain bg-black border border-slate-200 dark:border-slate-800 shadow-sm shrink-0" 
              />
              <div className="min-w-0">
                <h1 className="font-bold text-xs leading-tight text-slate-900 dark:text-white tracking-wide truncate">BANDLA LOGISTICS</h1>
                <p className="text-[10px] text-blue-600 dark:text-blue-400 font-semibold tracking-tight">Cloud Portal v2.0</p>
              </div>
            </div>

            {/* Light / Dark Mode Toggle Button */}
            <ThemeToggle />
          </div>

          {/* Navigation Links */}
          <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-180px)]">
            {visibleNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* User Info & Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-900/70 space-y-3">
          {/* User Profile Pill */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-800 border border-blue-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 flex items-center justify-center font-bold text-xs shrink-0">
                {user?.fullName?.charAt(0) || 'U'}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 truncate">{user?.fullName || 'User'}</p>
                <div className="flex items-center gap-1">
                  {isAdmin ? (
                    <span className="text-[10px] text-blue-700 bg-blue-100 dark:text-blue-400 dark:bg-blue-950/80 px-1.5 py-0.5 rounded border border-blue-200 dark:border-blue-800/60 font-medium">
                      Admin
                    </span>
                  ) : (
                    <span className="text-[10px] text-amber-700 bg-amber-100 dark:text-amber-400 dark:bg-amber-950/80 px-1.5 py-0.5 rounded border border-amber-200 dark:border-amber-800/60 font-medium">
                      Route Mgr
                    </span>
                  )}
                  {user?.depotName && (
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 truncate">• {user.depotName}</span>
                  )}
                </div>
              </div>
            </div>

            <button
              onClick={logout}
              title="Sign Out"
              className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:text-slate-400 dark:hover:text-rose-400 dark:hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-[11px] text-emerald-600 dark:text-emerald-400 font-medium pt-1 border-t border-slate-200 dark:border-slate-800/60">
            <Cloud className="w-3.5 h-3.5" />
            <span>PostgreSQL Cloud Active</span>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto bg-slate-100/70 dark:bg-slate-950 transition-colors duration-200">
        <div className="p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
          {children}
        </div>
      </main>
    </div>
  );
}