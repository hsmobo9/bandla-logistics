import React, { useState, useEffect } from 'react';
import { 
  Receipt, 
  FileText, 
  Download, 
  Plus, 
  Search, 
  Filter, 
  CheckCircle, 
  Clock, 
  XCircle, 
  Eye,
  RefreshCw,
  UploadCloud,
  AlertTriangle,
  Send,
  Lock,
  Unlock,
  ShieldCheck,
  Calculator,
  ChevronRight,
  TrendingDown,
  Info,
  Package
} from 'lucide-react';
import { 
  getInvoices, 
  getDrivers, 
  generateInvoice, 
  getInvoiceById, 
  updateInvoiceStatus, 
  generateInvoicePdf,
  downloadInvoicePdfBlob,
  downloadBatchInvoiceZipBlob,
  batchUpdateInvoiceStatus,
  uploadPortalCsv,
  getShifts,
  toggleTopUp,
  getInvoiceWhatsappUrl
} from '../services/api';
import Modal from '../components/Modal';
import { formatCurrency, formatDate, formatNumber } from '../utils/formatters';

export default function PayrollInvoices() {
  const [activeSubTab, setActiveSubTab] = useState('invoices'); // 'invoices' | 'reconciliation' | 'transparency'
  const [invoices, setInvoices] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('August 2026');
  const [statusFilter, setStatusFilter] = useState('');

  // CSV Ingestion Modal
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);
  const [csvFile, setCsvFile] = useState(null);
  const [csvUploading, setCsvUploading] = useState(false);
  const [csvResult, setCsvResult] = useState(null);

  // Generate Form Modal
  const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedInvoiceIds, setSelectedInvoiceIds] = useState([]);
  const [batchDownloading, setBatchDownloading] = useState(false);
  const [batchUpdating, setBatchUpdating] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [selectedReconDriver, setSelectedReconDriver] = useState('');
  const [generating, setGenerating] = useState(false);
  const [generateModalError, setGenerateModalError] = useState(null);

  // Top-Up Override Reason Modal
  const [isOverrideModalOpen, setIsOverrideModalOpen] = useState(false);
  const [selectedShiftForOverride, setSelectedShiftForOverride] = useState(null);
  const [selectedShiftForPortalData, setSelectedShiftForPortalData] = useState(null);
  const [isPortalDataModalOpen, setIsPortalDataModalOpen] = useState(false);
  const [overrideReason, setOverrideReason] = useState('');

  // Transparency Inspector Driver Select
  const [transparencyDriverId, setTransparencyDriverId] = useState('');
  const [reconFilterType, setReconFilterType] = useState('ALL'); // 'ALL' | 'FAILS' | 'TOPUP' | 'MISSING'

  // Generate Form
  const [formData, setFormData] = useState({
    driverId: '',
    billingMonth: 'August 2026',
    billingStartDate: '2026-08-01',
    billingEndDate: '2026-08-31',
    invoiceDate: '2026-08-31'
  });

  useEffect(() => {
    loadPrerequisites();
  }, []);

  useEffect(() => {
    if (activeSubTab === 'invoices') {
      loadInvoices();
    } else if (activeSubTab === 'reconciliation' || activeSubTab === 'transparency') {
      loadShifts();
    }
  }, [selectedMonth, statusFilter, activeSubTab]);

  const loadPrerequisites = async () => {
    try {
      const dList = await getDrivers();
      setDrivers(dList);
      if (dList.length > 0) {
        if (!formData.driverId) setFormData(prev => ({ ...prev, driverId: dList[0].id }));
        if (!transparencyDriverId) setTransparencyDriverId(dList[0].id);
      }
    } catch (err) {
      console.error('Error loading drivers:', err);
    }
  };

  const loadInvoices = async () => {
    try {
      setLoading(true);
      const params = {};
      if (selectedMonth) params.billingMonth = selectedMonth;
      if (statusFilter) params.status = statusFilter;
      const data = await getInvoices(params);
      setInvoices(data);
    } catch (err) {
      console.error('Error loading invoices:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadShifts = async () => {
    try {
      setLoading(true);
      const data = await getShifts({ startDate: '2026-08-01', endDate: '2026-08-31' });
      setShifts(data);
    } catch (err) {
      console.error('Error loading shifts:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCsvUpload = async (e) => {
    e.preventDefault();
    if (!csvFile) return console.warn('Please choose a CSV file first.');
    try {
      setCsvUploading(true);
      setCsvResult(null);
      const res = await uploadPortalCsv(csvFile);
      setCsvResult(res);
      await loadShifts();
      await loadInvoices();
    } catch (err) {
      console.warn('CSV Ingestion Failed: ' + (err.response?.data?.error || err.message));
    } finally {
      setCsvUploading(false);
    }
  };

  const handleOpenGenerateModal = () => {
    setGenerateModalError(null);
    setFormData(prev => ({
      ...prev,
      driverId: prev.driverId || (drivers.length > 0 ? drivers[0].id : ''),
      billingMonth: selectedMonth && selectedMonth !== 'all' ? selectedMonth : 'August 2026',
      billingStartDate: '2026-08-01',
      billingEndDate: '2026-08-31',
      invoiceDate: '2026-08-31'
    }));
    setIsGenerateModalOpen(true);
  };

  const handleGenerateInvoice = async (e) => {
    e.preventDefault();
    setGenerateModalError(null);

    const targetDriverId = formData.driverId || (drivers.length > 0 ? drivers[0].id : '');
    if (!targetDriverId) {
      setGenerateModalError('Please select a contractor courier driver from the list.');
      return;
    }

    try {
      setGenerating(true);
      const payload = {
        ...formData,
        driverId: targetDriverId
      };
      const created = await generateInvoice(payload);
      setIsGenerateModalOpen(false);
      await loadInvoices();
      if (created?.id) {
        handleViewDetails(created.id);
      }
    } catch (err) {
      const msg = err.response?.data?.error || err.message || 'Error generating contractor invoice';
      console.warn('Error generating invoice:', msg);
      setGenerateModalError(msg);
    } finally {
      setGenerating(false);
    }
  };

  const handleOpenPortalShiftModal = (shift) => {
    setSelectedShiftForPortalData(shift);
    setIsPortalDataModalOpen(true);
  };

  const handleViewDetails = async (id) => {
    try {
      const data = await getInvoiceById(id);
      setSelectedInvoice(data);
      setIsDetailModalOpen(true);
    } catch (err) {
      console.warn('Error loading invoice details: ' + (err.response?.data?.error || err.message));
    }
  };

  const [downloadingId, setDownloadingId] = useState(null);

  const handleDownloadPdf = async (id, invoiceNumber) => {
    try {
      setDownloadingId(id);
      await downloadInvoicePdfBlob(id, invoiceNumber);
    } catch (err) {
      console.warn('Blob download fallback triggered:', err.message);
      const token = localStorage.getItem('token') || '';
      window.open(`/api/invoices/${id}/pdf/download?token=${token}`, '_blank');
    } finally {
      setDownloadingId(null);
    }
  };

  
  const handleToggleSelectAllInvoices = () => {
    if (selectedInvoiceIds.length === filteredInvoices.length && filteredInvoices.length > 0) {
      setSelectedInvoiceIds([]);
    } else {
      setSelectedInvoiceIds(filteredInvoices.map(i => i.id));
    }
  };

  const handleToggleSelectInvoice = (id) => {
    setSelectedInvoiceIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleDownloadSelectedZip = async () => {
    if (!selectedInvoiceIds.length) return;
    try {
      setBatchDownloading(true);
      await downloadBatchInvoiceZipBlob({ invoiceIds: selectedInvoiceIds, billingMonth: selectedMonth });
    } catch (err) {
      console.warn('Batch download failed: ' + (err.response?.data?.error || err.message));
    } finally {
      setBatchDownloading(false);
    }
  };

  const handleDownloadAllFilteredZip = async () => {
    try {
      setBatchDownloading(true);
      const allIds = filteredInvoices.map(i => i.id);
      await downloadBatchInvoiceZipBlob({ invoiceIds: allIds, billingMonth: selectedMonth });
    } catch (err) {
      console.warn('All invoices download failed: ' + (err.response?.data?.error || err.message));
    } finally {
      setBatchDownloading(false);
    }
  };

  const handleBatchStatusUpdate = async (newStatus) => {
    if (!selectedInvoiceIds.length) return;
    try {
      setBatchUpdating(true);
      await batchUpdateInvoiceStatus(selectedInvoiceIds, newStatus, `Batch transitioned to ${newStatus}`);
      await loadInvoices();
      setSelectedInvoiceIds([]);
    } catch (err) {
      console.warn('Batch status update failed: ' + (err.response?.data?.error || err.message));
    } finally {
      setBatchUpdating(false);
    }
  };

  const handleStatusTransition = async (id, newStatus) => {
    try {
      await updateInvoiceStatus(id, newStatus, `Transitioned status to ${newStatus}`);
      await loadInvoices();
      if (selectedInvoice && selectedInvoice.id === id) {
        setSelectedInvoice({ ...selectedInvoice, status: newStatus, payment_status: newStatus });
      }
    } catch (err) {
      console.warn('Status Transition Failed: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleSendWhatsApp = async (id) => {
    try {
      const data = await getInvoiceWhatsappUrl(id);
      window.open(data.whatsappUrl, '_blank');
    } catch (err) {
      console.warn('Failed to generate WhatsApp link: ' + (err.response?.data?.error || err.message));
    }
  };

  const handlePromptToggleTopUp = (shift) => {
    setSelectedShiftForOverride(shift);
    setOverrideReason('');
    setIsOverrideModalOpen(true);
  };

  const handleConfirmToggleTopUp = async () => {
    if (!selectedShiftForOverride) return;
    try {
      await toggleTopUp(selectedShiftForOverride.id, overrideReason);
      setIsOverrideModalOpen(false);
      await loadShifts();
    } catch (err) {
      console.warn('Failed to override Top-Up: ' + (err.response?.data?.error || err.message));
    }
  };

  // Filter Invoices
  const filteredInvoices = invoices.filter(inv => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      inv.invoice_number?.toLowerCase().includes(q) ||
      inv.driver_name?.toLowerCase().includes(q) ||
      inv.driver_code?.toLowerCase().includes(q)
    );
  });

  // Filter Shifts for Reconciliation
  const filteredShifts = shifts.filter(s => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      s.driver_name?.toLowerCase().includes(q) ||
      s.driver_code?.toLowerCase().includes(q) ||
      s.route_code?.toLowerCase().includes(q)
    );
  });

  // Shifts for Transparency Inspector
  const transparencyDriver = drivers.find(d => d.id === transparencyDriverId);
  const driverShifts = shifts.filter(s => s.driver_id === transparencyDriverId);
  const totalDispatched = driverShifts.reduce((sum, s) => sum + (s.dispatched_stops || 0), 0);
  const totalPaid = driverShifts.reduce((sum, s) => sum + (s.paid_stops || 0), 0);
  const totalExcessParcels = driverShifts.reduce((sum, s) => sum + (s.excess_parcels || 0), 0);
  const totalStopPay = driverShifts.reduce((sum, s) => sum + parseFloat(s.calculated_stop_pay || 0), 0);
  const totalParcelPay = driverShifts.reduce((sum, s) => sum + parseFloat(s.calculated_parcel_pay || 0), 0);
  const totalTopUp = driverShifts.reduce((sum, s) => sum + parseFloat(s.top_up_pay || 0), 0);
  const grossPay = totalStopPay + totalParcelPay + totalTopUp;
  const overallFailPct = totalDispatched > 0 ? (((totalDispatched - totalPaid) / totalDispatched) * 100).toFixed(2) : '0.00';
  const vatAmount = transparencyDriver?.is_vat_registered ? grossPay * 0.20 : 0;
  const finalPay = grossPay + vatAmount;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl">
            <Receipt className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Admin Payroll & Reconciliation Hub</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Automated CSV reconciliation (Dynamic Base Pay & Excess Parcels), audit trails & WhatsApp statements</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsCsvModalOpen(true)}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 transition cursor-pointer"
          >
            <UploadCloud className="w-4 h-4 text-blue-600 dark:text-blue-400" /> Ingest Portal CSV
          </button>
          <button
            onClick={handleOpenGenerateModal}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 flex items-center gap-1.5 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Generate Invoice
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 space-x-4">
        <button
          onClick={() => setActiveSubTab('invoices')}
          className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'invoices'
              ? 'border-blue-500 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <Receipt className="w-4 h-4" /> Invoices & State Machine ({invoices.length})
        </button>
        <button
          onClick={() => setActiveSubTab('reconciliation')}
          className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'reconciliation'
              ? 'border-blue-500 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" /> CSV Reconciliation & Flags ({shifts.length})
        </button>
        <button
          onClick={() => setActiveSubTab('transparency')}
          className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'transparency'
              ? 'border-blue-500 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <Calculator className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> Calculation Transparency Inspector
        </button>
      </div>

      {/* SUB-TAB 1: INVOICES & STATE MACHINE */}
      {activeSubTab === 'invoices' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm dark:shadow-lg flex flex-wrap gap-4 items-center justify-between">
            <div className="flex items-center gap-3 flex-1 min-w-[280px]">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-500 dark:text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search invoice number or driver..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-800 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                <Filter className="w-3.5 h-3.5" />
                <span>Month:</span>
              </div>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500"
              >
                <option value="">All Months</option>
                <option value="August 2026">August 2026</option>
                <option value="July 2026">July 2026</option>
                <option value="June 2026">June 2026</option>
                <option value="April 2026">April 2026</option>
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500"
              >
                <option value="">All States</option>
                <option value="Draft">Draft</option>
                <option value="Checked">Checked</option>
                <option value="Approved">Approved</option>
                <option value="Locked">Locked (Protected)</option>
              </select>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
            {loading ? (
              <div className="p-12 text-center text-slate-500 dark:text-slate-400">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-2"></div>
                <span>Loading invoices...</span>
              </div>
            ) : filteredInvoices.length === 0 ? (
              <div className="p-12 text-center text-slate-500 dark:text-slate-400">
                <Receipt className="w-10 h-10 mx-auto mb-2 text-slate-600" />
                <p className="font-semibold text-slate-900 dark:text-white">No Invoices Found</p>
                <p className="text-xs text-slate-500 mt-1">Generate a new monthly invoice using the button above.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="p-3.5 w-10 text-center">
                        <input
                          type="checkbox"
                          checked={selectedInvoiceIds.length > 0 && selectedInvoiceIds.length === filteredInvoices.length}
                          onChange={handleToggleSelectAllInvoices}
                          className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-0 cursor-pointer"
                          title="Select / Deselect All Filtered Invoices"
                        />
                      </th>
                      <th className="p-3.5">Invoice #</th>
                      <th className="p-3.5">Contractor Driver</th>
                      <th className="p-3.5">Billing Period</th>
                      <th className="p-3.5 text-right">Days / Paid Stops</th>
                      <th className="p-3.5 text-right">Gross Earnings</th>
                      <th className="p-3.5 text-right">Deductions</th>
                      <th className="p-3.5 text-right">VAT (20%)</th>
                      <th className="p-3.5 text-right">Net Payable</th>
                      <th className="p-3.5 text-center">State Machine</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                    {filteredInvoices.map((inv) => {
                      const st = inv.status || inv.payment_status || 'Draft';
                      const isLocked = st === 'Locked';
                      const isApproved = st === 'Approved';
                      const isChecked = st === 'Checked';

                      return (
                        <tr key={inv.id} className={`hover:bg-slate-50/80 dark:hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition ${selectedInvoiceIds.includes(inv.id) ? 'bg-blue-50/50 dark:bg-blue-950/20' : ''}`}>

                          <td className="p-3.5 text-center">
                            <input
                              type="checkbox"
                              checked={selectedInvoiceIds.includes(inv.id)}
                              onChange={() => handleToggleSelectInvoice(inv.id)}
                              className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-0 cursor-pointer"
                            />
                          </td>
                          <td className="p-3.5 font-bold text-blue-600 dark:text-blue-400 font-mono">{inv.invoice_number}</td>
                          <td className="p-3.5">
                            <span className="font-semibold text-slate-900 dark:text-white block">{inv.driver_name}</span>
                            <div className="flex items-center gap-1.5 text-[10px] text-slate-500 dark:text-slate-400">
                              <span>{inv.driver_code || 'General'}</span>
                              {inv.is_vat_registered && (
                                <span className="px-1.5 py-0.2 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 font-bold">
                                  VAT (20%)
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium">{inv.billing_month}</td>
                          <td className="p-3.5 text-right text-slate-700 dark:text-slate-300">
                            <strong>{inv.days_worked}</strong> days / <strong>{formatNumber(inv.total_paid_stops)}</strong> stops
                          </td>
                          <td className="p-3.5 text-right font-medium text-slate-700 dark:text-slate-300">{formatCurrency(inv.gross_earnings)}</td>
                          <td className="p-3.5 text-right font-medium text-rose-600 dark:text-rose-400">
                            {parseFloat(inv.total_deductions) > 0 ? `- ${formatCurrency(inv.total_deductions)}` : '£0.00'}
                          </td>
                          <td className="p-3.5 text-right text-blue-600 dark:text-blue-400">
                            {parseFloat(inv.vat_applied) > 0 ? formatCurrency(inv.vat_applied) : '-'}
                          </td>
                          <td className="p-3.5 text-right font-bold text-emerald-600 dark:text-emerald-400 text-sm">{formatCurrency(inv.net_payable)}</td>
                          <td className="p-3.5 text-center">
                            <div className="inline-flex items-center gap-1">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 ${
                                isLocked ? 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/30' :
                                isApproved ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30' :
                                isChecked ? 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-500/30' :
                                'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                              }`}>
                                {isLocked && <Lock className="w-3 h-3" />}
                                {st}
                              </span>
                            </div>
                          </td>
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <select
                                value={st}
                                onChange={(e) => handleStatusTransition(inv.id, e.target.value)}
                                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-[11px] rounded px-2 py-1 focus:outline-none focus:border-blue-500"
                              >
                                <option value="Draft">Draft</option>
                                <option value="Checked">Checked</option>
                                <option value="Approved">Approved</option>
                                <option value="Locked">Locked </option>
                              </select>

                              <button
                                onClick={() => handleViewDetails(inv.id)}
                                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                                title="View Breakdown"
                              >
                                <Eye className="w-4 h-4" />
                              </button>

                              <button
                                onClick={() => handleDownloadPdf(inv.id, inv.invoice_number)} disabled={downloadingId === inv.id}
                                className="p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 transition flex items-center gap-1 text-[11px] font-semibold px-2 cursor-pointer"
                                title="Download PDF"
                              >
                                <Download className="w-3.5 h-3.5" /> PDF
                              </button>

                              <button
                                onClick={() => handleSendWhatsApp(inv.id)}
                                className="p-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/40 text-emerald-300 border border-emerald-500/40 transition flex items-center gap-1 text-[11px] font-semibold px-2 cursor-pointer"
                                title="Send via WhatsApp"
                              >
                                <Send className="w-3.5 h-3.5" /> WA
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: CLIENT CSV RECONCILIATION & ROUTE LEDGER */}
      {activeSubTab === 'reconciliation' && (() => {
        // Filter shifts by selectedReconDriver if chosen
        const reconShifts = selectedReconDriver
          ? shifts.filter(s => s.driver_id === selectedReconDriver || s.driver_name === selectedReconDriver)
          : shifts;

        const daysWorked = reconShifts.length;
        const totalStopsDispatched = reconShifts.reduce((acc, s) => acc + (parseInt(s.dispatched_stops || 0, 10)), 0);
        const totalPaidStopAmount = reconShifts.reduce((acc, s) => acc + (parseFloat(s.calculated_stop_pay || 0)), 0);
        const totalTopUpAmount = reconShifts.reduce((acc, s) => {
          const isCancelled = Boolean(s.is_top_up_cancelled || s.top_up_cancelled);
          return acc + (isCancelled ? 0 : parseFloat(s.top_up_pay || 0));
        }, 0);
        const missingStopDataCount = reconShifts.filter(s => parseInt(s.paid_stops || 0, 10) === 0).length;
        const failCount = reconShifts.filter(s => parseFloat(s.fail_percentage || 0) > 0).length;
        const topUpCount = reconShifts.filter(s => parseFloat(s.top_up_pay || 0) > 0).length;

        const displayedReconShifts = reconShifts.filter(s => {
          if (reconFilterType === 'FAILS') return parseFloat(s.fail_percentage || 0) > 0;
          if (reconFilterType === 'TOPUP') return parseFloat(s.top_up_pay || 0) > 0;
          if (reconFilterType === 'MISSING') return parseInt(s.paid_stops || 0, 10) === 0;
          return true;
        });

        return (
          <div className="space-y-4">
            {/* Top Summary Banner & Filter matching Client Sheet */}
            <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-2xl shadow-sm dark:shadow-xl">
              
              {/* Search / Filter Driver Box */}
              <div className="flex-1 max-w-xs">
                <label className="block text-[11px] font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1.5">
                  Search For:
                </label>
                <select
                  value={selectedReconDriver}
                  onChange={(e) => setSelectedReconDriver(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 shadow-sm"
                >
                  <option value="">All Drivers ({drivers.length} Registered)</option>
                  {drivers.map(d => (
                    <option key={d.id} value={d.id}>{d.full_name} ({d.driver_code || 'No Code'})</option>
                  ))}
                </select>
              </div>

              {/* Exact KPI Metric Boxes from Client Spreadsheet */}
              <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                <div className="bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 px-3.5 py-2 rounded-xl text-center min-w-[95px] shadow-sm">
                  <span className="block text-[10px] font-black uppercase text-slate-500 dark:text-slate-400">Days Worked</span>
                  <span className="text-lg font-black text-slate-900 dark:text-white font-mono">{daysWorked}</span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 px-3.5 py-2 rounded-xl text-center min-w-[125px] shadow-sm">
                  <span className="block text-[10px] font-black uppercase text-slate-500 dark:text-slate-400">Total Stops Dispatched</span>
                  <span className="text-lg font-black text-slate-900 dark:text-white font-mono">{totalStopsDispatched}</span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 px-3.5 py-2 rounded-xl text-center min-w-[110px] shadow-sm">
                  <span className="block text-[10px] font-black uppercase text-slate-500 dark:text-slate-400">Paid Stops</span>
                  <span className="text-lg font-black text-emerald-600 dark:text-emerald-400 font-mono">£{totalPaidStopAmount.toFixed(2)}</span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 px-3.5 py-2 rounded-xl text-center min-w-[100px] shadow-sm" title="Minimum £100 day rate guarantee subsidy for shifts with < 100 paid stops">
                  <span className="block text-[10px] font-black uppercase text-slate-500 dark:text-slate-400">Top-up (£)</span>
                  <span className="text-lg font-black text-sky-600 dark:text-sky-400 font-mono">£{totalTopUpAmount.toFixed(2)}</span>
                </div>

                <div className="bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 px-3.5 py-2 rounded-xl text-center min-w-[120px] shadow-sm">
                  <span className="block text-[10px] font-black uppercase text-slate-500 dark:text-slate-400">Missing Stop Data</span>
                  <span className={"text-lg font-black font-mono " + (missingStopDataCount > 0 ? "text-rose-600 dark:text-rose-400" : "text-slate-900 dark:text-white")}>
                    {missingStopDataCount}
                  </span>
                </div>

                <button
                  onClick={() => setIsCsvModalOpen(true)}
                  className="px-3.5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-1.5 transition cursor-pointer self-center"
                >
                  <UploadCloud className="w-4 h-4" /> Ingest Portal CSV
                </button>
              </div>
            </div>

            {/* Quick Slicer Filter Bar for Failed Stops & Top-Up */}
            <div className="flex flex-wrap items-center gap-2 p-2 bg-slate-100 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold">
              <span className="text-slate-500 text-[11px] px-1 font-medium">Quick Filter:</span>
              <button
                type="button"
                onClick={() => setReconFilterType('ALL')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                  reconFilterType === 'ALL'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                All Routes ({reconShifts.length})
              </button>
              <button
                type="button"
                onClick={() => setReconFilterType('FAILS')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                  reconFilterType === 'FAILS'
                    ? 'bg-amber-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Routes where courier completed fewer stops than dispatched"
              >
                <span>⚠️ Failed Stops (&gt; 0%)</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800/40 text-amber-300 font-mono">{failCount}</span>
              </button>
              <button
                type="button"
                onClick={() => setReconFilterType('TOPUP')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                  reconFilterType === 'TOPUP'
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Routes with < 100 paid stops qualifying for £100 minimum day guarantee"
              >
                <span>💰 Top-Up Guarantee (&lt; 100 Stops)</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800/40 text-sky-300 font-mono">{topUpCount}</span>
              </button>
              <button
                type="button"
                onClick={() => setReconFilterType('MISSING')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                  reconFilterType === 'MISSING'
                    ? 'bg-rose-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>🚨 Missing Portal Data</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800/40 text-rose-300 font-mono">{missingStopDataCount}</span>
              </button>
            </div>

            {/* Reconciliation Table with EXACT Client Headers */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-100 dark:bg-slate-950 text-slate-800 dark:text-slate-300 font-black text-[11px] uppercase tracking-wider border-b border-slate-300 dark:border-slate-800">
                    <tr>
                      <th className="p-3 border-r border-slate-200 dark:border-slate-800">Date</th>
                      <th className="p-3 border-r border-slate-200 dark:border-slate-800">Driver Name</th>
                      <th className="p-3 border-r border-slate-200 dark:border-slate-800">Depot</th>
                      <th className="p-3 border-r border-slate-200 dark:border-slate-800">Reg</th>
                      <th className="p-3 border-r border-slate-200 dark:border-slate-800">FD</th>
                      <th className="p-3 border-r border-slate-200 dark:border-slate-800">Route</th>
                      <th className="p-3 text-right border-r border-slate-200 dark:border-slate-800">Stops</th>
                      <th className="p-3 text-right border-r border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/80">Paid Stops</th>
                      <th className="p-3 text-center border-r border-slate-200 dark:border-slate-800" title="(Dispatched - Paid) / Dispatched">Fail (%)</th>
                      <th className="p-3 text-right border-r border-slate-200 dark:border-slate-800" title="£100 minimum day rate subsidy if paid stops < 100">Top-up (£)</th>
                      <th className="p-3 text-center border-r border-slate-200 dark:border-slate-800 bg-rose-500/10 text-rose-600 dark:text-rose-400" title="Manager checkbox to cancel £100 top-up subsidy">Top-Up Cancellation</th>
                      <th className="p-3 text-center">Status / Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900">
                    {displayedReconShifts.length === 0 ? (
                      <tr>
                        <td colSpan={12} className="p-8 text-center text-slate-500 space-y-1">
                          <p>No routes match the selected filter.</p>
                          {reconFilterType !== 'ALL' && (
                            <button
                              onClick={() => setReconFilterType('ALL')}
                              className="text-xs text-blue-500 font-bold hover:underline"
                            >
                              Show all routes
                            </button>
                          )}
                        </td>
                      </tr>
                    ) : (
                      displayedReconShifts.map((s) => {
                        const failPct = parseFloat(s.fail_percentage || 0);
                        const isUnpaid = parseInt(s.paid_stops || 0, 10) === 0;
                        const isHighFail = failPct > 10.0;
                        const isTopUpCancelled = Boolean(s.is_top_up_cancelled || s.top_up_cancelled);
                        const topUpAmount = parseFloat(s.top_up_pay || 0);
                        const isLocked = s.invoice_status === 'Locked';

                        let rowBg = "hover:bg-slate-50 dark:hover:bg-slate-800/50 transition font-medium ";
                        if (isUnpaid) rowBg += "bg-rose-50/50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-300";
                        else if (isHighFail) rowBg += "bg-amber-50/40 dark:bg-amber-950/20";

                        return (
                          <tr key={s.id} className={rowBg}>
                            {/* 1. Date (e.g. Wednesday, 26 Aug) */}
                            <td className="p-3 whitespace-nowrap font-mono text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-800">
                              {formatDate(s.shift_date)}
                            </td>

                            {/* 2. Driver Name */}
                            <td className="p-3 font-bold text-slate-900 dark:text-white border-r border-slate-200 dark:border-slate-800">
                              {s.driver_name}
                            </td>

                            {/* 3. Depot */}
                            <td className="p-3 font-semibold text-slate-700 dark:text-slate-300 border-r border-slate-200 dark:border-slate-800">
                              {s.depot_name || 'Peterborough'}
                            </td>

                            {/* 4. Reg */}
                            <td className="p-3 font-mono text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-800">
                              {s.assigned_vehicle_reg || s.vehicle_reg || 'DS74 COA'}
                            </td>

                            {/* 5. FD */}
                            <td className="p-3 font-mono text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-800">
                              {s.assigned_fd_number || 'FD74064'}
                            </td>

                            {/* 6. Route */}
                            <td className="p-3 font-bold font-mono text-blue-600 dark:text-blue-400 border-r border-slate-200 dark:border-slate-800">
                              {s.route_code || '114'}
                            </td>

                            {/* 7. Stops (Dispatched) */}
                            <td className="p-3 text-right font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-800">
                              {s.dispatched_stops}
                            </td>

                            {/* 8. Paid Stops (£) */}
                            <td className="p-3 text-right font-black text-slate-900 dark:text-white border-r border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40">
                              {isUnpaid ? (
                                <span className="text-rose-600 dark:text-rose-400 font-bold">£0.00</span>
                              ) : (
                                "£" + parseFloat(s.calculated_stop_pay || 0).toFixed(2)
                              )}
                            </td>

                            {/* 9. Fail (%) (Blank if 0 paid stops or missing, Green if 0%, Red if > 10%) */}
                            <td className="p-3 text-center border-r border-slate-200 dark:border-slate-800">
                              {isUnpaid || !s.dispatched_stops || s.fail_percentage === null || s.fail_percentage === undefined ? (
                                <span className="text-slate-400 text-xs">-</span>
                              ) : (
                                <span className={"px-2 py-0.5 rounded text-[11px] font-black " + (
                                  failPct === 0 ? "text-emerald-700 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-500/10" :
                                  isHighFail ? "text-rose-700 dark:text-rose-300 bg-rose-100 dark:bg-rose-500/30 border border-rose-400 dark:border-rose-500 font-black" :
                                  "text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800/60"
                                )}>
                                  {failPct}%
                                </span>
                              )}
                            </td>

                            {/* 10. Top-up (£) (Blank if Paid Stops is 0 or >= 100, Overridden to £0.00 if Cancelled) */}
                            <td className="p-3 text-right font-bold text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-800">
                              {isUnpaid ? (
                                <span className="text-slate-400 text-xs">-</span>
                              ) : isTopUpCancelled ? (
                                <span className="text-rose-500 line-through text-[11px] font-mono" title="Top-up overridden to £0.00 by portal cancellation flag">£0.00</span>
                              ) : topUpAmount > 0 ? (
                                <span className="text-sky-600 dark:text-sky-400 font-black font-mono">£{topUpAmount.toFixed(2)}</span>
                              ) : (
                                <span className="text-slate-400 text-xs">-</span>
                              )}
                            </td>

                            {/* 11. Top-Up Cancellation (Shows "Cancelled" when actively denied by Portal Data, or Active toggle) */}
                            <td className="p-3 text-center border-r border-slate-200 dark:border-slate-800">
                              {isUnpaid ? (
                                <span className="text-slate-400 text-xs">-</span>
                              ) : isTopUpCancelled ? (
                                <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30">
                                  Cancelled
                                </span>
                              ) : isLocked ? (
                                <span className="text-[10px] text-purple-600 dark:text-purple-400 font-bold flex items-center justify-center gap-1">
                                  <Lock className="w-3 h-3" /> Locked
                                </span>
                              ) : (parseInt(s.paid_stops || 0, 10) < 100 && parseInt(s.paid_stops || 0, 10) > 0) ? (
                                <label className="inline-flex items-center gap-1.5 cursor-pointer select-none" title="Click to override/cancel £100 top-up">
                                  <input
                                    type="checkbox"
                                    checked={isTopUpCancelled}
                                    onChange={() => handlePromptToggleTopUp(s)}
                                    className="w-4 h-4 rounded border-slate-300 dark:border-slate-700 text-rose-600 focus:ring-0 cursor-pointer"
                                  />
                                  <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                                    Active
                                  </span>
                                </label>
                              ) : (
                                <span className="text-slate-400 text-xs">-</span>
                              )}
                            </td>

                            {/* 12. Actions / Portal Link */}
                            <td className="p-3 text-center">
                              {isUnpaid ? (
                                <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-2 py-0.5 rounded border border-rose-200 dark:border-rose-800">
                                  Portal Data Missing
                                </span>
                              ) : (
                                <button
                                  onClick={() => handleOpenPortalShiftModal(s)}
                                  className="text-[11px] text-blue-600 dark:text-blue-400 font-bold hover:underline cursor-pointer flex items-center justify-center gap-1 mx-auto"
                                >
                                  🔗 View Route Data
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
      })()}

      {/* SUB-TAB 3: CALCULATION TRANSPARENCY INSPECTOR */}
      {activeSubTab === 'transparency' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Calculator className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                Live Calculation Transparency Engine
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Exact step-by-step mathematical trace (Base Stop Pay + Excess Parcel Bonus + Top-Up Guarantee Subsidy).
              </p>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-500 dark:text-slate-400">Contractor:</label>
              <select
                value={transparencyDriverId}
                onChange={(e) => setTransparencyDriverId(e.target.value)}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                {drivers.map(d => (
                  <option key={d.id} value={d.id}>
                    {d.full_name} ({d.driver_code || 'General'}) {d.is_vat_registered ? '- VAT (20%)' : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-6 rounded-2xl shadow-sm dark:shadow-xl space-y-6">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Audit Breakdown: {transparencyDriver?.full_name} ({selectedMonth})
            </h4>

            {/* Display Flow: Dispatched Stops -> Paid Stops -> Base Stop Pay -> Excess Parcels (£0.05 ea) -> Top-Up Subsidy -> Deductions/Credits -> VAT (20%) -> Final Net Payout */}
            <div className="grid grid-cols-1 md:grid-cols-6 gap-3">
              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">1. Stops Reconciled</span>
                <p className="text-lg font-black text-slate-900 dark:text-white">{formatNumber(totalPaid)} / {formatNumber(totalDispatched)}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Dispatched: {totalDispatched} | Paid: {totalPaid}</p>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">2. Fail % Tolerance</span>
                <p className={`text-lg font-black ${parseFloat(overallFailPct) > 10 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                  {overallFailPct}%
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Tolerance target &lt; 10%</p>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">3. Base Stop Pay</span>
                <p className="text-lg font-black text-slate-700 dark:text-slate-300">£{totalStopPay.toFixed(2)}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">From Portal Stop column / rate</p>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">4. Excess Parcels (£0.05)</span>
                <p className="text-lg font-black text-sky-600 dark:text-sky-400">£{totalParcelPay.toFixed(2)}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">{totalExcessParcels} excess parcels</p>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">5. Top-Up Subsidy</span>
                <p className="text-lg font-black text-indigo-600 dark:text-indigo-400">£{totalTopUp.toFixed(2)}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">100 stop minimum guarantee</p>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-emerald-500/30 rounded-xl space-y-1">
                <span className="text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-400 block">6. Final Net Payout</span>
                <p className="text-lg font-black text-emerald-600 dark:text-emerald-400">£{finalPay.toFixed(2)}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Gross £{grossPay.toFixed(2)} {transparencyDriver?.is_vat_registered ? '+ 20% VAT' : ''}</p>
              </div>
            </div>

            {/* Formula Code Box */}
            <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm dark:shadow-none/80 font-mono text-xs text-slate-700 dark:text-slate-300 space-y-1">
              <span className="text-slate-500 font-bold block">// BANDLA LOGISTICS PAYROLL FORMULA</span>
              <p><span className="text-blue-600 dark:text-blue-400">Gross Pay</span> = Base Stop Pay (from Portal Stop column) + (Excess Parcels Ã— £0.05) + (Top-Up Guarantee Subsidy)</p>
              <p><span className="text-rose-600 dark:text-rose-400">Net Subtotal</span> = Gross Pay - (Vehicle Rental + Insurance + Fines + Fuel Deductions) + (Manual Credits)</p>
              <p><span className="text-emerald-600 dark:text-emerald-400">Total Net Payable</span> = Net Subtotal + (Net Subtotal Ã— 20% VAT [if registered])</p>
            </div>
          </div>
        </div>
      )}

      {/* CSV Ingestion Modal */}
      <Modal
        isOpen={isCsvModalOpen}
        onClose={() => setIsCsvModalOpen(false)}
        title="Upload Raw Delivery Portal CSV"
        maxWidth="max-w-lg"
      >
        <form onSubmit={handleCsvUpload} className="space-y-4">
          <div className="p-6 border-2 border-dashed border-slate-700 hover:border-blue-500 rounded-2xl bg-slate-50 dark:bg-slate-950/60 text-center transition">
            <UploadCloud className="w-10 h-10 mx-auto text-blue-600 dark:text-blue-400 mb-2" />
            <p className="text-xs font-semibold text-slate-900 dark:text-white">Select Portal Data CSV File</p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Accepts raw dispatches, delivered stops & excess parcels export from regional portal.</p>
            <input
              type="file"
              accept=".csv"
              onChange={(e) => setCsvFile(e.target.files[0])}
              className="mt-4 block w-full text-xs text-slate-500 dark:text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-500 file:cursor-pointer"
            />
          </div>

          {csvResult && (
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs space-y-1">
              <p className="font-bold text-emerald-600 dark:text-emerald-400">CSV Successfully Ingested!</p>
              <div className="grid grid-cols-2 gap-2 text-slate-700 dark:text-slate-300 mt-2">
                <div>Total Rows: <strong className="text-slate-900 dark:text-white">{csvResult.totalRows}</strong></div>
                <div>Matched Shifts: <strong className="text-slate-900 dark:text-white">{csvResult.matchedRows}</strong></div>
                <div>Updated Shifts: <strong className="text-emerald-600 dark:text-emerald-400">{csvResult.updatedShifts}</strong></div>
                <div>Created Shifts: <strong className="text-blue-600 dark:text-blue-400">{csvResult.createdShifts}</strong></div>
              </div>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsCsvModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition"
            >
              Close
            </button>
            <button
              type="submit"
              disabled={csvUploading || !csvFile}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 transition flex items-center gap-1.5 disabled:opacity-50"
            >
              {csvUploading ? 'Reconciling CSV...' : 'Process & Reconcile'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Portal Route Ingestion & Reconciliation Modal */}
      <Modal
        isOpen={isPortalDataModalOpen}
        onClose={() => setIsPortalDataModalOpen(false)}
        title="Portal Route Reconciliation & Audit Inspector"
        maxWidth="max-w-2xl"
      >
        {selectedShiftForPortalData && (
          <div className="space-y-5 text-xs text-slate-700 dark:text-slate-300">
            {/* Top Header Card */}
            <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <p className="text-slate-500 font-medium text-[10px]">Driver</p>
                <p className="font-bold text-slate-900 dark:text-white text-sm">{selectedShiftForPortalData.driver_name}</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">{selectedShiftForPortalData.driver_code}</p>
              </div>
              <div>
                <p className="text-slate-500 font-medium text-[10px]">Route Date</p>
                <p className="font-bold text-slate-900 dark:text-white text-sm">{formatDate(selectedShiftForPortalData.shift_date)}</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">Route: <strong className="text-sky-600 dark:text-sky-400">{selectedShiftForPortalData.route_code || 'N/A'}</strong></p>
              </div>
              <div>
                <p className="text-slate-500 font-medium text-[10px]">Vehicle</p>
                <p className="font-bold text-slate-900 dark:text-white text-sm">{selectedShiftForPortalData.vehicle_reg || selectedShiftForPortalData.assigned_vehicle_reg || 'N/A'}</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">{selectedShiftForPortalData.vehicle_model || 'Courier Van'}</p>
              </div>
              <div>
                <p className="text-slate-500 font-medium text-[10px]">Operating Depot</p>
                <p className="font-bold text-slate-900 dark:text-white text-sm">{selectedShiftForPortalData.depot_name || selectedShiftForPortalData.depot_code || 'N/A'}</p>
                <span className="inline-block mt-0.5 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300">
                  Reconciled
                </span>
              </div>
            </div>

            {/* 4 Key Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
                <span className="text-[10px] text-slate-500 font-semibold uppercase">Dispatched Stops</span>
                <p className="text-lg font-black text-slate-900 dark:text-white mt-1">{selectedShiftForPortalData.dispatched_stops}</p>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">Portal target count</span>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
                <span className="text-[10px] text-slate-500 font-semibold uppercase">Paid Stops</span>
                <p className="text-lg font-black text-emerald-600 dark:text-emerald-400 mt-1">{selectedShiftForPortalData.paid_stops}</p>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">Base rate £{parseFloat(selectedShiftForPortalData.applied_base_rate || 1).toFixed(2)}/stop</span>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
                <span className="text-[10px] text-slate-500 font-semibold uppercase">Total Parcels</span>
                <p className="text-lg font-black text-blue-600 dark:text-blue-400 mt-1">{selectedShiftForPortalData.total_parcels || selectedShiftForPortalData.paid_stops}</p>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">+{selectedShiftForPortalData.excess_parcels || 0} excess parcels</span>
              </div>

              <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
                <span className="text-[10px] text-slate-500 font-semibold uppercase">Fail Rate</span>
                <p className={`text-lg font-black mt-1 ${parseFloat(selectedShiftForPortalData.fail_percentage) >= 10 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-white'}`}>
                  {parseFloat(selectedShiftForPortalData.fail_percentage || 0).toFixed(1)}%
                </p>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">
                  {parseFloat(selectedShiftForPortalData.fail_percentage) >= 10 ? '⚠️ High Fail Warning' : 'Normal compliance'}
                </span>
              </div>
            </div>

            {/* Calculation Breakdown Matrix */}
            <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-2">Shift Payroll Math Breakdown</h4>
              <div className="flex justify-between py-1 border-b border-slate-200 dark:border-slate-800">
                <span>Base Stop Pay ({selectedShiftForPortalData.paid_stops} stops × £{parseFloat(selectedShiftForPortalData.applied_base_rate || 1).toFixed(2)})</span>
                <strong className="text-slate-900 dark:text-white">£{parseFloat(selectedShiftForPortalData.calculated_stop_pay || 0).toFixed(2)}</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200 dark:border-slate-800">
                <span>Excess Parcel Pay ({selectedShiftForPortalData.excess_parcels || 0} parcels × £{parseFloat(selectedShiftForPortalData.applied_excess_rate || 0.05).toFixed(2)})</span>
                <strong className="text-slate-900 dark:text-white">£{parseFloat(selectedShiftForPortalData.calculated_parcel_pay || 0).toFixed(2)}</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200 dark:border-slate-800">
                <span>£100 Minimum Guarantee Top-Up</span>
                <strong className={parseFloat(selectedShiftForPortalData.top_up_pay) > 0 ? "text-sky-600 dark:text-sky-400" : "text-slate-500 dark:text-slate-400"}>
                  £{parseFloat(selectedShiftForPortalData.top_up_pay || 0).toFixed(2)}
                  {selectedShiftForPortalData.is_top_up_cancelled ? ' (Cancelled by Admin)' : ''}
                </strong>
              </div>
              <div className="flex justify-between pt-2 text-sm font-black border-t border-slate-300 dark:border-slate-700">
                <span className="text-slate-900 dark:text-white">Gross Route Total</span>
                <span className="text-emerald-600 dark:text-emerald-400 text-base">£{parseFloat(selectedShiftForPortalData.gross_shift_total || 0).toFixed(2)}</span>
              </div>
            </div>

            {/* Ingestion Notes / Audit */}
            <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
              <span className="text-[10px] text-slate-500 font-semibold uppercase block mb-1">Audit & Ingestion Notes</span>
              <p className="text-xs text-slate-800 dark:text-slate-200 italic">
                {selectedShiftForPortalData.notes || 'Reconciled automatically from portal dispatch records.'}
              </p>
            </div>

            {/* Invoice Attachment & Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-800">
              <div>
                {selectedShiftForPortalData.invoice_id ? (
                  <span className="inline-flex items-center gap-1.5 text-xs text-purple-600 dark:text-purple-400 font-semibold bg-purple-50 dark:bg-purple-950/40 px-3 py-1 rounded-lg border border-purple-200 dark:border-purple-800">
                    Linked to Invoice #{selectedShiftForPortalData.invoice_number || 'INV-MONTHLY'}
                  </span>
                ) : (
                  <span className="text-xs text-amber-600 dark:text-amber-400 font-medium bg-amber-50 dark:bg-amber-950/40 px-3 py-1 rounded-lg border border-amber-200 dark:border-amber-800">
                    Pending Monthly Statement Generation
                  </span>
                )}
              </div>

              <div className="flex gap-2">
                {selectedShiftForPortalData.invoice_id && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsPortalDataModalOpen(false);
                      handleViewDetails(selectedShiftForPortalData.invoice_id);
                    }}
                    className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-lg shadow-sm transition"
                  >
                    Open Monthly Statement
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setIsPortalDataModalOpen(false)}
                  className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Top-Up Override Reason Modal */}
      <Modal
        isOpen={isOverrideModalOpen}
        onClose={() => setIsOverrideModalOpen(false)}
        title="Admin Top-Up Guarantee Override"
        maxWidth="max-w-md"
      >
        <div className="space-y-4">
          <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-700 dark:text-slate-300 space-y-1">
            <p><span className="text-slate-500 font-semibold">Driver:</span> <strong className="text-slate-900 dark:text-white">{selectedShiftForOverride?.driver_name}</strong></p>
            <p><span className="text-slate-500 font-semibold">Shift Date:</span> {formatDate(selectedShiftForOverride?.shift_date)}</p>
            <p><span className="text-slate-500 font-semibold">Current Top-Up Status:</span> {selectedShiftForOverride?.is_top_up_cancelled ? 'Cancelled' : 'Active Subsidy'}</p>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Reason for Audit Log (Required):</label>
            <textarea
              rows="3"
              value={overrideReason}
              onChange={(e) => setOverrideReason(e.target.value)}
              placeholder="e.g. Driver departed depot without completing secondary delivery cycle..."
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsOverrideModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleConfirmToggleTopUp}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 transition"
            >
              Save Override & Log Audit Trail
            </button>
          </div>
        </div>
      </Modal>

      {/* Generate Invoice Modal */}
      <Modal
        isOpen={isGenerateModalOpen}
        onClose={() => setIsGenerateModalOpen(false)}
        title="Generate Contractor Payroll Invoice"
        maxWidth="max-w-md"
      >
        <form onSubmit={handleGenerateInvoice} className="space-y-4">
          {generateModalError && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/80 rounded-xl flex items-start gap-2.5 text-xs text-rose-700 dark:text-rose-300 animate-fadeIn">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600 dark:text-rose-400" />
              <div>
                <p className="font-bold">Generation Failed</p>
                <p className="mt-0.5">{generateModalError}</p>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Select Driver</label>
            <select
              value={formData.driverId || (drivers[0]?.id || '')}
              onChange={(e) => {
                setGenerateModalError(null);
                setFormData({ ...formData, driverId: e.target.value });
              }}
              required
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            >
              {drivers.map(d => (
                <option key={d.id} value={d.id}>
                  {d.full_name} {d.driver_code ? `(${d.driver_code})` : ''} {d.is_vat_registered ? '• [VAT 20%]' : ''}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Billing Month Label</label>
            <input
              type="text"
              value={formData.billingMonth}
              onChange={(e) => setFormData({ ...formData, billingMonth: e.target.value })}
              placeholder="e.g. August 2026"
              required
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Start Date</label>
              <input
                type="date"
                value={formData.billingStartDate}
                onChange={(e) => setFormData({ ...formData, billingStartDate: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">End Date</label>
              <input
                type="date"
                value={formData.billingEndDate}
                onChange={(e) => setFormData({ ...formData, billingEndDate: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsGenerateModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={generating}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 transition flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
            >
              {generating ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Generating & Compiling...
                </>
              ) : (
                'Generate & Compile Invoice'
              )}
            </button>
          </div>
        </form>
      </Modal>

      {/* Invoice Detail Modal */}
      <Modal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        title={`Invoice Breakdown: ${selectedInvoice?.invoice_number || ''}`}
        maxWidth="max-w-4xl"
      >
        {selectedInvoice && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm dark:shadow-none text-xs">
              <div>
                <span className="text-slate-500 dark:text-slate-400 block">Contractor</span>
                <strong className="text-slate-900 dark:text-white text-sm">{selectedInvoice.driver_name}</strong>
              </div>
              <div>
                <span className="text-slate-500 dark:text-slate-400 block">Billing Period</span>
                <strong className="text-slate-900 dark:text-white text-sm">{selectedInvoice.billing_month}</strong>
              </div>
              <div>
                <span className="text-slate-500 dark:text-slate-400 block">VAT Status</span>
                <strong className="text-sky-600 dark:text-sky-400 text-sm">
                  {selectedInvoice.is_vat_registered ? 'Registered (20%)' : 'Non-VAT (0%)'}
                </strong>
              </div>
              <div>
                <span className="text-slate-500 dark:text-slate-400 block">State</span>
                <strong className="text-purple-600 dark:text-purple-400 text-sm">{selectedInvoice.status || selectedInvoice.payment_status}</strong>
              </div>
            </div>

            {/* Shift Items */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Itemized Daily Shifts ({selectedInvoice.shifts?.length || 0})
              </h4>
              <div className="max-h-48 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="p-2.5">Date</th>
                      <th className="p-2.5">Route</th>
                      <th className="p-2.5 text-right">Dispatched</th>
                      <th className="p-2.5 text-right">Paid Stops</th>
                      <th className="p-2.5 text-right">Base Stop Pay</th>
                      <th className="p-2.5 text-right">Excess Bonus (£0.05)</th>
                      <th className="p-2.5 text-right">Top-Up</th>
                      <th className="p-2.5 text-right">Day Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900">
                    {selectedInvoice.shifts?.map((s) => (
                      <tr key={s.id}>
                        <td className="p-2.5 text-slate-700 dark:text-slate-300">{formatDate(s.shift_date)}</td>
                        <td className="p-2.5 text-slate-700 dark:text-slate-300">{s.route_code || '-'}</td>
                        <td className="p-2.5 text-right text-slate-500 dark:text-slate-400">{s.dispatched_stops}</td>
                        <td className="p-2.5 text-right font-semibold text-slate-900 dark:text-white">{s.paid_stops}</td>
                        <td className="p-2.5 text-right text-slate-700 dark:text-slate-300">£{parseFloat(s.calculated_stop_pay || 0).toFixed(2)}</td>
                        <td className="p-2.5 text-right text-sky-600 dark:text-sky-400 font-medium">
                          {parseFloat(s.calculated_parcel_pay || 0) > 0 ? `£${parseFloat(s.calculated_parcel_pay).toFixed(2)}` : '-'}
                        </td>
                        <td className="p-2.5 text-right text-sky-600 dark:text-sky-400 font-medium">
                          {parseFloat(s.top_up_pay || 0) > 0 ? `£${parseFloat(s.top_up_pay).toFixed(2)}` : '-'}
                        </td>
                        <td className="p-2.5 text-right font-bold text-emerald-600 dark:text-emerald-400">£{parseFloat(s.gross_shift_total || 0).toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Deductions & Credits */}
            {selectedInvoice.charges?.length > 0 && (
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                  Deductions & Offsets ({selectedInvoice.charges.length})
                </h4>
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                      <tr>
                        <th className="p-2.5">Date</th>
                        <th className="p-2.5">Category</th>
                        <th className="p-2.5">Notes</th>
                        <th className="p-2.5 text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900">
                      {selectedInvoice.charges.map((c) => {
                        const amt = parseFloat(c.amount || 0);
                        const isCredit = amt < 0;
                        return (
                          <tr key={c.id}>
                            <td className="p-2.5 text-slate-700 dark:text-slate-300">{formatDate(c.charge_date)}</td>
                            <td className="p-2.5 font-semibold text-slate-700 dark:text-slate-300">{c.cd_type || c.charge_type}</td>
                            <td className="p-2.5 text-slate-500 dark:text-slate-400">{c.notes || '-'}</td>
                            <td className={`p-2.5 text-right font-bold ${isCredit ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                              {isCredit ? `+ £${Math.abs(amt).toFixed(2)} (Credit)` : `- £${amt.toFixed(2)}`}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Summary Totals Box */}
            <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-none space-y-2 text-sm">
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>Gross Earnings (Stop Pay + Parcel Bonus + Top-Up):</span>
                <strong className="text-slate-900 dark:text-white">£{parseFloat(selectedInvoice.gross_earnings || 0).toFixed(2)}</strong>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>Less Deductions / Credits:</span>
                <strong className="text-rose-600 dark:text-rose-400">- £{parseFloat(selectedInvoice.total_deductions || 0).toFixed(2)}</strong>
              </div>
              <div className="flex justify-between text-slate-700 dark:text-slate-300 font-semibold py-1 border-t border-slate-200 dark:border-slate-800">
                <span>Net Subtotal (Pre-VAT):</span>
                <span className="text-slate-900 dark:text-white">£{parseFloat(selectedInvoice.subtotal || 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>VAT Applied ({(parseFloat(selectedInvoice.vat_rate || 0) * 100).toFixed(0)}%):</span>
                <strong className="text-sky-600 dark:text-sky-400">+ £{parseFloat(selectedInvoice.vat_applied || 0).toFixed(2)}</strong>
              </div>
              <div className="flex justify-between text-base font-extrabold text-emerald-600 dark:text-emerald-400 pt-2 border-t border-slate-200 dark:border-slate-800">
                <span>TOTAL NET PAYABLE:</span>
                <span>£{parseFloat(selectedInvoice.net_payable || 0).toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownloadPdf(selectedInvoice.id, selectedInvoice.invoice_number)} disabled={downloadingId === selectedInvoice.id}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-emerald-600/20 flex items-center gap-2 transition cursor-pointer"
                >
                  <Download className="w-4 h-4" /> Download PDF
                </button>
                <button
                  onClick={() => handleSendWhatsApp(selectedInvoice.id)}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-semibold rounded-lg flex items-center gap-2 transition cursor-pointer"
                >
                  <Send className="w-4 h-4" /> Send via WhatsApp
                </button>
              </div>

              <button
                onClick={() => setIsDetailModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}