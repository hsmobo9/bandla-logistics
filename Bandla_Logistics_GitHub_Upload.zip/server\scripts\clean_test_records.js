const { initDb } = require('../config/db');

async function clean() {
  const { client } = await initDb();
  await client.query(`DELETE FROM daily_shifts WHERE driver_id IN (SELECT id FROM drivers WHERE driver_code = 'DR9901')`);
  await client.query(`DELETE FROM charges_and_deductions WHERE driver_id IN (SELECT id FROM drivers WHERE driver_code = 'DR9901')`);
  await client.query(`DELETE FROM payroll_invoices WHERE driver_id IN (SELECT id FROM drivers WHERE driver_code = 'DR9901')`);
  await client.query(`DELETE FROM drivers WHERE driver_code = 'DR9901'`);
  console.log('Cleaned DR9901 test records');
}

clean().then(() => process.exit(0)).catch(e => {
  console.error(e);
  process.exit(1);
});