import React, { useState, useEffect } from 'react';
import { 
  getUsers, 
  createUser, 
  updateUser, 
  toggleUserStatus, 
  deleteUser, 
  getDepots 
} from '../services/api';
import { 
  Shield, 
  UserCheck, 
  UserX, 
  Plus, 
  Edit, 
  Trash2, 
  Check, 
  X, 
  Lock, 
  Key, 
  Building2, 
  Mail, 
  UserPlus, 
  Sparkles,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import Modal from '../components/Modal';

const ALL_PRIVILEGES = [
  { key: 'manage_drivers', label: 'Driver CRM & Compliance', desc: 'Can add, edit, and deactivate drivers & licenses', icon: '👤' },
  { key: 'manage_vehicles', label: 'Fleet Inventory & Vans', desc: 'Can add, edit, and decommission delivery vans', icon: '🚐' },
  { key: 'manage_maintenance', label: 'Maintenance CRM & Garages', desc: 'Can log repairs, service records, and garage suppliers', icon: '🔧' },
  { key: 'manage_fuel', label: 'Fuel Consumption Logs', desc: 'Can log and review fuel consumption and cards', icon: '⛽' },
  { key: 'view_payroll', label: 'Payroll Statements & Invoices', desc: 'Can view monthly contractor payroll and generated invoices', icon: '💰' },
  { key: 'manage_deductions', label: 'Charges & Van Rentals', desc: 'Can add, edit, and manage deductions ledger', icon: '🏷️' },
  { key: 'manage_rate_cards', label: 'Route Rates Configuration', desc: 'Can configure base stop rates and excess parcel rates', icon: '🧭' },
  { key: 'view_dashboard', label: 'Executive Dashboard KPIs', desc: 'Can view business-wide performance analytics & totals', icon: '📊' },
  { key: 'all_depots_access', label: 'Cross-Depot Fleet Access', desc: 'Can allocate and plan shifts across all 6 depots', icon: '🌐' }
];

export default function UserManager() {
  const [users, setUsers] = useState([]);
  const [depots, setDepots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState('');

  const [form, setForm] = useState({
    username: '',
    email: '',
    fullName: '',
    password: '',
    role: 'RouteManager',
    depotId: '',
    status: 'active',
    permissions: []
  });

  const loadData = async () => {
    try {
      setLoading(true);
      const [uList, dList] = await Promise.all([
        getUsers(),
        getDepots()
      ]);
      setUsers(uList || []);
      setDepots(dList || []);
    } catch (err) {
      console.error('Error loading users:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleOpenAdd = () => {
    setEditingUser(null);
    setForm({
      username: '',
      email: '',
      fullName: '',
      password: '',
      role: 'RouteManager',
      depotId: depots[0]?.id || '',
      status: 'active',
      permissions: ['manage_vehicles', 'manage_maintenance']
    });
    setSaveSuccess('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (u) => {
    setEditingUser(u);
    setForm({
      username: u.username || '',
      email: u.email || '',
      fullName: u.full_name || '',
      password: '',
      role: u.role || 'RouteManager',
      depotId: u.depot_id || '',
      status: u.status || 'active',
      permissions: Array.isArray(u.permissions) ? u.permissions : []
    });
    setSaveSuccess('');
    setIsModalOpen(true);
  };

  const togglePermission = (key) => {
    const current = form.permissions || [];
    if (current.includes(key)) {
      setForm({ ...form, permissions: current.filter(k => k !== key) });
    } else {
      setForm({ ...form, permissions: [...current, key] });
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      if (editingUser) {
        await updateUser(editingUser.id, form);
      } else {
        await createUser(form);
      }
      setSaveSuccess(editingUser ? 'User privileges successfully updated!' : 'New user created successfully!');
      setTimeout(() => {
        setIsModalOpen(false);
        loadData();
      }, 600);
    } catch (err) {
      console.warn('Error saving user: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleToggleStatus = async (id) => {
    try {
      await toggleUserStatus(id);
      loadData();
    } catch (err) {
      console.warn('Error updating status: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteUser(id);
      loadData();
    } catch (err) {
      console.warn('Error deleting user: ' + (err.response?.data?.error || err.message));
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-6 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-blue-600/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 rounded-xl">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
              User Roles & Privilege Management
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Admin Control Center: Delegate operational and financial permissions to Route / Operations Managers dynamically
            </p>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-600/20 flex items-center gap-2 transition cursor-pointer self-start sm:self-center"
        >
          <UserPlus className="w-4 h-4" /> Provision New User
        </button>
      </div>

      {/* Users Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 dark:bg-slate-950 text-slate-800 dark:text-slate-300 font-black text-[11px] uppercase tracking-wider border-b border-slate-300 dark:border-slate-800">
              <tr>
                <th className="p-4">User Details</th>
                <th className="p-4">Assigned Role</th>
                <th className="p-4">Assigned Depot</th>
                <th className="p-4">Delegated Privileges</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4 text-right">Admin Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900">
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500">Loading user directory...</td>
                </tr>
              ) : users.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500">No users found.</td>
                </tr>
              ) : (
                users.map((u) => {
                  const isAdmin = u.role === 'Admin';
                  const userPerms = Array.isArray(u.permissions) ? u.permissions : [];
                  const isActive = u.status === 'active';

                  return (
                    <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                      {/* 1. Details */}
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
                            isAdmin 
                              ? 'bg-purple-100 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-300 dark:border-purple-800' 
                              : 'bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-300 dark:border-blue-800'
                          }`}>
                            {u.full_name?.charAt(0) || u.username?.charAt(0) || 'U'}
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 dark:text-white block text-sm">{u.full_name}</span>
                            <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">@{u.username} • {u.email}</span>
                          </div>
                        </div>
                      </td>

                      {/* 2. Role */}
                      <td className="p-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-black ${
                          isAdmin
                            ? 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20'
                            : 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20'
                        }`}>
                          <Shield className="w-3.5 h-3.5" />
                          {isAdmin ? 'Head Office Admin' : 'Depot Route / Operations Manager'}
                        </span>
                      </td>

                      {/* 3. Depot */}
                      <td className="p-4 font-semibold text-slate-700 dark:text-slate-300">
                        {isAdmin ? (
                          <span className="text-slate-500 dark:text-slate-400">🌐 All Regional Depots</span>
                        ) : (
                          <span className="flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-blue-500" />
                            {u.depot_name || 'Central Hub'}
                          </span>
                        )}
                      </td>

                      {/* 4. Privileges Badges */}
                      <td className="p-4">
                        {isAdmin ? (
                          <span className="text-[11px] font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/40 px-2.5 py-1 rounded-lg border border-purple-200 dark:border-purple-800">
                            ⚡ Universal Privileges (All Enabled)
                          </span>
                        ) : userPerms.length === 0 ? (
                          <span className="text-[11px] text-slate-500 italic">Standard Shift Dispatch & Route Matrix only</span>
                        ) : (
                          <div className="flex flex-wrap gap-1 max-w-md">
                            {userPerms.map(pkey => {
                              const pDef = ALL_PRIVILEGES.find(p => p.key === pkey);
                              return (
                                <span key={pkey} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                                  <span>{pDef?.icon || '✓'}</span>
                                  <span>{pDef?.label || pkey}</span>
                                </span>
                              );
                            })}
                          </div>
                        )}
                      </td>

                      {/* 5. Status */}
                      <td className="p-4 text-center">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          isActive
                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                            : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                        }`}>
                          {u.status}
                        </span>
                      </td>

                      {/* 6. Actions */}
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleOpenEdit(u)}
                            className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 dark:hover:bg-blue-900/50 text-blue-600 dark:text-blue-400 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer border border-blue-200 dark:border-blue-800"
                            title="Edit Role & Privileges"
                          >
                            <Edit className="w-3.5 h-3.5" /> Edit Privileges
                          </button>

                          <button
                            onClick={() => handleToggleStatus(u.id)}
                            className={`p-1.5 rounded-lg text-xs font-bold transition cursor-pointer border ${
                              isActive
                                ? 'bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800'
                                : 'bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800'
                            }`}
                            title={isActive ? 'Deactivate Account' : 'Activate Account'}
                          >
                            {isActive ? <UserX className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                          </button>

                          {!isAdmin && (
                            <button
                              onClick={() => handleDelete(u.id)}
                              className="p-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 rounded-lg text-xs font-bold transition cursor-pointer border border-rose-200 dark:border-rose-800"
                              title="Delete User"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit / Provision Privileges Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingUser ? `Edit Privileges: ${editingUser.full_name}` : 'Provision New System User'}
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleSave} className="space-y-4">
          {saveSuccess && (
            <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>{saveSuccess}</span>
            </div>
          )}

          {/* Account Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                placeholder="e.g. David Miller"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white font-medium focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Email Address</label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="dmiller@bandlalogistics.co.uk"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white font-medium focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Username</label>
              <input
                type="text"
                required
                disabled={Boolean(editingUser)}
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
                placeholder="e.g. manager_dmiller"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white font-medium focus:outline-none focus:border-blue-500 disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {editingUser ? 'Reset Password (Optional)' : 'Password'}
              </label>
              <input
                type="password"
                required={!editingUser}
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder={editingUser ? 'Leave blank to keep' : 'Minimum 6 chars'}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white font-medium focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">System Role</label>
              <select
                value={form.role}
                onChange={(e) => setForm({ ...form, role: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="RouteManager">Route / Operations Manager</option>
                <option value="Admin">Head Office Admin</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Assigned Operational Depot</label>
              <select
                value={form.depotId}
                onChange={(e) => setForm({ ...form, depotId: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="">-- All Depots (Head Office) --</option>
                {depots.map(d => (
                  <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Account Status</label>
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="active">Active (Full Access)</option>
                <option value="deactivated">Deactivated (Blocked)</option>
              </select>
            </div>
          </div>

          {/* Granular Privilege Delegation Matrix */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <Key className="w-4 h-4 text-blue-500" /> Granular Privilege Delegation Matrix
              </label>
              <span className="text-[10px] text-slate-500 dark:text-slate-400">
                {form.role === 'Admin' ? 'Universal Access Enabled for Admin' : 'Toggle capabilities for this manager'}
              </span>
            </div>

            {form.role === 'Admin' ? (
              <div className="bg-purple-50/50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900 p-3 rounded-xl text-xs text-purple-700 dark:text-purple-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 shrink-0 text-purple-500" />
                <span>Head Office Admins automatically inherit 100% full authority across all financial, operational, and system modules.</span>
              </div>
            ) : (
              <div className="space-y-3">
                {/* 1-Click Role Presets */}
                <div className="bg-slate-50 dark:bg-slate-950 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                    ⚡ 1-Click Role Presets:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, permissions: ['manage_vehicles', 'manage_maintenance', 'manage_fuel', 'view_dashboard'] })}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-800 hover:bg-amber-100 transition cursor-pointer"
                    >
                      🚐 Fleet Manager Preset (Maintenance & Fuel)
                    </button>
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, permissions: ['manage_drivers', 'manage_vehicles', 'all_depots_access'] })}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border border-blue-300 dark:border-blue-800 hover:bg-blue-100 transition cursor-pointer"
                    >
                      🏢 Depot Manager Preset (Drivers & Vans)
                    </button>
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, permissions: ['manage_drivers', 'manage_vehicles', 'manage_maintenance', 'manage_fuel', 'manage_rate_cards', 'all_depots_access', 'view_dashboard'] })}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 hover:bg-emerald-100 transition cursor-pointer"
                    >
                      🚀 Full Ops Manager
                    </button>
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, permissions: ['view_payroll', 'manage_deductions', 'manage_rate_cards', 'view_dashboard'] })}
                      className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 border border-purple-300 dark:border-purple-800 hover:bg-purple-100 transition cursor-pointer"
                    >
                      💰 Payroll & Finance
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-60 overflow-y-auto p-1">
                {ALL_PRIVILEGES.map(p => {
                  const isChecked = (form.permissions || []).includes(p.key);
                  return (
                    <label 
                      key={p.key}
                      onClick={() => togglePermission(p.key)}
                      className={`flex items-start gap-2.5 p-2.5 rounded-xl border transition cursor-pointer select-none ${
                        isChecked 
                          ? 'bg-blue-50/60 dark:bg-blue-950/30 border-blue-400 dark:border-blue-600 text-slate-900 dark:text-white shadow-sm'
                          : 'bg-slate-50/50 dark:bg-slate-950/40 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {}}
                        className="mt-0.5 w-4 h-4 rounded text-blue-600 focus:ring-0 cursor-pointer"
                      />
                      <div className="min-w-0">
                        <span className="text-xs font-bold block flex items-center gap-1">
                          <span>{p.icon}</span> {p.label}
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 block leading-tight mt-0.5">{p.desc}</span>
                      </div>
                    </label>
                  );
                })}
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-600/20 transition"
            >
              {editingUser ? 'Save Privileges & Role' : 'Provision User Account'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
