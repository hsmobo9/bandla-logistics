const { initDb } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

async function seedAllScenarios() {
  console.log('========================================================================');
  console.log('SEEDING COMPREHENSIVE TEST SCENARIOS ACROSS ALL MODULES');
  console.log('========================================================================\n');

  const { client } = await initDb();

  // 1. Fetch Depots
  const depotsRes = await client.query('SELECT id, code, name FROM depots');
  const depots = depotsRes.rows;
  const pboroDepot = depots.find(d => d.name.toLowerCase().includes('peterborough')) || depots[0];
  const leicDepot = depots.find(d => d.name.toLowerCase().includes('leicester')) || depots[0];

  // 2. Fetch or Create Drivers
  console.log('--- 1. Setting up Representative Test Drivers ---');
  
  // Driver A: Aaron Ramirez (Peterborough, Non-VAT, Matching Client Screenshot)
  let aaronId;
  const aaronCheck = await client.query(`SELECT id FROM drivers WHERE LOWER(full_name) = 'aaron ramirez'`);
  if (aaronCheck.rows.length > 0) {
    aaronId = aaronCheck.rows[0].id;
    await client.query(`
      UPDATE drivers SET 
        driver_code = 'DR74064',
        default_depot_id = $1,
        assigned_vehicle_reg = 'DS74 COA',
        assigned_fd_number = 'FD74064',
        is_vat_registered = false,
        dvla_points = 0,
        is_active = true
      WHERE id = $2
    `, [pboroDepot.id, aaronId]);
  } else {
    aaronId = uuidv4();
    await client.query(`
      INSERT INTO drivers (id, driver_code, full_name, phone, email, default_depot_id, assigned_vehicle_reg, assigned_fd_number, is_vat_registered, dvla_points, is_active)
      VALUES ($1, 'DR74064', 'Aaron Ramirez', '07966 270101', 'aaron.ramirez@contractor.bandlalogistics.co.uk', $2, 'DS74 COA', 'FD74064', false, 0, true)
    `, [aaronId, pboroDepot.id]);
  }
  console.log(`✓ Driver A (Screenshot Master): Aaron Ramirez [${aaronId}]`);

  // Driver B: Amanpreet Singh (Leicester, VAT-Registered 20%, Locked Invoice Test)
  let amanId;
  const amanCheck = await client.query(`SELECT id FROM drivers WHERE LOWER(full_name) = 'amanpreet singh'`);
  if (amanCheck.rows.length > 0) {
    amanId = amanCheck.rows[0].id;
    await client.query(`
      UPDATE drivers SET 
        driver_code = 'DR74030',
        default_depot_id = $1,
        assigned_vehicle_reg = 'AO21 OWA',
        assigned_fd_number = 'FD74030',
        is_vat_registered = true,
        vat_number = 'GB376546166',
        dvla_points = 3,
        is_active = true
      WHERE id = $2
    `, [leicDepot.id, amanId]);
  } else {
    amanId = uuidv4();
    await client.query(`
      INSERT INTO drivers (id, driver_code, full_name, phone, email, default_depot_id, assigned_vehicle_reg, assigned_fd_number, is_vat_registered, vat_number, dvla_points, is_active)
      VALUES ($1, 'DR74030', 'Amanpreet Singh', '07966 270102', 'amanpreet.singh@contractor.bandlalogistics.co.uk', $2, 'AO21 OWA', 'FD74030', true, 'GB376546166', 3, true)
    `, [amanId, leicDepot.id]);
  }
  console.log(`✓ Driver B (VAT 20% & Locked Invoice): Amanpreet Singh [${amanId}]`);

  // Driver C: Amandeep Singh (Holiday & Unavailability Planner Scenario)
  let amanHoliId;
  const holiCheck = await client.query(`SELECT id FROM drivers WHERE LOWER(full_name) LIKE '%amandeep singh%'`);
  amanHoliId = holiCheck.rows.length > 0 ? holiCheck.rows[0].id : uuidv4();
  if (holiCheck.rows.length === 0) {
    await client.query(`
      INSERT INTO drivers (id, driver_code, full_name, phone, email, default_depot_id, is_active)
      VALUES ($1, 'DR1002', 'Amandeep Singh Patiyala', '07966 270103', 'amandeep@contractor.bandlalogistics.co.uk', $2, true)
    `, [amanHoliId, pboroDepot.id]);
  }
  await client.query(`DELETE FROM driver_availability WHERE driver_id = $1`, [amanHoliId]);
  await client.query(`
    INSERT INTO driver_availability (id, driver_id, start_date, end_date, status, notes)
    VALUES 
      ($1, $2, '2026-08-25', '2026-08-31', 'Holiday', 'Annual Leave (Approved by Head Office)'),
      ($3, $2, '2026-09-10', '2026-09-14', 'Unavailable', 'Family Commitment / Unavailable')
  `, [uuidv4(), amanHoliId, uuidv4()]);
  console.log(`✓ Driver C (Holiday & Availability Test): Amandeep Singh Patiyala [${amanHoliId}]`);

  // Driver D: Andrie Ploscaru (High DVLA Penalty Points - 9 pts Warning)
  let andrieId;
  const andrieCheck = await client.query(`SELECT id FROM drivers WHERE LOWER(full_name) LIKE '%andrie%'`);
  andrieId = andrieCheck.rows.length > 0 ? andrieCheck.rows[0].id : uuidv4();
  if (andrieCheck.rows.length > 0) {
    await client.query(`UPDATE drivers SET dvla_points = 9, notes = 'SP30 Speeding Endorsement (9 Points Risk Warning)' WHERE id = $1`, [andrieId]);
  } else {
    await client.query(`
      INSERT INTO drivers (id, driver_code, full_name, phone, email, dvla_points, is_active, notes)
      VALUES ($1, 'DR1004', 'Andrie Ploscaru', '07966 270104', 'andrie@contractor.bandlalogistics.co.uk', 9, true, 'SP30 Speeding Endorsement (9 Points Risk Warning)')
    `, [andrieId]);
  }
  console.log(`✓ Driver D (9 DVLA Penalty Points): Andrie Ploscaru [${andrieId}]`);

  // Driver E: Decommissioned Driver (Soft Delete Scenario)
  let decommId;
  const decommCheck = await client.query(`SELECT id FROM drivers WHERE LOWER(full_name) = 'david retired'`);
  if (decommCheck.rows.length === 0) {
    decommId = uuidv4();
    await client.query(`
      INSERT INTO drivers (id, driver_code, full_name, phone, email, is_active, notes)
      VALUES ($1, 'DR9999', 'David Retired', '07966 270999', 'david.retired@contractor.bandlalogistics.co.uk', false, 'Decommissioned contractor - historical records preserved')
    `, [decommId]);
  }
  console.log(`✓ Driver E (Soft-Deleted Inactive): David Retired`);


  // 3. Vehicles Compliance Scenarios (Green, Amber Due Soon, Red Overdue)
  console.log('\n--- 2. Setting up Fleet Compliance Status Scenarios ---');
  
  // Van 1: Fully Compliant (Green)
  const vGreen = await client.query(`SELECT id FROM vehicles WHERE registration_number = 'AO21 OWA'`);
  if (vGreen.rows.length > 0) {
    await client.query(`
      UPDATE vehicles SET
        category = 'Standard Van',
        mot_expiry = '2027-04-15',
        tax_expiry = '2027-04-30',
        insurance_expiry = '2027-06-30',
        current_mileage = 42500,
        next_service_mileage = 50000,
        depot_location = 'Leicester Depot',
        status = 'Available',
        is_active = true
      WHERE id = $1
    `, [vGreen.rows[0].id]);
    console.log('✓ Van 1 [AO21 OWA]: Fully Compliant (Green - All dates in 2027)');
  }

  // Van 2: MOT Due Soon (Amber Alert - 12 days remaining)
  const vAmber = await client.query(`SELECT id FROM vehicles WHERE registration_number = 'BD21 WLU'`);
  if (vAmber.rows.length > 0) {
    await client.query(`
      UPDATE vehicles SET
        category = 'Standard Van',
        mot_expiry = '2026-09-10',
        tax_expiry = '2027-02-28',
        insurance_expiry = '2027-05-31',
        current_mileage = 49200,
        next_service_mileage = 50000,
        depot_location = 'Peterborough Depot',
        status = 'Available',
        is_active = true
      WHERE id = $1
    `, [vAmber.rows[0].id]);
    console.log('✓ Van 2 [BD21 WLU]: Due Soon (Amber - MOT expires in 12 days)');
  }

  // Van 3: MOT Overdue (Red Alert - Expired 7 days ago)
  const vRed = await client.query(`SELECT id FROM vehicles WHERE registration_number = 'BJ20 NNK'`);
  if (vRed.rows.length > 0) {
    await client.query(`
      UPDATE vehicles SET
        category = 'LWB Van',
        mot_expiry = '2026-08-22',
        tax_expiry = '2026-10-31',
        insurance_expiry = '2027-01-31',
        current_mileage = 58400,
        next_service_mileage = 60000,
        depot_location = 'Raunds Depot',
        status = 'Under Maintenance',
        is_active = true,
        notes = 'GROUNDED: MOT Overdue by 7 days. Scheduled for inspection at Leicester Commercials.'
      WHERE id = $1
    `, [vRed.rows[0].id]);
    console.log('✓ Van 3 [BJ20 NNK]: Overdue Alert (Red - MOT expired 7 days ago)');
  }

  // Van 4: Mileage Service Overdue (Red Service Warning)
  const vService = await client.query(`SELECT id FROM vehicles WHERE registration_number = 'BL21 USB'`);
  if (vService.rows.length > 0) {
    await client.query(`
      UPDATE vehicles SET
        category = 'Luton Van',
        mot_expiry = '2027-03-31',
        tax_expiry = '2027-03-31',
        insurance_expiry = '2027-07-31',
        current_mileage = 63500,
        next_service_mileage = 60000,
        depot_location = 'Hinckley Depot',
        status = 'Available',
        is_active = true,
        notes = 'Service mileage exceeded by 3,500 miles'
      WHERE id = $1
    `, [vService.rows[0].id]);
    console.log('✓ Van 4 [BL21 USB]: Service Overdue (Red - Mileage 63,500 vs 60,000 target)');
  }


  // 4. Seed Shift Scenarios for Aaron Ramirez (July 2026 - Exact Client Workbook Rows)
  console.log('\n--- 3. Seeding Shift Scenarios for Aaron Ramirez (July 2026) ---');
  
  await client.query(`DELETE FROM daily_shifts WHERE driver_id = $1 AND shift_date >= '2026-07-01' AND shift_date <= '2026-07-31'`, [aaronId]);

  const aaronShifts = [
    // Wed 1 July: Standard full shift
    { date: '2026-07-01', route: '233', disp: 129, paid: 126, stopPay: 126.00, parcels: 130, fail: 2.33, topUp: 0, cancel: false },
    // Thu 2 July: Standard full shift
    { date: '2026-07-02', route: '233', disp: 118, paid: 118, stopPay: 116.00, parcels: 120, fail: 1.69, topUp: 0, cancel: false },
    // Fri 3 July: Standard full shift
    { date: '2026-07-03', route: '233', disp: 117, paid: 113, stopPay: 113.00, parcels: 115, fail: 3.42, topUp: 0, cancel: false },
    // Sat 4 July: High route shift
    { date: '2026-07-04', route: '730', disp: 135, paid: 128, stopPay: 128.00, parcels: 140, fail: 5.19, topUp: 0, cancel: false },
    // Sun 5 July: Unreconciled / Missing Portal Data (Dispatched 110, Paid 0)
    { date: '2026-07-05', route: '233', disp: 110, paid: 0, stopPay: 0.00, parcels: 0, fail: 100.0, topUp: 0, cancel: false, notes: 'Portal Data Missing' },
    // Mon 6 July: Low Stop Shift with Â£33 Top-Up & 18% Fail Alert (Screenshot Row 6)
    { date: '2026-07-06', route: '130', disp: 82, paid: 67, stopPay: 67.00, parcels: 70, fail: 18.29, topUp: 33.00, cancel: false },
    // Tue 7 July: High stop shift
    { date: '2026-07-07', route: '233', disp: 150, paid: 138, stopPay: 138.00, parcels: 160, fail: 8.00, topUp: 0, cancel: false },
    // Wed 8 July: Negative Fail (-5%) Extra Collections (Screenshot Row 8)
    { date: '2026-07-08', route: '233', disp: 127, paid: 133, stopPay: 133.00, parcels: 145, fail: -4.72, topUp: 0, cancel: false },
    // Thu 9 July: Low stop shift with Â£25 Top-Up (Screenshot Row 9)
    { date: '2026-07-09', route: '233', disp: 77, paid: 75, stopPay: 75.00, parcels: 80, fail: 2.60, topUp: 25.00, cancel: false },
    // Fri 10 July: Low stop shift with Â£5 Top-Up (Screenshot Row 10)
    { date: '2026-07-10', route: '233', disp: 100, paid: 95, stopPay: 95.00, parcels: 105, fail: 5.00, topUp: 5.00, cancel: false },
    // Sat 11 July: Low stop shift where Admin OVERRODE / CANCELLED Top-Up (Â£0 Top-Up)
    { date: '2026-07-11', route: '233', disp: 70, paid: 70, stopPay: 70.00, parcels: 70, fail: 0.00, topUp: 0.00, cancel: true, notes: 'Top-Up Cancelled by Admin: Driver finished early without authorization' },
    // Mon 13 July: Excess Parcel Bonus scenario (140 stops, 190 parcels = 50 excess * Â£0.05 = +Â£2.50)
    { date: '2026-07-13', route: '233', disp: 140, paid: 140, stopPay: 140.00, parcels: 190, excess: 50, parcelPay: 2.50, fail: 0.00, topUp: 0, cancel: false }
  ];

  for (const s of aaronShifts) {
    const excess = s.excess !== undefined ? s.excess : Math.max(0, s.parcels - s.paid);
    const parcelPay = s.parcelPay !== undefined ? s.parcelPay : Number((excess * 0.05).toFixed(2));
    const grossTotal = Number((s.stopPay + parcelPay + s.topUp).toFixed(2));
    const topUpStops = s.topUp > 0 ? (100 - s.paid) : 0;

    await client.query(`
      INSERT INTO daily_shifts (
        id, shift_date, driver_id, vehicle_id, depot_id, route_code, fd_number,
        dispatched_stops, paid_stops, total_parcels, excess_parcels,
        applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
        top_up_stops, top_up_pay, top_up_cancelled, is_top_up_cancelled,
        fail_percentage, gross_shift_total, notes, created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6, 'FD74064',
        $7, $8, $9, $10,
        1.0000, 0.0500, $11, $12,
        $13, $14, $15, $15,
        $16, $17, $18, NOW(), NOW()
      )
    `, [
      uuidv4(), s.date, aaronId, vAmber.rows[0]?.id || null, pboroDepot.id, s.route,
      s.disp, s.paid, s.parcels, excess,
      s.stopPay, parcelPay,
      topUpStops, s.topUp, s.cancel,
      s.fail, grossTotal, s.notes || null
    ]);
  }
  console.log(`✓ Seeded ${aaronShifts.length} comprehensive shifts for Aaron Ramirez (Low Stop, Â£33 Top-Up, -5% Fail, 18% Alert, Excess Bonuses, Top-Up Cancelled).`);


  // 5. Seed Charges, Deductions & Negative Decimal Credits for Aaron Ramirez
  console.log('\n--- 4. Seeding Charges, Deductions & Negative Reimbursements ---');
  await client.query(`DELETE FROM charges_and_deductions WHERE driver_id = $1`, [aaronId]);

  const chargeScenarios = [
    { date: '2026-07-05', cdType: 'Vehicle Rent', chargeType: 'Van Hire (Weekly)', amount: 185.00, notes: 'Standard Van Hire Week 1' },
    { date: '2026-07-12', cdType: 'Vehicle Rent', chargeType: 'Van Hire (Weekly)', amount: 185.00, notes: 'Standard Van Hire Week 2' },
    { date: '2026-07-15', cdType: 'Insurance', chargeType: 'Goods In Transit', amount: 35.00, notes: 'Monthly Courier Goods Cover' },
    { date: '2026-07-18', cdType: 'Fuel Repayment', chargeType: 'Fuel Card Refuel', amount: 112.50, notes: 'Allstar Card Pump Refuel' },
    { date: '2026-07-20', cdType: 'Fines / PCN', chargeType: 'Parking Charge Notice', amount: 65.00, notes: 'Council Parking PCN - City Center' },
    // Negative Decimal Credit / Reimbursement (-Â£50.00)
    { date: '2026-07-22', cdType: 'Manual Credit / Reimbursement', chargeType: 'Performance Bonus / Credit', amount: -50.00, notes: 'Weekend surge support bonus (Credit to contractor)' },
    // Negative Decimal Credit / Reimbursement (-Â£25.00)
    { date: '2026-07-25', cdType: 'Manual Credit / Reimbursement', chargeType: 'Fuel Adjustment Credit', amount: -25.00, notes: 'Overcharged fuel rebate adjustment' }
  ];

  for (const c of chargeScenarios) {
    await client.query(`
      INSERT INTO charges_and_deductions (
        id, billing_month, billing_period, charge_date, driver_id, cd_type, charge_type, amount, is_settled, notes, created_at, updated_at
      ) VALUES ($1, 'July 2026', 'July 2026', $2, $3, $4, $5, $6, false, $7, NOW(), NOW())
    `, [uuidv4(), c.date, aaronId, c.cdType, c.chargeType, c.amount, c.notes]);
  }
  console.log(`✓ Seeded ${chargeScenarios.length} deductions and manual negative credits (-Â£50.00, -Â£25.00).`);


  // 6. Seed Supplier Garages, Maintenance, Accidents & Fuel Logs
  console.log('\n--- 5. Seeding Fleet CRM, Garage Invoices, Accidents & Fuel Tracking ---');
  
  // Suppliers
  const s1Id = uuidv4();
  const s2Id = uuidv4();
  const s3Id = uuidv4();
  await client.query(`DELETE FROM suppliers`);
  await client.query(`
    INSERT INTO suppliers (id, name, contact_details, services_provided, is_active)
    VALUES 
      ($1, 'Leicester Commercials Ltd', 'T: 0116 299 1100 | E: service@leic-commercials.co.uk | Unit 4, Abbey Lane, Leicester', 'Engine Overhauls, Clutches & Major Service', true),
      ($2, 'Peterborough Auto Tyres & MOT Centre', 'T: 01733 882 400 | E: info@pboro-mot.co.uk | Fengate, Peterborough', 'Class 7 MOT, Commercial Tyres & Wheel Alignment', true),
      ($3, 'Midlands Bodyworks & Spraying', 'T: 01455 632 900 | E: claims@midlandsbody.co.uk | Dodwells Bridge, Hinckley', 'Accident Repair, Dent Removal & Insurance Estimates', true)
  `, [s1Id, s2Id, s3Id]);
  console.log('✓ Seeded 3 Specialist Fleet Garage Suppliers.');

  // Maintenance Records (Using date and issue_category)
  await client.query(`DELETE FROM maintenance_logs`);
  await client.query(`
    INSERT INTO maintenance_logs (
      id, vehicle_id, supplier_id, date, labor_cost, parts_cost, total_cost, issue_category, notes
    ) VALUES 
      ($1, $2, $3, '2026-08-10', 150.00, 185.00, 335.00, 'Scheduled Maintenance', 'Oil, all filters, spark plugs, full diagnostic report. Inv #INV-LC-8819'),
      ($4, $5, $6, '2026-08-15', 95.00, 145.00, 240.00, 'Scheduled Maintenance', 'Front vented discs and heavy duty courier ceramic pads. Inv #INV-PMOT-4421'),
      ($7, $8, $9, '2026-08-20', 80.00, 65.00, 145.00, 'Sudden Breakdown', 'Rear sliding door roller replacement after delivery wear. Inv #INV-MB-1092')
  `, [
    uuidv4(), vGreen.rows[0]?.id || vAmber.rows[0]?.id, s1Id,
    uuidv4(), vAmber.rows[0]?.id || vGreen.rows[0]?.id, s2Id,
    uuidv4(), vRed.rows[0]?.id || vGreen.rows[0]?.id, s3Id
  ]);
  console.log('✓ Seeded 3 Itemized Garage Maintenance Events with Labor/Parts Breakdown.');

  // Accidents & Insurance Claims
  await client.query(`DELETE FROM accident_logs`);
  await client.query(`
    INSERT INTO accident_logs (
      id, vehicle_id, driver_id, date, description, insurance_claim_status, estimated_damage_cost, third_party_details
    ) VALUES 
      ($1, $2, $3, '2026-08-14', 'Reversing into loading bay pillar, minor rear corner bumper dent.', 'Reported', 450.00, 'Aviva Commercial Fleet - Claim #CLM-2026-001'),
      ($4, $5, $6, '2026-08-18', 'Third party car failed to brake at roundabout on A47, rear bumper damage.', 'Under Review', 1850.00, 'Allianz Fleet Care - Claim #CLM-2026-002, Police Ref CAD-1902-PET'),
      ($7, $8, $9, '2026-07-28', 'Motorway stone chip resulting in 6 inch crack. Replaced by Autoglass.', 'Settled', 250.00, 'Autoglass Fleet Policy #CLM-2026-003')
  `, [
    uuidv4(), vAmber.rows[0]?.id || vGreen.rows[0]?.id, aaronId,
    uuidv4(), vGreen.rows[0]?.id || vAmber.rows[0]?.id, amanId,
    uuidv4(), vRed.rows[0]?.id || vGreen.rows[0]?.id, andrieId
  ]);
  console.log('✓ Seeded 3 Accident Scenarios (Reported, Under Review, Settled).');

  // Fuel Consumption Logs
  await client.query(`DELETE FROM fuel_logs`);
  await client.query(`
    INSERT INTO fuel_logs (
      id, refuel_date, vehicle_id, driver_id, station_name, liters_filled, total_cost, odometer_reading, fuel_card_ref, notes
    ) VALUES 
      ($1, '2026-08-12', $2, $3, 'Shell Leicester Central', 65.40, 98.10, 42100, 'FC-LEI-001', 'Routine delivery shift refueling'),
      ($4, '2026-08-19', $5, $6, 'BP Peterborough Distribution Hub', 70.00, 105.00, 48900, 'FC-PET-002', 'Full tank before regional dispatch route'),
      ($7, '2026-08-24', $8, $9, 'Texaco Raunds Bypass', 58.20, 87.30, 58100, 'FC-RAU-003', 'Evening return refuel'),
      ($10, '2026-08-28', $2, $3, 'Esso Hinckley Express', 62.00, 93.00, 42500, 'FC-LEI-001', 'Mid-week courier top-up')
  `, [
    uuidv4(), vGreen.rows[0]?.id || vAmber.rows[0]?.id, amanId,
    uuidv4(), vAmber.rows[0]?.id || vGreen.rows[0]?.id, aaronId,
    uuidv4(), vRed.rows[0]?.id || vGreen.rows[0]?.id, andrieId,
    uuidv4()
  ]);
  console.log('✓ Seeded 4 Fuel Consumption Transactions with Liters, Odometers & Fuel Cards.');


  // 7. Seed Audit Logs
  console.log('\n--- 6. Seeding Audit Trail Ledger ---');
  await client.query(`DELETE FROM audit_logs`);
  await client.query(`
    INSERT INTO audit_logs (id, user_id, user_name, user_email, action_type, table_affected, record_id, previous_value, new_value, reason, created_at)
    VALUES 
      ($1, NULL, 'System Administrator', 'admin@bandlalogistics.co.uk', 'TOP_UP_OVERRIDE', 'daily_shifts', $2, '{"top_up_cancelled": false, "top_up_pay": 30.00}', '{"top_up_cancelled": true, "top_up_pay": 0.00}', 'Driver departed shift early without supervisor permission', NOW() - INTERVAL '3 days'),
      ($3, NULL, 'System Administrator', 'admin@bandlalogistics.co.uk', 'MANUAL_CREDIT_ADJUSTMENT', 'charges_and_deductions', $4, '{"amount": 0}', '{"amount": -50.00, "type": "Credit"}', 'Weekend emergency route surge bonus approved', NOW() - INTERVAL '2 days'),
      ($5, NULL, 'System Administrator', 'admin@bandlalogistics.co.uk', 'INVOICE_STATUS_LOCKED', 'payroll_invoices', 'INV-AUGUST-2026-001', '{"status": "Approved"}', '{"status": "Locked"}', 'Monthly contractor payroll finalized and locked for bank transfer', NOW() - INTERVAL '1 day')
  `, [uuidv4(), aaronId, uuidv4(), aaronId, uuidv4()]);
  console.log('✓ Seeded Audit Trail logs for Top-Up Override, Manual Credit, and Invoice Locking.');

  console.log('\n========================================================================');
  console.log('ALL TEST SCENARIOS SUCCESSFULLY SEEDED! READY FOR COMPLETE VERIFICATION.');
  console.log('========================================================================\n');
}

seedAllScenarios().then(() => process.exit(0)).catch(err => {
  console.error('Error during scenario seed:', err);
  process.exit(1);
});