const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');
const env = require('../config/env');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

/**
 * POST /api/auth/login
 * Public login endpoint for Admin and Shift Managers
 */
router.post('/login', async (req, res) => {
  try {
    const { emailOrUsername, email, username, password } = req.body;
    const identifier = (emailOrUsername || email || username || '').trim();
    if (!identifier || !password) {
      return res.status(400).json({ error: 'Please provide email/username and password.' });
    }

    const db = getDb();
    const client = db.session.client;

    const userRes = await client.query(`
      SELECT u.*, d.name as depot_name
      FROM users u
      LEFT JOIN depots d ON u.depot_id = d.id
      WHERE LOWER(u.email) = LOWER($1) OR LOWER(u.username) = LOWER($1)
    `, [identifier]);

    if (userRes.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials. User not found.' });
    }

    const user = userRes.rows[0];

    if (user.status !== 'active') {
      return res.status(403).json({ error: 'Account is deactivated. Please contact administrator.' });
    }

    const isValidPassword = await bcrypt.compare(password, user.password_hash);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials. Incorrect password.' });
    }

    const permissions = (() => {
      try {
        return typeof user.permissions === 'string' ? JSON.parse(user.permissions) : (user.permissions || []);
      } catch (e) {
        return [];
      }
    })();

    // Generate JWT Token with payload
    const tokenPayload = {
      id: user.id,
      username: user.username,
      email: user.email,
      fullName: user.full_name,
      role: user.role,
      depotId: user.depot_id,
      depotName: user.depot_name,
      permissions
    };

    const token = jwt.sign(tokenPayload, env.JWT_SECRET, {
      expiresIn: env.JWT_EXPIRES_IN
    });

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.full_name,
        role: user.role,
        depotId: user.depot_id,
        depotName: user.depot_name,
        permissions
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Authentication service failure: ' + err.message });
  }
});

/**
 * GET /api/auth/me
 * Protected endpoint returning current user profile
 */
router.get('/me', authenticateToken, async (req, res) => {
  try {
    const db = getDb();
    const client = db.session.client;

    const userRes = await client.query(`
      SELECT u.id, u.username, u.email, u.full_name, u.role, u.depot_id, u.status, u.permissions, u.created_at, d.name as depot_name
      FROM users u
      LEFT JOIN depots d ON u.depot_id = d.id
      WHERE u.id = $1
    `, [req.user.id]);

    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: 'User profile not found.' });
    }

    const foundUser = userRes.rows[0];
    let userPerms = [];
    try {
      userPerms = typeof foundUser.permissions === 'string' ? JSON.parse(foundUser.permissions) : (foundUser.permissions || []);
    } catch(e) {}
    res.json({ user: { ...foundUser, permissions: userPerms } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/auth/register
 * Admin-only endpoint to provision new user accounts
 */
router.post('/register', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { username, email, password, fullName, role, depotId } = req.body;
    if (!username || !email || !password || !fullName || !role) {
      return res.status(400).json({ error: 'All fields (username, email, password, fullName, role) are required.' });
    }

    if (!['Admin', 'ShiftManager'].includes(role)) {
      return res.status(400).json({ error: "Role must be 'Admin' or 'ShiftManager'." });
    }

    const db = getDb();
    const client = db.session.client;

    const check = await client.query('SELECT id FROM users WHERE email = $1 OR username = $2', [email.trim(), username.trim()]);
    if (check.rows.length > 0) {
      return res.status(409).json({ error: 'User with this email or username already exists.' });
    }

    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    const newId = uuidv4();

    await client.query(`
      INSERT INTO users (id, username, email, password_hash, full_name, role, depot_id, status)
      VALUES ($1, $2, $3, $4, $5, $6, $7, 'active')
    `, [newId, username.trim(), email.trim(), hash, fullName.trim(), role, depotId || null]);

    res.status(201).json({
      message: 'User created successfully',
      user: { id: newId, username, email, fullName, role, depotId }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;