const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

// List suppliers
router.get('/', async (req, res) => {
  try {
    const { search, includeInactive } = req.query;
    const db = getDb();
    let query = `
      SELECT s.*,
        (SELECT COUNT(*) FROM maintenance_logs m WHERE m.supplier_id = s.id) as total_jobs_completed,
        (SELECT COALESCE(SUM(m.total_cost), 0) FROM maintenance_logs m WHERE m.supplier_id = s.id) as total_spend
      FROM suppliers s
      WHERE 1=1
    `;
    const params = [];

    if (includeInactive !== 'true') {
      query += ` AND s.is_active = TRUE`;
    }
    if (search) {
      params.push(`%${search}%`);
      query += ` AND (s.name ILIKE $${params.length} OR s.services_provided ILIKE $${params.length} OR s.contact_details ILIKE $${params.length})`;
    }

    query += ` ORDER BY s.is_active DESC, s.name ASC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create supplier (Admin Only)
router.post('/', async (req, res) => {
  try {
    const { name, contactDetails, servicesProvided, isActive } = req.body;
    if (!name) return res.status(400).json({ error: 'Supplier name is required.' });

    const db = getDb();
    const id = uuidv4();
    const { rows } = await db.session.client.query(`
      INSERT INTO suppliers (id, name, contact_details, services_provided, is_active)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *
    `, [id, name.trim(), contactDetails || null, servicesProvided || null, isActive !== undefined ? Boolean(isActive) : true]);

    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update supplier (Admin Only)
router.put('/:id', async (req, res) => {
  try {
    const { name, contactDetails, servicesProvided, isActive } = req.body;
    const db = getDb();

    const { rows } = await db.session.client.query(`
      UPDATE suppliers SET
        name = COALESCE($1, name),
        contact_details = COALESCE($2, contact_details),
        services_provided = COALESCE($3, services_provided),
        is_active = COALESCE($4, is_active),
        updated_at = NOW()
      WHERE id = $5
      RETURNING *
    `, [name ? name.trim() : undefined, contactDetails, servicesProvided, isActive !== undefined ? Boolean(isActive) : undefined, req.params.id]);

    if (!rows.length) return res.status(404).json({ error: 'Supplier not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Soft Delete / Toggle Active (Admin Only)
router.patch('/:id/toggle-active', async (req, res) => {
  try {
    const db = getDb();
    const check = await db.session.client.query(`SELECT is_active FROM suppliers WHERE id = $1`, [req.params.id]);
    if (!check.rows.length) return res.status(404).json({ error: 'Supplier not found' });

    const newActive = !check.rows[0].is_active;
    const { rows } = await db.session.client.query(`
      UPDATE suppliers SET is_active = $1, updated_at = NOW() WHERE id = $2 RETURNING *
    `, [newActive, req.params.id]);

    res.json({ message: `Supplier marked as ${newActive ? 'active' : 'inactive'}.`, supplier: rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete endpoint: Enforces Soft Delete
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const { rows } = await db.session.client.query(`
      UPDATE suppliers SET is_active = FALSE, updated_at = NOW() WHERE id = $1 RETURNING *
    `, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Supplier not found' });
    res.json({ message: 'Supplier soft-deleted (status marked inactive) to preserve historical records.', supplier: rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;