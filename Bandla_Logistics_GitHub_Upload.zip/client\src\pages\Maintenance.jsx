import React, { useState, useEffect, useMemo } from 'react';
import { 
  Wrench, Plus, Search, Filter, AlertTriangle, Trash2, Edit, 
  Building2, ShieldAlert, CheckCircle2, Clock, FileText, Phone, Mail,
  Fuel, Gauge, Receipt, Calendar, User, Truck, Columns
} from 'lucide-react';
import { 
  getMaintenance, createMaintenance, updateMaintenance, deleteMaintenance,
  getVehicles, getDrivers,
  getSuppliers, createSupplier, updateSupplier, toggleSupplierActive, deleteSupplier,
  getAccidents, createAccident, updateAccident, deleteAccident,
  getFuelLogs, createFuelLog, updateFuelLog, deleteFuelLog
} from '../services/api';
import Modal from '../components/Modal';
import ColumnVisibilityToggle from '../components/ColumnVisibilityToggle';
import { formatCurrency, formatDate, formatNumber } from '../utils/formatters';

const MAINT_COLUMNS = [
  { key: 'date', label: 'Service Date & Invoice #' },
  { key: 'reg', label: 'Vehicle Reg & Model' },
  { key: 'mileage', label: 'Mileage (mi)' },
  { key: 'supplier', label: 'Garage Supplier' },
  { key: 'details', label: 'Job Details & Description' },
  { key: 'breakdown', label: 'Labour / Parts Cost' },
  { key: 'cost', label: 'Total Cost & VAT' }
];

const FUEL_COLUMNS = [
  { key: 'date', label: 'Refuel Date' },
  { key: 'reg', label: 'Vehicle Reg' },
  { key: 'driver', label: 'Driver / Courier' },
  { key: 'station', label: 'Station & Card Ref' },
  { key: 'odometer', label: 'Odometer (mi)' },
  { key: 'liters', label: 'Liters Filled' },
  { key: 'cost', label: 'Total Cost (£)' }
];

export default function Maintenance() {
  const [activeTab, setActiveTab] = useState('maintenance'); // 'maintenance' | 'invoices_admin' | 'suppliers' | 'accidents' | 'fuel'
  const [loading, setLoading] = useState(true);

  // Column Visibility States (persisted to localStorage)
  const [maintVisible, setMaintVisible] = useState(() => {
    try {
      const saved = localStorage.getItem('maint_visible_cols');
      return saved ? JSON.parse(saved) : {};
    } catch (e) { return {}; }
  });

  const [fuelVisible, setFuelVisible] = useState(() => {
    try {
      const saved = localStorage.getItem('fuel_visible_cols');
      return saved ? JSON.parse(saved) : {};
    } catch (e) { return {}; }
  });

  // Data States
  const [records, setRecords] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [accidents, setAccidents] = useState([]);
  const [fuelLogs, setFuelLogs] = useState([]);
  const [search, setSearch] = useState('');

  // Modals & Form States
  const [isMaintModalOpen, setIsMaintModalOpen] = useState(false);
  const [editingMaint, setEditingMaint] = useState(null);
  const [maintForm, setMaintForm] = useState({
    serviceDate: new Date().toISOString().split('T')[0],
    vehicleId: '',
    supplierId: '',
    serviceType: 'Scheduled Maintenance',
    laborCost: 0,
    partsCost: 0,
    invoiceNumber: '',
    description: '',
    nextServiceOdometer: 0,
    notes: '', customSupplierName: ''
  });

  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [supplierForm, setSupplierForm] = useState({
    name: '',
    contactDetails: '',
    servicesProvided: 'MOT & General Servicing',
    isActive: true
  });

  const [isAccidentModalOpen, setIsAccidentModalOpen] = useState(false);
  const [editingAccident, setEditingAccident] = useState(null);
  const [accidentForm, setAccidentForm] = useState({
    vehicleId: '',
    driverId: '',
    incidentDate: new Date().toISOString().split('T')[0],
    incidentType: 'Collision',
    claimNumber: '',
    insuranceCompany: '',
    faultStatus: 'Non-Fault',
    claimStatus: 'Reported',
    costEstimate: 0,
    actualCost: 0,
    excessAmount: 0,
    policeReportRef: '',
    description: ''
  });

  const [isFuelModalOpen, setIsFuelModalOpen] = useState(false);
  const [editingFuel, setEditingFuel] = useState(null);
  const [fuelSearch, setFuelSearch] = useState('');
  const [fuelStationFilter, setFuelStationFilter] = useState('');
  const [fuelPage, setFuelPage] = useState(1);
  const fuelPageSize = 50;

  const [fuelForm, setFuelForm] = useState({
    refuelDate: new Date().toISOString().split('T')[0],
    vehicleId: '',
    driverId: '',
    stationName: 'Shell Leicester Hub',
    litersFilled: 60.00,
    totalCost: 95.00,
    odometerReading: 45000,
    fuelCardRef: 'CARD-001',
    notes: '', customSupplierName: ''
  });

  useEffect(() => {
    loadAllData();
  }, [activeTab]);

  const loadAllData = async () => {
    try {
      setLoading(true);
      const results = await Promise.allSettled([
        getMaintenance(),
        getVehicles({ includeInactive: 'false' }),
        getSuppliers(),
        getDrivers({ includeInactive: 'false' }),
        getAccidents(),
        getFuelLogs()
      ]);

      if (results[0].status === 'fulfilled' && Array.isArray(results[0].value)) setRecords(results[0].value);
      if (results[1].status === 'fulfilled' && Array.isArray(results[1].value)) setVehicles(results[1].value);
      if (results[2].status === 'fulfilled' && Array.isArray(results[2].value)) setSuppliers(results[2].value);
      if (results[3].status === 'fulfilled' && Array.isArray(results[3].value)) setDrivers(results[3].value);
      if (results[4].status === 'fulfilled' && Array.isArray(results[4].value)) setAccidents(results[4].value);
      if (results[5].status === 'fulfilled' && Array.isArray(results[5].value)) setFuelLogs(results[5].value);
    } catch (err) {
      console.error('Error loading CRM, Maintenance & Fuel data:', err);
    } finally {
      setLoading(false);
    }
  };

  // --- Maintenance Handlers ---
  const handleOpenAddMaint = () => {
    setEditingMaint(null);
    setMaintForm({
      serviceDate: new Date().toISOString().split('T')[0],
      vehicleId: vehicles[0]?.id || '',
      supplierId: suppliers[0]?.id || '',
      serviceType: 'Scheduled Maintenance',
      laborCost: 0,
      partsCost: 0,
      invoiceNumber: '',
      description: '',
      nextServiceOdometer: 0,
      notes: '', customSupplierName: ''
  });
    setIsMaintModalOpen(true);
  };

  const handleOpenEditMaint = (r) => {
    setEditingMaint(r);
    setMaintForm({
      serviceDate: r.service_date ? r.service_date.split('T')[0] : '',
      vehicleId: r.vehicle_id || '',
      supplierId: r.supplier_id || '',
      serviceType: r.service_type || 'Scheduled Maintenance',
      laborCost: parseFloat(r.labor_cost || 0),
      partsCost: parseFloat(r.parts_cost || 0),
      invoiceNumber: r.invoice_number || '',
      description: r.description || '',
      nextServiceOdometer: parseFloat(r.next_service_odometer || 0),
      notes: r.notes || ''
    });
    setIsMaintModalOpen(true);
  };

  const handleSaveMaint = async (e) => {
    e.preventDefault();
    try {
      let finalSupplierId = maintForm.supplierId;

      // Auto-create custom workshop if selected
      if (maintForm.supplierId === 'custom' && maintForm.customSupplierName?.trim()) {
        const newSup = await createSupplier({
          name: maintForm.customSupplierName.trim(),
          contactDetails: 'Added via Maintenance Quick-Log',
          servicesProvided: maintForm.serviceType || 'General Maintenance',
          isActive: true
        });
        finalSupplierId = newSup.id;
      }

      const payload = {
        ...maintForm,
        supplierId: finalSupplierId === 'custom' ? null : (finalSupplierId || null)
      };

      if (editingMaint) {
        await updateMaintenance(editingMaint.id, payload);
      } else {
        await createMaintenance(payload);
      }
      setIsMaintModalOpen(false);
      loadAllData();
    } catch (err) {
      console.warn('Error saving maintenance record: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDeleteMaint = async (id) => {
    
    try {
      await deleteMaintenance(id);
      loadAllData();
    } catch (err) {
      console.warn('Error deleting: ' + (err.response?.data?.error || err.message));
    }
  };

  // --- Supplier Handlers ---
  const handleOpenAddSupplier = () => {
    setEditingSupplier(null);
    setSupplierForm({
      name: '',
      contactDetails: '',
      servicesProvided: 'MOT & General Servicing',
      isActive: true
    });
    setIsSupplierModalOpen(true);
  };

  const handleOpenEditSupplier = (s) => {
    setEditingSupplier(s);
    setSupplierForm({
      name: s.name || '',
      contactDetails: s.contact_details || '',
      servicesProvided: s.services_provided || '',
      isActive: s.is_active !== undefined ? s.is_active : true
    });
    setIsSupplierModalOpen(true);
  };

  const handleSaveSupplier = async (e) => {
    e.preventDefault();
    try {
      if (editingSupplier) {
        await updateSupplier(editingSupplier.id, supplierForm);
      } else {
        await createSupplier(supplierForm);
      }
      setIsSupplierModalOpen(false);
      loadAllData();
    } catch (err) {
      console.warn('Error saving garage supplier: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleToggleSupplierActive = async (id) => {
    try {
      await toggleSupplierActive(id);
      loadAllData();
    } catch (err) {
      console.warn('Error toggling supplier: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDeleteSupplier = async (id) => {
    try {
      await deleteSupplier(id);
      loadAllData();
    } catch (err) {
      console.warn('Error deactivating: ' + (err.response?.data?.error || err.message));
    }
  };

  // --- Accident Handlers ---
  const handleOpenAddAccident = () => {
    setEditingAccident(null);
    setAccidentForm({
      vehicleId: vehicles[0]?.id || '',
      driverId: drivers[0]?.id || '',
      incidentDate: new Date().toISOString().split('T')[0],
      incidentType: 'Collision',
      claimNumber: '',
      insuranceCompany: '',
      faultStatus: 'Non-Fault',
      claimStatus: 'Reported',
      costEstimate: 0,
      actualCost: 0,
      excessAmount: 0,
      policeReportRef: '',
      description: ''
    });
    setIsAccidentModalOpen(true);
  };

  const handleOpenEditAccident = (a) => {
    setEditingAccident(a);
    setAccidentForm({
      vehicleId: a.vehicle_id || '',
      driverId: a.driver_id || '',
      incidentDate: a.incident_date ? a.incident_date.split('T')[0] : '',
      incidentType: a.incident_type || 'Collision',
      claimNumber: a.claim_number || '',
      insuranceCompany: a.insurance_company || '',
      faultStatus: a.fault_status || 'Non-Fault',
      claimStatus: a.claim_status || 'Reported',
      costEstimate: parseFloat(a.cost_estimate || 0),
      actualCost: parseFloat(a.actual_cost || 0),
      excessAmount: parseFloat(a.excess_amount || 0),
      policeReportRef: a.police_report_ref || '',
      description: a.description || ''
    });
    setIsAccidentModalOpen(true);
  };

  const handleSaveAccident = async (e) => {
    e.preventDefault();
    try {
      if (editingAccident) {
        await updateAccident(editingAccident.id, accidentForm);
      } else {
        await createAccident(accidentForm);
      }
      setIsAccidentModalOpen(false);
      loadAllData();
    } catch (err) {
      console.warn('Error saving accident log: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDeleteAccident = async (id) => {
    
    try {
      await deleteAccident(id);
      loadAllData();
    } catch (err) {
      console.warn('Error deleting: ' + (err.response?.data?.error || err.message));
    }
  };

  // --- Fuel Handlers ---
  const handleOpenAddFuel = () => {
    setEditingFuel(null);
    setFuelForm({
      refuelDate: new Date().toISOString().split('T')[0],
      vehicleId: vehicles[0]?.id || '',
      driverId: drivers[0]?.id || '',
      stationName: 'Shell Leicester Hub',
      litersFilled: 60.00,
      totalCost: 95.00,
      odometerReading: 45000,
      fuelCardRef: 'CARD-001',
      notes: '', customSupplierName: ''
  });
    setIsFuelModalOpen(true);
  };

  const handleOpenEditFuel = (f) => {
    setEditingFuel(f);
    setFuelForm({
      refuelDate: f.refuel_date ? f.refuel_date.split('T')[0] : '',
      vehicleId: f.vehicle_id || '',
      driverId: f.driver_id || '',
      stationName: f.station_name || '',
      litersFilled: parseFloat(f.liters_filled || 0),
      totalCost: parseFloat(f.total_cost || 0),
      odometerReading: parseFloat(f.odometer_reading || 0),
      fuelCardRef: f.fuel_card_ref || '',
      notes: f.notes || ''
    });
    setIsFuelModalOpen(true);
  };

  const handleSaveFuel = async (e) => {
    e.preventDefault();
    try {
      if (editingFuel) {
        await updateFuelLog(editingFuel.id, fuelForm);
      } else {
        await createFuelLog(fuelForm);
      }
      setIsFuelModalOpen(false);
      loadAllData();
    } catch (err) {
      console.warn('Error saving fuel log: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDeleteFuel = async (id) => {
    
    try {
      await deleteFuelLog(id);
      loadAllData();
    } catch (err) {
      console.warn('Error deleting fuel log: ' + (err.response?.data?.error || err.message));
    }
  };

  // Maintenance Filters & Pagination Hooks
  const [maintSearch, setMaintSearch] = useState('');
  const [maintVehicleFilter, setMaintVehicleFilter] = useState('');
  const [maintSupplierFilter, setMaintSupplierFilter] = useState('');
  const [maintPage, setMaintPage] = useState(1);
  const maintPageSize = 50;

  const filteredMaintRecords = useMemo(() => {
    return records.filter(r => {
      const s = maintSearch.toLowerCase().trim();
      const matchesSearch = !s ||
        (r.registration_number && r.registration_number.toLowerCase().includes(s)) ||
        (r.supplier_name && r.supplier_name.toLowerCase().includes(s)) ||
        (r.invoice_number && r.invoice_number.toLowerCase().includes(s)) ||
        (r.service_type && r.service_type.toLowerCase().includes(s)) ||
        (r.description && r.description.toLowerCase().includes(s)) ||
        (r.notes && r.notes.toLowerCase().includes(s)) ||
        (r.service_date && String(r.service_date).includes(s));
      const matchesVeh = !maintVehicleFilter || r.registration_number === maintVehicleFilter;
      const matchesSup = !maintSupplierFilter || (r.supplier_name || 'In-House Service') === maintSupplierFilter;
      return matchesSearch && matchesVeh && matchesSup;
    });
  }, [records, maintSearch, maintVehicleFilter, maintSupplierFilter]);

  const totalMaintPages = Math.ceil(filteredMaintRecords.length / maintPageSize) || 1;

  const paginatedMaintRecords = useMemo(() => {
    const start = (maintPage - 1) * maintPageSize;
    return filteredMaintRecords.slice(start, start + maintPageSize);
  }, [filteredMaintRecords, maintPage, maintPageSize]);

  const uniqueMaintVehicles = useMemo(() => {
    const set = new Set();
    records.forEach(r => { if (r.registration_number) set.add(r.registration_number); });
    return Array.from(set).sort();
  }, [records]);

  const uniqueMaintSuppliers = useMemo(() => {
    const set = new Set();
    records.forEach(r => { set.add(r.supplier_name || 'In-House Service'); });
    return Array.from(set).sort();
  }, [records]);

  // Fuel Filters & Pagination Hooks
  const filteredFuelLogs = useMemo(() => {
    return fuelLogs.filter(f => {
      const s = fuelSearch.toLowerCase().trim();
      const matchesSearch = !s ||
        (f.vehicle_reg && f.vehicle_reg.toLowerCase().includes(s)) ||
        (f.station_name && f.station_name.toLowerCase().includes(s)) ||
        (f.driver_name && f.driver_name.toLowerCase().includes(s)) ||
        (f.refuel_date && String(f.refuel_date).includes(s));
      const matchesStation = !fuelStationFilter || f.station_name === fuelStationFilter;
      return matchesSearch && matchesStation;
    });
  }, [fuelLogs, fuelSearch, fuelStationFilter]);

  const totalFuelPages = Math.ceil(filteredFuelLogs.length / fuelPageSize) || 1;

  const paginatedFuelLogs = useMemo(() => {
    const start = (fuelPage - 1) * fuelPageSize;
    return filteredFuelLogs.slice(start, start + fuelPageSize);
  }, [filteredFuelLogs, fuelPage, fuelPageSize]);

  const uniqueStations = useMemo(() => {
    const set = new Set();
    fuelLogs.forEach(f => { if (f.station_name) set.add(f.station_name); });
    return Array.from(set).sort();
  }, [fuelLogs]);

  // KPI Computations
  const totalMaintCost = records.reduce((sum, r) => sum + parseFloat(r.total_cost || 0), 0);
  const totalFuelCost = fuelLogs.reduce((sum, f) => sum + parseFloat(f.total_cost || 0), 0);
  const totalLiters = fuelLogs.reduce((sum, f) => sum + parseFloat(f.liters_filled || 0), 0);
  const avgCostPerLiter = totalLiters > 0 ? (totalFuelCost / totalLiters) : 0;

  // Monthly Breakdown & Garage Invoice Admin Hooks
  const [adminSupplierFilter, setAdminSupplierFilter] = useState('Ravi Coventry');
  const [adminMonthFilter, setAdminMonthFilter] = useState('July 2026');

  // Month formatter helper
  const getMonthStr = (dateStr) => {
    if (!dateStr) return 'General';
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? 'General' : d.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
  };

  // Grouped monthly garage totals
  const monthlyGarageRows = useMemo(() => {
    const map = new Map();
    records.forEach(r => {
      const g = r.supplier_name || 'Abdul / AutoTech';
      const m = getMonthStr(r.service_date || r.date);
      const key = `${g}__${m}`;
      const total = parseFloat(r.total_cost || 0);
      if (!map.has(key)) {
        map.set(key, { garage: g, month: m, total: 0 });
      }
      map.get(key).total += total;
    });
    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }, [records]);

  // Compiled monthly totals (all garages combined per month)
  const compiledMonthlyTotals = useMemo(() => {
    const map = new Map();
    records.forEach(r => {
      const m = getMonthStr(r.service_date || r.date);
      const total = parseFloat(r.total_cost || 0);
      map.set(m, (map.get(m) || 0) + total);
    });
    return Array.from(map.entries()).map(([month, total]) => ({ month, total }));
  }, [records]);

  const uniqueAdminMonths = useMemo(() => {
    const set = new Set();
    records.forEach(r => { set.add(getMonthStr(r.service_date || r.date)); });
    return Array.from(set);
  }, [records]);

  // Filtered jobs for search selection
  const adminSelectedJobs = useMemo(() => {
    return records.filter(r => {
      const g = r.supplier_name || 'Abdul / AutoTech';
      const m = getMonthStr(r.service_date || r.date);
      const matchesSup = !adminSupplierFilter || g === adminSupplierFilter;
      const matchesMon = !adminMonthFilter || m === adminMonthFilter;
      return matchesSup && matchesMon;
    });
  }, [records, adminSupplierFilter, adminMonthFilter]);

  const adminSearchTotal = useMemo(() => {
    return adminSelectedJobs.reduce((sum, r) => sum + parseFloat(r.total_cost || 0), 0);
  }, [adminSelectedJobs]);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-xl">
            <Wrench className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Fleet CRM, Maintenance & Fuel Hub</h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Manage garage suppliers, track repair costs, insurance accident claims & fuel consumption
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {activeTab === 'maintenance' && (
            <button
              onClick={handleOpenAddMaint}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Log Repair / Service
            </button>
          )}
          {activeTab === 'suppliers' && (
            <button
              onClick={handleOpenAddSupplier}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Add Garage Supplier
            </button>
          )}
          {activeTab === 'accidents' && (
            <button
              onClick={handleOpenAddAccident}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-rose-600/20 flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Report Accident
            </button>
          )}
          {activeTab === 'fuel' && (
            <button
              onClick={handleOpenAddFuel}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-emerald-600/20 flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Log Refuel Entry
            </button>
          )}
        </div>
      </div>

      {/* Subtab Switcher */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 space-x-6 text-xs font-semibold overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('maintenance')}
          className={`pb-3 flex items-center gap-2 transition cursor-pointer shrink-0 ${
            activeTab === 'maintenance'
              ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-500'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <Wrench className="w-4 h-4" /> Fleet Maintenance & Repair Logs ({records.length})
        </button>
        <button
          onClick={() => setActiveTab('invoices_admin')}
          className={`pb-3 flex items-center gap-2 transition cursor-pointer shrink-0 ${
            activeTab === 'invoices_admin'
              ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-500 font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <Receipt className="w-4 h-4" /> Maintenance Invoice Admin & Monthly Spend
        </button>
        <button
          onClick={() => setActiveTab('suppliers')}
          className={`pb-3 flex items-center gap-2 transition cursor-pointer shrink-0 ${
            activeTab === 'suppliers'
              ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-500'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <Building2 className="w-4 h-4" /> Garage Suppliers Directory ({suppliers.length})
        </button>
        <button
          onClick={() => setActiveTab('accidents')}
          className={`pb-3 flex items-center gap-2 transition cursor-pointer shrink-0 ${
            activeTab === 'accidents'
              ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-500'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <ShieldAlert className="w-4 h-4" /> Accidents & Insurance Claims ({accidents.length})
        </button>
        <button
          onClick={() => setActiveTab('fuel')}
          className={`pb-3 flex items-center gap-2 transition cursor-pointer shrink-0 ${
            activeTab === 'fuel'
              ? 'text-emerald-600 dark:text-emerald-400 border-b-2 border-emerald-500'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <Fuel className="w-4 h-4" /> Fuel Consumption Tracking ({fuelLogs.length})
        </button>
      </div>

      {/* --- TAB 1: MAINTENANCE LOGS --- */}
      {activeTab === 'maintenance' && (
        <div className="space-y-4">
          {/* Maintenance Search & Filter Toolbar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm flex flex-wrap gap-4 items-center justify-between">
            <div className="relative flex-1 min-w-[260px]">
              <Search className="w-4 h-4 text-slate-500 dark:text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search maintenance by reg, garage (Abdul, MS Tyres, Ravi...), invoice or job details..."
                value={maintSearch}
                onChange={(e) => { setMaintSearch(e.target.value); setMaintPage(1); }}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <ColumnVisibilityToggle
                columns={MAINT_COLUMNS}
                visibleColumns={maintVisible}
                onChange={setMaintVisible}
                onReset={() => setMaintVisible({})}
                storageKey="maint_visible_cols"
              />

              <select
                value={maintVehicleFilter}
                onChange={(e) => { setMaintVehicleFilter(e.target.value); setMaintPage(1); }}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500 font-medium"
              >
                <option value="">All Vehicles ({uniqueMaintVehicles.length})</option>
                {uniqueMaintVehicles.map(reg => (
                  <option key={reg} value={reg}>🚐 {reg}</option>
                ))}
              </select>

              <select
                value={maintSupplierFilter}
                onChange={(e) => { setMaintSupplierFilter(e.target.value); setMaintPage(1); }}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500 font-medium"
              >
                <option value="">All Garages ({uniqueMaintSuppliers.length})</option>
                {uniqueMaintSuppliers.map(sup => (
                  <option key={sup} value={sup}>🔧 {sup}</option>
                ))}
              </select>

              <div className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                Showing <strong className="text-slate-900 dark:text-white">{filteredMaintRecords.length}</strong> records
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
            {loading ? (
              <div className="p-12 text-center text-slate-600 dark:text-slate-400">Loading maintenance records...</div>
            ) : filteredMaintRecords.length === 0 ? (
              <div className="p-12 text-center text-slate-500">
                <CheckCircle2 className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                No matching maintenance events found. Click "Log Repair / Service" to record garage invoices.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      {maintVisible.date !== false && <th className="p-3.5">Service Date</th>}
                      {maintVisible.reg !== false && <th className="p-3.5">Vehicle Reg</th>}
                      {maintVisible.mileage !== false && <th className="p-3.5">Mileage (mi)</th>}
                      {maintVisible.supplier !== false && <th className="p-3.5">Garage Supplier</th>}
                      {maintVisible.details !== false && <th className="p-3.5">Job Details & Description</th>}
                      {maintVisible.breakdown !== false && <th className="p-3.5 text-right">Labour / Parts</th>}
                      {maintVisible.cost !== false && <th className="p-3.5 text-right">Total Cost</th>}
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                    {paginatedMaintRecords.map((r) => {
                      const totalC = parseFloat(r.total_cost || 0);
                      const vatAmt = totalC * 0.20;
                      return (
                        <tr key={r.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                          {maintVisible.date !== false && (
                            <td className="p-3.5">
                              <span className="font-mono font-bold text-slate-900 dark:text-white block">{formatDate(r.service_date || r.date)}</span>
                              <span className="text-[11px] text-slate-500 font-mono">{r.invoice_number ? `Inv: ${r.invoice_number}` : 'Receipt Log'}</span>
                            </td>
                          )}
                          {maintVisible.reg !== false && (
                            <td className="p-3.5">
                              <span className="font-mono font-bold text-slate-900 dark:text-white block">{r.registration_number || 'UNREGISTERED'}</span>
                              <span className="text-[11px] text-slate-500 dark:text-slate-400">{r.vehicle_model}</span>
                            </td>
                          )}
                          {maintVisible.mileage !== false && (
                            <td className="p-3.5 font-mono text-slate-700 dark:text-slate-300">
                              {r.service_mileage || r.current_mileage ? `${formatNumber(r.service_mileage || r.current_mileage)} mi` : '-'}
                            </td>
                          )}
                          {maintVisible.supplier !== false && (
                            <td className="p-3.5">
                              <span className="font-semibold text-blue-600 dark:text-blue-400 block">{r.supplier_name || 'Abdul / AutoTech'}</span>
                              <span className="text-[10px] text-slate-500">{r.service_type || 'Workshop Service'}</span>
                            </td>
                          )}
                          {maintVisible.details !== false && (
                            <td className="p-3.5 text-slate-700 dark:text-slate-300 max-w-xs">
                              <span className="font-medium text-slate-900 dark:text-white block">{r.description || r.notes || r.service_type || '-'}</span>
                            </td>
                          )}
                          {maintVisible.breakdown !== false && (
                            <td className="p-3.5 text-right text-slate-600 dark:text-slate-400 font-mono">
                              <div>Labour: {formatCurrency(r.labor_cost || 0)}</div>
                              <div>Parts: {formatCurrency(r.parts_cost || 0)}</div>
                            </td>
                          )}
                          {maintVisible.cost !== false && (
                            <td className="p-3.5 text-right font-mono">
                              <span className="font-bold text-slate-900 dark:text-white block">{formatCurrency(r.total_cost)}</span>
                              <span className="text-[10px] text-slate-500">VAT (20%): {formatCurrency(vatAmt)}</span>
                            </td>
                          )}
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => handleOpenEditMaint(r)}
                                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 transition"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteMaint(r.id)}
                                className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 transition"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Fast Pagination Bar */}
                <div className="flex items-center justify-between px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
                  <div className="text-xs text-slate-500">
                    Showing <strong className="text-slate-700 dark:text-slate-300">{(maintPage - 1) * maintPageSize + 1}</strong> - <strong className="text-slate-700 dark:text-slate-300">{Math.min(maintPage * maintPageSize, filteredMaintRecords.length)}</strong> of <strong className="text-slate-700 dark:text-slate-300">{filteredMaintRecords.length}</strong> repair records
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setMaintPage(prev => Math.max(1, prev - 1))}
                      disabled={maintPage === 1}
                      className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-700 transition cursor-pointer"
                    >
                      ← Previous
                    </button>
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300 px-2">
                      Page {maintPage} of {totalMaintPages}
                    </span>
                    <button
                      type="button"
                      onClick={() => setMaintPage(prev => Math.min(totalMaintPages, prev + 1))}
                      disabled={maintPage === totalMaintPages}
                      className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-700 transition cursor-pointer"
                    >
                      Next →
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- TAB 1B: MAINTENANCE INVOICE ADMIN & MONTHLY BREAKDOWN --- */}
      {activeTab === 'invoices_admin' && (
        <div className="space-y-6">
          {/* Top Filter & Search KPI Banner */}
          <div className="bg-gradient-to-r from-amber-500/10 via-slate-50 to-blue-500/10 dark:from-amber-950/30 dark:via-slate-900 dark:to-blue-950/30 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-4">
              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 mb-1">Supplier Search:</label>
                <select
                  value={adminSupplierFilter}
                  onChange={(e) => setAdminSupplierFilter(e.target.value)}
                  className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-bold focus:outline-none focus:border-amber-500"
                >
                  <option value="">All Garages ({uniqueMaintSuppliers.length})</option>
                  {uniqueMaintSuppliers.map(sup => (
                    <option key={sup} value={sup}>🔧 {sup}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 mb-1">Month Search:</label>
                <select
                  value={adminMonthFilter}
                  onChange={(e) => setAdminMonthFilter(e.target.value)}
                  className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-bold focus:outline-none focus:border-amber-500"
                >
                  <option value="">All Historical Months ({uniqueAdminMonths.length})</option>
                  {uniqueAdminMonths.map(mon => (
                    <option key={mon} value={mon}>📅 {mon}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-4 bg-white dark:bg-slate-950 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase block">Search Spend Total</span>
                <span className="text-xl font-black text-amber-600 dark:text-amber-400 font-mono">{formatCurrency(adminSearchTotal)}</span>
              </div>
              <div className="h-8 w-px bg-slate-200 dark:bg-slate-800" />
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase block">Jobs Completed</span>
                <span className="text-xl font-black text-slate-900 dark:text-white font-mono">{adminSelectedJobs.length} Jobs</span>
              </div>
            </div>
          </div>

          {/* 2-Column Split: Monthly Breakdown & Job Audit Table */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Col: Monthly Ledger Breakdown (4 Cols) */}
            <div className="lg:col-span-4 space-y-4">
              <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 pb-2 border-b border-slate-100 dark:border-slate-800">
                  Compiled Monthly Totals (£)
                </h3>
                <div className="divide-y divide-slate-100 dark:divide-slate-800/60 max-h-56 overflow-y-auto text-xs mt-2">
                  {compiledMonthlyTotals.map(row => (
                    <div 
                      key={row.month} 
                      onClick={() => setAdminMonthFilter(row.month)}
                      className={`flex items-center justify-between py-2 px-2 rounded-lg cursor-pointer transition ${adminMonthFilter === row.month ? 'bg-amber-500/10 font-bold text-amber-600 dark:text-amber-400' : 'hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-700 dark:text-slate-300'}`}
                    >
                      <span>{row.month}</span>
                      <span className="font-mono">{formatCurrency(row.total)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 pb-2 border-b border-slate-100 dark:border-slate-800">
                  Garage Spend Matrix
                </h3>
                <div className="divide-y divide-slate-100 dark:divide-slate-800/60 max-h-80 overflow-y-auto text-xs mt-2">
                  {monthlyGarageRows.slice(0, 20).map((row, idx) => (
                    <div 
                      key={idx}
                      onClick={() => { setAdminSupplierFilter(row.garage); setAdminMonthFilter(row.month); }}
                      className="flex items-center justify-between py-2 px-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer transition text-slate-700 dark:text-slate-300"
                    >
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white block">{row.garage}</span>
                        <span className="text-[10px] text-slate-500">{row.month}</span>
                      </div>
                      <span className="font-mono font-bold text-slate-900 dark:text-white">{formatCurrency(row.total)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Col: Detailed Filtered Jobs (8 Cols) */}
            <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Job Details for {adminSupplierFilter || 'All Garages'} ({adminMonthFilter || 'All Months'})
                  </h3>
                  <span className="text-[11px] text-slate-500">{adminSelectedJobs.length} completed repairs found</span>
                </div>
              </div>

              {adminSelectedJobs.length === 0 ? (
                <div className="p-12 text-center text-slate-500 text-xs">
                  No repair jobs match the selected garage and month.
                </div>
              ) : (
                <div className="overflow-x-auto max-h-[500px]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800 sticky top-0">
                      <tr>
                        <th className="p-2.5">Date</th>
                        <th className="p-2.5">Reg</th>
                        <th className="p-2.5 font-mono text-right">Mileage</th>
                        <th className="p-2.5">Garage</th>
                        <th className="p-2.5">Job Details</th>
                        <th className="p-2.5 text-right">Labour</th>
                        <th className="p-2.5 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                      {adminSelectedJobs.map((r) => (
                        <tr key={r.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                          <td className="p-2.5 font-mono text-slate-700 dark:text-slate-300">{formatDate(r.service_date || r.date)}</td>
                          <td className="p-2.5 font-mono font-bold text-slate-900 dark:text-white">{r.registration_number || 'UNREG'}</td>
                          <td className="p-2.5 font-mono text-right text-slate-600 dark:text-slate-400">
                            {r.service_mileage || r.current_mileage ? `${formatNumber(r.service_mileage || r.current_mileage)}` : '-'}
                          </td>
                          <td className="p-2.5 text-blue-600 dark:text-blue-400 font-semibold">{r.supplier_name || 'In-House'}</td>
                          <td className="p-2.5 text-slate-800 dark:text-slate-200 max-w-xs">{r.description || r.notes || r.service_type || '-'}</td>
                          <td className="p-2.5 text-right font-mono text-slate-600 dark:text-slate-400">{formatCurrency(r.labor_cost || 0)}</td>
                          <td className="p-2.5 text-right font-mono font-bold text-slate-900 dark:text-white">{formatCurrency(r.total_cost)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- TAB 2: SUPPLIERS DIRECTORY --- */}
      {activeTab === 'suppliers' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {suppliers.map((s) => (
            <div key={s.id} className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-900 dark:text-white text-sm">{s.name}</h3>
                <button
                  onClick={() => handleToggleSupplierActive(s.id)}
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border transition cursor-pointer ${
                    s.is_active
                      ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20'
                      : 'bg-slate-800 text-slate-500 border-slate-700'
                  }`}
                >
                  {s.is_active ? 'Active Partner' : 'Inactive'}
                </button>
              </div>
              <p className="text-xs text-blue-600 dark:text-blue-400 font-medium">{s.services_provided || 'General Fleet Maintenance'}</p>
              <div className="text-xs text-slate-600 dark:text-slate-400 space-y-1">
                <div className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-500" />
                  <span>{s.contact_details || 'No direct phone logged'}</span>
                </div>
              </div>
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800/80">
                <button
                  onClick={() => handleOpenEditSupplier(s)}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDeleteSupplier(s.id)}
                  className="p-1 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-500/10 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-500/20 transition cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* --- TAB 3: ACCIDENTS & CLAIMS --- */}
      {activeTab === 'accidents' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
            {accidents.length === 0 ? (
              <div className="p-12 text-center text-slate-500">
                <ShieldAlert className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                No accident claims on record. Click "Report Accident" to register a claim.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="p-3.5">Incident Date</th>
                      <th className="p-3.5">Vehicle / Driver</th>
                      <th className="p-3.5">Type & Fault</th>
                      <th className="p-3.5">Claim # / Insurer</th>
                      <th className="p-3.5 text-right">Cost Estimate / Actual</th>
                      <th className="p-3.5 text-center">Claim Status</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                    {accidents.map((a) => (
                      <tr key={a.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                        <td className="p-3.5 font-mono text-slate-700 dark:text-slate-300">{formatDate(a.incident_date)}</td>
                        <td className="p-3.5">
                          <span className="font-mono font-bold text-slate-900 dark:text-white block">{a.vehicle_reg || 'UNREGISTERED'}</span>
                          <span className="text-[11px] text-slate-600 dark:text-slate-400">{a.driver_name || 'Unassigned'}</span>
                        </td>
                        <td className="p-3.5">
                          <span className="font-semibold text-rose-600 dark:text-rose-400 block">{a.incident_type}</span>
                          <span className="text-[11px] text-slate-600 dark:text-slate-400">{a.fault_status || 'Under Investigation'}</span>
                        </td>
                        <td className="p-3.5 text-slate-700 dark:text-slate-300">
                          <span className="font-mono text-slate-900 dark:text-white block">{a.claim_number || 'Pending'}</span>
                          <span className="text-[11px] text-slate-500">{a.insurance_company || 'Fleet Policy'}</span>
                        </td>
                        <td className="p-3.5 text-right font-mono">
                          <div className="text-slate-600 dark:text-slate-400">Est: {formatCurrency(a.cost_estimate || 0)}</div>
                          <div className="font-bold text-slate-900 dark:text-white">Act: {formatCurrency(a.actual_cost || 0)}</div>
                        </td>
                        <td className="p-3.5 text-center">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                            a.claim_status === 'Under Investigation' || a.claim_status === 'Reported'
                              ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/50 animate-pulse shadow-sm shadow-amber-500/20'
                              : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                          }`}>
                            {a.claim_status === 'Under Investigation' ? '⚠️ ' : ''}{a.claim_status || 'Reported'}
                          </span>
                        </td>
                        <td className="p-3.5 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleOpenEditAccident(a)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 transition"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteAccident(a.id)}
                              className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- TAB 4: FUEL CONSUMPTION TRACKING --- */}
      {activeTab === 'fuel' && (
        <div className="space-y-4">
          {/* Fuel KPI Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase">Total Fuel Expenditure</span>
              <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">{formatCurrency(totalFuelCost)}</p>
              <span className="text-[11px] text-slate-500">Fleet refueling spend</span>
            </div>
            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase">Total Liters Filled</span>
              <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">{formatNumber(totalLiters)} L</p>
              <span className="text-[11px] text-emerald-500/80">Diesel & fuel volume</span>
            </div>
            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase">Avg Price / Liter</span>
              <p className="text-2xl font-black text-blue-600 dark:text-blue-400 mt-1">{formatCurrency(avgCostPerLiter)}/L</p>
              <span className="text-[11px] text-slate-500">Fleet average rate</span>
            </div>
            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase">Refuel Events</span>
              <p className="text-2xl font-black text-slate-900 dark:text-white mt-1">{fuelLogs.length}</p>
              <span className="text-[11px] text-slate-500">Recorded pump transactions</span>
            </div>
          </div>

          {/* Fuel Filter Toolbar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm flex flex-wrap gap-4 items-center justify-between">
            <div className="relative flex-1 min-w-[260px]">
              <Search className="w-4 h-4 text-slate-500 dark:text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search fuel by vehicle reg, station brand, driver or date..."
                value={fuelSearch}
                onChange={(e) => { setFuelSearch(e.target.value); setFuelPage(1); }}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <ColumnVisibilityToggle
                columns={FUEL_COLUMNS}
                visibleColumns={fuelVisible}
                onChange={setFuelVisible}
                onReset={() => setFuelVisible({})}
                storageKey="fuel_visible_cols"
              />

              <select
                value={fuelStationFilter}
                onChange={(e) => { setFuelStationFilter(e.target.value); setFuelPage(1); }}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500 font-medium"
              >
                <option value="">All Fuel Stations ({uniqueStations.length})</option>
                {uniqueStations.map(st => (
                  <option key={st} value={st}>⛽ {st}</option>
                ))}
              </select>

              <div className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                Showing <strong className="text-slate-900 dark:text-white">{filteredFuelLogs.length}</strong> entries
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
            {filteredFuelLogs.length === 0 ? (
              <div className="p-12 text-center text-slate-500">
                <Fuel className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                No matching fuel transactions found.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      {fuelVisible.date !== false && <th className="p-3.5">Refuel Date</th>}
                      {fuelVisible.reg !== false && <th className="p-3.5">Vehicle Reg</th>}
                      {fuelVisible.driver !== false && <th className="p-3.5">Driver / Courier</th>}
                      {fuelVisible.station !== false && <th className="p-3.5">Station & Card Ref</th>}
                      {fuelVisible.odometer !== false && <th className="p-3.5 text-right">Odometer</th>}
                      {fuelVisible.liters !== false && <th className="p-3.5 text-right">Liters Filled</th>}
                      {fuelVisible.cost !== false && <th className="p-3.5 text-right">Total Cost</th>}
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                    {paginatedFuelLogs.map((f) => (
                      <tr key={f.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                        {fuelVisible.date !== false && (
                          <td className="p-3.5 font-mono text-slate-700 dark:text-slate-300">{formatDate(f.refuel_date)}</td>
                        )}
                        {fuelVisible.reg !== false && (
                          <td className="p-3.5">
                            <span className="font-mono font-bold text-slate-900 dark:text-white block">{f.vehicle_reg || 'UNREGISTERED'}</span>
                            <span className="text-[11px] text-slate-500">{f.vehicle_model}</span>
                          </td>
                        )}
                        {fuelVisible.driver !== false && (
                          <td className="p-3.5 font-medium text-slate-700 dark:text-slate-300">
                            {f.driver_name || 'General Fleet'}
                          </td>
                        )}
                        {fuelVisible.station !== false && (
                          <td className="p-3.5">
                            <span className="font-semibold text-slate-900 dark:text-white block">{f.station_name}</span>
                            <span className="text-[11px] text-slate-500 font-mono">Card: {f.fuel_card_ref || 'Cash/Receipt'}</span>
                          </td>
                        )}
                        {fuelVisible.odometer !== false && (
                          <td className="p-3.5 text-right font-mono text-slate-700 dark:text-slate-300">
                            {f.odometer_reading ? `${formatNumber(f.odometer_reading)} mi` : '-'}
                          </td>
                        )}
                        {fuelVisible.liters !== false && (
                          <td className="p-3.5 text-right font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                            {formatNumber(f.liters_filled)} L
                          </td>
                        )}
                        {fuelVisible.cost !== false && (
                          <td className="p-3.5 text-right font-mono font-bold text-slate-900 dark:text-white">
                            {formatCurrency(f.total_cost)}
                          </td>
                        )}
                        <td className="p-3.5 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleOpenEditFuel(f)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 transition"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteFuel(f.id)}
                              className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Fast Pagination Bar */}
                <div className="flex items-center justify-between px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30">
                  <div className="text-xs text-slate-500">
                    Showing <strong className="text-slate-700 dark:text-slate-300">{(fuelPage - 1) * fuelPageSize + 1}</strong> - <strong className="text-slate-700 dark:text-slate-300">{Math.min(fuelPage * fuelPageSize, filteredFuelLogs.length)}</strong> of <strong className="text-slate-700 dark:text-slate-300">{filteredFuelLogs.length}</strong> refuel entries
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setFuelPage(prev => Math.max(1, prev - 1))}
                      disabled={fuelPage === 1}
                      className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-700 transition cursor-pointer"
                    >
                      ← Previous
                    </button>
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300 px-2">
                      Page {fuelPage} of {totalFuelPages}
                    </span>
                    <button
                      type="button"
                      onClick={() => setFuelPage(prev => Math.min(totalFuelPages, prev + 1))}
                      disabled={fuelPage === totalFuelPages}
                      className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-700 transition cursor-pointer"
                    >
                      Next →
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- MAINTENANCE MODAL --- */}
      <Modal
        isOpen={isMaintModalOpen}
        onClose={() => setIsMaintModalOpen(false)}
        title={editingMaint ? 'Edit Maintenance Record' : 'Log Maintenance / Repair Event'}
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleSaveMaint} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Service Date</label>
              <input
                type="date"
                value={maintForm.serviceDate}
                onChange={(e) => setMaintForm({ ...maintForm, serviceDate: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Vehicle</label>
              <select
                value={maintForm.vehicleId}
                onChange={(e) => setMaintForm({ ...maintForm, vehicleId: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="">-- Choose Courier Van ({vehicles.length} Active in Fleet) --</option>
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.registration_number || v.equipment_code} • {v.model_number} ({v.category || 'Standard Van'})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Garage Supplier</label>
              <div className="space-y-2">
                <select
                  value={maintForm.supplierId}
                  onChange={(e) => setMaintForm({ ...maintForm, supplierId: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="">🏢 In-House / Direct Workshop</option>
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>🔧 {s.name}</option>
                  ))}
                  <option value="custom">➕ Add New / Custom External Garage...</option>
                </select>
                {maintForm.supplierId === 'custom' && (
                  <input
                    type="text"
                    required
                    placeholder="Enter custom garage / workshop name..."
                    value={maintForm.customSupplierName || ''}
                    onChange={(e) => setMaintForm({ ...maintForm, customSupplierName: e.target.value })}
                    className="w-full bg-blue-50/50 dark:bg-slate-900 border border-blue-400 dark:border-blue-500 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 animate-fade-in"
                  />
                )}
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Service Type</label>
              <input
                type="text"
                value={maintForm.serviceType}
                onChange={(e) => setMaintForm({ ...maintForm, serviceType: e.target.value })}
                placeholder="e.g. Brake Pads & Full Service"
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Labor Cost (£)</label>
              <input
                type="number"
                step="0.01"
                value={maintForm.laborCost}
                onChange={(e) => setMaintForm({ ...maintForm, laborCost: parseFloat(e.target.value || 0) })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Parts Cost (£)</label>
              <input
                type="number"
                step="0.01"
                value={maintForm.partsCost}
                onChange={(e) => setMaintForm({ ...maintForm, partsCost: parseFloat(e.target.value || 0) })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Invoice Ref #</label>
              <input
                type="text"
                value={maintForm.invoiceNumber}
                onChange={(e) => setMaintForm({ ...maintForm, invoiceNumber: e.target.value })}
                placeholder="e.g. INV-8821"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Notes & Description</label>
            <textarea
              value={maintForm.description}
              onChange={(e) => setMaintForm({ ...maintForm, description: e.target.value })}
              rows={2}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsMaintModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20"
            >
              Save Maintenance Event
            </button>
          </div>
        </form>
      </Modal>

      {/* --- SUPPLIER MODAL --- */}
      <Modal
        isOpen={isSupplierModalOpen}
        onClose={() => setIsSupplierModalOpen(false)}
        title={editingSupplier ? 'Edit Supplier' : 'Add Garage Supplier'}
        maxWidth="max-w-md"
      >
        <form onSubmit={handleSaveSupplier} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Garage / Supplier Name</label>
            <input
              type="text"
              value={supplierForm.name}
              onChange={(e) => setSupplierForm({ ...supplierForm, name: e.target.value })}
              required
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Services Provided</label>
            <input
              type="text"
              value={supplierForm.servicesProvided}
              onChange={(e) => setSupplierForm({ ...supplierForm, servicesProvided: e.target.value })}
              placeholder="e.g. Tyres, MOT, Brake Overhauls"
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Contact Info (Phone / Email / Address)</label>
            <textarea
              value={supplierForm.contactDetails}
              onChange={(e) => setSupplierForm({ ...supplierForm, contactDetails: e.target.value })}
              rows={2}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsSupplierModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20"
            >
              Save Supplier
            </button>
          </div>
        </form>
      </Modal>

      {/* --- ACCIDENT MODAL --- */}
      <Modal
        isOpen={isAccidentModalOpen}
        onClose={() => setIsAccidentModalOpen(false)}
        title={editingAccident ? 'Edit Accident Report' : 'Report Fleet Incident & Claim'}
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleSaveAccident} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Incident Date</label>
              <input
                type="date"
                value={accidentForm.incidentDate}
                onChange={(e) => setAccidentForm({ ...accidentForm, incidentDate: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Vehicle</label>
              <select
                value={accidentForm.vehicleId}
                onChange={(e) => setAccidentForm({ ...accidentForm, vehicleId: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>{v.registration_number || v.equipment_code} - {v.model_number}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Driver Involved</label>
              <select
                value={accidentForm.driverId}
                onChange={(e) => setAccidentForm({ ...accidentForm, driverId: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="">Unassigned</option>
                {drivers.map((d) => (
                  <option key={d.id} value={d.id}>{d.full_name} ({d.driver_code})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Incident Type</label>
              <input
                type="text"
                value={accidentForm.incidentType}
                onChange={(e) => setAccidentForm({ ...accidentForm, incidentType: e.target.value })}
                placeholder="e.g. Minor Collision, Windscreen Damage"
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Claim #</label>
              <input
                type="text"
                value={accidentForm.claimNumber}
                onChange={(e) => setAccidentForm({ ...accidentForm, claimNumber: e.target.value })}
                placeholder="e.g. CLM-1092"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Claim Status</label>
              <select
                value={accidentForm.claimStatus}
                onChange={(e) => setAccidentForm({ ...accidentForm, claimStatus: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="Reported">Reported</option>
                <option value="Under Review">Under Review</option>
                <option value="Settled">Settled</option>
                <option value="Closed">Closed</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Actual Cost (£)</label>
              <input
                type="number"
                step="0.01"
                value={accidentForm.actualCost}
                onChange={(e) => setAccidentForm({ ...accidentForm, actualCost: parseFloat(e.target.value || 0) })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsAccidentModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-rose-600/20"
            >
              Save Claim Record
            </button>
          </div>
        </form>
      </Modal>

      {/* --- FUEL MODAL --- */}
      <Modal
        isOpen={isFuelModalOpen}
        onClose={() => setIsFuelModalOpen(false)}
        title={editingFuel ? 'Edit Refuel Entry' : 'Log Fuel Consumption Entry'}
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleSaveFuel} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Refuel Date</label>
              <input
                type="date"
                value={fuelForm.refuelDate}
                onChange={(e) => setFuelForm({ ...fuelForm, refuelDate: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Vehicle</label>
              <select
                value={fuelForm.vehicleId}
                onChange={(e) => setFuelForm({ ...fuelForm, vehicleId: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>{v.registration_number || v.equipment_code} - {v.model_number}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Driver / Courier</label>
              <select
                value={fuelForm.driverId}
                onChange={(e) => setFuelForm({ ...fuelForm, driverId: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="">General Fleet / Floater</option>
                {drivers.map((d) => (
                  <option key={d.id} value={d.id}>{d.full_name} ({d.driver_code})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Station / Provider Name</label>
              <input
                type="text"
                value={fuelForm.stationName}
                onChange={(e) => setFuelForm({ ...fuelForm, stationName: e.target.value })}
                placeholder="e.g. Shell Leicester, BP Hinckley"
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Liters Filled (L)</label>
              <input
                type="number"
                step="0.01"
                value={fuelForm.litersFilled}
                onChange={(e) => setFuelForm({ ...fuelForm, litersFilled: parseFloat(e.target.value || 0) })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Total Cost (£)</label>
              <input
                type="number"
                step="0.01"
                value={fuelForm.totalCost}
                onChange={(e) => setFuelForm({ ...fuelForm, totalCost: parseFloat(e.target.value || 0) })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Pump Odometer (mi)</label>
              <input
                type="number"
                step="0.1"
                value={fuelForm.odometerReading}
                onChange={(e) => setFuelForm({ ...fuelForm, odometerReading: parseFloat(e.target.value || 0) })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Fuel Card Ref / Receipt No.</label>
            <input
              type="text"
              value={fuelForm.fuelCardRef}
              onChange={(e) => setFuelForm({ ...fuelForm, fuelCardRef: e.target.value })}
              placeholder="e.g. ALLSTAR-88192"
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsFuelModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-emerald-600/20"
            >
              Save Refuel Record
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}