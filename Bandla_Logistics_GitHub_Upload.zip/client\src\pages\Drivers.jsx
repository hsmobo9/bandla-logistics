import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, Plus, Search, Filter, Edit, Trash2, Calendar, ShieldCheck, 
  AlertTriangle, CheckCircle2, XCircle, Power, UserCheck, Palmtree, ShieldAlert, FileWarning, Columns
} from 'lucide-react';
import { 
  getDrivers, getDepots, createDriver, updateDriver, toggleDriverActive, updateDriverStatus, deleteDriver,
  getDriverAvailability, createDriverAvailability, deleteDriverAvailability
} from '../services/api';
import Modal from '../components/Modal';
import ColumnVisibilityToggle from '../components/ColumnVisibilityToggle';
import { formatCurrency, formatNumber, formatDate } from '../utils/formatters';

const REGISTER_COLUMNS = [
  { key: 'name', label: 'Driver Name & DR Code' },
  { key: 'depot', label: 'Default Depot' },
  { key: 'vehicle', label: 'Assigned Vehicle & FD' },
  { key: 'license', label: 'License & DVLA Points' },
  { key: 'rtw', label: 'Right To Work & Expiry' },
  { key: 'vat', label: 'VAT Status (20%)' },
  { key: 'status', label: 'Active Status' }
];

const AUDIT_COLUMNS = [
  { key: 'missing', label: 'Docs Missing Badge' },
  { key: 'depot', label: 'Depot' },
  { key: 'dr_code', label: 'DR Code' },
  { key: 'driver_name', label: 'Driver Name' },
  { key: 'phone', label: 'Contact Phone' },
  { key: 'dl_status', label: 'DL Status' },
  { key: 'license_number', label: 'Licence No.' },
  { key: 'ni_number', label: 'NI No.' },
  { key: 'address', label: 'Home Address' },
  { key: 'passport', label: 'Passport' },
  { key: 'rtw', label: 'Right To Work' },
  { key: 'email', label: 'Email Address' }
];

export default function Drivers() {
  const [activeSubTab, setActiveSubTab] = useState('register'); // 'register' | 'audit' | 'holidays'
  const [drivers, setDrivers] = useState([]);
  const [depots, setDepots] = useState([]);
  const [availabilityList, setAvailabilityList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [includeInactive, setIncludeInactive] = useState(false);

  // Column Visibility States (persisted to localStorage)
  const [registerVisible, setRegisterVisible] = useState(() => {
    try {
      const saved = localStorage.getItem('drivers_reg_visible_cols');
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  const [auditVisible, setAuditVisible] = useState(() => {
    try {
      const saved = localStorage.getItem('drivers_audit_visible_cols');
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  // Driver Modal
  const [isDriverModalOpen, setIsDriverModalOpen] = useState(false);
  const [editingDriver, setEditingDriver] = useState(null);
  const [driverFormData, setDriverFormData] = useState({
    driverCode: '',
    fullName: '',
    phone: '',
    email: '',
    defaultDepotId: '',
    assignedVehicleReg: '',
    assignedFdNumber: '',
    licenseNumber: '',
    licenseExpiry: '',
    passDate: '',
    dvlaPoints: 0,
    niNumber: '',
    dob: '',
    address: '',
    passportNumber: '',
    passportExpiry: '',
    rightToWorkStatus: '',
    rightToWorkExpiry: '',
    sponsorRequired: false,
    isVatRegistered: false,
    vatNumber: '',
    status: 'active',
    isActive: true,
    notes: ''
  });

  // Holiday Modal
  const [isHolidayModalOpen, setIsHolidayModalOpen] = useState(false);
  const [holidayFormData, setHolidayFormData] = useState({
    driverId: '',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
    status: 'Holiday',
    notes: ''
  });

  useEffect(() => {
    loadData();
  }, [statusFilter, includeInactive, activeSubTab]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [dList, depList, availList] = await Promise.all([
        getDrivers({ status: statusFilter || undefined, includeInactive: includeInactive ? 'true' : 'false' }),
        getDepots(),
        getDriverAvailability()
      ]);
      setDrivers(dList);
      setDepots(depList);
      setAvailabilityList(availList);
    } catch (err) {
      console.error('Error loading driver data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenAddDriver = () => {
    setEditingDriver(null);
    setDriverFormData({
      driverCode: '',
      fullName: '',
      phone: '',
      email: '',
      defaultDepotId: depots[0]?.id || '',
      assignedVehicleReg: '',
      assignedFdNumber: '',
      licenseNumber: '',
      licenseExpiry: '',
      passDate: '',
      dvlaPoints: 0,
      niNumber: '',
      dob: '',
      address: '',
      passportNumber: '',
      passportExpiry: '',
      rightToWorkStatus: '',
      rightToWorkExpiry: '',
      sponsorRequired: false,
      isVatRegistered: false,
      vatNumber: '',
      status: 'active',
      isActive: true,
      notes: ''
    });
    setIsDriverModalOpen(true);
  };

  const handleOpenEditDriver = (driver) => {
    setEditingDriver(driver);
    setDriverFormData({
      driverCode: driver.driver_code || '',
      fullName: driver.full_name || '',
      phone: driver.phone || '',
      email: driver.email || '',
      defaultDepotId: driver.default_depot_id || '',
      assignedVehicleReg: driver.assigned_vehicle_reg || '',
      assignedFdNumber: driver.assigned_fd_number || '',
      licenseNumber: driver.license_number || '',
      licenseExpiry: driver.license_expiry ? driver.license_expiry.split('T')[0] : '',
      passDate: driver.pass_date ? driver.pass_date.split('T')[0] : '',
      dvlaPoints: driver.dvla_points || 0,
      niNumber: driver.ni_number || '',
      dob: driver.dob ? driver.dob.split('T')[0] : '',
      address: driver.address || '',
      passportNumber: driver.passport_number || '',
      passportExpiry: driver.passport_expiry ? driver.passport_expiry.split('T')[0] : '',
      rightToWorkStatus: driver.right_to_work_status || '',
      rightToWorkExpiry: driver.right_to_work_expiry ? driver.right_to_work_expiry.split('T')[0] : '',
      sponsorRequired: Boolean(driver.sponsor_required),
      isVatRegistered: Boolean(driver.is_vat_registered),
      vatNumber: driver.vat_number || '',
      status: driver.status || 'active',
      isActive: driver.is_active !== undefined ? driver.is_active : true,
      notes: driver.notes || ''
    });
    setIsDriverModalOpen(true);
  };

  const handleSaveDriver = async (e) => {
    e.preventDefault();
    try {
      if (editingDriver) {
        await updateDriver(editingDriver.id, driverFormData);
      } else {
        await createDriver(driverFormData);
      }
      setIsDriverModalOpen(false);
      loadData();
    } catch (err) {
      console.warn('Error saving driver: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleToggleDriverActive = async (id) => {
    try {
      await toggleDriverActive(id);
      if (!includeInactive) {
        setIncludeInactive(true);
      } else {
        loadData();
      }
    } catch (err) {
      console.warn('Error updating status: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleStatusChange = async (id, newStatus) => {
    try {
      const isAct = newStatus !== 'inactive';
      await updateDriverStatus(id, newStatus, isAct);
      loadData();
    } catch (err) {
      console.warn('Error updating status: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleSoftDelete = async (id) => {
    try {
      await deleteDriver(id);
      loadData();
    } catch (err) {
      console.warn('Error deactivating driver: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleOpenAddHoliday = () => {
    setHolidayFormData({
      driverId: drivers[0]?.id || '',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      status: 'Holiday',
      notes: ''
    });
    setIsHolidayModalOpen(true);
  };

  const handleSaveHoliday = async (e) => {
    e.preventDefault();
    try {
      await createDriverAvailability(holidayFormData);
      setIsHolidayModalOpen(false);
      loadData();
    } catch (err) {
      console.warn('Error logging availability: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDeleteHoliday = async (id) => {
    
    try {
      await deleteDriverAvailability(id);
      loadData();
    } catch (err) {
      console.warn('Error removing holiday: ' + (err.response?.data?.error || err.message));
    }
  };

  // Missing Documents Audit Computations
  const missingDrCount = useMemo(() => drivers.filter(d => !d.driver_code).length, [drivers]);
  const missingContactCount = useMemo(() => drivers.filter(d => !d.phone).length, [drivers]);
  const missingDlCount = useMemo(() => drivers.filter(d => !d.license_number).length, [drivers]);
  const missingNiCount = useMemo(() => drivers.filter(d => !d.ni_number).length, [drivers]);
  const missingAddressCount = useMemo(() => drivers.filter(d => !d.address).length, [drivers]);
  const missingRtwCount = useMemo(() => drivers.filter(d => !d.right_to_work_status || d.sponsor_required).length, [drivers]);

  // Depot breakdown
  const depotCounts = useMemo(() => {
    const map = new Map();
    drivers.forEach(d => {
      const dep = d.default_depot_name || 'Unassigned';
      map.set(dep, (map.get(dep) || 0) + 1);
    });
    return Array.from(map.entries()).map(([depot, count]) => ({ depot, count }));
  }, [drivers]);

  const getDriverMissingCount = (d) => {
    let count = 0;
    if (!d.driver_code) count++;
    if (!d.phone) count++;
    if (!d.license_number) count++;
    if (!d.ni_number) count++;
    if (!d.address) count++;
    if (!d.right_to_work_status) count++;
    if (!d.passport_number) count++;
    if (!d.email) count++;
    return count;
  };

  const filteredDrivers = drivers.filter(d => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      d.full_name?.toLowerCase().includes(q) ||
      d.driver_code?.toLowerCase().includes(q) ||
      d.assigned_vehicle_reg?.toLowerCase().includes(q) ||
      d.license_number?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Driver Personnel & Compliance Register</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Workforce compliance, RTW visa matrix, missing document audits & holiday planner</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {activeSubTab === 'register' || activeSubTab === 'audit' ? (
            <button
              onClick={handleOpenAddDriver}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Add Driver
            </button>
          ) : (
            <button
              onClick={handleOpenAddHoliday}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-amber-600/20 flex items-center gap-1.5 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" /> Log Holiday / Time-Off
            </button>
          )}
        </div>
      </div>

      {/* Sub-Tab Navigation */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveSubTab('register')}
          className={`pb-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer shrink-0 ${
            activeSubTab === 'register'
              ? 'border-blue-500 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <Users className="w-4 h-4" /> Driver Workforce Register ({filteredDrivers.length})
        </button>
        <button
          onClick={() => setActiveSubTab('audit')}
          className={`pb-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer shrink-0 ${
            activeSubTab === 'audit'
              ? 'border-rose-500 text-rose-600 dark:text-rose-400 font-bold'
              : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <FileWarning className="w-4 h-4" /> Missing Documents & Compliance Audit ({drivers.length})
        </button>
        <button
          onClick={() => setActiveSubTab('holidays')}
          className={`pb-3 px-4 text-xs font-bold transition-all border-b-2 flex items-center gap-2 cursor-pointer shrink-0 ${
            activeSubTab === 'holidays'
              ? 'border-amber-500 text-amber-600 dark:text-amber-400'
              : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300'
          }`}
        >
          <Palmtree className="w-4 h-4" /> Holiday & Unavailability Planner ({availabilityList.length})
        </button>
      </div>

      {activeSubTab === 'register' ? (
        <>
          {/* Search & Filters */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm dark:shadow-lg flex flex-wrap gap-4 items-center justify-between">
            <div className="relative flex-1 min-w-[280px]">
              <Search className="w-4 h-4 text-slate-500 dark:text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search driver by name, code, license, or vehicle reg..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-800 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <ColumnVisibilityToggle
                columns={REGISTER_COLUMNS}
                visibleColumns={registerVisible}
                onChange={setRegisterVisible}
                onReset={() => setRegisterVisible({})}
                storageKey="drivers_reg_visible_cols"
              />

              <label className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeInactive}
                  onChange={(e) => setIncludeInactive(e.target.checked)}
                  className="rounded bg-slate-50 dark:bg-slate-950 border-slate-700 text-blue-600 focus:ring-0"
                />
                <span>Include Inactive</span>
              </label>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 font-bold focus:outline-none focus:border-blue-500"
              >
                <option value="">All Operational Statuses</option>
                <option value="active">Active Available</option>
                <option value="on_leave">🌴 On Leave / Holiday</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>

          {/* Drivers Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
            {loading ? (
              <div className="p-12 text-center text-slate-500 dark:text-slate-400">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-2"></div>
                <span>Loading personnel records...</span>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      {registerVisible.name !== false && <th className="p-3.5">Driver Name / Code</th>}
                      {registerVisible.depot !== false && <th className="p-3.5">Default Depot</th>}
                      {registerVisible.vehicle !== false && <th className="p-3.5">Assigned Vehicle</th>}
                      {registerVisible.license !== false && <th className="p-3.5">License & DVLA</th>}
                      {registerVisible.rtw !== false && <th className="p-3.5">Right To Work (RTW)</th>}
                      {registerVisible.vat !== false && <th className="p-3.5 text-center">VAT (20%)</th>}
                      {registerVisible.status !== false && <th className="p-3.5 text-center">Active Status</th>}
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                    {filteredDrivers.map((d) => (
                      <tr key={d.id} className={`hover:bg-slate-50/80 dark:hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition ${!d.is_active ? 'opacity-50 bg-slate-50/60 dark:bg-slate-950/40' : ''}`}>
                        {registerVisible.name !== false && (
                          <td className="p-3.5">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-900 dark:text-white block text-sm">{d.full_name}</span>
                              {d.is_on_leave && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-black bg-amber-500/20 text-amber-600 dark:text-amber-300 border border-amber-500/40 animate-pulse">
                                  🌴 On Leave ({d.current_leave_type || 'Holiday'})
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-500 dark:text-slate-400">{d.driver_code || 'General Contractor'}</span>
                          </td>
                        )}
                        {registerVisible.depot !== false && (
                          <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium">{d.default_depot_name || '-'}</td>
                        )}
                        {registerVisible.vehicle !== false && (
                          <td className="p-3.5 text-slate-700 dark:text-slate-300">
                            <span className="block font-semibold text-slate-700 dark:text-slate-300">{d.assigned_vehicle_reg || '-'}</span>
                            <span className="text-[10px] text-slate-500">{d.assigned_fd_number || ''}</span>
                          </td>
                        )}
                        {registerVisible.license !== false && (
                          <td className="p-3.5 text-slate-700 dark:text-slate-300">
                            <div className="space-y-1">
                              <span className="block text-[11px] font-mono text-slate-700 dark:text-slate-300">{d.license_number || 'No Lic Recorded'}</span>
                              <div className="flex flex-wrap items-center gap-1.5">
                                {d.dvla_points > 0 ? (
                                  <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md shadow-sm ${
                                    d.dvla_points >= 6 
                                      ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/40 animate-pulse shadow-rose-500/20' 
                                      : 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/40 animate-pulse'
                                  }`}>
                                    ⚠️ {d.dvla_points} DVLA pts
                                  </span>
                                ) : (
                                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">0 pts (Clean)</span>
                                )}

                                {(() => {
                                  if (!d.license_expiry) return null;
                                  const days = Math.ceil((new Date(d.license_expiry) - new Date()) / (1000 * 60 * 60 * 24));
                                  if (days < 0) {
                                    return (
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-rose-500/20 text-rose-600 dark:text-rose-300 border border-rose-500/50 animate-pulse shadow-sm shadow-rose-500/30">
                                        🚨 Expired ({Math.abs(days)}d ago)
                                      </span>
                                    );
                                  }
                                  if (days <= 30) {
                                    return (
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/50 animate-pulse shadow-sm shadow-amber-500/20">
                                        ⚠️ Expiring ({days}d)
                                      </span>
                                    );
                                  }
                                  return (
                                    <span className="text-[10px] text-slate-500">Exp: {formatDate(d.license_expiry)}</span>
                                  );
                                })()}
                              </div>
                            </div>
                          </td>
                        )}
                        {registerVisible.rtw !== false && (
                          <td className="p-3.5 text-slate-700 dark:text-slate-300">
                            <div className="space-y-1">
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20">
                                {d.right_to_work_status || 'British Citizen'}
                              </span>
                              {d.sponsor_required && (
                                <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-black bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/40 animate-pulse block max-w-fit">
                                  ⚠️ Sponsor Req
                                </span>
                              )}
                              {d.right_to_work_expiry && (
                                <span className="text-[10px] text-slate-500 block">Exp: {formatDate(d.right_to_work_expiry)}</span>
                              )}
                            </div>
                          </td>
                        )}
                        {registerVisible.vat !== false && (
                          <td className="p-3.5 text-center">
                            {d.is_vat_registered ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                                20% ({d.vat_number || 'Registered'})
                              </span>
                            ) : (
                              <span className="text-slate-400 dark:text-slate-500 text-[10px]">No VAT</span>
                            )}
                          </td>
                        )}
                        {registerVisible.status !== false && (
                          <td className="p-3.5 text-center">
                            <button
                              onClick={() => handleToggleDriverActive(d.id)}
                              className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold transition cursor-pointer ${
                                d.is_active
                                  ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20'
                                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
                              }`}
                            >
                              <Power className="w-3 h-3" />
                              {d.is_active ? 'Active' : 'Inactive'}
                            </button>
                          </td>
                        )}
                        <td className="p-3.5 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleOpenEditDriver(d)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                              title="Edit Driver Profile"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleSoftDelete(d.id)}
                              className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-500/10 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-500/20 transition cursor-pointer"
                              title="Deactivate (Soft Delete)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      ) : activeSubTab === 'audit' ? (
        /* --- COMPLIANCE & MISSING DOCUMENTS AUDIT VIEW (MATCHES EXCEL SCREENSHOT) --- */
        <div className="space-y-6">
          {/* Top Audit KPI Cards (Matching Excel Sheet Top Summary) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Total Drivers</span>
              <p className="text-xl font-black text-slate-900 dark:text-white mt-1">{drivers.length}</p>
              <div className="text-[10px] text-slate-500 mt-1 space-y-0.5">
                {depotCounts.slice(0, 3).map(dc => (
                  <div key={dc.depot} className="flex justify-between">
                    <span>{dc.depot}:</span>
                    <strong className="text-slate-700 dark:text-slate-300">{dc.count}</strong>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/50 rounded-xl shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400 block">Missing DR Code</span>
              <p className="text-xl font-black text-rose-600 dark:text-rose-400 mt-1">{missingDrCount}</p>
              <span className="text-[10px] text-rose-500/80">Pending DR assignment</span>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">Missing Phone</span>
              <p className="text-xl font-black text-slate-900 dark:text-white mt-1">{missingContactCount}</p>
              <span className="text-[10px] text-slate-500">Contact unreachable</span>
            </div>

            <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 rounded-xl shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 block">Missing DL No.</span>
              <p className="text-xl font-black text-amber-600 dark:text-amber-400 mt-1">{missingDlCount}</p>
              <span className="text-[10px] text-amber-500/80">Driving licence unverified</span>
            </div>

            <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 rounded-xl shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 block">Missing NI No.</span>
              <p className="text-xl font-black text-amber-600 dark:text-amber-400 mt-1">{missingNiCount}</p>
              <span className="text-[10px] text-amber-500/80">HMRC NI pending</span>
            </div>

            <div className="p-4 bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/50 rounded-xl shadow-sm">
              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 block">Missing Address</span>
              <p className="text-xl font-black text-blue-600 dark:text-blue-400 mt-1">{missingAddressCount}</p>
              <span className="text-[10px] text-blue-500/80">Proof of residence</span>
            </div>
          </div>

          {/* Audit Table (With Red/Pink Highlight on Missing Fields) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <FileWarning className="w-4 h-4 text-rose-500" /> Courier Onboarding & Document Audit Ledger
                </h3>
                <p className="text-[11px] text-slate-500">Highlighted in pink/red where documents or compliance certificates are missing.</p>
              </div>
              <div className="flex items-center gap-3">
                <ColumnVisibilityToggle
                  columns={AUDIT_COLUMNS}
                  visibleColumns={auditVisible}
                  onChange={setAuditVisible}
                  onReset={() => setAuditVisible({})}
                  storageKey="drivers_audit_visible_cols"
                />
                <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Auditing <strong className="text-slate-900 dark:text-white">{filteredDrivers.length}</strong> couriers
                </span>
              </div>
            </div>

            <div className="overflow-x-auto max-h-[600px]">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800 sticky top-0">
                  <tr>
                    {auditVisible.missing !== false && <th className="p-3 text-center whitespace-nowrap min-w-[130px]">Docs Missing</th>}
                    {auditVisible.depot !== false && <th className="p-3 whitespace-nowrap min-w-[110px]">Depot</th>}
                    {auditVisible.dr_code !== false && <th className="p-3 whitespace-nowrap min-w-[100px]">DR Code</th>}
                    {auditVisible.driver_name !== false && <th className="p-3 whitespace-nowrap min-w-[170px]">Driver Name</th>}
                    {auditVisible.phone !== false && <th className="p-3 whitespace-nowrap min-w-[120px]">Contact Phone</th>}
                    {auditVisible.dl_status !== false && <th className="p-3 whitespace-nowrap min-w-[90px]">DL Status</th>}
                    {auditVisible.license_number !== false && <th className="p-3 whitespace-nowrap min-w-[130px]">Licence No.</th>}
                    {auditVisible.ni_number !== false && <th className="p-3 whitespace-nowrap min-w-[120px]">NI No.</th>}
                    {auditVisible.address !== false && <th className="p-3 whitespace-nowrap min-w-[200px]">Address</th>}
                    {auditVisible.passport !== false && <th className="p-3 whitespace-nowrap min-w-[110px]">Passport</th>}
                    {auditVisible.rtw !== false && <th className="p-3 whitespace-nowrap min-w-[150px]">Right To Work (RTW)</th>}
                    {auditVisible.email !== false && <th className="p-3 whitespace-nowrap min-w-[160px]">Email Address</th>}
                    <th className="p-3 text-right whitespace-nowrap min-w-[90px]">Quick Edit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900 font-sans">
                  {filteredDrivers.map((d) => {
                    const missingC = getDriverMissingCount(d);
                    const isMissing = missingC > 0;
                    return (
                      <tr 
                        key={d.id} 
                        className={`transition ${
                          isMissing 
                            ? 'bg-rose-50/40 hover:bg-rose-50/70 dark:bg-rose-950/10 dark:hover:bg-rose-950/20' 
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                        }`}
                      >
                        {auditVisible.missing !== false && (
                          <td className="p-3 text-center whitespace-nowrap min-w-[130px]">
                            {missingC > 0 ? (
                              <span className="inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-rose-500/20 text-rose-700 dark:text-rose-300 border border-rose-500/40 whitespace-nowrap shadow-sm shadow-rose-500/20">
                                <span>⚠️</span> {missingC} Missing
                              </span>
                            ) : (
                              <span className="inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 whitespace-nowrap">
                                <span>✅</span> 100% OK
                              </span>
                            )}
                          </td>
                        )}
                        {auditVisible.depot !== false && (
                          <td className="p-3 font-medium text-slate-700 dark:text-slate-300 whitespace-nowrap">{d.default_depot_name || 'Leicester'}</td>
                        )}
                        {auditVisible.dr_code !== false && (
                          <td className="p-3 font-mono whitespace-nowrap">
                            {d.driver_code ? (
                              <span className="font-bold text-slate-900 dark:text-white">{d.driver_code}</span>
                            ) : (
                              <span className="text-[10px] text-rose-500 italic">Missing DR</span>
                            )}
                          </td>
                        )}
                        {auditVisible.driver_name !== false && (
                          <td className="p-3 font-bold text-slate-900 dark:text-white whitespace-nowrap">{d.full_name}</td>
                        )}
                        {auditVisible.phone !== false && (
                          <td className="p-3 font-mono text-slate-700 dark:text-slate-300 whitespace-nowrap">
                            {d.phone || <span className="text-rose-500 italic text-[10px]">No Phone</span>}
                          </td>
                        )}
                        {auditVisible.dl_status !== false && (
                          <td className="p-3 whitespace-nowrap">
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                              Full UK
                            </span>
                          </td>
                        )}
                        {auditVisible.license_number !== false && (
                          <td className="p-3 font-mono text-slate-700 dark:text-slate-300 whitespace-nowrap">
                            {d.license_number || <span className="text-rose-500 italic text-[10px]">Missing DL</span>}
                          </td>
                        )}
                        {auditVisible.ni_number !== false && (
                          <td className="p-3 font-mono text-slate-700 dark:text-slate-300 whitespace-nowrap">
                            {d.ni_number || <span className="text-rose-500 italic text-[10px]">Missing NI</span>}
                          </td>
                        )}
                        {auditVisible.address !== false && (
                          <td className="p-3 text-slate-600 dark:text-slate-400 max-w-xs truncate">
                            {d.address || <span className="text-rose-500 italic text-[10px]">Missing Address</span>}
                          </td>
                        )}
                        {auditVisible.passport !== false && (
                          <td className="p-3 font-mono text-slate-700 dark:text-slate-300 whitespace-nowrap">
                            {d.passport_number || <span className="text-slate-400 text-[10px]">-</span>}
                          </td>
                        )}
                        {auditVisible.rtw !== false && (
                          <td className="p-3 whitespace-nowrap">
                            {d.right_to_work_status ? (
                              <div className="space-y-0.5">
                                <span className="text-[10px] font-bold block text-slate-900 dark:text-white">{d.right_to_work_status}</span>
                                {d.right_to_work_expiry && (
                                  <span className="text-[10px] text-slate-500 block font-mono">Exp: {formatDate(d.right_to_work_expiry)}</span>
                                )}
                              </div>
                            ) : (
                              <span className="text-rose-500 italic text-[10px]">Missing RTW</span>
                            )}
                          </td>
                        )}
                        {auditVisible.email !== false && (
                          <td className="p-3 text-slate-600 dark:text-slate-400 font-mono text-[11px] truncate max-w-xs">
                            {d.email || <span className="text-slate-400 text-[10px]">-</span>}
                          </td>
                        )}
                        <td className="p-3 text-right whitespace-nowrap">
                          <button
                            onClick={() => handleOpenEditDriver(d)}
                            className="p-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800 transition cursor-pointer"
                            title="Quick Edit & Fill In Missing Docs"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* Holiday & Availability View */
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden p-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <Palmtree className="w-4 h-4 text-amber-600 dark:text-amber-400" /> Scheduled Driver Holidays & Unavailability Blocks
            </h3>

            {availabilityList.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No holidays or unavailability blocks recorded yet. Click "Log Holiday / Time-Off" to add.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="p-3.5">Driver Name</th>
                      <th className="p-3.5">Depot</th>
                      <th className="p-3.5">Start Date</th>
                      <th className="p-3.5">End Date</th>
                      <th className="p-3.5 text-center">Status</th>
                      <th className="p-3.5">Notes</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
                    {availabilityList.map((a) => (
                      <tr key={a.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                        <td className="p-3.5 font-bold text-slate-900 dark:text-white">{a.driver_name}</td>
                        <td className="p-3.5 text-slate-700 dark:text-slate-300">{a.default_depot_name || '-'}</td>
                        <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium">{formatDate(a.start_date)}</td>
                        <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium">{formatDate(a.end_date)}</td>
                        <td className="p-3.5 text-center">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded text-[10px] font-bold ${
                            a.status === 'Holiday'
                              ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                              : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30'
                          }`}>
                            {a.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-500 dark:text-slate-400">{a.notes || '-'}</td>
                        <td className="p-3.5 text-right">
                          <button
                            onClick={() => handleDeleteHoliday(a.id)}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-500/10 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-500/20 transition cursor-pointer"
                            title="Delete Entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Driver Add/Edit Modal */}
      <Modal
        isOpen={isDriverModalOpen}
        onClose={() => setIsDriverModalOpen(false)}
        title={editingDriver ? `Edit Courier Profile: ${editingDriver.full_name}` : 'Add New Courier'}
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleSaveDriver} className="space-y-4 max-h-[80vh] overflow-y-auto pr-1">
          {/* Section 1: Personal & Contact */}
          <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 rounded-xl space-y-3">
            <h4 className="text-xs font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
              <Users className="w-4 h-4" /> Personal & Contact Details
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Full Name *</label>
                <input
                  type="text"
                  value={driverFormData.fullName}
                  onChange={(e) => setDriverFormData({ ...driverFormData, fullName: e.target.value })}
                  required
                  placeholder="e.g. Ashutosh Rana"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Driver Code (DR ID)</label>
                <input
                  type="text"
                  value={driverFormData.driverCode}
                  onChange={(e) => setDriverFormData({ ...driverFormData, driverCode: e.target.value })}
                  placeholder="e.g. DR65461"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Contact Phone Number</label>
                <input
                  type="text"
                  value={driverFormData.phone}
                  onChange={(e) => setDriverFormData({ ...driverFormData, phone: e.target.value })}
                  placeholder="e.g. 447768250071"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Email Address</label>
                <input
                  type="email"
                  value={driverFormData.email}
                  onChange={(e) => setDriverFormData({ ...driverFormData, email: e.target.value })}
                  placeholder="e.g. courier@bandlalogistics.co.uk"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Default Regional Depot</label>
                <select
                  value={driverFormData.defaultDepotId}
                  onChange={(e) => setDriverFormData({ ...driverFormData, defaultDepotId: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="">None / Floating Depot</option>
                  {depots.map(dep => (
                    <option key={dep.id} value={dep.id}>{dep.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Assigned Vehicle Reg</label>
                <input
                  type="text"
                  value={driverFormData.assignedVehicleReg}
                  onChange={(e) => setDriverFormData({ ...driverFormData, assignedVehicleReg: e.target.value })}
                  placeholder="e.g. DS74 GWE"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Driving License & DVLA Compliance */}
          <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 rounded-xl space-y-3">
            <h4 className="text-xs font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" /> Driving License & DVLA Compliance
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Driving License Number</label>
                <input
                  type="text"
                  value={driverFormData.licenseNumber}
                  onChange={(e) => setDriverFormData({ ...driverFormData, licenseNumber: e.target.value })}
                  placeholder="e.g. SMITH901015AB9CD"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">License Expiry Date</label>
                <input
                  type="date"
                  value={driverFormData.licenseExpiry}
                  onChange={(e) => setDriverFormData({ ...driverFormData, licenseExpiry: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Test Pass Date</label>
                <input
                  type="date"
                  value={driverFormData.passDate}
                  onChange={(e) => setDriverFormData({ ...driverFormData, passDate: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">DVLA Points on License</label>
                <input
                  type="number"
                  min="0"
                  max="12"
                  value={driverFormData.dvlaPoints}
                  onChange={(e) => setDriverFormData({ ...driverFormData, dvlaPoints: parseInt(e.target.value) || 0 })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Section 3: HMRC & Proof of Residence */}
          <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 rounded-xl space-y-3">
            <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4" /> HMRC & Proof of Residence
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">National Insurance (NI) Number</label>
                <input
                  type="text"
                  value={driverFormData.niNumber}
                  onChange={(e) => setDriverFormData({ ...driverFormData, niNumber: e.target.value })}
                  placeholder="e.g. QQ 12 34 56 A"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Date of Birth (DOB)</label>
                <input
                  type="date"
                  value={driverFormData.dob}
                  onChange={(e) => setDriverFormData({ ...driverFormData, dob: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Home Address / Proof of Residence</label>
              <textarea
                value={driverFormData.address}
                onChange={(e) => setDriverFormData({ ...driverFormData, address: e.target.value })}
                rows={2}
                placeholder="e.g. 14 High Street, Leicester, LE1 4AA"
                className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Section 4: Right to Work (RTW) & Immigration Compliance */}
          <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 rounded-xl space-y-3">
            <h4 className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
              <UserCheck className="w-4 h-4" /> Right to Work (RTW) & Immigration Compliance
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Passport Number</label>
                <input
                  type="text"
                  value={driverFormData.passportNumber}
                  onChange={(e) => setDriverFormData({ ...driverFormData, passportNumber: e.target.value })}
                  placeholder="e.g. 523849102"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Passport Expiry Date</label>
                <input
                  type="date"
                  value={driverFormData.passportExpiry}
                  onChange={(e) => setDriverFormData({ ...driverFormData, passportExpiry: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Right to Work Status</label>
                <select
                  value={driverFormData.rightToWorkStatus}
                  onChange={(e) => setDriverFormData({ ...driverFormData, rightToWorkStatus: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-bold focus:outline-none focus:border-emerald-500"
                >
                  <option value="">Select RTW Status...</option>
                  <option value="British Citizen">🇬🇧 British Citizen / Passport</option>
                  <option value="EU Settlement">🇪🇺 EU Settlement</option>
                  <option value="Visa - Student">🎓 Visa - Student</option>
                  <option value="Visa - PSW">⚡ Visa - PSW</option>
                  <option value="Visa - Skilled Worker">🛂 Visa - Skilled Worker</option>
                  <option value="Further Leave To Remain">📑 Further Leave To Remain</option>
                  <option value="Under Review">🔍 Under Review</option>
                  <option value="None">None / RTW - TBC</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">RTW Visa Expiry Date</label>
                <input
                  type="date"
                  value={driverFormData.rightToWorkExpiry}
                  onChange={(e) => setDriverFormData({ ...driverFormData, rightToWorkExpiry: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <label className="flex items-center gap-2 pt-1 cursor-pointer">
              <input
                type="checkbox"
                checked={driverFormData.sponsorRequired}
                onChange={(e) => setDriverFormData({ ...driverFormData, sponsorRequired: e.target.checked })}
                className="rounded bg-white dark:bg-slate-900 border-slate-700 text-rose-600 focus:ring-0"
              />
              <span className="text-xs font-bold text-rose-600 dark:text-rose-400">⚠️ Employer Sponsorship Required</span>
            </label>
          </div>

          {/* Section 5: Contractor Tax & Accounting */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={driverFormData.isVatRegistered}
                onChange={(e) => setDriverFormData({ ...driverFormData, isVatRegistered: e.target.checked })}
                className="rounded bg-white dark:bg-slate-900 border-slate-700 text-blue-600 focus:ring-0"
              />
              <span className="text-xs font-bold text-slate-900 dark:text-white">VAT Registered Contractor (20% Applied)</span>
            </label>
            {driverFormData.isVatRegistered && (
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">VAT Registration Number</label>
                <input
                  type="text"
                  value={driverFormData.vatNumber}
                  onChange={(e) => setDriverFormData({ ...driverFormData, vatNumber: e.target.value })}
                  placeholder="e.g. GB123456789"
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsDriverModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg shadow-lg shadow-blue-600/20 transition cursor-pointer"
            >
              {editingDriver ? 'Save Courier Compliance Profile' : 'Create Courier'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Holiday / Availability Modal */}
      <Modal
        isOpen={isHolidayModalOpen}
        onClose={() => setIsHolidayModalOpen(false)}
        title="Log Driver Holiday / Unavailability"
        maxWidth="max-w-md"
      >
        <form onSubmit={handleSaveHoliday} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Select Driver</label>
            <select
              value={holidayFormData.driverId}
              onChange={(e) => setHolidayFormData({ ...holidayFormData, driverId: e.target.value })}
              required
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            >
              {drivers.map(d => (
                <option key={d.id} value={d.id}>{d.full_name} ({d.default_depot_name || 'No Depot'})</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Start Date</label>
              <input
                type="date"
                value={holidayFormData.startDate}
                onChange={(e) => setHolidayFormData({ ...holidayFormData, startDate: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-800 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">End Date</label>
              <input
                type="date"
                value={holidayFormData.endDate}
                onChange={(e) => setHolidayFormData({ ...holidayFormData, endDate: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-800 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Unavailability Type</label>
            <select
              value={holidayFormData.status}
              onChange={(e) => setHolidayFormData({ ...holidayFormData, status: e.target.value })}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 font-medium"
            >
              <option value="Annual Leave">Annual Leave / Approved Holiday</option>
              <option value="Day Off">Scheduled Day Off / Rota Rest</option>
              <option value="Sick Leave">Sick Leave / Medical Absence</option>
              <option value="Personal Leave">Personal / Emergency Leave</option>
              <option value="Training">Depot Courier Training / Induction</option>
              <option value="Vehicle Issue">Vehicle Breakdown / Maintenance</option>
              <option value="Unavailable">Other Unavailable / Blocked</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Notes / Reason (Optional)</label>
            <textarea
              rows="2"
              value={holidayFormData.notes}
              onChange={(e) => setHolidayFormData({ ...holidayFormData, notes: e.target.value })}
              placeholder="e.g. Approved leave request..."
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-800 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsHolidayModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-amber-600/20 transition cursor-pointer"
            >
              Log Holiday
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}