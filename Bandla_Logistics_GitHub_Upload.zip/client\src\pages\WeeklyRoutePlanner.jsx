import React, { useState, useEffect } from 'react';
import { 
  Calendar, ChevronLeft, ChevronRight, Plus, MapPin, Truck, 
  User, CheckCircle2, AlertTriangle, AlertCircle, Clock, Save, 
  Trash2, Filter, Sparkles, Palmtree, Users, LayoutGrid, ListFilter
} from 'lucide-react';
import { 
  getShifts, createShift, updateShift, deleteShift, 
  getDrivers, getVehicles, getDepots, getRouteRates, 
  getDriverAvailability 
} from '../services/api';
import Modal from '../components/Modal';
import { formatDate } from '../utils/formatters';

export default function WeeklyRoutePlanner() {
  const [currentMonday, setCurrentMonday] = useState(() => {
    const d = new Date();
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Adjust when Sunday
    const mon = new Date(d.setDate(diff));
    mon.setHours(0, 0, 0, 0);
    return mon;
  });

  const [activeView, setActiveView] = useState('grid'); // 'grid' | 'matrix'
  const [depotFilter, setDepotFilter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [depots, setDepots] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [routeRates, setRouteRates] = useState([]);
  const [availability, setAvailability] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [loading, setLoading] = useState(true);

  // Quick Shift Allocation Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingShift, setEditingShift] = useState(null);
  const [targetDate, setTargetDate] = useState('');
  const [modalError, setModalError] = useState(null);

  const [shiftForm, setShiftForm] = useState({
    shiftDate: '',
    driverId: '',
    vehicleId: '',
    depotId: '',
    routeCode: '',
    dispatchedStops: 120,
    paidStops: 120,
    totalParcels: 135,
    appliedBaseRate: 1.00,
    notes: ''
  });

  // Calculate 7 days from current Monday (Mon to Sun)
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(currentMonday);
    d.setDate(d.getDate() + i);
    return {
      dateObj: d,
      dateStr: d.toISOString().split('T')[0],
      dayName: d.toLocaleDateString('en-GB', { weekday: 'short' }),
      formattedDate: d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
      isToday: new Date().toISOString().split('T')[0] === d.toISOString().split('T')[0]
    };
  });

  const startDateStr = weekDays[0].dateStr;
  const endDateStr = weekDays[6].dateStr;

  useEffect(() => {
    loadWeekData();
  }, [currentMonday, depotFilter]);

  const loadWeekData = async () => {
    try {
      setLoading(true);
      const [depList, dList, vList, rList, availList, shiftList] = await Promise.all([
        getDepots(),
        getDrivers({ includeInactive: 'false' }),
        getVehicles({ includeInactive: 'false' }),
        getRouteRates(),
        getDriverAvailability({ startDate: startDateStr, endDate: endDateStr }),
        getShifts({ startDate: startDateStr, endDate: endDateStr, depotId: depotFilter || undefined })
      ]);

      setDepots(depList);
      setDrivers(dList);
      setVehicles(vList);
      setRouteRates(rList);
      setAvailability(availList);
      setShifts(shiftList);
    } catch (err) {
      console.error('Error loading weekly planner:', err);
    } finally {
      setLoading(false);
    }
  };

  const handlePrevWeek = () => {
    const prev = new Date(currentMonday);
    prev.setDate(prev.getDate() - 7);
    setCurrentMonday(prev);
  };

  const handleNextWeek = () => {
    const next = new Date(currentMonday);
    next.setDate(next.getDate() + 7);
    setCurrentMonday(next);
  };

  const handleCurrentWeek = () => {
    const d = new Date();
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    const mon = new Date(d.setDate(diff));
    mon.setHours(0, 0, 0, 0);
    setCurrentMonday(mon);
  };

  const handleOpenAssignModal = (dateStr, existingShift = null, preSelectedDriverId = null) => {
    setTargetDate(dateStr);
    setEditingShift(existingShift);
    setModalError(null);

    if (existingShift) {
      setShiftForm({
        shiftDate: existingShift.shift_date ? existingShift.shift_date.split('T')[0] : dateStr,
        driverId: existingShift.driver_id || '',
        vehicleId: existingShift.vehicle_id || '',
        depotId: existingShift.depot_id || depots[0]?.id || '',
        routeCode: existingShift.route_code || 'LEI-01',
        dispatchedStops: existingShift.dispatched_stops || 120,
        paidStops: existingShift.paid_stops || 120,
        totalParcels: existingShift.total_parcels || 135,
        appliedBaseRate: parseFloat(existingShift.applied_base_rate || 1.00),
        notes: existingShift.notes || ''
      });
    } else {
      const defaultDep = depotFilter || depots[0]?.id || '';
      const depObj = depots.find(d => d.id === defaultDep);
      const depCode = depObj?.code || depObj?.name?.slice(0, 3).toUpperCase() || 'LEI';
      const matchedRate = routeRates.find(r => r.depot_id === defaultDep) || routeRates[0];
      const chosenDriver = preSelectedDriverId ? drivers.find(d => d.id === preSelectedDriverId) : null;
      const matchedVeh = chosenDriver?.assigned_vehicle_reg 
        ? vehicles.find(v => v.registration_number === chosenDriver.assigned_vehicle_reg)
        : vehicles[0];

      setShiftForm({
        shiftDate: dateStr,
        driverId: preSelectedDriverId || (drivers.length > 0 ? drivers[0].id : ''),
        vehicleId: matchedVeh?.id || vehicles[0]?.id || '',
        depotId: defaultDep,
        routeCode: matchedRate?.route_code || `${depCode}-01`,
        dispatchedStops: 120,
        paidStops: 120,
        totalParcels: 135,
        appliedBaseRate: parseFloat(routeRates[0]?.base_rate_per_stop || 1.00),
        notes: ''
      });
    }
    setIsModalOpen(true);
  };

  const handleSaveShift = async (e) => {
    e.preventDefault();
    setModalError(null);
    try {
      if (!shiftForm.driverId) {
        setModalError('Please select a driver for this shift.');
        return;
      }

      // Pre-check holiday block
      const isBlocked = availability.find(a => {
        const start = a.start_date ? a.start_date.split('T')[0] : '';
        const end = a.end_date ? a.end_date.split('T')[0] : '';
        return a.driver_id === shiftForm.driverId && start <= shiftForm.shiftDate && end >= shiftForm.shiftDate;
      });

      if (isBlocked) {
        setModalError(`Cannot assign shift: Driver is on ${isBlocked.status} (${isBlocked.notes || 'Approved Leave'}).`);
        return;
      }

      if (editingShift) {
        await updateShift(editingShift.id, shiftForm);
      } else {
        await createShift(shiftForm);
      }
      setIsModalOpen(false);
      loadWeekData();
    } catch (err) {
      const msg = err.response?.data?.error || err.message || 'Error saving shift assignment';
      setModalError(msg);
    }
  };

  const handleDeleteShift = async (shiftId) => {
    try {
      await deleteShift(shiftId);
      loadWeekData();
    } catch (err) {
      console.warn('Error unassigning shift: ' + (err.response?.data?.error || err.message));
    }
  };

  // Helper to categorize driver status for a given target date
  const getDriverAvailabilityStatus = (driver, dateStr, currentShiftId = null) => {
    // 1. Check if driver is on Holiday or marked Unavailable
    const offBlock = availability.find(a => {
      const start = a.start_date ? a.start_date.split('T')[0] : '';
      const end = a.end_date ? a.end_date.split('T')[0] : '';
      return a.driver_id === driver.id && start <= dateStr && end >= dateStr;
    });

    if (offBlock) {
      return {
        status: 'blocked',
        label: `🔴 ${offBlock.status} (${offBlock.notes || 'Time Off'})`,
        shortLabel: offBlock.status,
        disabled: true,
        bgClass: 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800'
      };
    }

    // 2. Check if driver is already allocated to another shift on dateStr
    const existingShift = shifts.find(s => 
      s.driver_id === driver.id && 
      (s.shift_date ? s.shift_date.split('T')[0] : '') === dateStr &&
      s.id !== currentShiftId
    );

    if (existingShift) {
      return {
        status: 'allocated',
        label: `🟡 Allocated (${existingShift.route_code || 'Active Route'})`,
        shortLabel: existingShift.route_code || 'Shift',
        shift: existingShift,
        disabled: false,
        bgClass: 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800'
      };
    }

    // 3. Driver is Available
    return {
      status: 'available',
      label: '🟢 Available',
      shortLabel: 'Available',
      disabled: false,
      bgClass: 'text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800'
    };
  };

  // Grouped drivers for Assign Modal
  const getCategorizedDriversForDate = (dateStr, currentShiftId = null) => {
    const available = [];
    const allocated = [];
    const blocked = [];

    drivers.forEach(d => {
      const status = getDriverAvailabilityStatus(d, dateStr, currentShiftId);
      if (status.status === 'blocked') blocked.push({ driver: d, status });
      else if (status.status === 'allocated') allocated.push({ driver: d, status });
      else available.push({ driver: d, status });
    });

    return { available, allocated, blocked };
  };

  // Selected Depot Object
  const selectedDepot = depots.find(dep => dep.id === depotFilter);

  // Dynamic Driver Workforce Filtered by Selected Depot
  const visibleDrivers = depotFilter 
    ? drivers.filter(d => d.default_depot_id === depotFilter || shifts.some(s => s.driver_id === d.id))
    : drivers;

  // Filtered drivers for Matrix view with search
  const filteredMatrixDrivers = visibleDrivers.filter(d => {
    const matchSearch = !searchQuery || 
      d.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) || 
      d.driver_code?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchSearch;
  });

  // Calculate live stats for today / this week for the selected Depot scope
  const todayStr = new Date().toISOString().split('T')[0];
  const activeWeekShiftsCount = shifts.length;
  
  const visibleDriverIds = new Set(visibleDrivers.map(d => d.id));
  const todayLeavesCount = availability.filter(a => {
    const start = a.start_date ? a.start_date.split('T')[0] : '';
    const end = a.end_date ? a.end_date.split('T')[0] : '';
    return visibleDriverIds.has(a.driver_id) && start <= todayStr && end >= todayStr;
  }).length;

  const todayShiftsCount = shifts.filter(s => (s.shift_date ? s.shift_date.split('T')[0] : '') === todayStr).length;
  const todayAvailableCount = Math.max(0, visibleDrivers.length - todayLeavesCount - todayShiftsCount);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Multi-Depot Weekly Route Planner</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Monday to Sunday dispatch rota with smart holiday checks & live driver allocation badges
            </p>
          </div>
        </div>

        {/* View Switcher, Week Navigator & Depot Selector */}
        <div className="flex flex-wrap items-center gap-3">
          {/* View Mode Toggle */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-1">
            <button
              onClick={() => setActiveView('grid')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                activeView === 'grid' 
                  ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-white shadow-sm' 
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" /> 7-Day Grid
            </button>
            <button
              onClick={() => setActiveView('matrix')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                activeView === 'matrix' 
                  ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-white shadow-sm' 
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" /> {drivers?.length || 0}-Driver Roster Matrix
            </button>
          </div>

          <select
            value={depotFilter}
            onChange={(e) => setDepotFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500 font-medium"
          >
            <option value="">All Regional Depots</option>
            {depots.map(dep => (
              <option key={dep.id} value={dep.id}>{dep.name}</option>
            ))}
          </select>

          <div className="flex items-center bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-0.5">
            <button
              onClick={handlePrevWeek}
              className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg transition cursor-pointer"
              title="Previous Week"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleCurrentWeek}
              className="px-3 py-1 text-xs font-semibold text-slate-700 hover:text-slate-900 dark:text-slate-200 dark:hover:text-white transition cursor-pointer"
            >
              This Week
            </button>
            <button
              onClick={handleNextWeek}
              className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg transition cursor-pointer"
              title="Next Week"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Live Rota Stats & Legend Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-2xl shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400">
              {selectedDepot ? `${selectedDepot.name} Workforce` : 'Total Workforce'}
            </span>
            <p className="text-lg font-black text-slate-900 dark:text-white">{visibleDrivers.length} Couriers</p>
          </div>
          <Users className="w-6 h-6 text-slate-500 dark:text-slate-400" />
        </div>

        <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-800/40 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-400">🟢 Available Today</span>
            <p className="text-lg font-black text-emerald-700 dark:text-emerald-300">{todayAvailableCount} Ready for Route</p>
          </div>
          <span className="flex h-3 w-3 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
          </span>
        </div>

        <div className="p-3 bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-800/40 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-amber-600 dark:text-amber-400">🟡 Allocated Routes</span>
            <p className="text-lg font-black text-amber-700 dark:text-amber-300">{activeWeekShiftsCount} Scheduled This Week</p>
          </div>
          <Truck className="w-6 h-6 text-amber-500" />
        </div>

        <div className="p-3 bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200/80 dark:border-rose-800/40 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-rose-600 dark:text-rose-400">🔴 On Holiday / Leave</span>
            <p className="text-lg font-black text-rose-700 dark:text-rose-300">{availability.length} Active Time-Off Blocks</p>
          </div>
          <Palmtree className="w-6 h-6 text-rose-500" />
        </div>
      </div>

      {/* Week Date Banner & Legend */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 px-4 py-3 rounded-xl shadow-sm flex flex-wrap items-center justify-between gap-3 text-xs">
        <span className="text-slate-600 dark:text-slate-400 font-medium">
          Rota Period: <strong className="text-slate-900 dark:text-white font-mono">{formatDate(startDateStr)} — {formatDate(endDateStr)}</strong>
        </span>
        <div className="flex flex-wrap items-center gap-4 text-[11px] font-semibold">
          <span className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block shadow-sm"></span> Available
          </span>
          <span className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block shadow-sm"></span> Allocated to Route
          </span>
          <span className="flex items-center gap-1.5 text-rose-600 dark:text-rose-400">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block shadow-sm"></span> On Holiday / Blocked
          </span>
        </div>
      </div>

      {/* VIEW 1: 7-DAY DISPATCH GRID VIEW */}
      {activeView === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
          {weekDays.map((day) => {
            const dayShifts = shifts.filter(s => (s.shift_date ? s.shift_date.split('T')[0] : '') === day.dateStr);
            const dayLeaves = availability.filter(a => {
              const start = a.start_date ? a.start_date.split('T')[0] : '';
              const end = a.end_date ? a.end_date.split('T')[0] : '';
              return visibleDriverIds.has(a.driver_id) && start <= day.dateStr && end >= day.dateStr;
            });

            return (
              <div 
                key={day.dateStr}
                className={`bg-white dark:bg-slate-900 border rounded-2xl p-3 flex flex-col min-h-[520px] shadow-sm dark:shadow-lg transition-all ${
                  day.isToday ? 'border-blue-500/80 ring-1 ring-blue-500/40 bg-blue-50/20 dark:bg-slate-900/95' : 'border-slate-200/80 dark:border-slate-800'
                }`}
              >
                {/* Day Header */}
                <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-200/80 dark:border-slate-800">
                  <div>
                    <span className={`text-xs font-black uppercase tracking-wider block ${
                      day.isToday ? 'text-blue-600 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400'
                    }`}>
                      {day.dayName}
                    </span>
                    <span className="text-sm font-bold text-slate-900 dark:text-white font-mono">{day.formattedDate}</span>
                  </div>
                  <button
                    onClick={() => handleOpenAssignModal(day.dateStr)}
                    className="p-1 rounded-lg bg-blue-600/10 hover:bg-blue-600 text-blue-600 hover:text-white dark:bg-blue-500/20 dark:text-blue-600 dark:text-blue-400 dark:hover:text-white transition cursor-pointer"
                    title={`Assign route on ${day.dayName}`}
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Holiday / Leave Notice Banner */}
                {dayLeaves.length > 0 && (
                  <div className="mb-2 p-2 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/80 rounded-xl space-y-1">
                    <span className="text-[10px] font-black text-rose-700 dark:text-rose-600 dark:text-rose-400 flex items-center gap-1">
                      <Palmtree className="w-3 h-3" /> On Leave ({dayLeaves.length})
                    </span>
                    {dayLeaves.map(l => (
                      <div key={l.id} className="text-[10px] font-semibold text-rose-800 dark:text-rose-300 truncate flex items-center justify-between">
                        <span>• {l.driver_name}</span>
                        <span className="text-[9px] px-1 bg-rose-200/60 dark:bg-rose-900/60 rounded">{l.status}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Rota Shift Cards */}
                <div className="space-y-2.5 flex-1 overflow-y-auto pr-0.5">
                  {dayShifts.length === 0 ? (
                    <div className="h-48 flex flex-col items-center justify-center text-center p-4 border border-dashed border-slate-200 dark:border-slate-800/80 rounded-xl text-slate-400 dark:text-slate-600 text-[11px]">
                      <span>No routes allocated</span>
                      <button
                        onClick={() => handleOpenAssignModal(day.dateStr)}
                        className="mt-2 text-blue-600 dark:text-blue-400 font-bold hover:underline cursor-pointer"
                      >
                        + Assign Route
                      </button>
                    </div>
                  ) : (
                    dayShifts.map((s) => (
                      <div 
                        key={s.id}
                        className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 rounded-xl hover:border-slate-400 dark:hover:border-slate-700 transition group shadow-sm"
                      >
                        <div className="flex items-start justify-between gap-1 mb-1.5">
                          <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 font-mono px-1.5 py-0.2 bg-blue-50 dark:bg-blue-950/40 rounded border border-blue-200 dark:border-blue-800">
                            {s.route_code || 'UNASSIGNED'}
                          </span>
                          <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                            <button
                              onClick={() => handleOpenAssignModal(day.dateStr, s)}
                              className="text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white text-[10px] font-semibold cursor-pointer"
                              title="Edit Assignment"
                            >
                              Edit
                            </button>
                            <span className="text-slate-500 dark:text-slate-400">•</span>
                            <button
                              onClick={() => handleDeleteShift(s.id)}
                              className="text-rose-500 hover:text-rose-600 text-[10px] font-semibold cursor-pointer"
                              title="Unassign Route"
                            >
                              Remove
                            </button>
                          </div>
                        </div>

                        <span className="block text-xs font-bold text-slate-900 dark:text-white truncate">{s.driver_name || 'Assigned Driver'}</span>
                        <div className="flex items-center gap-1.5 text-[10px] text-slate-500 dark:text-slate-400 mt-1">
                          <Truck className="w-3 h-3 text-slate-500 dark:text-slate-400 shrink-0" />
                          <span className="font-mono truncate">{s.assigned_vehicle_reg || 'No Van'}</span>
                        </div>

                        <div className="flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400 mt-2 pt-1.5 border-t border-slate-200 dark:border-slate-800">
                          <span>Stops: <strong className="text-slate-900 dark:text-white">{s.dispatched_stops || 0}</strong></span>
                          <span>Parcels: <strong className="text-slate-900 dark:text-white">{s.total_parcels || 0}</strong></span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* VIEW 2: 55-DRIVER AVAILABILITY & ROTA MATRIX */}
      {activeView === 'matrix' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm p-4 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Live Workforce Roster & Route Matrix</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Full 7-day status of all registered drivers ({filteredMatrixDrivers.length} drivers). Click any Available cell to assign.
              </p>
            </div>
            <div className="w-full sm:w-64">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search driver by name or code..."
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="p-3 sticky left-0 bg-slate-100 dark:bg-slate-950 z-10">Driver Name</th>
                  <th className="p-3">Code</th>
                  <th className="p-3">Assigned Van</th>
                  {weekDays.map(d => (
                    <th key={d.dateStr} className={`p-3 text-center ${d.isToday ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400' : ''}`}>
                      {d.dayName} <span className="block text-[9px] font-normal font-mono">{d.formattedDate}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                {filteredMatrixDrivers.map((driver) => (
                  <tr key={driver.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition">
                    <td className="p-3 font-semibold text-slate-900 dark:text-white sticky left-0 bg-white dark:bg-slate-900 z-10 border-r border-slate-200 dark:border-slate-800">
                      {driver.full_name}
                      {driver.is_vat_registered && (
                        <span className="ml-1.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800">
                          VAT
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-slate-500 font-mono text-[11px]">{driver.driver_code || '-'}</td>
                    <td className="p-3 text-slate-600 dark:text-slate-300 font-mono text-[11px]">{driver.assigned_vehicle_reg || 'Own'}</td>
                    
                    {weekDays.map(d => {
                      const avail = getDriverAvailabilityStatus(driver, d.dateStr);

                      if (avail.status === 'blocked') {
                        return (
                          <td key={d.dateStr} className="p-2 text-center">
                            <span 
                              className="inline-block px-2 py-1 rounded-lg text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300 dark:border-rose-800 shadow-sm"
                              title={avail.label}
                            >
                              🔴 {avail.shortLabel}
                            </span>
                          </td>
                        );
                      }

                      if (avail.status === 'allocated') {
                        return (
                          <td key={d.dateStr} className="p-2 text-center">
                            <button
                              onClick={() => handleOpenAssignModal(d.dateStr, avail.shift)}
                              className="px-2 py-1 rounded-lg text-[10px] font-bold bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-800 shadow-sm hover:brightness-105 transition cursor-pointer"
                              title="Click to edit shift allocation"
                            >
                              🟡 {avail.shortLabel}
                            </button>
                          </td>
                        );
                      }

                      return (
                        <td key={d.dateStr} className="p-2 text-center">
                          <button
                            onClick={() => handleOpenAssignModal(d.dateStr, null, driver.id)}
                            className="px-2 py-1 rounded-lg text-[10px] font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition cursor-pointer"
                            title="Click to assign route to this driver"
                          >
                            🟢 Available
                          </button>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Quick Shift Assignment Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingShift ? 'Edit Route Allocation' : `Assign Route on ${formatDate(targetDate)}`}
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleSaveShift} className="space-y-4">
          {modalError && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/80 rounded-xl flex items-start gap-2.5 text-xs text-rose-700 dark:text-rose-300 animate-fadeIn">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600 dark:text-rose-400" />
              <div>
                <p className="font-bold">Assignment Blocked</p>
                <p className="mt-0.5">{modalError}</p>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
              Select Driver <span className="text-rose-500">* (Holiday & Allocated Status Enforced)</span>
            </label>
            {(() => {
              const { available, allocated, blocked } = getCategorizedDriversForDate(targetDate, editingShift?.id);

              return (
                <select
                  value={shiftForm.driverId}
                  onChange={(e) => {
                    setModalError(null);
                    const selId = e.target.value;
                    const dObj = drivers.find(d => d.id === selId);
                    const matchedVeh = dObj?.assigned_vehicle_reg ? vehicles.find(v => v.registration_number === dObj.assigned_vehicle_reg) : null;
                    setShiftForm(prev => ({
                      ...prev,
                      driverId: selId,
                      vehicleId: matchedVeh?.id || prev.vehicleId
                    }));
                  }}
                  required
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 font-medium"
                >
                  <option value="">-- Choose Available Courier Driver --</option>
                  
                  {available.length > 0 && (
                    <optgroup label={`🟢 Available Couriers (${available.length})`}>
                      {available.map(({ driver, status }) => (
                        <option key={driver.id} value={driver.id}>
                          {driver.full_name} ({driver.driver_code || 'General'}) — 🟢 Available
                        </option>
                      ))}
                    </optgroup>
                  )}

                  {allocated.length > 0 && (
                    <optgroup label={`🟡 Already Allocated (${allocated.length})`}>
                      {allocated.map(({ driver, status }) => (
                        <option key={driver.id} value={driver.id}>
                          {driver.full_name} — {status.label}
                        </option>
                      ))}
                    </optgroup>
                  )}

                  {blocked.length > 0 && (
                    <optgroup label={`🔴 On Holiday / Blocked (${blocked.length})`}>
                      {blocked.map(({ driver, status }) => (
                        <option key={driver.id} value={driver.id} disabled>
                          {driver.full_name} — {status.label}
                        </option>
                      ))}
                    </optgroup>
                  )}
                </select>
              );
            })()}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Assigned Vehicle</label>
              <select
                value={shiftForm.vehicleId}
                onChange={(e) => setShiftForm({ ...shiftForm, vehicleId: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 font-mono"
              >
                <option value="">No Vehicle (Contractor Own)</option>
                {vehicles.map(v => (
                  <option key={v.id} value={v.id}>
                    {v.registration_number || v.equipment_code} ({v.model_number})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Depot Hub</label>
              <select
                value={shiftForm.depotId}
                onChange={(e) => setShiftForm({ ...shiftForm, depotId: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                {depots.map(dep => (
                  <option key={dep.id} value={dep.id}>{dep.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Route Code</label>
              <input
                type="text"
                value={shiftForm.routeCode}
                onChange={(e) => setShiftForm({ ...shiftForm, routeCode: e.target.value.toUpperCase() })}
                placeholder="e.g. LEI-01"
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Dispatched Stops</label>
              <input
                type="number"
                value={shiftForm.dispatchedStops}
                onChange={(e) => setShiftForm({ ...shiftForm, dispatchedStops: parseInt(e.target.value) || 0, paidStops: parseInt(e.target.value) || 0 })}
                min="0"
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Base Rate (£/stop)</label>
              <input
                type="number"
                step="0.01"
                value={shiftForm.appliedBaseRate}
                onChange={(e) => setShiftForm({ ...shiftForm, appliedBaseRate: parseFloat(e.target.value) || 1.00 })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Dispatch & Allocation Notes</label>
            <input
              type="text"
              value={shiftForm.notes}
              onChange={(e) => setShiftForm({ ...shiftForm, notes: e.target.value })}
              placeholder="e.g. Reliever cover shift, primary van in garage, special parcel bulk..."
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex justify-between items-center pt-2">
            {editingShift ? (
              <button
                type="button"
                onClick={() => {
                  handleDeleteShift(editingShift.id);
                  setIsModalOpen(false);
                }}
                className="px-3 py-2 text-rose-600 hover:text-rose-700 dark:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 text-xs font-semibold rounded-lg border border-rose-200 dark:border-rose-800/80 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition cursor-pointer"
              >
                Unassign / Remove Route
              </button>
            ) : <div />}

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 transition flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                {editingShift ? 'Update Allocation' : 'Confirm Route Allocation'}
              </button>
            </div>
          </div>
        </form>
      </Modal>
    </div>
  );
}
