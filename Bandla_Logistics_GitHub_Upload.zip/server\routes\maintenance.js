const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

// List maintenance logs with supplier & vehicle details
router.get('/', async (req, res) => {
  try {
    const { vehicleId, supplierId, issueCategory, startDate, endDate } = req.query;
    const db = getDb();
    let query = `
      SELECT m.*,
        m.date as date,
        m.date as service_date,
        COALESCE(m.labor_cost, 0) as labor_cost,
        COALESCE(m.parts_cost, 0) as parts_cost,
        m.notes as notes,
        m.notes as description,
        m.issue_category as service_type,
        v.model_number as vehicle_model, v.registration_number, v.category as vehicle_category, v.equipment_code,
        s.name as supplier_name
      FROM maintenance_logs m
      JOIN vehicles v ON m.vehicle_id = v.id
      LEFT JOIN suppliers s ON m.supplier_id = s.id
      WHERE 1=1
    `;
    const params = [];

    if (vehicleId) {
      params.push(vehicleId);
      query += ` AND m.vehicle_id = $${params.length}`;
    }
    if (supplierId) {
      params.push(supplierId);
      query += ` AND m.supplier_id = $${params.length}`;
    }
    if (issueCategory) {
      params.push(issueCategory);
      query += ` AND m.issue_category = $${params.length}`;
    }
    if (startDate) {
      params.push(startDate);
      query += ` AND m.date >= $${params.length}`;
    }
    if (endDate) {
      params.push(endDate);
      query += ` AND m.date <= $${params.length}`;
    }

    query += ` ORDER BY m.date DESC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create maintenance log
router.post('/', async (req, res) => {
  try {
    const {
      vehicleId, supplierId, date, serviceDate, logDate,
      laborCost, partsCost, sparePartsCost,
      serviceType, issueCategory,
      invoiceNumber, description, notes
    } = req.body;

    const targetDate = serviceDate || date || logDate || new Date().toISOString().split('T')[0];
    if (!vehicleId) {
      return res.status(400).json({ error: 'Vehicle selection is required.' });
    }

    const labor = parseFloat(laborCost || 0);
    const parts = parseFloat(partsCost || sparePartsCost || 0);
    const total = parseFloat((labor + parts).toFixed(2));
    const finalCategory = serviceType || issueCategory || 'Scheduled Maintenance';

    let finalNotes = (description || notes || '').trim();
    if (invoiceNumber && invoiceNumber.trim() && !finalNotes.includes(invoiceNumber)) {
      finalNotes = finalNotes ? `${finalNotes} [Inv #${invoiceNumber.trim()}]` : `Inv #${invoiceNumber.trim()}`;
    }

    const db = getDb();
    const id = uuidv4();

    const { rows } = await db.session.client.query(`
      INSERT INTO maintenance_logs (
        id, vehicle_id, supplier_id, date, labor_cost, parts_cost, total_cost, issue_category, notes, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())
      RETURNING *
    `, [
      id, vehicleId, (supplierId && supplierId !== 'custom') ? supplierId : null,
      targetDate, labor.toFixed(2), parts.toFixed(2), total.toFixed(2),
      finalCategory, finalNotes || null
    ]);

    // Update vehicle status
    if (finalCategory === 'Scheduled Maintenance' || finalCategory === 'Service') {
      await db.session.client.query(`
        UPDATE vehicles SET last_service_date = $1, status = 'Available', updated_at = NOW() WHERE id = $2
      `, [targetDate, vehicleId]);
    } else if (finalCategory.toLowerCase().includes('breakdown')) {
      await db.session.client.query(`
        UPDATE vehicles SET status = 'Under Maintenance', updated_at = NOW() WHERE id = $1
      `, [vehicleId]);
    }

    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update maintenance log
router.put('/:id', async (req, res) => {
  try {
    const {
      vehicleId, supplierId, date, serviceDate, logDate,
      laborCost, partsCost, sparePartsCost,
      serviceType, issueCategory,
      invoiceNumber, description, notes
    } = req.body;

    const targetDate = serviceDate || date || logDate;
    const labor = laborCost !== undefined ? parseFloat(laborCost) : undefined;
    const parts = (partsCost !== undefined || sparePartsCost !== undefined) ? parseFloat(partsCost || sparePartsCost || 0) : undefined;
    const finalCategory = serviceType || issueCategory;

    const db = getDb();
    const existing = await db.session.client.query(`SELECT * FROM maintenance_logs WHERE id = $1`, [req.params.id]);
    if (!existing.rows.length) return res.status(404).json({ error: 'Maintenance record not found' });

    const currentLabor = labor !== undefined ? labor : parseFloat(existing.rows[0].labor_cost || 0);
    const currentParts = parts !== undefined ? parts : parseFloat(existing.rows[0].parts_cost || 0);
    const currentTotal = parseFloat((currentLabor + currentParts).toFixed(2));

    let finalNotes = (description || notes !== undefined ? (notes || description) : existing.rows[0].notes) || '';
    if (invoiceNumber && invoiceNumber.trim() && !finalNotes.includes(invoiceNumber)) {
      finalNotes = finalNotes ? `${finalNotes} [Inv #${invoiceNumber.trim()}]` : `Inv #${invoiceNumber.trim()}`;
    }

    const { rows } = await db.session.client.query(`
      UPDATE maintenance_logs SET
        vehicle_id = COALESCE($1, vehicle_id),
        supplier_id = $2,
        date = COALESCE($3, date),
        labor_cost = $4,
        parts_cost = $5,
        total_cost = $6,
        issue_category = COALESCE($7, issue_category),
        notes = $8,
        updated_at = NOW()
      WHERE id = $9
      RETURNING *
    `, [
      vehicleId, (supplierId && supplierId !== 'custom') ? supplierId : null,
      targetDate,
      currentLabor.toFixed(2), currentParts.toFixed(2), currentTotal.toFixed(2),
      finalCategory, finalNotes, req.params.id
    ]);

    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete maintenance log
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const { rowCount } = await db.session.client.query(`DELETE FROM maintenance_logs WHERE id = $1`, [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: 'Record not found' });
    res.json({ message: 'Maintenance record deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
