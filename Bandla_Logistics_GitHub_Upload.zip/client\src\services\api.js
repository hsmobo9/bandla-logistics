import axios from 'axios';

const API_BASE_URL = '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Attach JWT Token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('bandla_token') || localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

// Intercept 401 Unauthorized
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      if (!window.location.pathname.includes('/login')) {
        localStorage.removeItem('bandla_token');
        localStorage.removeItem('bandla_user');
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// Auth Endpoints
export const loginApi = (emailOrUsername, password) => api.post('/auth/login', { emailOrUsername, email: emailOrUsername, username: emailOrUsername, password }).then(res => res.data);
export const getMeApi = () => api.get('/auth/me').then(res => res.data);
export const login = loginApi;
export const getCurrentUser = getMeApi;

// Executive Dashboard, Analytics & Depots
export const getDashboardKpi = () => api.get('/dashboard/stats').then(res => res.data);
export const getDashboardStats = () => api.get('/dashboard/stats').then(res => res.data);
export const getPerformanceAnalytics = () => api.get('/analytics/performance').then(res => res.data);
export const getDepots = () => api.get('/depots').then(res => res.data);
export const createDepot = (data) => api.post('/depots', data).then(res => res.data);

// Drivers & Contractors CRM
export const getDrivers = (params) => api.get('/drivers', { params }).then(res => res.data);
export const getDriverById = (id) => api.get(`/drivers/${id}`).then(res => res.data);
export const createDriver = (data) => api.post('/drivers', data).then(res => res.data);
export const updateDriver = (id, data) => api.put(`/drivers/${id}`, data).then(res => res.data);
export const toggleDriverActive = (id) => api.patch(`/drivers/${id}/toggle-active`).then(res => res.data);
export const updateDriverStatus = (id, status, isActive) => api.patch(`/drivers/${id}/status`, { status, isActive }).then(res => res.data);
export const deleteDriver = (id, force = true) => api.delete(`/drivers/${id}${force ? '?force=true' : ''}`).then(res => res.data);

// Driver Availability & Holiday Planner
export const getDriverAvailability = (params) => api.get('/driver-availability', { params }).then(res => res.data);
export const bookDriverAvailability = (data) => api.post('/driver-availability', data).then(res => res.data);
export const createDriverAvailability = bookDriverAvailability;
export const deleteDriverAvailability = (id) => api.delete(`/driver-availability/${id}`).then(res => res.data);

// Vehicles & Courier Fleet Compliance
export const getVehicles = (params) => api.get('/vehicles', { params }).then(res => res.data);
export const getVehicleById = (id) => api.get(`/vehicles/${id}`).then(res => res.data);
export const createVehicle = (data) => api.post('/vehicles', data).then(res => res.data);
export const updateVehicle = (id, data) => api.put(`/vehicles/${id}`, data).then(res => res.data);
export const toggleVehicleActive = (id) => api.patch(`/vehicles/${id}/toggle-active`).then(res => res.data);
export const deleteVehicle = (id) => api.delete(`/vehicles/${id}`).then(res => res.data);

// Route Rates Card
export const getRouteRates = (params) => api.get('/route-rates', { params }).then(res => res.data);
export const createRouteRate = (data) => api.post('/route-rates', data).then(res => res.data);
export const updateRouteRate = (id, data) => api.put(`/route-rates/${id}`, data).then(res => res.data);
export const deleteRouteRate = (id) => api.delete(`/route-rates/${id}`).then(res => res.data);

// Daily Shifts Log & Ingestion
export const getShifts = (params) => api.get('/shifts', { params }).then(res => res.data);
export const getShiftById = (id) => api.get(`/shifts/${id}`).then(res => res.data);
export const createShift = (data) => api.post('/shifts', data).then(res => res.data);
export const updateShift = (id, data) => api.put(`/shifts/${id}`, data).then(res => res.data);
export const deleteShift = (id) => api.delete(`/shifts/${id}`).then(res => res.data);
export const toggleTopUp = (id, reason) => api.patch(`/shifts/${id}/toggle-top-up`, { reason }).then(res => res.data);

// Weekly Route Planner Matrix
export const getWeeklyPlanner = (startDate) => api.get('/planner/weekly', { params: { startDate } }).then(res => res.data);
export const allocateRoutePlanner = (data) => api.post('/planner/allocate', data).then(res => res.data);

// Automated Portal CSV Upload
export const uploadPortalCsv = (file) => {
  const formData = new FormData();
  formData.append('file', file);
  return api.post('/shifts/upload-portal-csv', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }).then(res => res.data);
};

// Charges & Deductions (Signed Decimal)
export const getCharges = (params) => api.get('/charges', { params }).then(res => res.data);
export const createCharge = (data) => api.post('/charges', data).then(res => res.data);
export const updateCharge = (id, data) => api.put(`/charges/${id}`, data).then(res => res.data);
export const deleteCharge = (id, reason) => api.delete(`/charges/${id}`, { data: { reason } }).then(res => res.data);

// Payroll Invoices & State Machine
export const getInvoices = (params) => api.get('/invoices', { params }).then(res => res.data);
export const getInvoiceById = (id) => api.get(`/invoices/${id}`).then(res => res.data);
export const generateInvoice = (data) => api.post('/invoices/generate', data).then(res => res.data);
export const generateInvoicePdf = (id) => api.post(`/invoices/${id}/pdf`).then(res => res.data);
export const updateInvoiceStatus = (id, status, reason) => api.patch(`/invoices/${id}/status`, { status, reason }).then(res => res.data);
export const getInvoiceWhatsappUrl = (id) => api.get(`/invoices/${id}/whatsapp-url`).then(res => res.data);

// Direct Authenticated Blob PDF Downloader
export const downloadInvoicePdfBlob = async (id, invoiceNumber) => {
  const response = await api.get(`/invoices/${id}/pdf/download`, {
    responseType: 'blob'
  });
  const blob = new Blob([response.data], { type: 'application/pdf' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  const fileName = `${invoiceNumber || 'Bandla_Invoice_' + id}.pdf`;
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
};


// Direct Authenticated Blob Batch ZIP Downloader
export const downloadBatchInvoiceZipBlob = async ({ invoiceIds, billingMonth }) => {
  const response = await api.post('/invoices/batch/download-zip', { invoiceIds, billingMonth }, {
    responseType: 'blob'
  });
  const blob = new Blob([response.data], { type: 'application/zip' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  const monthLabel = (billingMonth && billingMonth !== 'all') ? billingMonth.replace(/[^a-zA-Z0-9]/g, '_') : 'Batch';
  const fileName = `Bandla_Invoices_${monthLabel}_${Date.now()}.zip`;
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
};

export const batchUpdateInvoiceStatus = (invoiceIds, status, reason) =>
  api.post('/invoices/batch/status', { invoiceIds, status, reason }).then(res => res.data);

// Suppliers & Garages Master
export const getSuppliers = (params) => api.get('/suppliers', { params }).then(res => res.data);
export const createSupplier = (data) => api.post('/suppliers', data).then(res => res.data);
export const updateSupplier = (id, data) => api.put(`/suppliers/${id}`, data).then(res => res.data);
export const toggleSupplierActive = (id) => api.patch(`/suppliers/${id}/toggle-active`).then(res => res.data);
export const deleteSupplier = (id) => api.delete(`/suppliers/${id}`).then(res => res.data);

// Maintenance Logs & Supplier Invoices
export const getMaintenance = (params) => api.get('/maintenance', { params }).then(res => res.data);
export const createMaintenance = (data) => api.post('/maintenance', data).then(res => res.data);
export const updateMaintenance = (id, data) => api.put(`/maintenance/${id}`, data).then(res => res.data);
export const deleteMaintenance = (id) => api.delete(`/maintenance/${id}`).then(res => res.data);

// Accident & Claim Logs
export const getAccidents = (params) => api.get('/accidents', { params }).then(res => res.data);
export const createAccident = (data) => api.post('/accidents', data).then(res => res.data);
export const updateAccident = (id, data) => api.put(`/accidents/${id}`, data).then(res => res.data);
export const deleteAccident = (id) => api.delete(`/accidents/${id}`).then(res => res.data);

// Fuel Consumption Logs
export const getFuelLogs = (params) => api.get('/fuel', { params }).then(res => res.data);
export const createFuelLog = (data) => api.post('/fuel', data).then(res => res.data);
export const updateFuelLog = (id, data) => api.put(`/fuel/${id}`, data).then(res => res.data);
export const deleteFuelLog = (id) => api.delete(`/fuel/${id}`).then(res => res.data);

// Financial Audit Trails
export const getAuditLogs = (params) => api.get('/audit-logs', { params }).then(res => res.data);

// System Migration & Maintenance
export const runLegacyMigration = () => api.post('/system/migrate-legacy').then(res => res.data);
export const getMigrationHistory = () => api.get('/system/status').then(res => res.data);
export const getSystemStatus = () => api.get('/system/status').then(res => res.data);

export default api;
// User Roles & Granular Privilege Management
export const getUsers = () => api.get('/users').then(res => res.data);
export const createUser = (data) => api.post('/users', data).then(res => res.data);
export const updateUser = (id, data) => api.put(`/users/${id}`, data).then(res => res.data);
export const toggleUserStatus = (id) => api.patch(`/users/${id}/toggle-status`).then(res => res.data);
export const deleteUser = (id) => api.delete(`/users/${id}`).then(res => res.data);
