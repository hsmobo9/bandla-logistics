const { v4: uuidv4 } = require('uuid');
const { getDb, initDb } = require('../config/db');
const { migrate } = require('../db/migrate');
const { calculateShift } = require('../services/calculationService');

async function seedEdgeCases() {
  console.log('================================================================================');
  console.log('BANDLA LOGISTICS EDGE-CASES & STRESS TEST SEEDING (EXACT 55 DRIVERS / 53 VANS)');
  console.log('================================================================================\n');

  const { client } = await initDb();
  await migrate();

  // Prune any extraneous test records created earlier
  await client.query("DELETE FROM daily_shifts WHERE driver_id IN (SELECT id FROM drivers WHERE driver_code LIKE 'DRV-%')");
  await client.query("DELETE FROM driver_availability WHERE driver_id IN (SELECT id FROM drivers WHERE driver_code LIKE 'DRV-%')");
  await client.query("DELETE FROM charges_and_deductions WHERE driver_id IN (SELECT id FROM drivers WHERE driver_code LIKE 'DRV-%')");
  await client.query("DELETE FROM drivers WHERE driver_code LIKE 'DRV-%'");
  await client.query("DELETE FROM maintenance_logs WHERE vehicle_id IN (SELECT id FROM vehicles WHERE registration_number IN ('BD21 WLU', 'DS74 COA'))");
  await client.query("DELETE FROM accident_logs WHERE vehicle_id IN (SELECT id FROM vehicles WHERE registration_number IN ('BD21 WLU', 'DS74 COA'))");
  await client.query("DELETE FROM daily_shifts WHERE vehicle_id IN (SELECT id FROM vehicles WHERE registration_number IN ('BD21 WLU', 'DS74 COA'))");
  await client.query("DELETE FROM vehicles WHERE registration_number IN ('BD21 WLU', 'DS74 COA')");

  // Helper to fetch official driver by name
  async function getDriver(fullName) {
    const res = await client.query('SELECT id, full_name, driver_code, assigned_vehicle_reg, default_depot_id FROM drivers WHERE full_name ILIKE $1 LIMIT 1', [fullName]);
    if (!res.rows.length) throw new Error(`Official driver not found: ${fullName}`);
    return res.rows[0];
  }

  // Helper to fetch official vehicle by reg
  async function getVehicle(reg) {
    const res = await client.query('SELECT id, registration_number, model_number FROM vehicles WHERE UPPER(registration_number) = $1 LIMIT 1', [reg.toUpperCase().trim()]);
    if (!res.rows.length) throw new Error(`Official vehicle not found: ${reg}`);
    return res.rows[0];
  }

  const leicesterDepotRes = await client.query("SELECT id FROM depots WHERE name ILIKE 'Leicester' LIMIT 1");
  const leicesterId = leicesterDepotRes.rows[0]?.id;

  // 1. Vehicle in Maintenance & Driver Relocation Scenario
  console.log('--- 1. Seeding Vehicle in Maintenance & Driver Relocation ---');
  const driver1 = await getDriver('Amanpreet Singh'); // DR1003
  const vehA = await getVehicle('BL21 USB'); // Primary Van
  const vehB = await getVehicle('BN70 PXW'); // Spare Van

  // Set Primary Van BL21 USB Maintenance
  await client.query('DELETE FROM maintenance_logs WHERE vehicle_id = $1', [vehA.id]);
  await client.query(`
    INSERT INTO maintenance_logs (id, vehicle_id, date, issue_category, labor_cost, parts_cost, total_cost, notes, created_at, updated_at)
    VALUES ($1, $2, '2026-08-29', 'Engine Repair', 250.00, 200.00, 450.00, 'Engine Diagnostic & Cylinder Head Overhaul - In Workshop', NOW(), NOW())
  `, [uuidv4(), vehA.id]);
  console.log(`✓ Added £450 Engine Repair maintenance log for Primary Van BL21 USB`);

  // Reassign Driver 1 (Amanpreet Singh) to Spare Van (BN70 PXW) for today
  const shift1Math = await calculateShift({ dispatchedStops: 125, paidStops: 125, totalParcels: 135, appliedBaseRate: 1.00 });
  await client.query('DELETE FROM daily_shifts WHERE driver_id = $1 AND shift_date = $2', [driver1.id, '2026-08-29']);
  await client.query(`
    INSERT INTO daily_shifts (
      id, driver_id, vehicle_id, depot_id, shift_date, route_code,
      dispatched_stops, paid_stops, total_parcels, excess_parcels,
      applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
      top_up_stops, top_up_pay, gross_shift_total, is_top_up_cancelled, notes, created_at, updated_at
    ) VALUES (
      $1, $2, $3, $4, '2026-08-29', 'LEI-01',
      $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, FALSE,
      'Primary van BL21 USB in maintenance (£450 repair). Relocated to spare van BN70 PXW', NOW(), NOW()
    )
  `, [
    uuidv4(), driver1.id, vehB.id, leicesterId,
    shift1Math.dispatchedStops, shift1Math.paidStops, shift1Math.totalParcels, shift1Math.excessParcels,
    shift1Math.appliedBaseRate, shift1Math.appliedExcessRate, shift1Math.calculatedStopPay, shift1Math.calculatedParcelPay,
    shift1Math.topUpStops, shift1Math.topUpPay, shift1Math.grossShiftTotal
  ]);
  console.log(`✓ Reassigned Amanpreet Singh to Spare Van BN70 PXW for today\n`);

  // 2. Driver on Leave & Reliever Cover Shift Scenario
  console.log('--- 2. Seeding Driver on Leave & Reliever Cover Shift ---');
  const driver2 = await getDriver('Andrie Ploscaru'); // DR1004
  const relieverDriver = await getDriver('Amandeep Singh'); // DR1001

  // Log Andrie Ploscaru on Holiday for this week
  await client.query('DELETE FROM driver_availability WHERE driver_id = $1', [driver2.id]);
  await client.query(`
    INSERT INTO driver_availability (id, driver_id, start_date, end_date, status, notes, created_at, updated_at)
    VALUES ($1, $2, '2026-08-24', '2026-08-31', 'Holiday', 'Approved Annual Leave - Week 35', NOW(), NOW())
  `, [uuidv4(), driver2.id]);
  console.log('✓ Logged Andrie Ploscaru on Holiday (24 Aug - 31 Aug 2026)');

  // Log Baljinder Singh on Sick Leave (27 Aug - 30 Aug 2026)
  const dBaljinder = await getDriver('Baljinder Singh');
  await client.query('DELETE FROM driver_availability WHERE driver_id = $1', [dBaljinder.id]);
  await client.query(`
    INSERT INTO driver_availability (id, driver_id, start_date, end_date, status, notes, created_at, updated_at)
    VALUES ($1, $2, '2026-08-27', '2026-08-30', 'Sick Leave', 'Medical Certificate Submitted', NOW(), NOW())
  `, [uuidv4(), dBaljinder.id]);
  console.log('✓ Logged Baljinder Singh on Sick Leave (27 Aug - 30 Aug 2026)');

  // Log Bhavdeep Singh on Holiday (25 Aug - 29 Aug 2026)
  const dBhavdeep = await getDriver('Bhavdeep Singh');
  await client.query('DELETE FROM driver_availability WHERE driver_id = $1', [dBhavdeep.id]);
  await client.query(`
    INSERT INTO driver_availability (id, driver_id, start_date, end_date, status, notes, created_at, updated_at)
    VALUES ($1, $2, '2026-08-25', '2026-08-29', 'Holiday', 'Approved Summer Break', NOW(), NOW())
  `, [uuidv4(), dBhavdeep.id]);
  console.log('✓ Logged Bhavdeep Singh on Holiday (25 Aug - 29 Aug 2026)');

  // Assign Reliever to Driver 2 route (LEI-02) for today
  const relieverMath = await calculateShift({ dispatchedStops: 120, paidStops: 120, totalParcels: 130, appliedBaseRate: 1.00 });
  await client.query('DELETE FROM daily_shifts WHERE driver_id = $1 AND shift_date = $2', [relieverDriver.id, '2026-08-29']);
  await client.query(`
    INSERT INTO daily_shifts (
      id, driver_id, vehicle_id, depot_id, shift_date, route_code,
      dispatched_stops, paid_stops, total_parcels, excess_parcels,
      applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
      top_up_stops, top_up_pay, gross_shift_total, is_top_up_cancelled, notes, created_at, updated_at
    ) VALUES (
      $1, $2, $3, $4, '2026-08-29', 'LEI-02',
      $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, FALSE,
      'Cover Shift for Andrie Ploscaru (On Annual Leave)', NOW(), NOW()
    )
  `, [
    uuidv4(), relieverDriver.id, vehA.id, leicesterId,
    relieverMath.dispatchedStops, relieverMath.paidStops, relieverMath.totalParcels, relieverMath.excessParcels,
    relieverMath.appliedBaseRate, relieverMath.appliedExcessRate, relieverMath.calculatedStopPay, relieverMath.calculatedParcelPay,
    relieverMath.topUpStops, relieverMath.topUpPay, relieverMath.grossShiftTotal
  ]);
  console.log('✓ Assigned Reliever Driver Amandeep Singh to Route LEI-02 without conflict\n');

  // 3. Fleet Compliance Traffic Lights
  console.log('--- 3. Seeding Fleet Compliance Traffic Lights ---');
  // Vehicle C: GREEN (AO21 OWA: MOT 2026-10-28 [in 60 days], 40k / 50k service)
  const vehC = await getVehicle('AO21 OWA');
  await client.query("UPDATE vehicles SET mot_expiry = '2026-10-28', current_mileage = 40000, next_service_mileage = 50000, model_number = 'Mercedes Sprinter (Green Spec)' WHERE id = $1", [vehC.id]);
  console.log('✓ Vehicle C (AO21 OWA) -> GREEN / Valid (MOT in 60 days, 10,000 miles to service)');

  // Vehicle D: AMBER (BT21 EUA: MOT 2026-09-12 [in 14 days], 49.5k / 50k service)
  const vehD = await getVehicle('BT21 EUA');
  await client.query("UPDATE vehicles SET mot_expiry = '2026-09-12', current_mileage = 49500, next_service_mileage = 50000, model_number = 'Mercedes Sprinter (Amber Spec)' WHERE id = $1", [vehD.id]);
  console.log('✓ Vehicle D (BT21 EUA) -> AMBER / Due Soon (MOT in 14 days, 500 miles to service)');

  // Vehicle E: RED (BT74 AMO: MOT 2026-08-28 [expired yesterday], 51k / 50k service exceeded)
  const vehE = await getVehicle('BT74 AMO');
  await client.query("UPDATE vehicles SET mot_expiry = '2026-08-28', current_mileage = 51000, next_service_mileage = 50000, model_number = 'Mercedes Sprinter (Red Spec)' WHERE id = $1", [vehE.id]);
  console.log('✓ Vehicle E (BT74 AMO) -> RED / Overdue (MOT expired yesterday, Mileage exceeded by 1,000mi)');

  // Add accident log for Vehicle E: Under Investigation
  await client.query('DELETE FROM accident_logs WHERE vehicle_id = $1', [vehE.id]);
  await client.query(`
    INSERT INTO accident_logs (id, vehicle_id, driver_id, date, description, insurance_claim_status, estimated_damage_cost, third_party_details, created_at, updated_at)
    VALUES ($1, $2, $3, '2026-08-28', 'Rear bumper and tailgate collision during reverse manoeuvre', 'Under Investigation', 1200.00, 'Claim REF: CLM-88901 - Allianz Commercial', NOW(), NOW())
  `, [uuidv4(), vehE.id, driver2.id]);
  console.log('✓ Added Accident Log for Vehicle E with status "Under Investigation" (£1,200 damage)\n');

  // 4. Payroll Extremes & Warning Flags (August 2026)
  console.log('--- 4. Seeding Payroll Extremes & Warning Flags (August 2026) ---');
  const dPerfect = await getDriver('Arshpreet Singh'); // DR1006
  const dTopUp = await getDriver('Chahit Kumar'); // DR1011
  const dRedUnpaid = await getDriver('Gurpreet Singh'); // DR1020
  const dAmberFail = await getDriver('Harjinder Singh'); // DR1021

  // Shift 1: The Perfect Shift (125 Dispatched, 125 Paid, 40 Excess => 165 total parcels)
  const perfMath = await calculateShift({ dispatchedStops: 125, paidStops: 125, totalParcels: 165, appliedBaseRate: 1.00 });
  await client.query('DELETE FROM daily_shifts WHERE driver_id = $1 AND shift_date = $2', [dPerfect.id, '2026-08-10']);
  await client.query(`
    INSERT INTO daily_shifts (
      id, driver_id, vehicle_id, depot_id, shift_date, route_code,
      dispatched_stops, paid_stops, total_parcels, excess_parcels,
      applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
      top_up_stops, top_up_pay, gross_shift_total, is_top_up_cancelled, notes, created_at, updated_at
    ) VALUES ($1, $2, $3, $4, '2026-08-10', 'LEI-10', $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, FALSE, 'The Perfect Shift: 125 Paid + 40 Excess (£2.00 bonus)', NOW(), NOW())
  `, [uuidv4(), dPerfect.id, vehC.id, leicesterId, perfMath.dispatchedStops, perfMath.paidStops, perfMath.totalParcels, perfMath.excessParcels, perfMath.appliedBaseRate, perfMath.appliedExcessRate, perfMath.calculatedStopPay, perfMath.calculatedParcelPay, perfMath.topUpStops, perfMath.topUpPay, perfMath.grossShiftTotal]);
  console.log('✓ 4A. The Perfect Shift (Arshpreet Singh): £125.00 Base + £2.00 Parcel Bonus = £127.00 Gross');

  // Shift 2: The £100 Top-Up Guarantee Trigger (75 Dispatched, 75 Paid, 0 Excess)
  const topUpMath = await calculateShift({ dispatchedStops: 75, paidStops: 75, totalParcels: 75, appliedBaseRate: 1.00 });
  await client.query('DELETE FROM daily_shifts WHERE driver_id = $1 AND shift_date = $2', [dTopUp.id, '2026-08-11']);
  await client.query(`
    INSERT INTO daily_shifts (
      id, driver_id, vehicle_id, depot_id, shift_date, route_code,
      dispatched_stops, paid_stops, total_parcels, excess_parcels,
      applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
      top_up_stops, top_up_pay, gross_shift_total, is_top_up_cancelled, notes, created_at, updated_at
    ) VALUES ($1, $2, $3, $4, '2026-08-11', 'LEI-11', $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, FALSE, 'The Top-Up Guarantee: 75 Stops (£75) + 25 Top-up stops (£25) = £100.00 Min', NOW(), NOW())
  `, [uuidv4(), dTopUp.id, vehD.id, leicesterId, topUpMath.dispatchedStops, topUpMath.paidStops, topUpMath.totalParcels, topUpMath.excessParcels, topUpMath.appliedBaseRate, topUpMath.appliedExcessRate, topUpMath.calculatedStopPay, topUpMath.calculatedParcelPay, topUpMath.topUpStops, topUpMath.topUpPay, topUpMath.grossShiftTotal]);
  console.log('✓ 4B. The Top-Up Trigger (Chahit Kumar): £75.00 Base + £25.00 Top-Up Guarantee = £100.00 Gross');

  // Shift 3: The Red Alert (Unpaid: 110 Dispatched, 0 Paid)
  await client.query('DELETE FROM daily_shifts WHERE driver_id = $1 AND shift_date = $2', [dRedUnpaid.id, '2026-08-12']);
  await client.query(`
    INSERT INTO daily_shifts (
      id, driver_id, vehicle_id, depot_id, shift_date, route_code,
      dispatched_stops, paid_stops, total_parcels, excess_parcels,
      applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
      top_up_stops, top_up_pay, gross_shift_total, is_top_up_cancelled, notes, created_at, updated_at
    ) VALUES ($1, $2, $3, $4, '2026-08-12', 'LEI-12', 110, 0, 110, 0, '1.0000', '0.0500', '0.00', '0.00', 0, '0.00', '0.00', TRUE, '🚨 RED ALERT: 110 Dispatched Stops / 0 Paid Stops (100% Unpaid Route)', NOW(), NOW())
  `, [uuidv4(), dRedUnpaid.id, vehE.id, leicesterId]);
  console.log('✓ 4C. The Red Alert (Gurpreet Singh): 110 Dispatched / 0 Paid (Triggers RED Unpaid Badge)');

  // Shift 4: The Amber Alert (High Fail: 150 Dispatched, 120 Paid => 20% Fail Rate)
  const amberMath = await calculateShift({ dispatchedStops: 150, paidStops: 120, totalParcels: 120, appliedBaseRate: 1.00 });
  await client.query('DELETE FROM daily_shifts WHERE driver_id = $1 AND shift_date = $2', [dAmberFail.id, '2026-08-13']);
  await client.query(`
    INSERT INTO daily_shifts (
      id, driver_id, vehicle_id, depot_id, shift_date, route_code,
      dispatched_stops, paid_stops, total_parcels, excess_parcels,
      applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
      top_up_stops, top_up_pay, gross_shift_total, is_top_up_cancelled, notes, created_at, updated_at
    ) VALUES ($1, $2, $3, $4, '2026-08-13', 'LEI-13', $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, FALSE, '⚠️ AMBER ALERT: 150 Dispatched / 120 Paid (20.00% High Fail Rate)', NOW(), NOW())
  `, [uuidv4(), dAmberFail.id, vehA.id, leicesterId, amberMath.dispatchedStops, amberMath.paidStops, amberMath.totalParcels, amberMath.excessParcels, amberMath.appliedBaseRate, amberMath.appliedExcessRate, amberMath.calculatedStopPay, amberMath.calculatedParcelPay, amberMath.topUpStops, amberMath.topUpPay, amberMath.grossShiftTotal]);
  console.log('✓ 4D. The Amber Alert (Harjinder Singh): 150 Dispatched / 120 Paid = 20.00% Fail Rate (Triggers AMBER Badge)\n');

  // 5. Financial Overrides, Deductions & The Vault Lock (July 2026)
  console.log('--- 5. Seeding Deductions, Credits & July 2026 Vault Lock ---');

  // Add Van Hire Deduction (£135.00)
  await client.query('DELETE FROM charges_and_deductions WHERE driver_id = $1 AND billing_month = $2', [driver1.id, 'August 2026']);
  const chargeId1 = uuidv4();
  await client.query(`
    INSERT INTO charges_and_deductions (
      id, billing_month, billing_period, charge_date, driver_id, cd_type, charge_type, amount, vehicle_id, notes, is_settled, created_at, updated_at
    ) VALUES ($1, 'August 2026', 'August 2026', '2026-08-15', $2, 'Van Hire', 'Van Hire', 135.00, $3, 'Standard Weekly Van Hire Deducted from August Payroll', FALSE, NOW(), NOW())
  `, [chargeId1, driver1.id, vehB.id]);
  console.log('✓ Added Van Hire Deduction: +£135.00 for Amanpreet Singh (August 2026)');

  // Add Negative Reimbursement Credit (-£50.00)
  const chargeId2 = uuidv4();
  await client.query(`
    INSERT INTO charges_and_deductions (
      id, billing_month, billing_period, charge_date, driver_id, cd_type, charge_type, amount, vehicle_id, notes, is_settled, created_at, updated_at
    ) VALUES ($1, 'August 2026', 'August 2026', '2026-08-16', $2, 'Management Credit', 'Management Credit', -50.00, NULL, 'Management Approved Fuel & Toll Reimbursement Credit', FALSE, NOW(), NOW())
  `, [chargeId2, driver1.id]);
  console.log('✓ Added Negative Reimbursement: -£50.00 (adds £50 credit) for Amanpreet Singh (August 2026)');

  // Create Processed & Locked July 2026 Invoice
  const lockedInvoiceId = uuidv4();
  const lockedChargeId = uuidv4();
  const lockedShiftId = uuidv4();

  await client.query('DELETE FROM payroll_invoices WHERE driver_id = $1 AND billing_month = $2', [driver1.id, 'July 2026']);
  await client.query(`
    INSERT INTO payroll_invoices (
      id, invoice_number, driver_id, billing_month, billing_start_date, billing_end_date,
      invoice_date, days_worked, total_stops_dispatched, total_paid_stops,
      total_stop_pay, total_excess_parcel_pay, total_top_up_pay, gross_earnings,
      total_deductions, subtotal, vat_rate, vat_applied, net_payable, payment_status, status, created_at, updated_at
    ) VALUES (
      $1, 'INV-JULY-2026-001', $2, 'July 2026', '2026-07-01', '2026-07-31',
      '2026-07-31', 22, 2750, 2750,
      '2750.00', '0.00', '0.00', '2750.00',
      '540.00', '2210.00', '0.00', '0.00', '2210.00', 'Locked', 'Locked', NOW(), NOW()
    )
  `, [lockedInvoiceId, driver1.id]);

  // Insert locked July deduction stamped with invoice_id
  await client.query('DELETE FROM charges_and_deductions WHERE driver_id = $1 AND billing_month = $2', [driver1.id, 'July 2026']);
  await client.query(`
    INSERT INTO charges_and_deductions (
      id, billing_month, billing_period, charge_date, driver_id, cd_type, charge_type, amount, invoice_id, is_settled, notes, created_at, updated_at
    ) VALUES ($1, 'July 2026', 'July 2026', '2026-07-15', $2, 'Van Hire', 'Van Hire', 540.00, $3, TRUE, 'July Monthly Van Rental - Finalized & Settled', NOW(), NOW())
  `, [lockedChargeId, driver1.id, lockedInvoiceId]);

  // Insert locked July shift stamped with invoice_id
  await client.query('DELETE FROM daily_shifts WHERE driver_id = $1 AND shift_date = $2', [driver1.id, '2026-07-15']);
  await client.query(`
    INSERT INTO daily_shifts (
      id, driver_id, vehicle_id, depot_id, shift_date, route_code,
      dispatched_stops, paid_stops, total_parcels, excess_parcels,
      applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
      top_up_stops, top_up_pay, gross_shift_total, is_top_up_cancelled, invoice_id, notes, created_at, updated_at
    ) VALUES (
      $1, $2, $3, $4, '2026-07-15', 'LEI-01',
      125, 125, 135, 10, '1.0000', '0.0500', '125.00', '0.50',
      0, '0.00', '125.50', FALSE, $5, 'Finalized July Shift in Vault Lock', NOW(), NOW()
    )
  `, [lockedShiftId, driver1.id, vehB.id, leicesterId, lockedInvoiceId]);

  console.log('✓ Created Locked July 2026 Invoice (#INV-JULY-2026-001) for Amanpreet Singh (Status: LOCKED 🔒)');
  console.log('✓ Stamped July Shifts and July Deductions with Vault Lock');

  const finalDrv = await client.query('SELECT COUNT(*) FROM drivers');
  const finalVeh = await client.query('SELECT COUNT(*) FROM vehicles');
  console.log(`\n✓ Final Database Totals: ${finalDrv.rows[0].count} Drivers, ${finalVeh.rows[0].count} Vehicles (Exact Match)`);

  console.log('\n================================================================================');
  console.log('✨ ALL 5 EDGE CASES SEEDED! EXACT 55 DRIVERS & 53 VEHICLES PRESERVED.');
  console.log('================================================================================\n');
}

module.exports = { seedEdgeCases };

if (require.main === module) {
  seedEdgeCases()
    .then(() => process.exit(0))
    .catch(err => {
      console.error('Fatal Error during edge cases seeding:', err);
      process.exit(1);
    });
}