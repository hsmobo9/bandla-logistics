const express = require('express');
const router = express.Router();
const { getDb } = require('../config/db');

async function getDashboardData() {
  const db = getDb();
  const client = db.session.client;

  // 1. Drivers counts
  const driverRes = await client.query(`
    SELECT 
      COUNT(*) as total, 
      COUNT(*) FILTER (WHERE is_active = true) as active 
    FROM drivers
  `);

  // 2. Vehicles counts
  const vehicleRes = await client.query(`
    SELECT 
      COUNT(*) as total, 
      COUNT(*) FILTER (WHERE status = 'Available' OR status = 'Deployed on Site') as operational,
      COUNT(*) FILTER (WHERE status = 'Under Maintenance' OR status = 'Breakdown') as in_maintenance
    FROM vehicles 
    WHERE is_active = true
  `);

  // 3. Shift statistics
  const shiftRes = await client.query(`
    SELECT 
      COUNT(*) as total_shifts,
      COALESCE(SUM(dispatched_stops), 0) as total_dispatched_stops,
      COALESCE(SUM(paid_stops), 0) as total_paid_stops,
      COALESCE(SUM(gross_shift_total), 0) as total_gross_shift_pay,
      COALESCE(SUM(top_up_pay), 0) as total_top_up_pay
    FROM daily_shifts
  `);

  // 4. Invoices statistics
  const invRes = await client.query(`
    SELECT 
      COUNT(*) as count,
      COALESCE(SUM(gross_earnings), 0) as total_gross_earnings,
      COALESCE(SUM(total_deductions), 0) as total_deductions,
      COALESCE(SUM(net_payable), 0) as total_net_payable
    FROM payroll_invoices
  `);

  // 5. Recent Shifts
  const recentShiftsRes = await client.query(`
    SELECT 
      s.id, s.shift_date, s.dispatched_stops, s.paid_stops, s.gross_shift_total, s.route_code,
      d.full_name as driver_name, d.driver_code,
      CASE 
        WHEN s.dispatched_stops > 0 THEN ROUND(((s.dispatched_stops - s.paid_stops)::numeric / s.dispatched_stops) * 100, 2)
        ELSE 0 
      END as fail_percentage
    FROM daily_shifts s
    JOIN drivers d ON s.driver_id = d.id
    ORDER BY s.shift_date DESC, s.created_at DESC
    LIMIT 8
  `);

  // 6. Fleet Compliance Alerts (MOT / Tax / Ins expiring within 30 days, 10k Service, or Timing Belt milestones)
  const fleetAlertsRes = await client.query(`
    SELECT 
      id, registration_number, model_number, mot_expiry, tax_expiry, insurance_expiry, 
      current_mileage, next_service_mileage, depot_location, status
    FROM vehicles
    WHERE is_active = true 
      AND (
        mot_expiry <= (CURRENT_DATE + INTERVAL '30 days')
        OR tax_expiry <= (CURRENT_DATE + INTERVAL '30 days')
        OR insurance_expiry <= (CURRENT_DATE + INTERVAL '30 days')
        OR current_mileage >= next_service_mileage
        OR (current_mileage >= 67000 AND current_mileage <= 73000)
        OR (current_mileage >= 127000 AND current_mileage <= 133000)
        OR (current_mileage >= 197000 AND current_mileage <= 203000)
      )
    ORDER BY mot_expiry ASC
    LIMIT 8
  `);

  // 7. Depot SPR Distribution
  const depotSprRes = await client.query(`
    SELECT 
      COALESCE(dep.name, 'Unassigned') as depot_name,
      COUNT(s.id) as routes_count,
      COALESCE(SUM(s.paid_stops), 0) as total_stops,
      CASE WHEN COUNT(s.id) > 0 THEN ROUND(SUM(s.paid_stops)::numeric / COUNT(s.id), 1) ELSE 0 END as spr
    FROM daily_shifts s
    LEFT JOIN depots dep ON s.depot_id = dep.id
    GROUP BY dep.name
    ORDER BY total_stops DESC
  `);

  return {
    drivers: {
      total: parseInt(driverRes.rows[0]?.total || 0, 10),
      active: parseInt(driverRes.rows[0]?.active || 0, 10)
    },
    vehicles: {
      total: parseInt(vehicleRes.rows[0]?.total || 0, 10),
      operational: parseInt(vehicleRes.rows[0]?.operational || 0, 10),
      inMaintenance: parseInt(vehicleRes.rows[0]?.in_maintenance || 0, 10)
    },
    shifts: {
      totalShifts: parseInt(shiftRes.rows[0]?.total_shifts || 0, 10),
      totalDispatchedStops: parseInt(shiftRes.rows[0]?.total_dispatched_stops || 0, 10),
      totalPaidStops: parseInt(shiftRes.rows[0]?.total_paid_stops || 0, 10),
      totalGrossShiftPay: parseFloat(shiftRes.rows[0]?.total_gross_shift_pay || 0),
      totalTopUpPay: parseFloat(shiftRes.rows[0]?.total_top_up_pay || 0)
    },
    invoices: {
      count: parseInt(invRes.rows[0]?.count || 0, 10),
      totalGrossEarnings: parseFloat(invRes.rows[0]?.total_gross_earnings || 0),
      totalDeductions: parseFloat(invRes.rows[0]?.total_deductions || 0),
      totalNetPayable: parseFloat(invRes.rows[0]?.total_net_payable || 0)
    },
    recentShifts: recentShiftsRes.rows || [],
    fleetAlerts: fleetAlertsRes.rows || [],
    depotSpr: depotSprRes.rows || []
  };
}

// Support /stats, /kpi, and /
router.get('/stats', async (req, res) => {
  try {
    const data = await getDashboardData();
    res.json(data);
  } catch (err) {
    console.error('Error fetching dashboard stats:', err);
    res.status(500).json({ error: err.message });
  }
});

router.get('/kpi', async (req, res) => {
  try {
    const data = await getDashboardData();
    res.json(data);
  } catch (err) {
    console.error('Error fetching dashboard kpi:', err);
    res.status(500).json({ error: err.message });
  }
});

router.get('/', async (req, res) => {
  try {
    const data = await getDashboardData();
    res.json(data);
  } catch (err) {
    console.error('Error fetching dashboard root:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;