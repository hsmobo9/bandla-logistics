const { pgTable, text, varchar, integer, numeric, boolean, timestamp, date, uniqueIndex, index } = require('drizzle-orm/pg-core');

// Valid Courier Vehicle Categories: 'Standard Van', 'LWB Van', 'SWB Van', 'Luton Van', 'Courier Car', 'Other'
const COURIER_VEHICLE_CATEGORIES = ['Standard Van', 'LWB Van', 'SWB Van', 'Luton Van', 'Courier Car', 'Other'];

// 1. Depots Master
const depots = pgTable('depots', {
  id: text('id').primaryKey(),
  code: varchar('code', { length: 20 }).notNull().unique(),
  name: varchar('name', { length: 100 }).notNull(),
  address: text('address'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// 2. Users & RBAC Master (Admin vs ShiftManager)
const users = pgTable('users', {
  id: text('id').primaryKey(),
  username: varchar('username', { length: 100 }).notNull().unique(),
  email: varchar('email', { length: 150 }).notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  fullName: varchar('full_name', { length: 150 }).notNull(),
  role: varchar('role', { length: 50 }).notNull(), // 'Admin' (Head Office) or 'ShiftManager' (Regional Depots)
  depotId: text('depot_id').references(() => depots.id),
  status: varchar('status', { length: 30 }).default('active').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
}, (table) => ({
  roleIdx: index('user_role_idx').on(table.role),
  emailIdx: uniqueIndex('user_email_idx').on(table.email)
}));

// 3. Drivers Master (with License, DVLA Points & Soft Delete)
const drivers = pgTable('drivers', {
  id: text('id').primaryKey(),
  driverCode: varchar('driver_code', { length: 50 }).unique(),
  fullName: varchar('full_name', { length: 150 }).notNull(),
  phone: varchar('phone', { length: 50 }),
  email: varchar('email', { length: 100 }),
  defaultDepotId: text('default_depot_id').references(() => depots.id),
  assignedVehicleReg: varchar('assigned_vehicle_reg', { length: 50 }),
  assignedFdNumber: varchar('assigned_fd_number', { length: 50 }),
  isVatRegistered: boolean('is_vat_registered').default(false).notNull(),
  vatNumber: varchar('vat_number', { length: 50 }),
  status: varchar('status', { length: 30 }).default('active').notNull(), // active, on_leave, inactive
  licenseNumber: varchar('license_number', { length: 50 }),
  licenseExpiry: date('license_expiry'),
  passDate: date('pass_date'),
  dvlaPoints: integer('dvla_points').default(0).notNull(),
  isActive: boolean('is_active').default(true).notNull(), // Soft delete flag
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
}, (table) => ({
  nameIdx: index('driver_name_idx').on(table.fullName),
  activeIdx: index('driver_active_idx').on(table.isActive)
}));

// 4. Driver Availability & Holiday Planner
const driverAvailability = pgTable('driver_availability', {
  id: text('id').primaryKey(),
  driverId: text('driver_id').references(() => drivers.id).notNull(),
  startDate: date('start_date').notNull(),
  endDate: date('end_date').notNull(),
  status: varchar('status', { length: 30 }).default('Holiday').notNull(), // 'Holiday', 'Unavailable'
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
}, (table) => ({
  driverDateIdx: index('driver_avail_date_idx').on(table.driverId, table.startDate, table.endDate)
}));

// 5. Route Rates Master
const routeRates = pgTable('route_rates', {
  id: text('id').primaryKey(),
  routeCode: varchar('route_code', { length: 50 }).notNull(),
  depotId: text('depot_id').references(() => depots.id),
  baseRatePerStop: numeric('base_rate_per_stop', { precision: 10, scale: 4 }).notNull(),
  excessParcelRate: numeric('excess_parcel_rate', { precision: 10, scale: 4 }).default('0.0000').notNull(),
  minStopGuarantee: integer('min_stop_guarantee').default(100).notNull(),
  effectiveFrom: date('effective_from').defaultNow(),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
}, (table) => ({
  routeDepotIdx: uniqueIndex('route_depot_idx').on(table.routeCode, table.depotId)
}));

// 6. Courier Vehicles & Fleet Inventory (Strictly Courier Van Categories)
const vehicles = pgTable('vehicles', {
  id: text('id').primaryKey(),
  equipmentCode: varchar('equipment_code', { length: 50 }).unique(),
  modelNumber: varchar('model_number', { length: 50 }).notNull(),
  registrationNumber: varchar('registration_number', { length: 50 }),
  category: varchar('category', { length: 50 }).default('Standard Van').notNull(),
  ownershipType: varchar('ownership_type', { length: 30 }).default('Company'),
  hourlyRate: numeric('hourly_rate', { precision: 10, scale: 2 }).default('0'),
  dailyRate: numeric('daily_rate', { precision: 10, scale: 2 }).default('0'),
  monthlyRate: numeric('monthly_rate', { precision: 10, scale: 2 }).default('0'),
  weeklyRentalCost: numeric('weekly_rental_cost', { precision: 10, scale: 2 }).default('0'),
  currentMeterHours: numeric('current_meter_hours', { precision: 10, scale: 2 }).default('0'),
  lastServiceDate: date('last_service_date'),
  serviceIntervalHours: integer('service_interval_hours').default(250),
  status: varchar('status', { length: 50 }).default('Available'),
  assignedOperator: varchar('assigned_operator', { length: 150 }),
  assignedClient: varchar('assigned_client', { length: 150 }),
  motExpiry: date('mot_expiry'),
  taxExpiry: date('tax_expiry'),
  insuranceExpiry: date('insurance_expiry'),
  currentMileage: numeric('current_mileage', { precision: 10, scale: 2 }).default('0'),
  nextServiceMileage: numeric('next_service_mileage', { precision: 10, scale: 2 }).default('0'),
  depotLocation: varchar('depot_location', { length: 100 }),
  isActive: boolean('is_active').default(true).notNull(),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// 7. Suppliers & Garages Master
const suppliers = pgTable('suppliers', {
  id: text('id').primaryKey(),
  name: varchar('name', { length: 150 }).notNull(),
  contactDetails: text('contact_details'),
  servicesProvided: varchar('services_provided', { length: 200 }),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// 8. Maintenance Logs & Supplier Invoices
const maintenanceLogs = pgTable('maintenance_logs', {
  id: text('id').primaryKey(),
  vehicleId: text('vehicle_id').references(() => vehicles.id).notNull(),
  supplierId: text('supplier_id').references(() => suppliers.id),
  serviceDate: date('service_date').notNull(),
  serviceType: varchar('service_type', { length: 100 }).notNull(),
  odometerReading: numeric('odometer_reading', { precision: 10, scale: 2 }),
  laborCost: numeric('labor_cost', { precision: 10, scale: 2 }).default('0'),
  partsCost: numeric('parts_cost', { precision: 10, scale: 2 }).default('0'),
  totalCost: numeric('total_cost', { precision: 10, scale: 2 }).notNull(),
  invoiceNumber: varchar('invoice_number', { length: 100 }),
  description: text('description'),
  nextServiceDate: date('next_service_date'),
  nextServiceOdometer: numeric('next_service_odometer', { precision: 10, scale: 2 }),
  status: varchar('status', { length: 50 }).default('Completed').notNull(),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// 9. Accidents & Insurance Claims Register
const accidents = pgTable('accidents', {
  id: text('id').primaryKey(),
  vehicleId: text('vehicle_id').references(() => vehicles.id).notNull(),
  driverId: text('driver_id').references(() => drivers.id),
  incidentDate: date('incident_date').notNull(),
  claimNumber: varchar('claim_number', { length: 100 }),
  insuranceCompany: varchar('insurance_company', { length: 150 }),
  incidentType: varchar('incident_type', { length: 100 }).notNull(),
  faultStatus: varchar('fault_status', { length: 50 }),
  claimStatus: varchar('claim_status', { length: 50 }).default('Reported').notNull(),
  costEstimate: numeric('cost_estimate', { precision: 10, scale: 2 }).default('0'),
  actualCost: numeric('actual_cost', { precision: 10, scale: 2 }).default('0'),
  excessAmount: numeric('excess_amount', { precision: 10, scale: 2 }).default('0'),
  description: text('description'),
  policeReportRef: varchar('police_report_ref', { length: 100 }),
  isResolved: boolean('is_resolved').default(false).notNull(),
  resolvedDate: date('resolved_date'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// 10. Fuel Consumption Logs
const fuelLogs = pgTable('fuel_logs', {
  id: text('id').primaryKey(),
  refuelDate: date('refuel_date').notNull(),
  vehicleId: text('vehicle_id').references(() => vehicles.id).notNull(),
  driverId: text('driver_id').references(() => drivers.id),
  stationName: varchar('station_name', { length: 150 }).notNull(),
  litersFilled: numeric('liters_filled', { precision: 10, scale: 2 }).notNull(),
  totalCost: numeric('total_cost', { precision: 10, scale: 2 }).notNull(),
  odometerReading: numeric('odometer_reading', { precision: 10, scale: 2 }),
  fuelCardRef: varchar('fuel_card_ref', { length: 100 }),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
}, (table) => ({
  fuelVehicleIdx: index('fuel_vehicle_idx').on(table.vehicleId),
  fuelDateIdx: index('fuel_date_idx').on(table.refuelDate)
}));

// 11. Payroll Invoices
const payrollInvoices = pgTable('payroll_invoices', {
  id: text('id').primaryKey(),
  invoiceNumber: varchar('invoice_number', { length: 100 }).notNull().unique(),
  driverId: text('driver_id').references(() => drivers.id).notNull(),
  billingMonth: varchar('billing_month', { length: 50 }).notNull(),
  billingStartDate: date('billing_start_date').notNull(),
  billingEndDate: date('billing_end_date').notNull(),
  invoiceDate: date('invoice_date').notNull(),
  daysWorked: integer('days_worked').default(0).notNull(),
  totalStopsDispatched: integer('total_stops_dispatched').default(0).notNull(),
  totalPaidStops: integer('total_paid_stops').default(0).notNull(),
  totalStopPay: numeric('total_stop_pay', { precision: 10, scale: 2 }).default('0.00').notNull(),
  totalExcessParcelPay: numeric('total_excess_parcel_pay', { precision: 10, scale: 2 }).default('0.00').notNull(),
  totalTopUpPay: numeric('total_top_up_pay', { precision: 10, scale: 2 }).default('0.00').notNull(),
  grossEarnings: numeric('gross_earnings', { precision: 10, scale: 2 }).default('0.00').notNull(),
  totalDeductions: numeric('total_deductions', { precision: 10, scale: 2 }).default('0.00').notNull(),
  subtotal: numeric('subtotal', { precision: 10, scale: 2 }).default('0.00').notNull(),
  vatRate: numeric('vat_rate', { precision: 5, scale: 4 }).default('0.0000').notNull(),
  vatApplied: numeric('vat_applied', { precision: 10, scale: 2 }).default('0.00').notNull(),
  netPayable: numeric('net_payable', { precision: 10, scale: 2 }).default('0.00').notNull(),
  paymentStatus: varchar('payment_status', { length: 50 }).default('Draft').notNull(),
  status: varchar('status', { length: 50 }).default('Draft').notNull(), // 'Draft', 'Checked', 'Approved', 'Locked'
  paymentDate: date('payment_date'),
  paymentMethod: varchar('payment_method', { length: 50 }),
  notes: text('notes'),
  pdfPath: text('pdf_path'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

// 12. Daily Shifts Log
const dailyShifts = pgTable('daily_shifts', {
  id: text('id').primaryKey(),
  shiftDate: date('shift_date').notNull(),
  driverId: text('driver_id').references(() => drivers.id).notNull(),
  vehicleId: text('vehicle_id').references(() => vehicles.id),
  depotId: text('depot_id').references(() => depots.id),
  routeId: text('route_id').references(() => routeRates.id),
  routeCode: varchar('route_code', { length: 50 }),
  fdNumber: varchar('fd_number', { length: 50 }),
  dispatchedStops: integer('dispatched_stops').default(0).notNull(),
  paidStops: integer('paid_stops').default(0).notNull(),
  totalParcels: integer('total_parcels').default(0).notNull(),
  excessParcels: integer('excess_parcels').default(0).notNull(),
  mileage: numeric('mileage', { precision: 10, scale: 2 }).default('0'),
  appliedBaseRate: numeric('applied_base_rate', { precision: 10, scale: 4 }).default('1.0000').notNull(),
  appliedExcessRate: numeric('applied_excess_rate', { precision: 10, scale: 4 }).default('0.0500').notNull(),
  calculatedStopPay: numeric('calculated_stop_pay', { precision: 10, scale: 2 }).default('0.00').notNull(),
  calculatedParcelPay: numeric('calculated_parcel_pay', { precision: 10, scale: 2 }).default('0.00').notNull(),
  topUpStops: integer('top_up_stops').default(0).notNull(),
  topUpPay: numeric('top_up_pay', { precision: 10, scale: 2 }).default('0.00').notNull(),
  topUpCancelled: boolean('top_up_cancelled').default(false).notNull(),
  isTopUpCancelled: boolean('is_top_up_cancelled').default(false).notNull(),
  failPercentage: numeric('fail_percentage', { precision: 5, scale: 2 }).default('0.00'),
  grossShiftTotal: numeric('gross_shift_total', { precision: 10, scale: 2 }).default('0.00').notNull(),
  invoiceId: text('invoice_id').references(() => payrollInvoices.id),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
}, (table) => ({
  driverShiftDateUnique: uniqueIndex('driver_shift_date_idx').on(table.driverId, table.shiftDate),
  shiftInvoiceIdx: index('shift_invoice_idx').on(table.invoiceId)
}));

// 13. Charges and Deductions Ledger
const chargesAndDeductions = pgTable('charges_and_deductions', {
  id: text('id').primaryKey(),
  billingMonth: varchar('billing_month', { length: 50 }),
  billingPeriod: varchar('billing_period', { length: 50 }),
  chargeDate: date('charge_date').notNull(),
  driverId: text('driver_id').references(() => drivers.id).notNull(),
  cdType: varchar('cd_type', { length: 50 }),
  chargeType: varchar('charge_type', { length: 50 }),
  amount: numeric('amount', { precision: 10, scale: 2 }).notNull(),
  vehicleId: text('vehicle_id').references(() => vehicles.id),
  invoiceId: text('invoice_id').references(() => payrollInvoices.id),
  notes: text('notes'),
  isSettled: boolean('is_settled').default(false).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
}, (table) => ({
  chargesDriverMonthIdx: index('charges_driver_month_idx').on(table.driverId, table.billingMonth),
  chargesInvoiceIdx: index('charges_invoice_idx').on(table.invoiceId)
}));

// 14. Audit Trails Ledger (Phase 3 Financial Controls)
const auditLogs = pgTable('audit_logs', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id),
  userName: varchar('user_name', { length: 150 }),
  userEmail: varchar('user_email', { length: 150 }),
  actionType: varchar('action_type', { length: 100 }).notNull(),
  tableAffected: varchar('table_affected', { length: 100 }).notNull(),
  recordId: text('record_id'),
  previousValue: text('previous_value'),
  newValue: text('new_value'),
  reason: text('reason'),
  createdAt: timestamp('created_at').defaultNow().notNull()
}, (table) => ({
  auditActionIdx: index('audit_action_idx').on(table.actionType),
  auditTableIdx: index('audit_table_idx').on(table.tableAffected),
  auditCreatedIdx: index('audit_created_idx').on(table.createdAt)
}));

// 15. App Settings
const appSettings = pgTable('app_settings', {
  key: varchar('key', { length: 100 }).primaryKey(),
  value: text('value').notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull()
});

module.exports = {
  COURIER_VEHICLE_CATEGORIES,
  depots,
  users,
  drivers,
  driverAvailability,
  routeRates,
  vehicles,
  suppliers,
  maintenanceLogs,
  accidents,
  fuelLogs,
  payrollInvoices,
  dailyShifts,
  chargesAndDeductions,
  auditLogs,
  appSettings
};