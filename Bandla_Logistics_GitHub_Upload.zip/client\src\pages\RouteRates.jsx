import React, { useState, useEffect } from 'react';
import { Navigation, Plus, Search, Filter, Edit, Trash2 } from 'lucide-react';
import { getRouteRates, getDepots, createRouteRate, updateRouteRate, deleteRouteRate } from '../services/api';
import Modal from '../components/Modal';
import { formatCurrency, formatNumber } from '../utils/formatters';

export default function RouteRates() {
  const [rates, setRates] = useState([]);
  const [depots, setDepots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [depotFilter, setDepotFilter] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRate, setEditingRate] = useState(null);

  const [formData, setFormData] = useState({
    routeCode: '',
    depotId: '',
    baseRatePerStop: 2.10,
    excessParcelRate: 0.05,
    minStopGuarantee: 100,
    notes: ''
  });

  useEffect(() => {
    loadData();
  }, [depotFilter]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [rList, depList] = await Promise.all([
        getRouteRates({ depotId: depotFilter || undefined }),
        getDepots()
      ]);
      setRates(rList);
      setDepots(depList);
    } catch (err) {
      console.error('Error loading route rates:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenAdd = () => {
    setEditingRate(null);
    setFormData({
      routeCode: '',
      depotId: depots[0]?.id || '',
      baseRatePerStop: 2.10,
      excessParcelRate: 0.05,
      minStopGuarantee: 100,
      notes: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (rate) => {
    setEditingRate(rate);
    setFormData({
      routeCode: rate.route_code || '',
      depotId: rate.depot_id || '',
      baseRatePerStop: parseFloat(rate.base_rate_per_stop || 0),
      excessParcelRate: parseFloat(rate.excess_parcel_rate || 0.05),
      minStopGuarantee: rate.min_stop_guarantee || 100,
      notes: rate.notes || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingRate) {
        await updateRouteRate(editingRate.id, formData);
      } else {
        await createRouteRate(formData);
      }
      setIsModalOpen(false);
      loadData();
    } catch (err) {
      console.warn('Error saving route rate: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDelete = async (id) => {
    
    try {
      await deleteRouteRate(id);
      loadData();
    } catch (err) {
      console.warn('Error deleting route rate: ' + (err.response?.data?.error || err.message));
    }
  };

  const filtered = rates.filter(r => {
    if (!search) return true;
    const q = search.toLowerCase();
    return r.route_code?.toLowerCase().includes(q) || r.depot_name?.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-sky-500/10 text-sky-600 dark:text-sky-400 rounded-xl">
            <Navigation className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Route Rates Master</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Baseline stop rates, £0.05 excess parcel rate rules, and 100-stop minimum guarantee</p>
          </div>
        </div>
        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-slate-900 dark:text-white text-xs font-semibold rounded-lg shadow-lg shadow-sky-600/20 flex items-center gap-1.5 transition"
        >
          <Plus className="w-4 h-4" /> Configure Route Rate
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm dark:shadow-lg flex flex-wrap gap-4 items-center justify-between">
        <div className="relative flex-1 min-w-[280px]">
          <Search className="w-4 h-4 text-slate-500 dark:text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by route code (e.g. 114, 123, 731)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>
        <div>
          <select
            value={depotFilter}
            onChange={(e) => setDepotFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-sky-500"
          >
            <option value="">All Depots</option>
            {depots.map(d => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Rates Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500 dark:text-slate-400">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-500 mx-auto mb-2"></div>
            <span>Loading route rates...</span>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="p-3.5">Route Code</th>
                  <th className="p-3.5">Depot Hub</th>
                  <th className="p-3.5 text-right">Base Stop Rate</th>
                  <th className="p-3.5 text-right">Excess Parcel Bonus</th>
                  <th className="p-3.5 text-right">Min Guarantee</th>
                  <th className="p-3.5">Notes</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                {filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                    <td className="p-3.5 font-bold text-slate-900 dark:text-white text-sm">Route {r.route_code}</td>
                    <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium">{r.depot_name || 'All Depots (Default)'}</td>
                    <td className="p-3.5 text-right font-bold text-emerald-600 dark:text-emerald-400 text-sm">
                      £{parseFloat(r.base_rate_per_stop).toFixed(4)} / stop
                    </td>
                    <td className="p-3.5 text-right font-semibold text-amber-600 dark:text-amber-400">
                      £{parseFloat(r.excess_parcel_rate).toFixed(2)} / parcel
                    </td>
                    <td className="p-3.5 text-right text-sky-600 dark:text-sky-400 font-semibold">
                      {r.min_stop_guarantee} stops
                    </td>
                    <td className="p-3.5 text-slate-500 dark:text-slate-400">{r.notes || '-'}</td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenEdit(r)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 transition"
                          title="Edit Route Rate"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(r.id)}
                          className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 transition"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingRate ? 'Edit Route Rate' : 'Configure Route Rate'}
        maxWidth="max-w-md"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Route Code</label>
              <input
                type="text"
                value={formData.routeCode}
                onChange={(e) => setFormData({ ...formData, routeCode: e.target.value })}
                placeholder="e.g. 114"
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Depot Hub</label>
              <select
                value={formData.depotId}
                onChange={(e) => setFormData({ ...formData, depotId: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
              >
                <option value="">All Depots (Default)</option>
                {depots.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Base Rate (£/stop)</label>
              <input
                type="number"
                step="0.0001"
                value={formData.baseRatePerStop}
                onChange={(e) => setFormData({ ...formData, baseRatePerStop: parseFloat(e.target.value || 0) })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Parcel Bonus (£)</label>
              <input
                type="number"
                step="0.01"
                value={formData.excessParcelRate}
                onChange={(e) => setFormData({ ...formData, excessParcelRate: parseFloat(e.target.value || 0) })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Min Guarantee</label>
              <input
                type="number"
                value={formData.minStopGuarantee}
                onChange={(e) => setFormData({ ...formData, minStopGuarantee: parseInt(e.target.value || 0, 10) })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Notes</label>
            <input
              type="text"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="e.g. Standard London North route"
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-slate-900 dark:text-white text-xs font-semibold rounded-lg shadow-lg shadow-sky-600/20 transition"
            >
              Save Rate
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
