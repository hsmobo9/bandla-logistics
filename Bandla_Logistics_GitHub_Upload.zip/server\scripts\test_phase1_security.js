const { startServer } = require('../index');
const { initDb, getDb } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

async function apiRequest(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    data = null;
  }
  return { status: res.status, data };
}

async function runSecurityTestSuite() {
  console.log('========================================================================');
  console.log('PHASE 1 VERIFICATION: CLOUD ARCHITECTURE, RBAC SECURITY & SCHEMA');
  console.log('========================================================================\n');

  const { server, port } = await startServer(4006);
  const baseURL = `http://localhost:${port}`;
  const testResults = [];
  const recordTest = (name, passed, details = '') => {
    testResults.push({ Test: name, Status: passed ? 'PASSED ✅' : 'FAILED ❌', Details: details });
    console.log(`[${passed ? 'PASS' : 'FAIL'}] ${name} ${details ? '(' + details + ')' : ''}`);
  };

  try {
    // 1. Logins
    const adminLoginRes = await apiRequest(`${baseURL}/api/auth/login`, {
      method: 'POST',
      body: { emailOrUsername: 'admin@bandlalogistics.co.uk', password: 'AdminPass123!' }
    });
    const adminToken = adminLoginRes.data?.token;

    const managerLoginRes = await apiRequest(`${baseURL}/api/auth/login`, {
      method: 'POST',
      body: { emailOrUsername: 'manager@bandlalogistics.co.uk', password: 'ManagerPass123!' }
    });
    const managerToken = managerLoginRes.data?.token;

    // 2. Seed a test driver for Step 4 & 5
    const db = getDb();
    const pgClient = db.session.client;
    const testDriverId = uuidv4();
    await pgClient.query(`
      INSERT INTO drivers (id, driver_code, full_name, status)
      VALUES ($1, 'DR9999', 'Test Contractor Driver', 'active')
    `, [testDriverId]);

    // 3. Step 5: Signed Decimal - Positive Deduction (+£175.50)
    const posChargeRes = await apiRequest(`${baseURL}/api/charges`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        billingMonth: 'August 2026',
        chargeDate: '2026-08-15',
        driverId: testDriverId,
        cdType: 'Van Hire',
        amount: 175.50,
        notes: 'Test positive deduction'
      }
    });
    recordTest('Step 5: Signed Decimal Positive Deduction (+£175.50)', posChargeRes.status === 201 && parseFloat(posChargeRes.data?.amount) === 175.50, `Stored: £${posChargeRes.data?.amount}`);

    // 4. Step 5: Signed Decimal - Negative Manual Credit (-£50.00)
    const negChargeRes = await apiRequest(`${baseURL}/api/charges`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        billingMonth: 'August 2026',
        chargeDate: '2026-08-16',
        driverId: testDriverId,
        cdType: 'Credit Reimbursement',
        amount: -50.00,
        notes: 'Test negative manual credit for driver support'
      }
    });
    recordTest('Step 5: Signed Decimal Negative Credit (-£50.00)', negChargeRes.status === 201 && parseFloat(negChargeRes.data?.amount) === -50.00, `Stored: £${negChargeRes.data?.amount}`);

    // 5. Step 4: Daily Shifts Dispatched vs Paid & Fail Percentage (120 dispatched, 108 paid -> 10.00% fail)
    const shiftCreateRes = await apiRequest(`${baseURL}/api/shifts`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${managerToken}` },
      body: {
        shiftDate: '2026-08-20',
        driverId: testDriverId,
        dispatchedStops: 120,
        paidStops: 108,
        totalParcels: 130,
        appliedBaseRate: 2.10,
        isTopUpCancelled: false,
        notes: 'Test reconciliation shift'
      }
    });
    const createdShift = shiftCreateRes.data;
    const failPctExpected = 10.00;
    const isFailPctValid = Math.abs(parseFloat(createdShift?.fail_percentage) - failPctExpected) < 0.05;
    recordTest('Step 4: Shift Dispatched vs Paid & Fail % (10.00%)', shiftCreateRes.status === 201 && isFailPctValid, `Fail %: ${createdShift?.fail_percentage}%`);

    // Clean up test records
    await pgClient.query('DELETE FROM charges_and_deductions WHERE driver_id = $1', [testDriverId]);
    await pgClient.query('DELETE FROM daily_shifts WHERE driver_id = $1', [testDriverId]);
    await pgClient.query('DELETE FROM drivers WHERE id = $1', [testDriverId]);

    console.log('\n========================================================================');
    console.log('COMPLETE PHASE 1 VERIFICATION TABLE');
    console.log('========================================================================');
    console.table(testResults);

  } finally {
    server.close();
  }
}

runSecurityTestSuite().then(() => process.exit(0)).catch(err => {
  console.error('Fatal Error:', err);
  process.exit(1);
});