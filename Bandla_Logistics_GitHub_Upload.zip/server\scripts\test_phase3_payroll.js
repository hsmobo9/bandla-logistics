const { startServer } = require('../index');
const { initDb, getDb } = require('../config/db');

async function apiRequest(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    data = null;
  }
  return { status: res.status, data };
}

async function runPayrollTestSuite() {
  console.log('========================================================================');
  console.log('PHASE 3 VERIFICATION: DYNAMIC BASE PAY, EXCESS PARCEL BONUS & LOCKING');
  console.log('========================================================================\n');

  const { server, port } = await startServer(4010);
  const baseURL = `http://localhost:${port}`;
  const testResults = [];
  const recordTest = (name, passed, details = '') => {
    testResults.push({ Test: name, Status: passed ? 'PASSED ✅' : 'FAILED âŒ', Details: details });
    console.log(`[${passed ? 'PASS' : 'FAIL'}] ${name} ${details ? '(' + details + ')' : ''}`);
  };

  let driver = null;
  let shift1 = null;
  let shift2 = null;
  let creditCharge = null;
  let invoice = null;

  try {
    // 1. Auth Tokens
    const adminLoginRes = await apiRequest(`${baseURL}/api/auth/login`, {
      method: 'POST',
      body: { emailOrUsername: 'admin@bandlalogistics.co.uk', password: 'AdminPass123!' }
    });
    const adminToken = adminLoginRes.data?.token;

    const managerLoginRes = await apiRequest(`${baseURL}/api/auth/login`, {
      method: 'POST',
      body: { emailOrUsername: 'manager@bandlalogistics.co.uk', password: 'ManagerPass123!' }
    });
    const managerToken = managerLoginRes.data?.token;

    recordTest('Authentication Tokens Active', adminToken && managerToken, 'Admin & ShiftManager Tokens Active');

    // 2. Setup Test Driver & Initial Shift
    const driverRes = await apiRequest(`${baseURL}/api/drivers`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        driverCode: 'DR9902',
        fullName: 'Amanpreet Singh (Payroll Verification)',
        phone: '07966270270',
        isVatRegistered: true,
        vatNumber: 'GB376546166',
        status: 'active'
      }
    });
    driver = driverRes.data;
    recordTest('Driver Setup (VAT 20%)', driverRes.status === 201, `Driver ID: ${driver?.id}`);

    const shift1Res = await apiRequest(`${baseURL}/api/shifts`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        shiftDate: '2026-08-10',
        driverId: driver.id,
        routeCode: '114',
        dispatchedStops: 125,
        paidStops: 0,
        totalParcels: 165
      }
    });
    shift1 = shift1Res.data;
    recordTest('Initial Unreconciled Shift Created', shift1Res.status === 201, `Shift ID: ${shift1?.id}`);

    // 3. Step 1: Automated Portal CSV Ingestion with Portal Data Row (Stop = 278.75, Excess = 40, Parcels = 2.00, Total = 280.75)
    const csvContent = `FD Number,Date,No of Stops,Total Parcels,Excess Parcels,Stop,Parcels,Total,Route,Mileage,Driver,Top Up Cancellation\nFD71885,2026-08-10,125,165,40,278.75,2.00,280.75,114,129,DR9902 Amanpreet Singh,false\nFD71886,2026-08-11,80,95,15,100.00,0.75,120.75,115,85,DR9902 Amanpreet Singh,false`;
    
    const formData = new FormData();
    const blob = new Blob([csvContent], { type: 'text/csv' });
    formData.append('file', blob, 'Portal_August_2026.csv');

    const uploadRes = await fetch(`${baseURL}/api/shifts/upload-portal-csv`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: formData
    });
    const uploadData = await uploadRes.json();
    recordTest('Step 1: Portal CSV Ingestion & Reconciliation', uploadRes.status === 200 && uploadData.matchedRows === 2, `Matched: ${uploadData.matchedRows}, Updated: ${uploadData.updatedShifts}, Created: ${uploadData.createdShifts}`);

    // Verify reconciled shift calculations:
    // Dynamic Base Stop Pay = Â£278.75 (from Stop column)
    // Excess Parcel Bonus = 40 * Â£0.05 = Â£2.00
    // Gross Total = 278.75 + 2.00 = Â£280.75
    const checkShift1 = await apiRequest(`${baseURL}/api/shifts/${shift1.id}`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    const s1 = checkShift1.data;
    const isDynamicStopPay = parseFloat(s1.calculated_stop_pay) === 278.75;
    const isExcessParcelBonus = parseFloat(s1.calculated_parcel_pay) === 2.00;
    const isGrossTotalMatch = parseFloat(s1.gross_shift_total) === 280.75;
    recordTest('Step 1: Dynamic Base Pay (Â£278.75 from CSV Stop col)', isDynamicStopPay, `Stop Pay: Â£${s1.calculated_stop_pay}`);
    recordTest('Step 1: Excess Parcel Bonus (40 excess * Â£0.05 = Â£2.00)', isExcessParcelBonus, `Bonus: Â£${s1.calculated_parcel_pay}`);
    recordTest('Step 1: Gross Shift Total Validated (Â£280.75 = CSV Total)', isGrossTotalMatch, `Gross: Â£${s1.gross_shift_total}`);

    // 4. Low-Stop Shift with Top-Up Guarantee & Excess Parcel Bonus (80 stops -> Â£100 stop pay + Â£0.75 parcel bonus + Â£20 top-up)
    const shiftsList = await apiRequest(`${baseURL}/api/shifts?driverId=${driver.id}&startDate=2026-08-11&endDate=2026-08-11`, {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    shift2 = shiftsList.data[0];
    const isShift2TopUp = parseFloat(shift2?.top_up_pay) === 25.00 && parseFloat(shift2?.calculated_parcel_pay) === 0.75;
    recordTest('Step 1 & 2: Low-Stop Top-Up Guarantee + Excess Parcels', isShift2TopUp, `Top-Up: Â£${shift2?.top_up_pay}, Bonus: Â£${shift2?.calculated_parcel_pay}, Gross: Â£${shift2?.gross_shift_total}`);

    // 5. Top-Up Cancellation Override with Audit Trail
    const toggleRes = await apiRequest(`${baseURL}/api/shifts/${shift2.id}/toggle-top-up`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { reason: 'Early finish requested by contractor' }
    });
    const shift2Updated = toggleRes.data?.shift;
    const isTopUpCancelled = shift2Updated?.is_top_up_cancelled === true && parseFloat(shift2Updated?.gross_shift_total) === 100.75;
    recordTest('Step 3: Top-Up Cancelled Override (Â£100.75 gross total)', isTopUpCancelled, `Gross: Â£${shift2Updated?.gross_shift_total}`);

    // 6. Negative Decimal Credit / Reimbursement
    const creditChargeRes = await apiRequest(`${baseURL}/api/charges`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        driverId: driver.id,
        billingMonth: 'August 2026',
        chargeDate: '2026-08-15',
        cdType: 'Fuel Repayment',
        amount: -50.00,
        notes: 'Driver authorized diesel reimbursement',
        reason: 'Fuel credit approved by fleet manager'
      }
    });
    creditCharge = creditChargeRes.data;
    recordTest('Step 3: Negative Decimal Credit (-Â£50.00)', creditChargeRes.status === 201 && parseFloat(creditCharge?.amount) === -50.00, `Amount: Â£${creditCharge?.amount}`);

    // 7. Generate Monthly Invoice & State Machine (Draft -> Locked)
    const generateInvRes = await apiRequest(`${baseURL}/api/invoices/generate`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        driverId: driver.id,
        billingMonth: 'August 2026',
        billingStartDate: '2026-08-01',
        billingEndDate: '2026-08-31',
        invoiceDate: '2026-08-31'
      }
    });
    invoice = generateInvRes.data;
    recordTest('Step 4: Invoice Generated', generateInvRes.status === 201, `Invoice #${invoice?.invoiceNumber}`);

    // Generate PDF to verify legal branding & header
    const pdfRes = await apiRequest(`${baseURL}/api/invoices/${invoice.id}/pdf`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    recordTest('Step 3: Legal Branding PDF Generated', pdfRes.status === 200 && pdfRes.data?.pdfFileName, `PDF: ${pdfRes.data?.pdfFileName}`);

    // Transition invoice state: Draft -> Locked
    const lockRes = await apiRequest(`${baseURL}/api/invoices/${invoice.id}/status`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { status: 'Locked', reason: 'Final payroll lock by Finance Director' }
    });
    recordTest('Step 4: Invoice State Transition to LOCKED', lockRes.status === 200 && lockRes.data?.status === 'Locked', 'Status: Locked ðŸ”’');

    // 8. Locked Invoice Security Enforcement
    const lockedShiftEdit = await apiRequest(`${baseURL}/api/shifts/${shift1.id}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { paidStops: 130 }
    });
    recordTest('Step 4: Locked Invoice BLOCKS Shift Updates (403 Forbidden)', lockedShiftEdit.status === 403, `HTTP Status: ${lockedShiftEdit.status}`);

    const lockedChargeDelete = await apiRequest(`${baseURL}/api/charges/${creditCharge.id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    recordTest('Step 4: Locked Invoice BLOCKS Charge Deletions (403 Forbidden)', lockedChargeDelete.status === 403, `HTTP Status: ${lockedChargeDelete.status}`);

    // 9. RBAC Boundary Enforcement
    const managerInvoice = await apiRequest(`${baseURL}/api/invoices`, {
      headers: { Authorization: `Bearer ${managerToken}` }
    });
    recordTest('RBAC: ShiftManager BLOCKED from Invoices Hub (403 Forbidden)', managerInvoice.status === 403, `Status: ${managerInvoice.status}`);

    console.log('\n========================================================================');
    console.log('COMPLETE PHASE 3 VERIFICATION TABLE');
    console.log('========================================================================');
    console.table(testResults);

  } finally {
    // Cleanup test records
    try {
      const db = getDb();
      const client = db.session.client;
      if (shift2?.id || creditCharge?.id || invoice?.id) {
        await client.query('DELETE FROM audit_logs WHERE record_id = $1 OR record_id = $2 OR record_id = $3', [shift2?.id || '', creditCharge?.id || '', invoice?.id || '']);
      }
      if (driver?.id) {
        await client.query('DELETE FROM daily_shifts WHERE driver_id = $1', [driver.id]);
        await client.query('DELETE FROM charges_and_deductions WHERE driver_id = $1', [driver.id]);
      }
      if (invoice?.id) {
        await client.query('DELETE FROM payroll_invoices WHERE id = $1', [invoice.id]);
      }
      if (driver?.id) {
        await client.query('DELETE FROM drivers WHERE id = $1', [driver.id]);
      }
    } catch (e) {
      console.warn('Cleanup notice:', e.message);
    }
    server.close();
  }
}

runPayrollTestSuite().then(() => process.exit(0)).catch(err => {
  console.error('Fatal Error in Test Suite:', err);
  process.exit(1);
});