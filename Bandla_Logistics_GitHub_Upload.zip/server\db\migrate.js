const { initDb } = require('../config/db');

async function migrate() {
  console.log('Running database migrations & schema unification on PostgreSQL...');
  const { client } = await initDb();

  const migrationQueries = [
    // 1. Depots
    `CREATE TABLE IF NOT EXISTS depots (
      id TEXT PRIMARY KEY,
      code VARCHAR(20) NOT NULL UNIQUE,
      name VARCHAR(100) NOT NULL,
      address TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,

    // 2. Users
    `CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username VARCHAR(100) NOT NULL UNIQUE,
      email VARCHAR(150) NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      full_name VARCHAR(150) NOT NULL,
      role VARCHAR(50) NOT NULL,
      depot_id TEXT REFERENCES depots(id),
      status VARCHAR(30) NOT NULL DEFAULT 'active',
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS user_role_idx ON users (role);`,
    `CREATE UNIQUE INDEX IF NOT EXISTS user_email_idx ON users (email);`,

    // 3. Drivers
    `CREATE TABLE IF NOT EXISTS drivers (
      id TEXT PRIMARY KEY,
      driver_code VARCHAR(50) UNIQUE,
      full_name VARCHAR(150) NOT NULL,
      phone VARCHAR(50),
      email VARCHAR(100),
      default_depot_id TEXT REFERENCES depots(id),
      assigned_vehicle_reg VARCHAR(50),
      assigned_fd_number VARCHAR(50),
      is_vat_registered BOOLEAN NOT NULL DEFAULT FALSE,
      vat_number VARCHAR(50),
      status VARCHAR(30) NOT NULL DEFAULT 'active',
      license_number VARCHAR(50),
      license_expiry DATE,
      pass_date DATE,
      dvla_points INTEGER NOT NULL DEFAULT 0,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      notes TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS driver_name_idx ON drivers (full_name);`,
    `CREATE INDEX IF NOT EXISTS driver_active_idx ON drivers (is_active);`,

    // 4. Driver Availability
    `CREATE TABLE IF NOT EXISTS driver_availability (
      id TEXT PRIMARY KEY,
      driver_id TEXT NOT NULL REFERENCES drivers(id),
      start_date DATE NOT NULL,
      end_date DATE NOT NULL,
      status VARCHAR(30) NOT NULL DEFAULT 'Holiday',
      notes TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS driver_avail_date_idx ON driver_availability (driver_id, start_date, end_date);`,

    // 5. Route Rates
    `CREATE TABLE IF NOT EXISTS route_rates (
      id TEXT PRIMARY KEY,
      route_code VARCHAR(50) NOT NULL,
      depot_id TEXT REFERENCES depots(id),
      base_rate_per_stop NUMERIC(10, 4) NOT NULL,
      excess_parcel_rate NUMERIC(10, 4) NOT NULL DEFAULT 0.0000,
      min_stop_guarantee INTEGER NOT NULL DEFAULT 100,
      effective_from DATE DEFAULT CURRENT_DATE,
      notes TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,
    `CREATE UNIQUE INDEX IF NOT EXISTS route_depot_idx ON route_rates (route_code, depot_id);`,

    // 6. Vehicles
    `CREATE TABLE IF NOT EXISTS vehicles (
      id TEXT PRIMARY KEY,
      equipment_code VARCHAR(50) UNIQUE,
      model_number VARCHAR(50) NOT NULL,
      registration_number VARCHAR(50),
      category VARCHAR(50) NOT NULL DEFAULT 'Standard Van',
      ownership_type VARCHAR(30) DEFAULT 'Company',
      hourly_rate NUMERIC(10, 2) DEFAULT 0,
      daily_rate NUMERIC(10, 2) DEFAULT 0,
      monthly_rate NUMERIC(10, 2) DEFAULT 0,
      weekly_rental_cost NUMERIC(10, 2) DEFAULT 0,
      current_meter_hours NUMERIC(10, 2) DEFAULT 0,
      last_service_date DATE,
      service_interval_hours INTEGER DEFAULT 250,
      status VARCHAR(50) DEFAULT 'Available',
      assigned_operator VARCHAR(150),
      assigned_client VARCHAR(150),
      mot_expiry DATE,
      tax_expiry DATE,
      insurance_expiry DATE,
      current_mileage NUMERIC(10, 2) DEFAULT 0,
      next_service_mileage NUMERIC(10, 2) DEFAULT 0,
      depot_location VARCHAR(100),
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      notes TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,

    // 7. Suppliers & Garages
    `CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      contact_details TEXT,
      services_provided VARCHAR(200),
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,

    // 8. Maintenance Logs
    `CREATE TABLE IF NOT EXISTS maintenance_logs (
      id TEXT PRIMARY KEY,
      vehicle_id TEXT NOT NULL REFERENCES vehicles(id),
      supplier_id TEXT REFERENCES suppliers(id),
      date DATE NOT NULL DEFAULT CURRENT_DATE,
      service_date DATE,
      issue_category VARCHAR(100) DEFAULT 'Scheduled Maintenance',
      labor_cost NUMERIC(10, 2) DEFAULT 0,
      parts_cost NUMERIC(10, 2) DEFAULT 0,
      total_cost NUMERIC(10, 2) NOT NULL DEFAULT 0,
      notes TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,

    // 9. Accident Logs
    `CREATE TABLE IF NOT EXISTS accident_logs (
      id TEXT PRIMARY KEY,
      vehicle_id TEXT NOT NULL REFERENCES vehicles(id),
      driver_id TEXT REFERENCES drivers(id),
      date DATE NOT NULL DEFAULT CURRENT_DATE,
      description TEXT NOT NULL,
      insurance_claim_status VARCHAR(50) NOT NULL DEFAULT 'Reported',
      estimated_damage_cost NUMERIC(10, 2) DEFAULT 0,
      third_party_details TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,

    // 10. Fuel Consumption Logs
    `CREATE TABLE IF NOT EXISTS fuel_logs (
      id TEXT PRIMARY KEY,
      refuel_date DATE NOT NULL,
      vehicle_id TEXT NOT NULL REFERENCES vehicles(id),
      driver_id TEXT REFERENCES drivers(id),
      station_name VARCHAR(150) NOT NULL,
      liters_filled NUMERIC(10, 2) NOT NULL,
      total_cost NUMERIC(10, 2) NOT NULL,
      odometer_reading NUMERIC(10, 2),
      fuel_card_ref VARCHAR(100),
      notes TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS fuel_vehicle_idx ON fuel_logs (vehicle_id);`,
    `CREATE INDEX IF NOT EXISTS fuel_date_idx ON fuel_logs (refuel_date);`,

    // 11. Payroll Invoices
    `CREATE TABLE IF NOT EXISTS payroll_invoices (
      id TEXT PRIMARY KEY,
      invoice_number VARCHAR(100) NOT NULL UNIQUE,
      driver_id TEXT NOT NULL REFERENCES drivers(id),
      billing_month VARCHAR(50) NOT NULL,
      billing_start_date DATE NOT NULL,
      billing_end_date DATE NOT NULL,
      invoice_date DATE NOT NULL,
      days_worked INTEGER NOT NULL DEFAULT 0,
      total_stops_dispatched INTEGER NOT NULL DEFAULT 0,
      total_paid_stops INTEGER NOT NULL DEFAULT 0,
      total_stop_pay NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      total_excess_parcel_pay NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      total_top_up_pay NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      gross_earnings NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      total_deductions NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      subtotal NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      vat_rate NUMERIC(5, 4) NOT NULL DEFAULT 0.0000,
      vat_applied NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      net_payable NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      payment_status VARCHAR(50) NOT NULL DEFAULT 'Draft',
      status VARCHAR(50) NOT NULL DEFAULT 'Draft',
      payment_date DATE,
      payment_method VARCHAR(50),
      notes TEXT,
      pdf_path TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,

    // 12. Daily Shifts Log
    `CREATE TABLE IF NOT EXISTS daily_shifts (
      id TEXT PRIMARY KEY,
      shift_date DATE NOT NULL,
      driver_id TEXT NOT NULL REFERENCES drivers(id),
      vehicle_id TEXT REFERENCES vehicles(id),
      depot_id TEXT REFERENCES depots(id),
      route_id TEXT REFERENCES route_rates(id),
      route_code VARCHAR(50),
      fd_number VARCHAR(50),
      dispatched_stops INTEGER NOT NULL DEFAULT 0,
      paid_stops INTEGER NOT NULL DEFAULT 0,
      total_parcels INTEGER NOT NULL DEFAULT 0,
      excess_parcels INTEGER NOT NULL DEFAULT 0,
      mileage NUMERIC(10, 2) DEFAULT 0,
      applied_base_rate NUMERIC(10, 4) NOT NULL DEFAULT 1.0000,
      applied_excess_rate NUMERIC(10, 4) NOT NULL DEFAULT 0.0500,
      calculated_stop_pay NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      calculated_parcel_pay NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      top_up_stops INTEGER NOT NULL DEFAULT 0,
      top_up_pay NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      top_up_cancelled BOOLEAN NOT NULL DEFAULT FALSE,
      is_top_up_cancelled BOOLEAN NOT NULL DEFAULT FALSE,
      fail_percentage NUMERIC(5, 2) DEFAULT 0.00,
      gross_shift_total NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
      invoice_id TEXT REFERENCES payroll_invoices(id),
      notes TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,
    `CREATE UNIQUE INDEX IF NOT EXISTS driver_shift_date_idx ON daily_shifts (driver_id, shift_date);`,
    `CREATE INDEX IF NOT EXISTS shift_invoice_idx ON daily_shifts (invoice_id);`,

    // 13. Charges and Deductions
    `CREATE TABLE IF NOT EXISTS charges_and_deductions (
      id TEXT PRIMARY KEY,
      billing_month VARCHAR(50),
      billing_period VARCHAR(50),
      charge_date DATE NOT NULL,
      driver_id TEXT NOT NULL REFERENCES drivers(id),
      cd_type VARCHAR(50),
      charge_type VARCHAR(50),
      amount NUMERIC(10, 2) NOT NULL,
      vehicle_id TEXT REFERENCES vehicles(id),
      invoice_id TEXT REFERENCES payroll_invoices(id),
      notes TEXT,
      is_settled BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS charges_driver_month_idx ON charges_and_deductions (driver_id, billing_month);`,
    `CREATE INDEX IF NOT EXISTS charges_invoice_idx ON charges_and_deductions (invoice_id);`,

    // 14. Audit Trails Ledger
    `CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id),
      user_name VARCHAR(150),
      user_email VARCHAR(150),
      action_type VARCHAR(100) NOT NULL,
      table_affected VARCHAR(100) NOT NULL,
      record_id TEXT,
      previous_value TEXT,
      new_value TEXT,
      reason TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`,
    `CREATE INDEX IF NOT EXISTS audit_action_idx ON audit_logs (action_type);`,
    `CREATE INDEX IF NOT EXISTS audit_table_idx ON audit_logs (table_affected);`,
    `CREATE INDEX IF NOT EXISTS audit_created_idx ON audit_logs (created_at);`,

    // 15. App Settings
    `CREATE TABLE IF NOT EXISTS app_settings (
      key VARCHAR(100) PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TIMESTAMP NOT NULL DEFAULT NOW()
    );`
  ];

  for (const q of migrationQueries) {
    await client.query(q);
  }

  // Ensure category normalization & purge
  await client.query(`
    UPDATE vehicles 
    SET category = 'Standard Van' 
    WHERE category = 'Van' OR category = 'Delivery Van' OR category IS NULL OR category = '';
  `);

  await client.query(`
    DELETE FROM vehicles 
    WHERE category NOT IN ('Standard Van', 'LWB Van', 'SWB Van', 'Luton Van', 'Courier Car', 'Other');
  `);

  try { await client.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS permissions TEXT DEFAULT '[]';`); } catch (e) {}
  try { await client.query(`ALTER TABLE drivers ADD COLUMN IF NOT EXISTS ni_number VARCHAR(50);`); } catch (e) {}
  try { await client.query(`ALTER TABLE drivers ADD COLUMN IF NOT EXISTS dob DATE;`); } catch (e) {}
  try { await client.query(`ALTER TABLE drivers ADD COLUMN IF NOT EXISTS address TEXT;`); } catch (e) {}
  try { await client.query(`ALTER TABLE drivers ADD COLUMN IF NOT EXISTS passport_number VARCHAR(50);`); } catch (e) {}
  try { await client.query(`ALTER TABLE drivers ADD COLUMN IF NOT EXISTS passport_expiry DATE;`); } catch (e) {}
  try { await client.query(`ALTER TABLE drivers ADD COLUMN IF NOT EXISTS right_to_work_status VARCHAR(100);`); } catch (e) {}
  try { await client.query(`ALTER TABLE drivers ADD COLUMN IF NOT EXISTS right_to_work_expiry DATE;`); } catch (e) {}
  try { await client.query(`ALTER TABLE drivers ADD COLUMN IF NOT EXISTS sponsor_required BOOLEAN DEFAULT FALSE;`); } catch (e) {}

  try { await client.query(`ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS has_livery BOOLEAN DEFAULT TRUE;`); } catch (e) {}
  try { await client.query(`ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS keys_count INTEGER DEFAULT 1;`); } catch (e) {}
  try { await client.query(`ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS has_dash_camera BOOLEAN DEFAULT TRUE;`); } catch (e) {}
  try { await client.query(`ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS handover_remarks TEXT;`); } catch (e) {}
  try { await client.query(`ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS fd_number VARCHAR(50);`); } catch (e) {}
  try { await client.query(`ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS manufacture_year VARCHAR(50);`); } catch (e) {}
  try { await client.query(`ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS insurance_category VARCHAR(50);`); } catch (e) {}
  try { await client.query(`ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS last_service_mileage NUMERIC(10, 2) DEFAULT 0;`); } catch (e) {}
  try { await client.query(`ALTER TABLE vehicles ADD COLUMN IF NOT EXISTS service_due_miles INTEGER;`); } catch (e) {}

  console.log('✓ Database migrations verified. All tables ready.');
}

if (require.main === module) {
  migrate().then(() => process.exit(0)).catch(err => {
    console.error('Migration failed:', err);
    process.exit(1);
  });
}

module.exports = { migrate };