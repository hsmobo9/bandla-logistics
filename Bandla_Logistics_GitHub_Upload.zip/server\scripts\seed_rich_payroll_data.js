const { v4: uuidv4 } = require('uuid');
const { getDb, initDb } = require('../config/db');
const { migrate } = require('../db/migrate');
const { calculateShift } = require('../services/calculationService');

async function seedRichPayrollData() {
  console.log('================================================================================');
  console.log('💰 BANDLA LOGISTICS RICH PAYROLL & INVOICE DATA GENERATOR');
  console.log('================================================================================\n');

  const { client } = await initDb();
  await migrate();

  // Fetch Drivers and Vehicles
  const driversRes = await client.query('SELECT * FROM drivers ORDER BY full_name ASC');
  const drivers = driversRes.rows;
  if (!drivers.length) {
    console.error('No drivers found in database.');
    return;
  }

  const vehiclesRes = await client.query('SELECT * FROM vehicles ORDER BY registration_number ASC');
  const vehicles = vehiclesRes.rows;

  const depotsRes = await client.query('SELECT * FROM depots ORDER BY name ASC');
  const depots = depotsRes.rows;

  console.log(`Found ${drivers.length} drivers, ${vehicles.length} vehicles, ${depots.length} depots.`);

  // 1. Distribute all 55 drivers across all 6 depots
  for (let i = 0; i < drivers.length; i++) {
    const dep = depots[i % depots.length];
    await client.query('UPDATE drivers SET default_depot_id = $1 WHERE id = $2', [dep.id, drivers[i].id]);
    drivers[i].default_depot_id = dep.id;
  }
  console.log('✓ Successfully assigned all 55 drivers across all 6 regional depots.');

  // 2. Ensure Route Rates exist for all 6 depots
  for (const dep of depots) {
    const code = dep.code || dep.name.slice(0, 3).toUpperCase();
    for (let r = 1; r <= 3; r++) {
      const rCode = `${code}-${String(r).padStart(2, '0')}`;
      const existing = await client.query('SELECT id FROM route_rates WHERE route_code = $1', [rCode]);
      if (!existing.rows.length) {
        await client.query(`
          INSERT INTO route_rates (id, route_code, depot_id, base_rate_per_stop, excess_parcel_rate, created_at, updated_at)
          VALUES ($1, $2, $3, $4, 0.05, NOW(), NOW())
        `, [uuidv4(), rCode, dep.id, 1.00 + (r * 0.10)]);
      }
    }
  }

  // Target 18 prominent drivers (3 per each of the 6 depots)
  const targetDrivers = drivers.slice(0, 18);

  let totalInvoicesCreated = 0;
  let totalShiftsCreated = 0;
  let totalDeductionsCreated = 0;

  for (let dIdx = 0; dIdx < targetDrivers.length; dIdx++) {
    const driver = targetDrivers[dIdx];
    const assignedVeh = vehicles[dIdx % vehicles.length];
    const assignedDepotObj = depots[dIdx % depots.length];
    const assignedDepot = assignedDepotObj.id;
    const depotCode = assignedDepotObj.code || assignedDepotObj.name.slice(0, 3).toUpperCase();
    const routeCode = `${depotCode}-${String((Math.floor(dIdx / depots.length)) + 1).padStart(2, '0')}`;

    console.log(`\n--- Processing Driver ${dIdx + 1}/15: ${driver.full_name} (${driver.driver_code}) ---`);

    // Months to generate
    const months = [
      {
        month: 'June 2026',
        startDate: '2026-06-01',
        endDate: '2026-06-30',
        status: 'Paid',
        daysCount: 20
      },
      {
        month: 'July 2026',
        startDate: '2026-07-01',
        endDate: '2026-07-31',
        status: 'Locked',
        daysCount: 22
      },
      {
        month: 'August 2026',
        startDate: '2026-08-01',
        endDate: '2026-08-29',
        status: dIdx % 3 === 0 ? 'Approved' : (dIdx % 3 === 1 ? 'Checked' : 'Draft'),
        daysCount: 29
      }
    ];

    for (const m of months) {
      // 1. Unlink and clean shifts/deductions BEFORE deleting invoice to respect foreign key constraints
      await client.query('UPDATE daily_shifts SET invoice_id = NULL WHERE driver_id = $1 AND shift_date >= $2 AND shift_date <= $3', [driver.id, m.startDate, m.endDate]);
      await client.query('UPDATE charges_and_deductions SET invoice_id = NULL WHERE driver_id = $1 AND billing_month = $2', [driver.id, m.month]);
      await client.query('DELETE FROM payroll_invoices WHERE driver_id = $1 AND billing_month = $2', [driver.id, m.month]);

      // 2. Pre-calculate shifts
      const startDay = new Date(m.startDate);
      const shiftRecords = [];
      let totalStopsDispatched = 0;
      let totalPaidStops = 0;
      let totalStopPay = 0;
      let totalExcessParcelPay = 0;
      let totalTopUpPay = 0;
      let grossEarnings = 0;

      for (let day = 1; day <= m.daysCount; day++) {
        const currentDate = new Date(startDay);
        currentDate.setDate(day);
        const dateStr = currentDate.toISOString().split('T')[0];

        // Skip Sundays
        if (currentDate.getDay() === 0) continue;

        // Realistic Stop & Parcel Variation
        const dispatched = 110 + ((dIdx * 7 + day * 3) % 45); // 110 - 155 stops
        const failStops = day % 7 === 0 ? 5 : 0; // occasional fails
        const paid = Math.max(70, dispatched - failStops);
        const parcels = paid + ((dIdx + day) % 35); // excess parcels

        const shiftCalc = await calculateShift({
          dispatchedStops: dispatched,
          paidStops: paid,
          totalParcels: parcels,
          appliedBaseRate: 1.00,
          appliedExcessRate: 0.05
        });

        const shiftId = uuidv4();
        shiftRecords.push({
          id: shiftId,
          dateStr,
          shiftCalc
        });

        totalStopsDispatched += parseInt(shiftCalc.dispatchedStops, 10);
        totalPaidStops += parseInt(shiftCalc.paidStops, 10);
        totalStopPay += parseFloat(shiftCalc.calculatedStopPay);
        totalExcessParcelPay += parseFloat(shiftCalc.calculatedParcelPay);
        totalTopUpPay += parseFloat(shiftCalc.topUpPay);
        grossEarnings += parseFloat(shiftCalc.grossShiftTotal);
      }

      // 3. Pre-calculate Deductions for this month
      const weeklyVanRate = 135.00;
      const totalVanRent = weeklyVanRate * 4; // £540.00
      let totalDeductions = totalVanRent;
      const hasCredit = dIdx % 2 === 0;
      const creditAmount = -35.00;
      if (hasCredit) totalDeductions += creditAmount;

      // 4. Calculate Subtotal, VAT & Net Payable
      const subtotal = Number((grossEarnings - totalDeductions).toFixed(2));
      const vatRate = driver.is_vat_registered ? 0.20 : 0.00;
      const vatApplied = Number((subtotal * vatRate).toFixed(2));
      const netPayable = Number((subtotal + vatApplied).toFixed(2));

      // 5. Generate Unique Invoice Number & INSERT Invoice First
      const invoiceId = uuidv4();
      const monthPrefix = m.month.split(' ')[0].toUpperCase();
      const drvCodeClean = (driver.driver_code || `DR${dIdx + 1001}`).replace(/[^a-zA-Z0-9]/g, '');
      const invNumber = `INV-${monthPrefix}-2026-${drvCodeClean}`;

      await client.query(`
        INSERT INTO payroll_invoices (
          id, invoice_number, driver_id, billing_month, billing_start_date, billing_end_date,
          invoice_date, days_worked, total_stops_dispatched, total_paid_stops,
          total_stop_pay, total_excess_parcel_pay, total_top_up_pay, gross_earnings,
          total_deductions, subtotal, vat_rate, vat_applied, net_payable, payment_status, status, created_at, updated_at
        ) VALUES (
          $1, $2, $3, $4, $5, $6,
          $7, $8, $9, $10,
          $11, $12, $13, $14,
          $15, $16, $17, $18, $19, $20, $20, NOW(), NOW()
        )
      `, [
        invoiceId, invNumber, driver.id, m.month, m.startDate, m.endDate,
        m.endDate, shiftRecords.length, totalStopsDispatched, totalPaidStops,
        totalStopPay.toFixed(2), totalExcessParcelPay.toFixed(2), totalTopUpPay.toFixed(2), grossEarnings.toFixed(2),
        totalDeductions.toFixed(2), subtotal.toFixed(2), vatRate.toFixed(2), vatApplied.toFixed(2), netPayable.toFixed(2), m.status
      ]);
      totalInvoicesCreated++;

      // 6. Insert Daily Shifts with valid invoice_id
      for (const sr of shiftRecords) {
        await client.query('DELETE FROM daily_shifts WHERE driver_id = $1 AND shift_date = $2', [driver.id, sr.dateStr]);
        await client.query(`
          INSERT INTO daily_shifts (
            id, driver_id, vehicle_id, depot_id, shift_date, route_code,
            dispatched_stops, paid_stops, total_parcels, excess_parcels,
            applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
            top_up_stops, top_up_pay, gross_shift_total, is_top_up_cancelled, invoice_id, notes, created_at, updated_at
          ) VALUES (
            $1, $2, $3, $4, $5, $6,
            $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, FALSE, $18, $19, NOW(), NOW()
          )
        `, [
          sr.id, driver.id, assignedVeh.id, assignedDepot, sr.dateStr, routeCode,
          sr.shiftCalc.dispatchedStops, sr.shiftCalc.paidStops, sr.shiftCalc.totalParcels, sr.shiftCalc.excessParcels,
          sr.shiftCalc.appliedBaseRate, sr.shiftCalc.appliedExcessRate, sr.shiftCalc.calculatedStopPay, sr.shiftCalc.calculatedParcelPay,
          sr.shiftCalc.topUpStops, sr.shiftCalc.topUpPay, sr.shiftCalc.grossShiftTotal,
          invoiceId, `Daily Dispatch: ${sr.shiftCalc.paidStops} paid stops on ${routeCode}`
        ]);
        totalShiftsCreated++;
      }

      // 7. Insert Deductions linked to invoice
      await client.query('DELETE FROM charges_and_deductions WHERE driver_id = $1 AND billing_month = $2', [driver.id, m.month]);
      
      const chargeId1 = uuidv4();
      await client.query(`
        INSERT INTO charges_and_deductions (
          id, billing_month, billing_period, charge_date, driver_id, cd_type, charge_type, amount, vehicle_id, invoice_id, is_settled, notes, created_at, updated_at
        ) VALUES (
          $1, $2, $2, $3, $4, 'Van Hire', 'Van Hire', $5, $6, $7, TRUE, 'Monthly Van Hire Rental Charge (4 Weeks)', NOW(), NOW()
        )
      `, [chargeId1, m.month, m.startDate, driver.id, totalVanRent.toFixed(2), assignedVeh.id, invoiceId]);
      totalDeductionsCreated++;

      if (hasCredit) {
        const creditId = uuidv4();
        await client.query(`
          INSERT INTO charges_and_deductions (
            id, billing_month, billing_period, charge_date, driver_id, cd_type, charge_type, amount, vehicle_id, invoice_id, is_settled, notes, created_at, updated_at
          ) VALUES (
            $1, $2, $2, $3, $4, 'Management Credit', 'Management Credit', $5, NULL, $6, TRUE, 'Toll & Parcel Bag Reimbursement Credit', NOW(), NOW()
          )
        `, [creditId, m.month, m.startDate, driver.id, creditAmount.toFixed(2), invoiceId]);
        totalDeductionsCreated++;
      }

      console.log(`  ✓ ${m.month}: ${invNumber} -> Gross £${grossEarnings.toFixed(2)}, Deductions £${totalDeductions.toFixed(2)}, Net £${netPayable.toFixed(2)} [${m.status}]`);
    }
  }

  // 4. Seed Rich Financial Controls & Audit Trails
  await client.query('DELETE FROM audit_logs');
  const usersRes = await client.query('SELECT * FROM users');
  const adminUser = usersRes.rows.find(u => u.role === 'Admin') || { id: 'admin-1', full_name: 'Admin Director', email: 'admin@bandlalogistics.co.uk' };
  const mgrUser = usersRes.rows.find(u => u.role !== 'Admin') || { id: 'mgr-1', full_name: 'Leicester Route Manager', email: 'manager@bandlalogistics.co.uk' };

  const auditEvents = [
    {
      userId: adminUser.id,
      userName: adminUser.full_name || 'Admin Director',
      userEmail: adminUser.email || 'admin@bandlalogistics.co.uk',
      actionType: 'TOP_UP_OVERRIDE',
      tableAffected: 'daily_shifts',
      recordId: 'ROUTE-2026-08-29-01',
      previousValue: JSON.stringify({ is_top_up_cancelled: false, applied_top_up: 25.00, gross: 100.00 }),
      newValue: JSON.stringify({ is_top_up_cancelled: true, applied_top_up: 0.00, gross: 75.00 }),
      reason: 'Driver departed depot early without completing second wave delivery cycle. Cancelled £25 top-up guarantee subsidy per depot manager authorization.',
      createdAt: new Date('2026-08-29T10:15:00Z')
    },
    {
      userId: adminUser.id,
      userName: adminUser.full_name || 'Admin Director',
      userEmail: adminUser.email || 'admin@bandlalogistics.co.uk',
      actionType: 'INVOICE_VAULT_LOCK',
      tableAffected: 'payroll_invoices',
      recordId: 'INV-JULY-2026-001',
      previousValue: JSON.stringify({ status: 'Approved', net_payable: 1988.65 }),
      newValue: JSON.stringify({ status: 'Locked', locked_at: '2026-08-01T09:00:00Z', is_immutable: true }),
      reason: 'Month-end payroll reconciliation finalized. July 2026 contractor statements permanently locked to prevent post-close edits or rate tampering.',
      createdAt: new Date('2026-08-01T09:00:00Z')
    },
    {
      userId: adminUser.id,
      userName: adminUser.full_name || 'Admin Director',
      userEmail: adminUser.email || 'admin@bandlalogistics.co.uk',
      actionType: 'VAT_STATUS_ALTERED',
      tableAffected: 'drivers',
      recordId: 'DRV-1002-AMAN',
      previousValue: JSON.stringify({ is_vat_registered: false, vat_number: null, vat_rate: '0%' }),
      newValue: JSON.stringify({ is_vat_registered: true, vat_number: 'GB992837411', vat_rate: '20%' }),
      reason: 'Driver verified VAT Registration Certificate with HMRC (GB992837411). Enabled 20% VAT addition on contractor invoice generation.',
      createdAt: new Date('2026-08-15T14:30:00Z')
    },
    {
      userId: mgrUser.id,
      userName: mgrUser.full_name || 'Route Manager',
      userEmail: mgrUser.email || 'manager@bandlalogistics.co.uk',
      actionType: 'DEDUCTION_CREDIT_APPLIED',
      tableAffected: 'charges_and_deductions',
      recordId: 'CHG-2026-08-004',
      previousValue: null,
      newValue: JSON.stringify({ cd_type: 'Credit', amount: -50.00, description: 'Management Goodwill Compensation' }),
      reason: 'Applied £50 management goodwill fuel reimbursement credit following unavoidable highway detour during Leicester dispatch.',
      createdAt: new Date('2026-08-20T11:45:00Z')
    },
    {
      userId: adminUser.id,
      userName: adminUser.full_name || 'Admin Director',
      userEmail: adminUser.email || 'admin@bandlalogistics.co.uk',
      actionType: 'RATE_CARD_UPDATED',
      tableAffected: 'route_rates',
      recordId: 'RATE-PET-01',
      previousValue: JSON.stringify({ base_rate_per_stop: 1.10, excess_parcel_rate: 0.05 }),
      newValue: JSON.stringify({ base_rate_per_stop: 1.20, excess_parcel_rate: 0.05 }),
      reason: 'Annual contract review: Adjusted Peterborough PE-01 rural route base stop rate from £1.10 to £1.20 per stop due to increased mileage.',
      createdAt: new Date('2026-08-05T16:00:00Z')
    },
    {
      userId: adminUser.id,
      userName: adminUser.full_name || 'Admin Director',
      userEmail: adminUser.email || 'admin@bandlalogistics.co.uk',
      actionType: 'BATCH_INVOICES_APPROVED',
      tableAffected: 'payroll_invoices',
      recordId: 'BATCH-AUG-2026',
      previousValue: JSON.stringify({ count: 6, status: 'Checked' }),
      newValue: JSON.stringify({ count: 6, status: 'Approved' }),
      reason: 'Batch approved August 2026 contractor statements following cross-depot CSV portal reconciliation and courier attendance verification.',
      createdAt: new Date('2026-08-28T18:20:00Z')
    },
    {
      userId: mgrUser.id,
      userName: mgrUser.full_name || 'Route Manager',
      userEmail: mgrUser.email || 'manager@bandlalogistics.co.uk',
      actionType: 'HOLIDAY_OVERRIDE_APPROVED',
      tableAffected: 'driver_availability',
      recordId: 'AVAIL-ANDRIE-W35',
      previousValue: JSON.stringify({ status: 'Available' }),
      newValue: JSON.stringify({ status: 'Holiday', start: '2026-08-24', end: '2026-08-31' }),
      reason: 'Approved annual holiday leave request for Andrie Ploscaru. Smart route planner locked courier from weekly dispatch rota.',
      createdAt: new Date('2026-08-22T09:10:00Z')
    }
  ];

  for (const ev of auditEvents) {
    await client.query(`
      INSERT INTO audit_logs (id, user_id, user_name, user_email, action_type, table_affected, record_id, previous_value, new_value, reason, created_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
    `, [
      uuidv4(),
      ev.userId,
      ev.userName,
      ev.userEmail,
      ev.actionType,
      ev.tableAffected,
      ev.recordId,
      ev.previousValue,
      ev.newValue,
      ev.reason,
      ev.createdAt
    ]);
  }

  console.log('\n================================================================================');
  console.log(`✨ RICH PAYROLL & AUDIT GENERATION COMPLETE:`);
  console.log(`   • ${totalInvoicesCreated} Monthly Invoices generated across June, July, and August 2026`);
  console.log(`   • ${totalShiftsCreated} Daily Dispatch Shifts reconciled`);
  console.log(`   • ${totalDeductionsCreated} Deductions & Management Credits stamped and settled`);
  console.log(`   • ${auditEvents.length} Tamper-Evident Financial Audit Trail Logs Registered`);
  console.log('================================================================================\n');
}

module.exports = { seedRichPayrollData };

if (require.main === module) {
  seedRichPayrollData()
    .then(() => process.exit(0))
    .catch(err => {
      console.error('Fatal Error during rich payroll seeding:', err);
      process.exit(1);
    });
}
