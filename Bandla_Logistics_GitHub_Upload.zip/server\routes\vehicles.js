const cleanDate = (d) => (!d || String(d).trim() === '' ? null : String(d).trim());
const cleanStr = (s) => (!s || String(s).trim() === '' ? null : String(s).trim());
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

const APPROVED_COURIER_CATEGORIES = [
  'Standard Van',
  'LWB Van',
  'SWB Van',
  'Luton Van',
  'Courier Car',
  'Other'
];

function normalizeCategory(cat) {
  if (!cat) return 'Standard Van';
  const trimmed = cat.trim();
  if (trimmed.toLowerCase() === 'van') return 'Standard Van';
  if (APPROVED_COURIER_CATEGORIES.includes(trimmed)) return trimmed;
  // Match case-insensitively
  const found = APPROVED_COURIER_CATEGORIES.find(c => c.toLowerCase() === trimmed.toLowerCase());
  return found || null;
}

function calculateCompliance(v) {
  const now = new Date();
  
  const getDaysDiff = (dateStr) => {
    if (!dateStr) return null;
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return null;
    const diffTime = d.getTime() - now.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const motDays = getDaysDiff(v.mot_expiry);
  const taxDays = getDaysDiff(v.tax_expiry);
  const insuranceDays = getDaysDiff(v.insurance_expiry);

  const curMiles = parseFloat(v.current_mileage || 0);

  // 1. Routine Service reminder every 10k miles
  const next10kInterval = Math.ceil((curMiles + 1) / 10000) * 10000;
  const customNextService = parseFloat(v.next_service_mileage || 0);
  const targetServiceMiles = (customNextService > curMiles) ? customNextService : next10kInterval;
  const milesToService = targetServiceMiles - curMiles;

  // 2. Timing Belt (Cambelt) Change Milestones at 70k, 130k, 200k
  const TIMING_BELT_MILESTONES = [70000, 130000, 200000, 270000, 340000];
  let targetTimingBeltMiles = TIMING_BELT_MILESTONES.find(m => curMiles < (m + 3000));
  if (!targetTimingBeltMiles) {
    targetTimingBeltMiles = 200000 + Math.ceil((curMiles - 200000) / 70000) * 70000;
  }
  const milesToTimingBelt = targetTimingBeltMiles - curMiles;

  const getStatus = (days) => {
    if (days === null) return 'unknown';
    if (days < 0) return 'red';       // Overdue (Annual Expiry)
    if (days <= 30) return 'amber';   // Due Soon (within 30 days)
    return 'green';                   // Valid
  };

  const getMileageStatus = (milesDiff) => {
    if (milesDiff === null) return 'unknown';
    if (milesDiff <= 0) return 'red';      // Overdue / Exceeded 10k interval
    if (milesDiff <= 1000) return 'amber'; // Due Soon (within 1,000 miles)
    return 'green';                        // Valid
  };

  const getTimingBeltStatus = (milesDiff) => {
    if (milesDiff <= 0) return 'red';      // Overdue timing belt change
    if (milesDiff <= 3000) return 'amber'; // Due soon within 3,000 miles
    return 'green';                        // Valid
  };

  const motStatus = motDays !== null && motDays <= 14 && motDays >= 0 ? 'amber' : getStatus(motDays);
  const taxStatus = getStatus(taxDays);
  const insuranceStatus = getStatus(insuranceDays);
  const serviceStatus = getMileageStatus(milesToService);
  const timingBeltStatus = getTimingBeltStatus(milesToTimingBelt);

  // Overall compliance severity
  let overall = 'green';
  if ([motStatus, taxStatus, insuranceStatus, serviceStatus, timingBeltStatus].includes('red')) {
    overall = 'red';
  } else if ([motStatus, taxStatus, insuranceStatus, serviceStatus, timingBeltStatus].includes('amber')) {
    overall = 'amber';
  }

  return {
    mot: { days: motDays, status: motStatus },
    tax: { days: taxDays, status: taxStatus },
    insurance: { days: insuranceDays, status: insuranceStatus },
    service: { 
      milesRemaining: milesToService, 
      targetMileage: targetServiceMiles,
      status: serviceStatus 
    },
    timingBelt: {
      milesRemaining: milesToTimingBelt,
      targetMileage: targetTimingBeltMiles,
      status: timingBeltStatus
    },
    overall
  };
}

// List vehicles with compliance badges & filters
router.get('/', async (req, res) => {
  try {
    const { category, status, search, complianceFilter, includeInactive, onlyInactive, scope } = req.query;
    const db = getDb();
    let query = `
      SELECT v.*,
        (SELECT COUNT(*) FROM maintenance_logs m WHERE m.vehicle_id = v.id) as total_maintenance_events,
        (SELECT COALESCE(SUM(m.total_cost), 0) FROM maintenance_logs m WHERE m.vehicle_id = v.id) as total_maintenance_cost
      FROM vehicles v
      WHERE 1=1
    `;
    const params = [];

    if (scope === 'decommissioned' || onlyInactive === 'true' || status === 'Decommissioned') {
      query += ` AND (v.is_active = FALSE OR v.status = 'Decommissioned')`;
    } else if (scope === 'all' || includeInactive === 'true') {
      // Return both active and decommissioned
      if (status) {
        params.push(status);
        query += ` AND v.status = $${params.length}`;
      }
    } else {
      // Default: Active vehicles only
      query += ` AND v.is_active = TRUE`;
      if (status) {
        params.push(status);
        query += ` AND v.status = $${params.length}`;
      }
    }

    if (category) {
      params.push(category);
      query += ` AND v.category = $${params.length}`;
    }
    if (search) {
      params.push(`%${search}%`);
      query += ` AND (v.model_number ILIKE $${params.length} OR v.registration_number ILIKE $${params.length} OR v.equipment_code ILIKE $${params.length} OR v.depot_location ILIKE $${params.length})`;
    }

    query += ` ORDER BY v.is_active DESC, v.model_number ASC`;
    const { rows } = await db.session.client.query(query, params);

    // Map compliance indicators to each vehicle
    let enriched = rows.map(v => ({
      ...v,
      compliance: calculateCompliance(v)
    }));

    if (complianceFilter && ['red', 'amber', 'green'].includes(complianceFilter)) {
      enriched = enriched.filter(v => v.compliance?.overall === complianceFilter);
    }

    res.json(enriched);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single vehicle by ID
router.get('/:id', async (req, res) => {
  try {
    const db = getDb();
    const { rows } = await db.session.client.query(`
      SELECT v.*,
        (SELECT COUNT(*) FROM maintenance_logs m WHERE m.vehicle_id = v.id) as total_maintenance_events,
        (SELECT COALESCE(SUM(m.total_cost), 0) FROM maintenance_logs m WHERE m.vehicle_id = v.id) as total_maintenance_cost
      FROM vehicles v
      WHERE v.id = $1
    `, [req.params.id]);

    if (!rows.length) return res.status(404).json({ error: 'Vehicle not found' });
    const vehicle = rows[0];
    res.json({ ...vehicle, compliance: calculateCompliance(vehicle) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create new courier vehicle
router.post('/', async (req, res) => {
  try {
    const {
      equipmentCode, modelNumber, registrationNumber, category, ownershipType,
      hourlyRate, dailyRate, monthlyRate, weeklyRentalCost, currentMeterHours,
      lastServiceDate, serviceIntervalHours, status, assignedOperator, assignedClient,
      motExpiry, taxExpiry, insuranceExpiry, currentMileage, nextServiceMileage, depotLocation, isActive, notes
    } = req.body;

    if (!modelNumber) {
      return res.status(400).json({ error: 'Model number is required' });
    }

    const validatedCategory = normalizeCategory(category);
    if (!validatedCategory) {
      return res.status(400).json({ 
        error: `Invalid vehicle category. Allowed courier types are: ${APPROVED_COURIER_CATEGORIES.join(', ')}` 
      });
    }

    const db = getDb();
    const id = uuidv4();
    const { rows } = await db.session.client.query(`
      INSERT INTO vehicles (
        id, equipment_code, model_number, registration_number, category, ownership_type,
        hourly_rate, daily_rate, monthly_rate, weekly_rental_cost, current_meter_hours,
        last_service_date, service_interval_hours, status, assigned_operator, assigned_client,
        mot_expiry, tax_expiry, insurance_expiry, current_mileage, next_service_mileage,
        depot_location, is_active, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24)
      RETURNING *
    `, [
      id, equipmentCode || null, modelNumber.trim(), registrationNumber ? registrationNumber.trim().toUpperCase() : null,
      validatedCategory, ownershipType || 'Company',
      parseFloat(hourlyRate || 0), parseFloat(dailyRate || 0), parseFloat(monthlyRate || 0),
      parseFloat(weeklyRentalCost || 0), parseFloat(currentMeterHours || 0),
      cleanDate(lastServiceDate), parseInt(serviceIntervalHours || 250, 10),
      status || 'Available', assignedOperator || null, assignedClient || null,
      cleanDate(motExpiry), cleanDate(taxExpiry), cleanDate(insuranceExpiry),
      parseFloat(currentMileage || 0), parseFloat(nextServiceMileage || 0),
      depotLocation || null, isActive !== undefined ? Boolean(isActive) : true, notes || null
    ]);

    const created = rows[0];
    res.status(201).json({ ...created, compliance: calculateCompliance(created) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update courier vehicle
router.put('/:id', async (req, res) => {
  try {
    const {
      equipmentCode, modelNumber, registrationNumber, category, ownershipType,
      hourlyRate, dailyRate, monthlyRate, weeklyRentalCost, currentMeterHours,
      lastServiceDate, serviceIntervalHours, status, assignedOperator, assignedClient,
      motExpiry, taxExpiry, insuranceExpiry, currentMileage, nextServiceMileage, depotLocation, isActive, notes
    } = req.body;

    const validatedCategory = category !== undefined ? normalizeCategory(category) : undefined;
    if (category !== undefined && !validatedCategory) {
      return res.status(400).json({ 
        error: `Invalid vehicle category. Allowed courier types are: ${APPROVED_COURIER_CATEGORIES.join(', ')}` 
      });
    }

    const db = getDb();
    const { rows } = await db.session.client.query(`
      UPDATE vehicles SET
        equipment_code = COALESCE($1, equipment_code),
        model_number = COALESCE($2, model_number),
        registration_number = COALESCE($3, registration_number),
        category = COALESCE($4, category),
        ownership_type = COALESCE($5, ownership_type),
        hourly_rate = COALESCE($6, hourly_rate),
        daily_rate = COALESCE($7, daily_rate),
        monthly_rate = COALESCE($8, monthly_rate),
        weekly_rental_cost = COALESCE($9, weekly_rental_cost),
        current_meter_hours = COALESCE($10, current_meter_hours),
        last_service_date = $11,
        service_interval_hours = COALESCE($12, service_interval_hours),
        status = COALESCE($13, status),
        assigned_operator = $14,
        assigned_client = $15,
        mot_expiry = $16,
        tax_expiry = $17,
        insurance_expiry = $18,
        current_mileage = COALESCE($19, current_mileage),
        next_service_mileage = COALESCE($20, next_service_mileage),
        depot_location = COALESCE($21, depot_location),
        is_active = COALESCE($22, is_active),
        notes = $23,
        updated_at = NOW()
      WHERE id = $24
      RETURNING *
    `, [
      equipmentCode, modelNumber ? modelNumber.trim() : undefined,
      registrationNumber ? registrationNumber.trim().toUpperCase() : undefined,
      validatedCategory, ownershipType,
      hourlyRate !== undefined ? parseFloat(hourlyRate) : undefined,
      dailyRate !== undefined ? parseFloat(dailyRate) : undefined,
      monthlyRate !== undefined ? parseFloat(monthlyRate) : undefined,
      weeklyRentalCost !== undefined ? parseFloat(weeklyRentalCost) : undefined,
      currentMeterHours !== undefined ? parseFloat(currentMeterHours) : undefined,
      cleanDate(lastServiceDate),
      serviceIntervalHours !== undefined ? parseInt(serviceIntervalHours, 10) : undefined,
      status, assignedOperator, assignedClient,
      cleanDate(motExpiry), cleanDate(taxExpiry), cleanDate(insuranceExpiry),
      currentMileage !== undefined ? parseFloat(currentMileage) : undefined,
      nextServiceMileage !== undefined ? parseFloat(nextServiceMileage) : undefined,
      depotLocation,
      isActive !== undefined ? Boolean(isActive) : undefined,
      notes,
      req.params.id
    ]);

    if (!rows.length) return res.status(404).json({ error: 'Vehicle not found' });
    const updated = rows[0];
    res.json({ ...updated, compliance: calculateCompliance(updated) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Toggle Active / Decommission Status (Soft Delete Toggle)
router.patch('/:id/toggle-active', async (req, res) => {
  try {
    const db = getDb();
    const check = await db.session.client.query(`SELECT is_active, status FROM vehicles WHERE id = $1`, [req.params.id]);
    if (!check.rows.length) return res.status(404).json({ error: 'Vehicle not found' });

    const newActive = !check.rows[0].is_active;
    const newStatus = newActive ? 'Available' : 'Decommissioned';

    const { rows } = await db.session.client.query(`
      UPDATE vehicles 
      SET is_active = $1, status = $2, updated_at = NOW() 
      WHERE id = $3 
      RETURNING *
    `, [newActive, newStatus, req.params.id]);

    const updated = rows[0];
    res.json({ 
      message: `Vehicle ${newActive ? 'activated' : 'decommissioned'} successfully.`, 
      vehicle: { ...updated, compliance: calculateCompliance(updated) }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Soft Delete Vehicle
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const { rows } = await db.session.client.query(`
      UPDATE vehicles 
      SET is_active = FALSE, status = 'Decommissioned', updated_at = NOW() 
      WHERE id = $1 
      RETURNING *
    `, [req.params.id]);

    if (!rows.length) return res.status(404).json({ error: 'Vehicle not found' });
    res.json({ message: 'Vehicle decommissioned (soft deleted) successfully.', vehicle: rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;