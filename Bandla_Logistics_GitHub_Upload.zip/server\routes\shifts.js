const express = require('express');
const router = express.Router();
const multer = require('multer');
const csv = require('csv-parser');
const { Readable } = require('stream');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');
const { logAuditEvent } = require('../services/auditService');
const { requireAdmin } = require('../middleware/auth');
const { calculateShift } = require('../services/calculationService');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

// Helper: Check if a driver has a Locked invoice for a target shift date
async function isShiftMonthLocked(client, driverId, shiftDate) {
  if (!driverId || !shiftDate) return null;
  const dStr = typeof shiftDate === 'string' ? shiftDate.split('T')[0] : (shiftDate instanceof Date ? shiftDate.toISOString().split('T')[0] : String(shiftDate));
  const dateObj = new Date(dStr);
  const monthName = dateObj.toLocaleString('en-GB', { month: 'long', year: 'numeric' }); // e.g. "August 2026"

  const check = await client.query(`
    SELECT id, invoice_number, status, payment_status
    FROM payroll_invoices
    WHERE driver_id = $1 
      AND (status = 'Locked' OR payment_status = 'Locked')
      AND (billing_month = $2 OR (billing_start_date <= $3 AND billing_end_date >= $3))
    LIMIT 1
  `, [driverId, monthName, dStr]);

  return check.rows.length > 0 ? check.rows[0] : null;
}

// List shifts with rich filtering
router.get('/', async (req, res) => {
  try {
    const { startDate, endDate, driverId, depotId, routeCode, invoiceStatus, invoicedOnly, month } = req.query;
    const db = getDb();
    let query = `
      SELECT s.*, 
        d.full_name as driver_name, d.driver_code, d.assigned_vehicle_reg,
        dep.name as depot_name, dep.code as depot_code,
        v.model_number as vehicle_model, v.registration_number as vehicle_reg,
        inv.invoice_number, COALESCE(inv.status, inv.payment_status) as invoice_status,
        CASE 
          WHEN s.dispatched_stops > 0 AND s.paid_stops > 0 THEN ROUND(((s.dispatched_stops - s.paid_stops)::numeric / s.dispatched_stops) * 100, 2)
          ELSE NULL 
        END as fail_percentage,
        COALESCE(s.is_top_up_cancelled, s.top_up_cancelled, false) as is_top_up_cancelled
      FROM daily_shifts s
      JOIN drivers d ON s.driver_id = d.id
      LEFT JOIN depots dep ON s.depot_id = dep.id
      LEFT JOIN vehicles v ON s.vehicle_id = v.id
      LEFT JOIN payroll_invoices inv ON s.invoice_id = inv.id
      WHERE 1=1
    `;
    const params = [];

    if (startDate) {
      params.push(startDate);
      query += ` AND s.shift_date >= $${params.length}`;
    }
    if (endDate) {
      params.push(endDate);
      query += ` AND s.shift_date <= $${params.length}`;
    }
    if (driverId) {
      params.push(driverId);
      query += ` AND s.driver_id = $${params.length}`;
    }
    if (depotId) {
      params.push(depotId);
      query += ` AND s.depot_id = $${params.length}`;
    }
    if (routeCode) {
      params.push(routeCode);
      query += ` AND s.route_code = $${params.length}`;
    }
    if (invoicedOnly === 'false' || invoiceStatus === 'unbilled') {
      query += ` AND s.invoice_id IS NULL`;
    } else if (invoicedOnly === 'true' || invoiceStatus === 'billed') {
      query += ` AND s.invoice_id IS NOT NULL`;
    }

    query += ` ORDER BY s.shift_date DESC, d.full_name ASC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single shift
router.get('/:id', async (req, res) => {
  try {
    const db = getDb();
    const { rows } = await db.session.client.query(`
      SELECT s.*, d.full_name as driver_name, dep.name as depot_name,
        CASE 
          WHEN s.dispatched_stops > 0 THEN ROUND(((s.dispatched_stops - s.paid_stops)::numeric / s.dispatched_stops) * 100, 2)
          ELSE 0 
        END as fail_percentage,
        COALESCE(s.is_top_up_cancelled, s.top_up_cancelled, false) as is_top_up_cancelled
      FROM daily_shifts s
      JOIN drivers d ON s.driver_id = d.id
      LEFT JOIN depots dep ON s.depot_id = dep.id
      WHERE s.id = $1
    `, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Shift not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Helper to parse dates from string, UK format, worded format, or Excel serial
function parseCsvDate(val) {
  if (!val) return '';
  if (!isNaN(val) && Number(val) > 40000 && Number(val) < 60000) {
    const date = new Date(Math.round((Number(val) - 25569) * 86400 * 1000));
    return date.toISOString().split('T')[0];
  }
  const str = String(val).trim();
  if (str.includes('/')) {
    const parts = str.split('/');
    if (parts.length === 3) {
      const d = parts[0].padStart(2, '0');
      const m = parts[1].padStart(2, '0');
      let y = parts[2];
      if (y.length === 2) y = '20' + y;
      return `${y}-${m}-${d}`;
    }
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
    return str;
  }
  const d = new Date(str.includes('2026') ? str : `${str} 2026`);
  if (!isNaN(d.getTime())) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
  return str;
}

// Automated Portal CSV Ingestion (Admin Only)
router.post('/upload-portal-csv', requireAdmin, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No CSV file uploaded.' });
    }

    const db = getDb();
    const client = db.session.client;
    const records = [];

    // Parse CSV from memory buffer
    await new Promise((resolve, reject) => {
      const stream = Readable.from(req.file.buffer);
      stream
        .pipe(csv())
        .on('data', (row) => records.push(row))
        .on('end', resolve)
        .on('error', reject);
    });

    if (!records.length) {
      return res.status(400).json({ error: 'Uploaded CSV is empty.' });
    }

    // Load drivers & routes cache
    const driversRes = await client.query(`SELECT id, driver_code, full_name, assigned_fd_number FROM drivers`);
    const driversByCode = new Map();
    const driversByName = new Map();
    const driversByFd = new Map();

    driversRes.rows.forEach(d => {
      if (d.driver_code) driversByCode.set(d.driver_code.toUpperCase().trim(), d);
      if (d.full_name) driversByName.set(d.full_name.toLowerCase().trim(), d);
      if (d.assigned_fd_number) driversByFd.set(d.assigned_fd_number.toUpperCase().trim(), d);
    });

    let matchedCount = 0;
    let updatedCount = 0;
    let createdCount = 0;
    let skippedLockedCount = 0;

    for (const row of records) {
      const rawDate = row['Date'] || row['date'] || row['Shift Date'] || row['Delivery Date'] || '';
      const dateStr = parseCsvDate(rawDate);
      const driverIdent = (row['Driver'] || row['Driver Code'] || row['Driver ID'] || row['Driver Name'] || '').trim();
      const fdNumber = (row['FD Number'] || row['FD No'] || row['FD'] || '').trim();
      const routeCode = String(row['Route'] || row['Route Code'] || row['Route Name'] || '').trim();
      
      const paidStops = parseInt(row['No of Stops'] || row['Paid Stops'] || row['Delivered Stops'] || row['Stops Paid'] || row['Stops'] || 0, 10);
      const dispatchedStops = parseInt(row['Dispatched Stops'] || row['Planned Stops'] || row['Dispatched'] || paidStops, 10);
      const totalParcels = parseInt(row['Total Parcels'] || row['Parcels Total'] || row['Parcels'] || 0, 10);
      const excessParcels = parseInt(row['Excess Parcels'] || Math.max(0, totalParcels - paidStops), 10);
      const mileage = parseFloat(row['Mileage'] || 0);

      if (!dateStr || (!driverIdent && !fdNumber)) continue;

      // Find driver by Code, Name, FD, or partial match
      let driver = null;
      if (driverIdent) {
        // Strip out leading DR code if formatted as "DR74030 Amanpreet Singh"
        const cleanIdent = driverIdent.toUpperCase();
        driver = driversByCode.get(cleanIdent) || driversByName.get(driverIdent.toLowerCase());
        
        if (!driver) {
          const matchCode = driverIdent.match(/DR\d+/i);
          if (matchCode) {
            driver = driversByCode.get(matchCode[0].toUpperCase());
          }
        }
        if (!driver) {
          driver = driversRes.rows.find(d => 
            d.full_name.toLowerCase().includes(driverIdent.toLowerCase()) || 
            driverIdent.toLowerCase().includes(d.full_name.toLowerCase())
          );
        }
      }
      if (!driver && fdNumber) {
        driver = driversByFd.get(fdNumber.toUpperCase());
      }
      if (!driver) continue;

      matchedCount++;

      // Check if locked
      const lockedInv = await isShiftMonthLocked(client, driver.id, dateStr);
      if (lockedInv) {
        skippedLockedCount++;
        continue;
      }

      // Step 1 Corrections:
      // Dynamic Stop Pay: Pull exact financial value from Stop column if present
      const rawStopCol = row['Stop'] || row['Stop Pay'] || row['Stops Pay'];
      const hasStopCol = rawStopCol !== undefined && !isNaN(parseFloat(rawStopCol)) && parseFloat(rawStopCol) > 0;
      const baseRate = hasStopCol && paidStops > 0 ? Number((parseFloat(rawStopCol) / paidStops).toFixed(4)) : 1.0000;
      const calculatedStopPay = hasStopCol ? Number(parseFloat(rawStopCol).toFixed(2)) : Number((paidStops * baseRate).toFixed(2));

      // Excess Parcel Bonus: Â£0.05 per excess parcel (or Parcels column)
      const rawParcelCol = row['Parcels'] || row['Parcel Bonus'];
      const calculatedParcelPay = rawParcelCol !== undefined && !isNaN(parseFloat(rawParcelCol))
        ? Number(parseFloat(rawParcelCol).toFixed(2))
        : Number((excessParcels * 0.05).toFixed(2));

      const failPct = dispatchedStops > 0 ? parseFloat((((dispatchedStops - paidStops) / dispatchedStops) * 100).toFixed(2)) : 0;

      // Check existing shift
      const existing = await client.query(`
        SELECT id, is_top_up_cancelled, top_up_cancelled
        FROM daily_shifts
        WHERE driver_id = $1 AND shift_date = $2
        LIMIT 1
      `, [driver.id, dateStr]);

      if (existing.rows.length > 0) {
        const cancelFlag = Boolean(existing.rows[0].is_top_up_cancelled || existing.rows[0].top_up_cancelled);
        const topUpStops = (!cancelFlag && paidStops > 0 && paidStops < 100) ? (100 - paidStops) : 0;
        const topUpPay = Number((topUpStops * (baseRate || 1.0000)).toFixed(2));
        const grossTotal = Number((calculatedStopPay + calculatedParcelPay + topUpPay).toFixed(2));

        await client.query(`
          UPDATE daily_shifts SET
            fd_number = COALESCE($1, fd_number),
            route_code = COALESCE($2, route_code),
            paid_stops = $3,
            dispatched_stops = GREATEST(dispatched_stops, $4),
            total_parcels = GREATEST(total_parcels, $5),
            excess_parcels = $6,
            mileage = GREATEST(mileage, $7),
            applied_base_rate = $8,
            applied_excess_rate = 0.0500,
            calculated_stop_pay = $9,
            calculated_parcel_pay = $10,
            top_up_stops = $11,
            top_up_pay = $12,
            fail_percentage = $13,
            gross_shift_total = $14,
            updated_at = NOW()
          WHERE id = $15
        `, [
          fdNumber || null, routeCode || null, paidStops, dispatchedStops, totalParcels,
          excessParcels, mileage, baseRate, calculatedStopPay, calculatedParcelPay,
          topUpStops, topUpPay, failPct, grossTotal, existing.rows[0].id
        ]);
        updatedCount++;
      } else {
        const topUpStops = (paidStops > 0 && paidStops < 100) ? (100 - paidStops) : 0;
        const topUpPay = Number((topUpStops * (baseRate || 1.0000)).toFixed(2));
        const grossTotal = Number((calculatedStopPay + calculatedParcelPay + topUpPay).toFixed(2));
        const newId = uuidv4();

        await client.query(`
          INSERT INTO daily_shifts (
            id, shift_date, driver_id, fd_number, route_code, dispatched_stops, paid_stops, total_parcels,
            excess_parcels, mileage, applied_base_rate, applied_excess_rate, calculated_stop_pay,
            calculated_parcel_pay, top_up_stops, top_up_pay, is_top_up_cancelled, fail_percentage, gross_shift_total
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 0.0500, $12, $13, $14, $15, FALSE, $16, $17)
        `, [
          newId, dateStr, driver.id, fdNumber || null, routeCode || 'PORTAL-CSV',
          dispatchedStops, paidStops, totalParcels, excessParcels, mileage,
          baseRate, calculatedStopPay, calculatedParcelPay, topUpStops, topUpPay,
          failPct, grossTotal
        ]);
        createdCount++;
      }
    }

    // Log Audit Event
    await logAuditEvent(req, {
      actionType: 'CSV_IMPORT',
      tableAffected: 'daily_shifts',
      reason: `Portal CSV uploaded: ${req.file.originalname} (${records.length} rows processed, ${updatedCount} updated, ${createdCount} created)`
    });

    res.json({
      message: 'Portal CSV processed successfully.',
      filename: req.file.originalname,
      totalRows: records.length,
      matchedRows: matchedCount,
      updatedShifts: updatedCount,
      createdShifts: createdCount,
      skippedLocked: skippedLockedCount
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Toggle Top-Up Guarantee Override (Admin Only with Audit Trail)
router.patch('/:id/toggle-top-up', requireAdmin, async (req, res) => {
  try {
    const { reason } = req.body;
    const db = getDb();
    const client = db.session.client;

    const existing = await client.query(`
      SELECT s.*, d.full_name as driver_name
      FROM daily_shifts s
      JOIN drivers d ON s.driver_id = d.id
      WHERE s.id = $1
    `, [req.params.id]);

    if (!existing.rows.length) return res.status(404).json({ error: 'Shift not found' });
    const shift = existing.rows[0];

    // Check if locked
    const lockedInv = await isShiftMonthLocked(client, shift.driver_id, shift.shift_date);
    if (lockedInv) {
      return res.status(403).json({ error: `Cannot modify shift: Invoice #${lockedInv.invoice_number} for this billing month is LOCKED.` });
    }

    const currentCancelled = Boolean(shift.is_top_up_cancelled || shift.top_up_cancelled);
    const newCancelled = !currentCancelled;

    const baseRate = Number(shift.applied_base_rate || 1.00);
    const paidStops = Number(shift.paid_stops || 0);
    const stopPay = Number(shift.calculated_stop_pay || (paidStops * baseRate));
    const parcelPay = Number(shift.calculated_parcel_pay || 0);

    const newTopUpStops = (!newCancelled && paidStops > 0 && paidStops < 100) ? (100 - paidStops) : 0;
    const newTopUpPay = Number((newTopUpStops * baseRate).toFixed(2));
    const newGrossTotal = Number((stopPay + parcelPay + newTopUpPay).toFixed(2));

    const { rows } = await client.query(`
      UPDATE daily_shifts SET
        is_top_up_cancelled = $1,
        top_up_cancelled = $1,
        top_up_stops = $2,
        top_up_pay = $3,
        gross_shift_total = $4,
        updated_at = NOW()
      WHERE id = $5
      RETURNING *
    `, [newCancelled, newTopUpStops, newTopUpPay, newGrossTotal, req.params.id]);

    // Record Audit Log
    await logAuditEvent(req, {
      actionType: newCancelled ? 'CANCEL_TOP_UP' : 'RESTORE_TOP_UP',
      tableAffected: 'daily_shifts',
      recordId: shift.id,
      previousValue: { is_top_up_cancelled: currentCancelled, top_up_pay: shift.top_up_pay },
      newValue: { is_top_up_cancelled: newCancelled, top_up_pay: newTopUpPay },
      reason: reason || (newCancelled ? 'Manual top-up cancellation by Admin' : 'Restored standard top-up subsidy')
    });

    res.json({
      message: `Top-Up Guarantee ${newCancelled ? 'Cancelled' : 'Restored'}.`,
      shift: rows[0]
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create single shift
router.post('/', async (req, res) => {
  try {
    const {
      shiftDate, shift_date,
      driverId, driver_id, driver,
      vehicleId, vehicle_id,
      depotId, depot_id,
      routeId, route_id,
      routeCode, route_code,
      fdNumber, fd_number,
      dispatchedStops, dispatched_stops,
      paidStops, paid_stops,
      totalParcels, total_parcels,
      mileage, appliedBaseRate, appliedExcessRate,
      calculatedStopPay, calculatedParcelPay, topUpCancelled, isTopUpCancelled, notes
    } = req.body;

    let targetDate = shiftDate || shift_date;
    let targetDriverId = driverId || driver_id || driver;

    const db = getDb();
    const client = db.session.client;

    // If driver identifier is a name or code instead of UUID
    if (targetDriverId && !targetDriverId.includes('-')) {
      const dRes = await client.query(`SELECT id FROM drivers WHERE driver_code = $1 OR full_name ILIKE $1 LIMIT 1`, [targetDriverId]);
      if (dRes.rows.length) targetDriverId = dRes.rows[0].id;
    }

    if (!targetDate || !targetDriverId) {
      return res.status(400).json({ error: 'Shift date and driver are required' });
    }

    const lockedInv = await isShiftMonthLocked(client, targetDriverId, targetDate);
    if (lockedInv) {
      return res.status(403).json({ error: `Cannot add shift: Invoice #${lockedInv.invoice_number} for this billing month is LOCKED.` });
    }

    const cancelFlag = Boolean(isTopUpCancelled !== undefined ? isTopUpCancelled : topUpCancelled);
    const computed = await calculateShift({
      shiftDate: targetDate,
      driverId: targetDriverId,
      vehicleId: vehicleId || vehicle_id,
      depotId: depotId || depot_id,
      routeId: routeId || route_id,
      routeCode: routeCode || route_code,
      fdNumber: fdNumber || fd_number,
      dispatchedStops: dispatchedStops !== undefined ? dispatchedStops : dispatched_stops,
      paidStops: paidStops !== undefined ? paidStops : paid_stops,
      totalParcels: totalParcels !== undefined ? totalParcels : total_parcels,
      mileage, appliedBaseRate, appliedExcessRate,
      calculatedStopPay, calculatedParcelPay, topUpCancelled: cancelFlag, notes
    });

    const dStops = computed.dispatchedStops || 0;
    const pStops = computed.paidStops || 0;
    const failPct = dStops > 0 ? parseFloat((((dStops - pStops) / dStops) * 100).toFixed(2)) : 0;

    const id = uuidv4();
    const { rows } = await client.query(`
      INSERT INTO daily_shifts (
        id, shift_date, driver_id, vehicle_id, depot_id, route_id, route_code, fd_number,
        dispatched_stops, paid_stops, total_parcels, excess_parcels, mileage,
        applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
        top_up_stops, top_up_pay, top_up_cancelled, is_top_up_cancelled, fail_percentage, gross_shift_total, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $20, $21, $22, $23)
      ON CONFLICT (driver_id, shift_date) DO UPDATE SET
        vehicle_id = COALESCE(EXCLUDED.vehicle_id, daily_shifts.vehicle_id),
        depot_id = COALESCE(EXCLUDED.depot_id, daily_shifts.depot_id),
        route_id = COALESCE(EXCLUDED.route_id, daily_shifts.route_id),
        route_code = COALESCE(EXCLUDED.route_code, daily_shifts.route_code),
        fd_number = COALESCE(EXCLUDED.fd_number, daily_shifts.fd_number),
        dispatched_stops = EXCLUDED.dispatched_stops,
        paid_stops = EXCLUDED.paid_stops,
        total_parcels = EXCLUDED.total_parcels,
        excess_parcels = EXCLUDED.excess_parcels,
        mileage = EXCLUDED.mileage,
        applied_base_rate = EXCLUDED.applied_base_rate,
        applied_excess_rate = EXCLUDED.applied_excess_rate,
        calculated_stop_pay = EXCLUDED.calculated_stop_pay,
        calculated_parcel_pay = EXCLUDED.calculated_parcel_pay,
        top_up_stops = EXCLUDED.top_up_stops,
        top_up_pay = EXCLUDED.top_up_pay,
        top_up_cancelled = EXCLUDED.top_up_cancelled,
        is_top_up_cancelled = EXCLUDED.is_top_up_cancelled,
        fail_percentage = EXCLUDED.fail_percentage,
        gross_shift_total = EXCLUDED.gross_shift_total,
        notes = COALESCE(EXCLUDED.notes, daily_shifts.notes),
        updated_at = NOW()
      RETURNING *
    `, [
      id, computed.shiftDate, computed.driverId, computed.vehicleId || null, computed.depotId || null,
      computed.routeId || null, computed.routeCode || null, computed.fdNumber || null,
      dStops, pStops, computed.totalParcels, computed.excessParcels,
      parseFloat(computed.mileage || 0), computed.appliedBaseRate, computed.appliedExcessRate,
      computed.calculatedStopPay, computed.calculatedParcelPay,
      computed.topUpStops, computed.topUpPay, cancelFlag, failPct, computed.grossShiftTotal, computed.notes || null
    ]);

    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update shift (protected by Locked state)
router.put('/:id', async (req, res) => {
  try {
    const db = getDb();
    const client = db.session.client;
    const check = await client.query(`SELECT * FROM daily_shifts WHERE id = $1`, [req.params.id]);
    if (!check.rows.length) return res.status(404).json({ error: 'Shift not found' });
    const shift = check.rows[0];

    const lockedInv = await isShiftMonthLocked(client, shift.driver_id, shift.shift_date);
    if (lockedInv) {
      return res.status(403).json({ error: `Cannot modify shift: Invoice #${lockedInv.invoice_number} for this billing month is LOCKED.` });
    }

    const cancelFlag = Boolean(req.body.isTopUpCancelled !== undefined ? req.body.isTopUpCancelled : (req.body.topUpCancelled !== undefined ? req.body.topUpCancelled : shift.is_top_up_cancelled));
    const computed = await calculateShift({ ...shift, ...req.body, topUpCancelled: cancelFlag });

    const dStops = computed.dispatchedStops || 0;
    const pStops = computed.paidStops || 0;
    const failPct = dStops > 0 ? parseFloat((((dStops - pStops) / dStops) * 100).toFixed(2)) : 0;

    const { rows } = await client.query(`
      UPDATE daily_shifts SET
        shift_date = COALESCE($1, shift_date),
        driver_id = COALESCE($2, driver_id),
        vehicle_id = $3,
        depot_id = $4,
        route_id = $5,
        route_code = COALESCE($6, route_code),
        fd_number = COALESCE($7, fd_number),
        dispatched_stops = $8,
        paid_stops = $9,
        total_parcels = $10,
        excess_parcels = $11,
        mileage = $12,
        applied_base_rate = $13,
        applied_excess_rate = $14,
        calculated_stop_pay = $15,
        calculated_parcel_pay = $16,
        top_up_stops = $17,
        top_up_pay = $18,
        top_up_cancelled = $19,
        is_top_up_cancelled = $19,
        fail_percentage = $20,
        gross_shift_total = $21,
        notes = $22,
        updated_at = NOW()
      WHERE id = $23
      RETURNING *
    `, [
      computed.shiftDate || null, computed.driverId || null, computed.vehicleId || null, computed.depotId || null,
      computed.routeId || null, computed.routeCode || null, computed.fdNumber || null,
      dStops, pStops, computed.totalParcels, computed.excessParcels,
      parseFloat(computed.mileage || 0), computed.appliedBaseRate, computed.appliedExcessRate,
      computed.calculatedStopPay, computed.calculatedParcelPay,
      computed.topUpStops, computed.topUpPay, cancelFlag, failPct, computed.grossShiftTotal, computed.notes || null, req.params.id
    ]);

    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete shift (protected by Locked state)
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const client = db.session.client;
    const check = await client.query(`SELECT * FROM daily_shifts WHERE id = $1`, [req.params.id]);
    if (!check.rows.length) return res.status(404).json({ error: 'Shift not found' });
    const shift = check.rows[0];

    const lockedInv = await isShiftMonthLocked(client, shift.driver_id, shift.shift_date);
    if (lockedInv) {
      return res.status(403).json({ error: `Cannot delete shift: Invoice #${lockedInv.invoice_number} for this billing month is LOCKED.` });
    }

    await client.query(`DELETE FROM daily_shifts WHERE id = $1`, [req.params.id]);
    res.json({ message: 'Shift deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;