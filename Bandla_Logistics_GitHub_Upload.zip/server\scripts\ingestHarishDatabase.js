const fs = require('fs');
const path = require('path');
const xlsx = require('E:/badla logistic/node_modules/xlsx');
const { v4: uuidv4 } = require('uuid');
const { getDb, initDb } = require('E:/badla logistic/server/config/db');
const { migrate } = require('E:/badla logistic/server/db/migrate');

function excelDateToISO(val) {
  if (!val) return null;
  if (typeof val === 'number' && val > 30000 && val < 60000) {
    const d = new Date(Math.round((val - 25569) * 86400 * 1000));
    return d.toISOString().split('T')[0];
  }
  const str = String(val).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
  if (str.includes('/')) {
    const parts = str.split('/');
    if (parts.length === 3) {
      const d = parts[0].padStart(2, '0');
      const m = parts[1].padStart(2, '0');
      let y = parts[2];
      if (y.length === 2) y = '20' + y;
      return `${y}-${m}-${d}`;
    }
  }
  const d = new Date(str);
  if (!isNaN(d.getTime())) {
    return d.toISOString().split('T')[0];
  }
  return null;
}

function normalizeReg(reg) {
  if (!reg) return '';
  return String(reg).replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
}

function normalizeName(name) {
  if (!name) return '';
  return String(name).toLowerCase().replace(/[^a-z0-9 ]/g, '').trim();
}

async function ingestHarishDatabase() {
  console.log('================================================================');
  console.log('🚀 STARTING ZERO-DUPLICATE HARISH TECH DATABASE INGESTION');
  console.log('================================================================');

  await initDb();
  await migrate();
  const db = getDb();
  const client = db.session.client;

  const excelPath = 'E:/badla logistic/Harish Tech Copy - Transport Database.xlsx';
  if (!fs.existsSync(excelPath)) {
    throw new Error(`Excel file not found at: ${excelPath}`);
  }

  const wb = xlsx.readFile(excelPath);
  console.log(`✓ Loaded workbook: "${path.basename(excelPath)}"`);

  // Load existing depots, drivers, and vehicles from database
  const [depotsRes, driversRes, vehiclesRes, suppliersRes] = await Promise.all([
    client.query('SELECT id, code, name FROM depots'),
    client.query('SELECT id, driver_code, full_name, email, phone FROM drivers'),
    client.query('SELECT id, registration_number, model_number FROM vehicles'),
    client.query('SELECT id, name FROM suppliers')
  ]);

  const depotsByCode = new Map();
  const depotsByName = new Map();
  depotsRes.rows.forEach(d => {
    depotsByCode.set(d.code.toUpperCase(), d.id);
    depotsByName.set(d.name.toLowerCase().trim(), d.id);
  });
  const defaultDepotId = depotsRes.rows[0]?.id || null;

  // -------------------------------------------------------------
  // 1. VEHICLE DEDUPLICATION & IN-PLACE ENRICHMENT
  // -------------------------------------------------------------
  console.log('\n--- Ingesting Vehicles & Equipment Handover Tracker ---');
  const existingVehByReg = new Map();
  vehiclesRes.rows.forEach(v => {
    existingVehByReg.set(normalizeReg(v.registration_number), v);
  });

  // Read Sheet13 for equipment status (Keys, Camera, Livery, Remarks)
  const equipmentByReg = new Map();
  if (wb.Sheets['Sheet13']) {
    const s13Rows = xlsx.utils.sheet_to_json(wb.Sheets['Sheet13'], { header: 1 });
    for (let r = 5; r < s13Rows.length; r++) {
      const row = s13Rows[r];
      if (row && row[3]) {
        const reg = normalizeReg(row[3]);
        if (reg) {
          equipmentByReg.set(reg, {
            assignedDriver: row[2] ? String(row[2]).trim() : null,
            depot: row[1] ? String(row[1]).trim() : null,
            livery: row[4] === true || String(row[4]).toLowerCase() === 'true',
            keysCount: parseInt(row[5] || 1, 10) || 1,
            hasCamera: row[6] === true || String(row[6]).toLowerCase() === 'true',
            remarks: row[7] ? String(row[7]).trim() : null
          });
        }
      }
    }
  }

  const vehSheet = wb.Sheets['Vehicle Database'];
  const vehRows = xlsx.utils.sheet_to_json(vehSheet, { header: 1 });
  let vehEnrichedCount = 0;
  let vehCreatedCount = 0;

  for (let r = 12; r < vehRows.length; r++) {
    const row = vehRows[r];
    if (row && row[2]) {
      const rawReg = String(row[2]).trim().toUpperCase();
      const norm = normalizeReg(rawReg);
      if (!norm) continue;

      const depotLoc = row[0] ? String(row[0]).trim() : null;
      const fdNo = row[1] ? String(row[1]).trim() : null;
      const make = row[3] ? String(row[3]).trim() : 'Ford Transit';
      const livery = row[4] === true || String(row[4]).toLowerCase() === 'yes' || String(row[4]).toLowerCase() === 'true';
      const mfgYear = row[5] ? String(row[5]).trim() : null;
      const insCat = row[6] ? String(row[6]).trim() : null;
      const taxDate = excelDateToISO(row[7]);
      const insDate = excelDateToISO(row[9]);
      const motDate = excelDateToISO(row[11]);
      const lastSvcMileage = parseFloat(row[13] || 0) || null;
      const curMileage = parseFloat(row[14] || row[13] || 45000);
      const svcDueMiles = (row[15] !== undefined && row[15] !== null && !isNaN(parseInt(row[15], 10))) ? parseInt(row[15], 10) : null;
      const nextService = curMileage + (svcDueMiles ? Math.max(svcDueMiles, 1000) : 10000);

      const eq = equipmentByReg.get(norm) || {
        livery: livery,
        keysCount: 1,
        hasCamera: true,
        remarks: null
      };

      if (existingVehByReg.has(norm)) {
        // MATCH: ENRICH EXISTING RECORD IN-PLACE
        const existing = existingVehByReg.get(norm);
        await client.query(`
          UPDATE vehicles SET
            depot_location = COALESCE($1, depot_location),
            fd_number = COALESCE($2, fd_number),
            manufacture_year = COALESCE($3, manufacture_year),
            insurance_category = COALESCE($4, insurance_category),
            mot_expiry = COALESCE($5, mot_expiry),
            tax_expiry = COALESCE($6, tax_expiry),
            insurance_expiry = COALESCE($7, insurance_expiry),
            last_service_mileage = COALESCE($8, last_service_mileage),
            current_mileage = GREATEST(current_mileage, $9),
            service_due_miles = COALESCE($10, service_due_miles),
            next_service_mileage = GREATEST(next_service_mileage, $11),
            has_livery = $12,
            keys_count = $13,
            has_dash_camera = $14,
            handover_remarks = COALESCE($15, handover_remarks),
            updated_at = NOW()
          WHERE id = $16
        `, [
          depotLoc, fdNo, mfgYear, insCat,
          motDate, taxDate, insDate, lastSvcMileage, curMileage,
          svcDueMiles, nextService,
          eq.livery, eq.keysCount, eq.hasCamera, eq.remarks, existing.id
        ]);
        vehEnrichedCount++;
      } else {
        // NEW VAN: INSERT NEW ROW
        const newId = uuidv4();
        const eqCode = `VAN-${norm.slice(-4)}`;
        await client.query(`
          INSERT INTO vehicles (
            id, equipment_code, model_number, registration_number, category, ownership_type,
            hourly_rate, daily_rate, monthly_rate, weekly_rental_cost,
            depot_location, fd_number, manufacture_year, insurance_category,
            mot_expiry, tax_expiry, insurance_expiry,
            last_service_mileage, current_mileage, service_due_miles, next_service_mileage,
            has_livery, keys_count, has_dash_camera, handover_remarks,
            status, is_active, created_at, updated_at
          ) VALUES (
            $1, $2, $3, $4, 'Standard Van', 'Company',
            0, 0, 0, 185.00,
            $5, $6, $7, $8,
            $9, $10, $11,
            $12, $13, $14, $15,
            $16, $17, $18, $19,
            'Available', TRUE, NOW(), NOW()
          )
        `, [
          newId, eqCode, make, rawReg,
          depotLoc, fdNo, mfgYear, insCat,
          motDate || '2027-05-01', taxDate || '2027-04-01', insDate || '2027-03-01',
          lastSvcMileage, curMileage, svcDueMiles, nextService,
          eq.livery, eq.keysCount, eq.hasCamera, eq.remarks
        ]);
        existingVehByReg.set(norm, { id: newId, registration_number: rawReg });
        vehCreatedCount++;
      }
    }
  }

  console.log(`  ✓ Enriched ${vehEnrichedCount} existing vans in-place with MOT/Tax/Equipment specs.`);
  console.log(`  ✓ Inserted ${vehCreatedCount} additional vans.`);
  console.log(`  ✓ Total Active Delivery Vans in Database: ${existingVehByReg.size}`);

  // -------------------------------------------------------------
  // 2. DRIVER DEDUPLICATION & RTW VISA ENRICHMENT
  // -------------------------------------------------------------
  console.log('\n--- Ingesting Drivers & Right to Work (RTW) Compliance ---');
  const existingDrvByName = new Map();
  const existingDrvByCode = new Map();
  driversRes.rows.forEach(d => {
    existingDrvByName.set(normalizeName(d.full_name), d);
    if (d.driver_code) existingDrvByCode.set(d.driver_code.toUpperCase().trim(), d);
  });

  let drvEnrichedCount = 0;
  let drvCreatedCount = 0;

  // Process RTW Check Sheet
  if (wb.Sheets['RTW Check']) {
    const rtwRows = xlsx.utils.sheet_to_json(wb.Sheets['RTW Check'], { header: 1 });
    for (let r = 1; r < rtwRows.length; r++) {
      const row = rtwRows[r];
      if (row && row[0]) {
        const rawName = String(row[0]).trim();
        const normName = normalizeName(rawName);
        if (!normName || normName === 'driver name') continue;

        const depotStr = row[1] ? String(row[1]).toLowerCase().trim() : '';
        const depotId = depotsByName.get(depotStr) || defaultDepotId;
        const drCode = row[2] ? String(row[2]).trim().toUpperCase() : null;
        const rtwStatus = row[3] ? String(row[3]).trim() : 'British Citizen';
        const rtwExp = excelDateToISO(row[4]);
        const sponsorReq = String(row[5] || '').toLowerCase().includes('yes');
        const email = row[12] ? String(row[12]).trim() : `${normName.replace(/ /g, '.')}@bandlalogistics.co.uk`;
        const phone = row[13] ? String(row[13]).replace(/[^0-9+]/g, '') : null;

        if (existingDrvByName.has(normName) || (drCode && existingDrvByCode.has(drCode))) {
          // MATCH: ENRICH EXISTING DRIVER IN-PLACE
          const existing = existingDrvByName.get(normName) || existingDrvByCode.get(drCode);
          await client.query(`
            UPDATE drivers SET
              right_to_work_status = COALESCE($1, right_to_work_status),
              right_to_work_expiry = COALESCE($2, right_to_work_expiry),
              sponsor_required = $3,
              email = COALESCE($4, email),
              phone = COALESCE($5, phone),
              updated_at = NOW()
            WHERE id = $6
          `, [rtwStatus, rtwExp, sponsorReq, email, phone, existing.id]);
          drvEnrichedCount++;
        } else {
          // NEW DRIVER: INSERT
          const newId = uuidv4();
          const generatedCode = drCode || `DR${Math.floor(10000 + Math.random() * 90000)}`;
          await client.query(`
            INSERT INTO drivers (
              id, driver_code, full_name, phone, email, default_depot_id,
              is_vat_registered, status, right_to_work_status, right_to_work_expiry, sponsor_required,
              is_active, created_at, updated_at
            ) VALUES (
              $1, $2, $3, $4, $5, $6,
              FALSE, 'active', $7, $8, $9,
              TRUE, NOW(), NOW()
            )
          `, [
            newId, generatedCode, rawName, phone || '07700900000', email, depotId,
            rtwStatus, rtwExp, sponsorReq
          ]);
          existingDrvByName.set(normName, { id: newId, full_name: rawName });
          existingDrvByCode.set(generatedCode, { id: newId, full_name: rawName });
          drvCreatedCount++;
        }
      }
    }
  }

  console.log(`  ✓ Enriched ${drvEnrichedCount} existing couriers in-place with RTW Visa compliance.`);
  console.log(`  ✓ Inserted ${drvCreatedCount} additional unique couriers.`);
  console.log(`  ✓ Total Master Driver Roster in Database: ${existingDrvByName.size}`);

  // -------------------------------------------------------------
  // 3. GARAGE SUPPLIERS & MAINTENANCE LOGS
  // -------------------------------------------------------------
  console.log('\n--- Ingesting Garage Suppliers & Maintenance History ---');
  const existingSuppliers = new Map();
  suppliersRes.rows.forEach(s => existingSuppliers.set(s.name.toLowerCase().trim(), s.id));

  // Reload vehicles map for vehicle_id lookup
  const freshVehicles = await client.query('SELECT id, registration_number FROM vehicles');
  const vehMap = new Map();
  freshVehicles.rows.forEach(v => vehMap.set(normalizeReg(v.registration_number), v.id));

  let maintImported = 0;
  if (wb.Sheets['Maintenance Log']) {
    const mRows = xlsx.utils.sheet_to_json(wb.Sheets['Maintenance Log'], { header: 1 });
    for (let r = 7; r < mRows.length; r++) {
      const row = mRows[r];
      if (row && row[2]) {
        const rawDate = excelDateToISO(row[1]) || '2026-06-15';
        const normReg = normalizeReg(row[2]);
        const vehicleId = vehMap.get(normReg);
        if (!vehicleId) continue;

        const garageName = row[4] ? String(row[4]).trim() : 'AutoTech Garage';
        let supplierId = existingSuppliers.get(garageName.toLowerCase());
        if (!supplierId) {
          supplierId = uuidv4();
          await client.query(`
            INSERT INTO suppliers (id, name, services_provided, is_active, created_at, updated_at)
            VALUES ($1, $2, 'Fleet Mechanical Repairs & Servicing', TRUE, NOW(), NOW())
          `, [supplierId, garageName]);
          existingSuppliers.set(garageName.toLowerCase(), supplierId);
        }

        const partsCost = parseFloat(row[5] || 0);
        const labourCost = parseFloat(row[6] || 0);
        const totalCost = parseFloat(row[7] || (partsCost + labourCost) || 120);
        const jobDesc = row[10] ? String(row[10]).trim() : 'Scheduled Fleet Maintenance';

        // Deduplication check
        const check = await client.query(`
          SELECT id FROM maintenance_logs
          WHERE vehicle_id = $1 AND (date = $2 OR service_date = $2) AND total_cost = $3
          LIMIT 1
        `, [vehicleId, rawDate, totalCost]);

        if (check.rows.length === 0) {
          const logId = uuidv4();
          await client.query(`
            INSERT INTO maintenance_logs (
              id, vehicle_id, supplier_id, date, service_date, issue_category,
              labor_cost, parts_cost, total_cost, notes, created_at, updated_at
            ) VALUES (
              $1, $2, $3, $4, $4, 'Scheduled Maintenance',
              $5, $6, $7, $8, NOW(), NOW()
            )
          `, [logId, vehicleId, supplierId, rawDate, labourCost, partsCost, totalCost, jobDesc]);
          maintImported++;
        }
      }
    }
  }
  console.log(`  ✓ Ingested ${maintImported} garage maintenance and repair records.`);

  // -------------------------------------------------------------
  // 4. FUEL & MILEAGE LOGS (3,300+ Transactions)
  // -------------------------------------------------------------
  console.log('\n--- Ingesting 3,300+ Fuel & Odometer Logs ---');
  let fuelImported = 0;
  let fuelSkipped = 0;

  const fuelSheet = wb.Sheets['Fuel Log'] || wb.Sheets['Form responses 1'];
  if (fuelSheet) {
    const fuelRows = xlsx.utils.sheet_to_json(fuelSheet, { header: 1 });
    console.log(`  • Processing ${fuelRows.length - 1} raw fuel transaction rows...`);

    for (let r = 1; r < fuelRows.length; r++) {
      const row = fuelRows[r];
      if (row && row[2]) {
        const rawDate = excelDateToISO(row[1]) || excelDateToISO(row[0]) || '2026-06-01';
        const normReg = normalizeReg(row[2]);
        const vehicleId = vehMap.get(normReg);
        if (!vehicleId) {
          fuelSkipped++;
          continue;
        }

        const odometer = parseFloat(row[3] || 0);
        const litres = parseFloat(row[5] || 0);
        const cost = parseFloat(row[6] || 0);
        const station = row[7] ? String(row[7]).trim() : 'BP';

        // Check duplicate
        const check = await client.query(`
          SELECT id FROM fuel_logs
          WHERE vehicle_id = $1 AND refuel_date = $2 AND total_cost = $3
          LIMIT 1
        `, [vehicleId, rawDate, cost]);

        if (check.rows.length === 0) {
          const fuelId = uuidv4();
          await client.query(`
            INSERT INTO fuel_logs (
              id, refuel_date, vehicle_id, station_name, liters_filled,
              total_cost, odometer_reading, notes, created_at, updated_at
            ) VALUES (
              $1, $2, $3, $4, $5, $6, $7, 'Fuel Card Fleet Purchase', NOW(), NOW()
            )
          `, [fuelId, rawDate, vehicleId, station, litres, cost, odometer]);
          fuelImported++;
        }
      }
    }
  }

  console.log(`  ✓ Ingested ${fuelImported} new fuel purchase transactions.`);

  // -------------------------------------------------------------
  // 5. SUMMARY
  // -------------------------------------------------------------
  console.log('\n================================================================');
  console.log('✨ HARISH TECH TRANSPORT DATABASE INGESTION COMPLETED WITH 0 DUPLICATES:');
  console.log(`   • ${existingDrvByName.size} Total Master Drivers (${drvEnrichedCount} Enriched in-place, ${drvCreatedCount} New)`);
  console.log(`   • ${existingVehByReg.size} Total Delivery Vans (${vehEnrichedCount} Enriched in-place, ${vehCreatedCount} New)`);
  console.log(`   • ${maintImported} Maintenance & Repair Invoices`);
  console.log(`   • ${fuelImported} Fuel Refill & Odometer Logs Synchronized`);
  console.log('================================================================\n');

  return {
    driversTotal: existingDrvByName.size,
    driversEnriched: drvEnrichedCount,
    driversCreated: drvCreatedCount,
    vehiclesTotal: existingVehByReg.size,
    vehiclesEnriched: vehEnrichedCount,
    vehiclesCreated: vehCreatedCount,
    maintenanceImported: maintImported,
    fuelImported
  };
}

module.exports = { ingestHarishDatabase };

if (require.main === module) {
  ingestHarishDatabase()
    .then(() => process.exit(0))
    .catch(err => {
      console.error('Fatal Error during Harish database ingestion:', err);
      process.exit(1);
    });
}
