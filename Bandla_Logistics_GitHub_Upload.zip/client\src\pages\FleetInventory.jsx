import React, { useState, useEffect } from 'react';
import { 
  Truck, Plus, Search, Filter, Wrench, AlertTriangle, ShieldCheck, 
  CheckCircle2, AlertCircle, Edit, Trash2, Gauge, Power, ShieldAlert, Columns
} from 'lucide-react';
import { getVehicles, createVehicle, updateVehicle, toggleVehicleActive, deleteVehicle } from '../services/api';
import Modal from '../components/Modal';
import ColumnVisibilityToggle from '../components/ColumnVisibilityToggle';
import { formatCurrency, formatNumber, formatDate } from '../utils/formatters';

const FLEET_COLUMNS = [
  { key: 'reg', label: 'Registration & Model (Keys/Cam/Livery)' },
  { key: 'depot', label: 'Depot Location' },
  { key: 'compliance', label: 'Compliance (Annual MOT / Tax / Ins & Cambelt)' },
  { key: 'mileage', label: 'Mileage & 10k Routine Service Interval' },
  { key: 'status', label: 'Fleet Status' }
];

export default function FleetInventory() {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [complianceFilter, setComplianceFilter] = useState(''); // 'red', 'amber', 'green', ''
  const [fleetScope, setFleetScope] = useState('active'); // 'active' | 'decommissioned' | 'all'
  const [fleetCounts, setFleetCounts] = useState({ active: 0, decommissioned: 0, total: 0 });
  const [toastMessage, setToastMessage] = useState('');

  // Column Visibility State (persisted to localStorage)
  const [fleetVisible, setFleetVisible] = useState(() => {
    try {
      const saved = localStorage.getItem('fleet_visible_cols');
      return saved ? JSON.parse(saved) : {};
    } catch (e) { return {}; }
  });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState(null);

  const [formData, setFormData] = useState({
    equipmentCode: '',
    modelNumber: '',
    registrationNumber: '',
    category: 'Standard Van',
    ownershipType: 'Company',
    hourlyRate: 0,
    dailyRate: 0,
    monthlyRate: 0,
    weeklyRentalCost: 185.00,
    currentMeterHours: 0,
    lastServiceDate: '',
    serviceIntervalHours: 250,
    status: 'Available',
    assignedOperator: '',
    assignedClient: '',
    motExpiry: '',
    taxExpiry: '',
    insuranceExpiry: '',
    currentMileage: 0,
    nextServiceMileage: 0,
    depotLocation: '',
    isActive: true,
    notes: ''
  });

  useEffect(() => {
    loadVehicles();
  }, [categoryFilter, statusFilter, complianceFilter, fleetScope]);

  const loadVehicles = async () => {
    try {
      setLoading(true);
      // Fetch filtered list
      const data = await getVehicles({
        category: categoryFilter || undefined,
        status: statusFilter || undefined,
        complianceFilter: complianceFilter || undefined,
        scope: fleetScope,
        includeInactive: fleetScope === 'all' || fleetScope === 'decommissioned' ? 'true' : 'false',
        onlyInactive: fleetScope === 'decommissioned' ? 'true' : 'false'
      });
      setVehicles(data);

      // Also fetch all to keep live scope badge counts accurate
      const allVehicles = await getVehicles({ scope: 'all' });
      const activeCount = allVehicles.filter(v => v.is_active && v.status !== 'Decommissioned').length;
      const decommCount = allVehicles.filter(v => !v.is_active || v.status === 'Decommissioned').length;
      setFleetCounts({
        active: activeCount,
        decommissioned: decommCount,
        total: allVehicles.length
      });
    } catch (err) {
      console.error('Error loading vehicles:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (id, newStatus, reg) => {
    try {
      const isDecomm = newStatus === 'Decommissioned';
      await updateVehicle(id, {
        status: newStatus,
        isActive: !isDecomm
      });
      setToastMessage(
        isDecomm
          ? `Vehicle ${reg || 'van'} decommissioned (moved to Only Decommissioned tab).`
          : `Updated ${reg || 'van'} status to ${newStatus}.`
      );
      setTimeout(() => setToastMessage(''), 4000);
      loadVehicles();
    } catch (err) {
      console.warn('Error updating vehicle status:', err);
    }
  };

  const handleRestoreAllDecommissioned = async () => {
    try {
      const allVehicles = await getVehicles({ scope: 'decommissioned' });
      for (const v of allVehicles) {
        await updateVehicle(v.id, { status: 'Available', isActive: true });
      }
      setToastMessage(`Restored ${allVehicles.length} decommissioned vehicles to Active Fleet.`);
      setTimeout(() => setToastMessage(''), 4000);
      setFleetScope('active');
      loadVehicles();
    } catch (err) {
      console.warn('Error restoring vehicles:', err);
    }
  };

  const handleOpenAdd = () => {
    setEditingVehicle(null);
    setFormData({
      equipmentCode: '',
      modelNumber: '',
      registrationNumber: '',
      category: 'Standard Van',
      ownershipType: 'Company',
      hourlyRate: 0,
      dailyRate: 0,
      monthlyRate: 0,
      weeklyRentalCost: 185.00,
      currentMeterHours: 0,
      lastServiceDate: '',
      serviceIntervalHours: 250,
      status: 'Available',
      assignedOperator: '',
      assignedClient: '',
      motExpiry: '',
      taxExpiry: '',
      insuranceExpiry: '',
      currentMileage: 0,
      nextServiceMileage: 0,
      depotLocation: 'Leicester Depot',
      isActive: true,
      notes: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (v) => {
    setEditingVehicle(v);
    setFormData({
      equipmentCode: v.equipment_code || '',
      modelNumber: v.model_number || '',
      registrationNumber: v.registration_number || '',
      category: v.category || 'Standard Van',
      ownershipType: v.ownership_type || 'Company',
      hourlyRate: v.hourly_rate || 0,
      dailyRate: v.daily_rate || 0,
      monthlyRate: v.monthly_rate || 0,
      weeklyRentalCost: v.weekly_rental_cost || 185.00,
      currentMeterHours: v.current_meter_hours || 0,
      lastServiceDate: v.last_service_date ? v.last_service_date.split('T')[0] : '',
      serviceIntervalHours: v.service_interval_hours || 250,
      status: v.status || 'Available',
      assignedOperator: v.assigned_operator || '',
      assignedClient: v.assigned_client || '',
      motExpiry: v.mot_expiry ? v.mot_expiry.split('T')[0] : '',
      taxExpiry: v.tax_expiry ? v.tax_expiry.split('T')[0] : '',
      insuranceExpiry: v.insurance_expiry ? v.insurance_expiry.split('T')[0] : '',
      currentMileage: v.current_mileage || 0,
      nextServiceMileage: v.next_service_mileage || 0,
      depotLocation: v.depot_location || '',
      isActive: v.is_active !== undefined ? v.is_active : true,
      notes: v.notes || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingVehicle) {
        await updateVehicle(editingVehicle.id, formData);
      } else {
        await createVehicle(formData);
      }
      setIsModalOpen(false);
      loadVehicles();
    } catch (err) {
      console.warn('Error saving vehicle: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleToggleActive = async (id, reg) => {
    try {
      const res = await toggleVehicleActive(id);
      const isNowActive = res.vehicle?.is_active;
      setToastMessage(
        isNowActive
          ? `Vehicle ${reg || 'van'} restored to Active Fleet.`
          : `Vehicle ${reg || 'van'} decommissioned (view in Decommissioned tab).`
      );
      setTimeout(() => setToastMessage(''), 4000);
      loadVehicles();
    } catch (err) {
      console.warn('Error toggling vehicle status: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleSoftDelete = async (id, reg) => {
    try {
      await deleteVehicle(id);
      setToastMessage(`Vehicle ${reg || 'van'} decommissioned successfully.`);
      setTimeout(() => setToastMessage(''), 4000);
      loadVehicles();
    } catch (err) {
      console.warn('Error deleting vehicle: ' + (err.response?.data?.error || err.message));
    }
  };

  // KPI Stats
  const totalFleet = vehicles.length;
  const redCount = vehicles.filter(v => v.compliance?.overall === 'red').length;
  const amberCount = vehicles.filter(v => v.compliance?.overall === 'amber').length;
  const greenCount = vehicles.filter(v => v.compliance?.overall === 'green').length;

  const filtered = vehicles.filter(v => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      v.model_number?.toLowerCase().includes(q) ||
      v.registration_number?.toLowerCase().includes(q) ||
      v.equipment_code?.toLowerCase().includes(q) ||
      v.depot_location?.toLowerCase().includes(q)
    );
  });

  const renderBadge = (label, complianceItem) => {
    if (!complianceItem) return null;
    const { status, days } = complianceItem;

    if (status === 'unknown') {
      return <span className="text-[10px] text-slate-500 font-mono">{label}: N/A</span>;
    }

    if (status === 'red') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-rose-500/20 text-rose-600 dark:text-rose-300 border border-rose-500/50 animate-pulse shadow-sm shadow-rose-500/30">
          <AlertCircle className="w-3 h-3 text-rose-500 animate-spin" style={{ animationDuration: '3s' }} />
          {label}: {days < 0 ? `${Math.abs(days)}d OVERDUE` : 'EXPIRED'}
        </span>
      );
    }
    if (status === 'amber') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/50 animate-pulse shadow-sm shadow-amber-500/20 whitespace-nowrap">
          <AlertTriangle className="w-3 h-3 text-amber-500" />
          {label}: {days}d due
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 whitespace-nowrap">
        <CheckCircle2 className="w-3 h-3" />
        {label}: {days}d
      </span>
    );
  };

  const renderTimingBeltBadge = (compTb) => {
    if (!compTb) return null;
    const { status, milesRemaining, targetMileage } = compTb;
    const targetK = Math.round((targetMileage || 70000) / 1000);

    if (status === 'red') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-rose-500/20 text-rose-600 dark:text-rose-300 border border-rose-500/50 animate-pulse shadow-sm shadow-rose-500/30 whitespace-nowrap" title={`Timing Belt (Cambelt) replacement overdue at ${targetK}k mi milestone`}>
          <AlertCircle className="w-3 h-3 text-rose-500" />
          ⚙️ Cambelt: {targetK}k mi OVERDUE ({Math.abs(milesRemaining)} mi)
        </span>
      );
    }
    if (status === 'amber') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/50 animate-pulse shadow-sm shadow-amber-500/20 whitespace-nowrap" title={`Timing Belt (Cambelt) change due soon at ${targetK}k mi milestone`}>
          <AlertTriangle className="w-3 h-3 text-amber-500" />
          ⚙️ Cambelt: {targetK}k mi Due ({milesRemaining} mi left)
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 whitespace-nowrap" title={`Next Timing Belt (Cambelt) milestone target is ${targetK}k mi`}>
        <span>⚙️</span> Cambelt: {targetK}k mi ({milesRemaining} mi left)
      </span>
    );
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-xl">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Fleet Compliance & Courier Hub</h2>
            <p className="text-xs text-slate-600 dark:text-slate-400">Live MOT, Road Tax, Insurance expiry countdowns & delivery van maintenance tracking</p>
          </div>
        </div>
        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 flex items-center gap-1.5 transition cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Add Courier Vehicle
        </button>
      </div>

      {/* Compliance Countdown Dashboard Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div 
          onClick={() => setComplianceFilter('')}
          className={`p-4 rounded-xl border transition-all cursor-pointer ${
            complianceFilter === '' ? 'bg-blue-50 dark:bg-slate-800/90 border-blue-500 ring-2 ring-blue-500/30' : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Total Courier Fleet</span>
            <Truck className="w-5 h-5 text-slate-600 dark:text-slate-400" />
          </div>
          <p className="text-2xl font-black text-slate-900 dark:text-white mt-2">{totalFleet}</p>
          <span className="text-[11px] text-slate-500">Active courier vans</span>
        </div>

        <div 
          onClick={() => setComplianceFilter('green')}
          className={`p-4 rounded-xl border transition-all cursor-pointer ${
            complianceFilter === 'green' ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-500 ring-2 ring-emerald-500/30' : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">Fully Compliant</span>
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-2">{greenCount}</p>
          <span className="text-[11px] text-emerald-500/80">Valid MOT, Tax & Insurance</span>
        </div>

        <div 
          onClick={() => setComplianceFilter('amber')}
          className={`p-4 rounded-xl border transition-all cursor-pointer ${
            complianceFilter === 'amber' ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-500 ring-2 ring-amber-500/30' : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wider">Due Soon (≤ 30 Days)</span>
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400" />
          </div>
          <p className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-2">{amberCount}</p>
          <span className="text-[11px] text-amber-500/80">Action required within month</span>
        </div>

        <div 
          onClick={() => setComplianceFilter('red')}
          className={`p-4 rounded-xl border transition-all cursor-pointer ${
            complianceFilter === 'red' ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-500 ring-2 ring-rose-500/30' : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-rose-600 dark:text-rose-400 uppercase tracking-wider">Overdue Alert</span>
            <ShieldAlert className="w-5 h-5 text-rose-600 dark:text-rose-400" />
          </div>
          <p className="text-2xl font-black text-rose-600 dark:text-rose-400 mt-2">{redCount}</p>
          <span className="text-[11px] text-rose-500/80">Immediate ground/service</span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm dark:shadow-lg flex flex-wrap gap-4 items-center justify-between">
        <div className="relative flex-1 min-w-[280px]">
          <Search className="w-4 h-4 text-slate-600 dark:text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search fleet by model, reg, or depot location..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-800 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500 shadow-sm dark:shadow-none"
          />
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <ColumnVisibilityToggle
            columns={FLEET_COLUMNS}
            visibleColumns={fleetVisible}
            onChange={setFleetVisible}
            onReset={() => setFleetVisible({})}
            storageKey="fleet_visible_cols"
          />

          {/* Fleet Scope Slicer: Active vs Only Decommissioned vs All */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-950 p-1 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-bold">
            <button
              type="button"
              onClick={() => { setFleetScope('active'); setStatusFilter(''); }}
              className={`px-2.5 py-1 rounded-md transition cursor-pointer flex items-center gap-1.5 ${
                fleetScope === 'active' && statusFilter !== 'Decommissioned'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="Show active operational fleet only"
            >
              <Truck className="w-3.5 h-3.5" /> Active Fleet ({fleetCounts.active})
            </button>
            <button
              type="button"
              onClick={() => { setFleetScope('decommissioned'); setStatusFilter(''); }}
              className={`px-2.5 py-1 rounded-md transition cursor-pointer flex items-center gap-1.5 ${
                fleetScope === 'decommissioned' || statusFilter === 'Decommissioned'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="Show ONLY decommissioned / off-road vehicles"
            >
              <Power className="w-3.5 h-3.5" /> Only Decommissioned ({fleetCounts.decommissioned})
            </button>
            <button
              type="button"
              onClick={() => { setFleetScope('all'); setStatusFilter(''); }}
              className={`px-2.5 py-1 rounded-md transition cursor-pointer flex items-center gap-1.5 ${
                fleetScope === 'all' && statusFilter !== 'Decommissioned'
                  ? 'bg-slate-700 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="Show all vehicles (active and decommissioned)"
            >
              All ({fleetCounts.total})
            </button>
          </div>

          {/* Approved Courier Categories Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500"
          >
            <option value="">All Categories</option>
            <option value="Standard Van">Standard Van</option>
            <option value="LWB Van">LWB Van</option>
            <option value="SWB Van">SWB Van</option>
            <option value="Luton Van">Luton Van</option>
            <option value="Courier Car">Courier Car</option>
            <option value="Other">Other</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => {
              const val = e.target.value;
              setStatusFilter(val);
              if (val === 'Decommissioned') {
                setFleetScope('decommissioned');
              } else if (fleetScope === 'decommissioned') {
                setFleetScope('active');
              }
            }}
            className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500"
          >
            <option value="">All Operational Statuses</option>
            <option value="Available">Available</option>
            <option value="Deployed on Site">Deployed on Route</option>
            <option value="Under Maintenance">Under Maintenance</option>
            <option value="Breakdown">Breakdown</option>
            <option value="Decommissioned">Decommissioned (Inactive)</option>
          </select>
        </div>
      </div>

      {/* Real-time Action Feedback Banner */}
      {toastMessage && (
        <div className="p-3 bg-blue-600/10 border border-blue-500/30 text-blue-600 dark:text-blue-400 rounded-xl text-xs font-bold flex items-center justify-between animate-fade-in shadow-sm">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-blue-500" />
            <span>{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage('')} className="text-slate-400 hover:text-slate-600 text-xs">✕</button>
        </div>
      )}

      {/* Fleet Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-600 dark:text-slate-400">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-2"></div>
            <span>Loading compliance data...</span>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-12 h-12 bg-rose-500/10 text-rose-500 rounded-2xl flex items-center justify-center mx-auto">
              <Power className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              {fleetScope === 'decommissioned' ? 'No Decommissioned Vehicles in Fleet' : 'No Vehicles Found'}
            </h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              {fleetScope === 'decommissioned'
                ? 'All courier vehicles are currently active in operational service. To decommission a vehicle (take off-road, sold, or scrapped), choose Decommissioned from the status dropdown on any row.'
                : 'No vehicles match the selected search or filter criteria.'}
            </p>
            {fleetScope === 'decommissioned' && (
              <button
                onClick={() => setFleetScope('active')}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition cursor-pointer inline-flex items-center gap-1.5"
              >
                <Truck className="w-3.5 h-3.5" /> View Active Fleet ({fleetCounts.active} Vans)
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            {fleetScope === 'decommissioned' && filtered.length > 0 && (
              <div className="p-3 bg-rose-500/10 border-b border-rose-500/20 flex items-center justify-between text-xs text-rose-700 dark:text-rose-300 px-4 font-medium">
                <span>Showing {filtered.length} decommissioned (off-road) vehicles.</span>
                <button
                  onClick={handleRestoreAllDecommissioned}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1"
                  title="Restore all decommissioned vehicles back to active fleet"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" /> Restore All to Active Fleet
                </button>
              </div>
            )}
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  {fleetVisible.reg !== false && <th className="p-3.5">Registration / Model</th>}
                  {fleetVisible.depot !== false && <th className="p-3.5">Depot Location</th>}
                  {fleetVisible.compliance !== false && <th className="p-3.5">Compliance Countdown (MOT / Tax / Ins)</th>}
                  {fleetVisible.mileage !== false && <th className="p-3.5 text-right">Mileage & Service</th>}
                  {fleetVisible.status !== false && <th className="p-3.5 text-center">Operational Status</th>}
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                {filtered.map((v) => {
                  const comp = v.compliance || {};
                  return (
                    <tr key={v.id} className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition ${!v.is_active ? 'opacity-60 bg-slate-50/60 dark:bg-slate-950/40' : ''}`}>
                      {fleetVisible.reg !== false && (
                        <td className="p-3.5">
                          <span className="font-bold text-slate-900 dark:text-white block text-sm font-mono">{v.registration_number || v.equipment_code || 'UNREGISTERED'}</span>
                          <span className="text-[11px] text-blue-600 dark:text-blue-400 font-medium block">{v.model_number} • {v.category}</span>
                          <div className="flex flex-wrap items-center gap-1.5 mt-1">
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                              🔑 {v.keys_count || 1} {v.keys_count === 1 ? 'Key' : 'Keys'}
                            </span>
                            {v.has_dash_camera !== false ? (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                                📹 Dashcam
                              </span>
                            ) : (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20">
                                ⚠️ Cam Missing
                              </span>
                            )}
                            {v.has_livery && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                                🎨 Livery
                              </span>
                            )}
                          </div>
                        </td>
                      )}
                      {fleetVisible.depot !== false && (
                        <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium">
                          {v.depot_location || 'General Hub'}
                        </td>
                      )}
                      {fleetVisible.compliance !== false && (
                        <td className="p-3.5">
                          <div className="flex flex-wrap items-center gap-1.5">
                            {renderBadge('MOT', comp.mot)}
                            {renderBadge('Tax', comp.tax)}
                            {renderBadge('Ins', comp.insurance)}
                            {renderTimingBeltBadge(comp.timingBelt)}
                          </div>
                        </td>
                      )}
                      {fleetVisible.mileage !== false && (
                        <td className="p-3.5 text-right font-mono">
                          <span className="block font-mono font-bold text-slate-900 dark:text-white text-sm">{formatNumber(v.current_mileage || 0)} mi</span>
                          <div className="mt-1 space-y-1">
                            {comp.service?.status === 'red' ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-rose-500/20 text-rose-600 dark:text-rose-300 border border-rose-500/50 animate-pulse shadow-sm shadow-rose-500/20 whitespace-nowrap">
                                <AlertCircle className="w-3 h-3" /> 10k Service Overdue ({Math.abs(comp.service?.milesRemaining || 0)} mi)
                              </span>
                            ) : comp.service?.status === 'amber' ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-black bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/50 animate-pulse shadow-sm shadow-amber-500/20 whitespace-nowrap">
                                <AlertTriangle className="w-3 h-3" /> 10k Service Due ({comp.service?.milesRemaining} mi left)
                              </span>
                            ) : (
                              <span className="text-[10px] text-slate-500 font-sans block whitespace-nowrap">
                                Next 10k: <strong className="text-slate-700 dark:text-slate-300 font-mono">{formatNumber(comp.service?.targetMileage || 0)} mi</strong> ({comp.service?.milesRemaining} mi left)
                              </span>
                            )}
                          </div>
                        </td>
                      )}
                      {fleetVisible.status !== false && (
                        <td className="p-3.5 text-center">
                          <select
                            value={!v.is_active || v.status === 'Decommissioned' ? 'Decommissioned' : (v.status || 'Available')}
                            onChange={(e) => handleStatusChange(v.id, e.target.value, v.registration_number || v.equipment_code)}
                            className={`inline-flex items-center text-[10px] font-bold rounded-lg px-2.5 py-1 border cursor-pointer transition focus:outline-none ${
                              !v.is_active || v.status === 'Decommissioned'
                                ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30'
                                : v.status === 'Under Maintenance'
                                ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30'
                                : v.status === 'Breakdown'
                                ? 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30'
                                : v.status === 'Deployed on Site'
                                ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30'
                                : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                            }`}
                            title="Click to select or change vehicle operational status"
                          >
                            <option value="Available">🟢 Available</option>
                            <option value="Deployed on Site">🔵 Deployed on Route</option>
                            <option value="Under Maintenance">🟡 Under Maintenance</option>
                            <option value="Breakdown">🟠 Breakdown</option>
                            <option value="Decommissioned">🛑 Decommissioned</option>
                          </select>
                        </td>
                      )}
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(v)}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                            title="Edit Vehicle & Compliance Dates"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleToggleActive(v.id, v.registration_number || v.equipment_code)}
                            className={`p-1.5 rounded-lg border transition cursor-pointer ${
                              v.is_active && v.status !== 'Decommissioned'
                                ? 'bg-amber-50 hover:bg-amber-100 dark:bg-amber-500/10 dark:hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-500/20'
                                : 'bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:hover:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/20'
                            }`}
                            title={v.is_active && v.status !== 'Decommissioned' ? 'Decommission Vehicle (Take Off-Road)' : 'Re-activate Vehicle into Active Fleet'}
                          >
                            <Power className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleSoftDelete(v.id, v.registration_number || v.equipment_code)}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-500/10 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-500/20 transition cursor-pointer"
                            title="Delete / Decommission"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingVehicle ? 'Edit Vehicle Compliance & Specs' : 'Add Courier Vehicle to Fleet'}
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Registration No. (Vans)</label>
              <input
                type="text"
                value={formData.registrationNumber}
                onChange={(e) => setFormData({ ...formData, registrationNumber: e.target.value })}
                placeholder="e.g. AO21 OWA"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm font-mono text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Model / Make</label>
              <input
                type="text"
                value={formData.modelNumber}
                onChange={(e) => setFormData({ ...formData, modelNumber: e.target.value })}
                placeholder="e.g. Mercedes Sprinter LWB"
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Category</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="Standard Van">Standard Van</option>
                <option value="LWB Van">LWB Van</option>
                <option value="SWB Van">SWB Van</option>
                <option value="Luton Van">Luton Van</option>
                <option value="Courier Car">Courier Car</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Depot Hub Location</label>
              <input
                type="text"
                value={formData.depotLocation}
                onChange={(e) => setFormData({ ...formData, depotLocation: e.target.value })}
                placeholder="e.g. Leicester Depot"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Compliance Expiry Section */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
            <h4 className="text-xs font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" /> Compliance & Roadworthiness Expiries
            </h4>
            <div className="grid grid-cols-3 gap-2.5">
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">MOT Expiry</label>
                <input
                  type="date"
                  value={formData.motExpiry}
                  onChange={(e) => setFormData({ ...formData, motExpiry: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">Road Tax Expiry</label>
                <input
                  type="date"
                  value={formData.taxExpiry}
                  onChange={(e) => setFormData({ ...formData, taxExpiry: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">Insurance Expiry</label>
                <input
                  type="date"
                  value={formData.insuranceExpiry}
                  onChange={(e) => setFormData({ ...formData, insuranceExpiry: e.target.value })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Mileage & Service Section */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
            <h4 className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
              <Gauge className="w-4 h-4" /> Mileage & Service Schedule
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Current Odometer (Miles)</label>
                <input
                  type="number"
                  value={formData.currentMileage}
                  onChange={(e) => setFormData({ ...formData, currentMileage: parseFloat(e.target.value || 0) })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Next Service Target (Miles)</label>
                <input
                  type="number"
                  value={formData.nextServiceMileage}
                  onChange={(e) => setFormData({ ...formData, nextServiceMileage: parseFloat(e.target.value || 0) })}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 transition cursor-pointer"
            >
              {editingVehicle ? 'Save Vehicle Specs' : 'Add Vehicle'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}