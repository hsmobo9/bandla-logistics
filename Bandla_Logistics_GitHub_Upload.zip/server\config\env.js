const path = require('path');
const fs = require('fs');
require('dotenv').config();

const dataDir = process.env.DATA_DIR || path.join(__dirname, '../../data');
const invoicesDir = path.join(dataDir, 'invoices');

try {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(invoicesDir)) fs.mkdirSync(invoicesDir, { recursive: true });
} catch (err) {
  console.warn('Directory creation warning:', err.message);
}

module.exports = {
  PORT: process.env.PORT || 4000,
  NODE_ENV: process.env.NODE_ENV || 'production',
  DATABASE_URL: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/bandla_logistics',
  JWT_SECRET: process.env.JWT_SECRET || 'bandla-logistics-super-secret-jwt-key-2026',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  DATA_DIR: dataDir,
  INVOICES_DIR: invoicesDir,
  COMPANY_NAME: 'Bandla Logistics Ltd',
  COMPANY_ADDRESS: '128 City Road, London, EC1V 2NX',
  COMPANY_PHONE: '07966 270270',
  COMPANY_EMAIL: 'Admin@Bandlalogistics.co.uk',
  COMPANY_NO: '13307245',
  COMPANY_VAT_NO: 'GB376546166'
};