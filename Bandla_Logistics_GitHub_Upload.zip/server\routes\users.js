const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');
const { logAuditEvent } = require('../services/auditService');

// Helper to parse permissions JSON string
function parsePerms(val) {
  if (!val) return [];
  if (Array.isArray(val)) return val;
  try {
    const parsed = JSON.parse(val);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

// 1. GET /api/users - List all users (Admin Only)
router.get('/', async (req, res) => {
  try {
    const db = getDb();
    const { rows } = await db.session.client.query(`
      SELECT u.id, u.username, u.email, u.full_name, u.role, u.depot_id, u.status, COALESCE(u.permissions, '[]') as permissions, u.created_at, u.updated_at,
        d.name as depot_name, d.code as depot_code
      FROM users u
      LEFT JOIN depots d ON u.depot_id = d.id
      ORDER BY 
        CASE WHEN u.role = 'Admin' THEN 1 ELSE 2 END,
        u.full_name ASC
    `);

    const enriched = rows.map(u => ({
      ...u,
      permissions: parsePerms(u.permissions)
    }));

    res.json(enriched);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 2. POST /api/users - Create new manager or admin
router.post('/', async (req, res) => {
  try {
    const { username, email, password, fullName, role, depotId, permissions } = req.body;
    if (!username || !email || !password || !fullName || !role) {
      return res.status(400).json({ error: 'Username, email, password, full name, and role are required.' });
    }

    const db = getDb();
    const client = db.session.client;

    const check = await client.query('SELECT id FROM users WHERE email = $1 OR username = $2', [email.trim().toLowerCase(), username.trim().toLowerCase()]);
    if (check.rows.length > 0) {
      return res.status(409).json({ error: 'User with this email or username already exists.' });
    }

    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    const newId = uuidv4();
    const permsJson = JSON.stringify(Array.isArray(permissions) ? permissions : []);

    const { rows } = await client.query(`
      INSERT INTO users (id, username, email, password_hash, full_name, role, depot_id, status, permissions, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, 'active', $8, NOW(), NOW())
      RETURNING id, username, email, full_name, role, depot_id, status, permissions, created_at
    `, [newId, username.trim().toLowerCase(), email.trim().toLowerCase(), hash, fullName.trim(), role, depotId || null, permsJson]);

    // Audit Log
    await logAuditEvent(req, {
      actionType: 'USER_CREATED',
      tableAffected: 'users',
      recordId: newId,
      previousValue: null,
      newValue: { username, email, role, depotId, permissions },
      reason: `New ${role} account created for ${fullName}`
    });

    res.status(201).json({
      ...rows[0],
      permissions: parsePerms(rows[0].permissions)
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. PUT /api/users/:id - Update user details, role, depot & privileges
router.put('/:id', async (req, res) => {
  try {
    const { fullName, email, role, depotId, status, permissions, password } = req.body;
    const db = getDb();
    const client = db.session.client;

    const existing = await client.query('SELECT * FROM users WHERE id = $1', [req.params.id]);
    if (!existing.rows.length) {
      return res.status(404).json({ error: 'User not found.' });
    }

    const oldUser = existing.rows[0];
    let newHash = oldUser.password_hash;
    if (password && password.trim().length >= 6) {
      const salt = await bcrypt.genSalt(10);
      newHash = await bcrypt.hash(password.trim(), salt);
    }

    const permsJson = permissions !== undefined ? JSON.stringify(Array.isArray(permissions) ? permissions : []) : oldUser.permissions;

    const { rows } = await client.query(`
      UPDATE users SET
        full_name = COALESCE($1, full_name),
        email = COALESCE($2, email),
        role = COALESCE($3, role),
        depot_id = $4,
        status = COALESCE($5, status),
        permissions = $6,
        password_hash = $7,
        updated_at = NOW()
      WHERE id = $8
      RETURNING id, username, email, full_name, role, depot_id, status, permissions, created_at, updated_at
    `, [
      fullName ? fullName.trim() : null,
      email ? email.trim().toLowerCase() : null,
      role || null,
      depotId !== undefined ? (depotId || null) : oldUser.depot_id,
      status || null,
      permsJson,
      newHash,
      req.params.id
    ]);

    // Audit Log
    await logAuditEvent(req, {
      actionType: 'USER_PRIVILEGES_UPDATED',
      tableAffected: 'users',
      recordId: req.params.id,
      previousValue: { role: oldUser.role, permissions: parsePerms(oldUser.permissions), status: oldUser.status },
      newValue: { role: rows[0].role, permissions: parsePerms(rows[0].permissions), status: rows[0].status },
      reason: `Privileges and role updated by Admin (${req.user?.username || 'Admin'})`
    });

    res.json({
      ...rows[0],
      permissions: parsePerms(rows[0].permissions)
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 4. PATCH /api/users/:id/toggle-status - Activate / Deactivate user
router.patch('/:id/toggle-status', async (req, res) => {
  try {
    const db = getDb();
    const client = db.session.client;

    const check = await client.query('SELECT id, username, status, role FROM users WHERE id = $1', [req.params.id]);
    if (!check.rows.length) return res.status(404).json({ error: 'User not found.' });

    const u = check.rows[0];
    if (u.id === req.user.id) {
      return res.status(400).json({ error: 'You cannot deactivate your own admin account.' });
    }

    const nextStatus = u.status === 'active' ? 'deactivated' : 'active';
    const { rows } = await client.query(`
      UPDATE users SET status = $1, updated_at = NOW() WHERE id = $2
      RETURNING id, username, email, full_name, role, status
    `, [nextStatus, req.params.id]);

    await logAuditEvent(req, {
      actionType: 'USER_STATUS_CHANGE',
      tableAffected: 'users',
      recordId: req.params.id,
      previousValue: { status: u.status },
      newValue: { status: nextStatus },
      reason: `Account ${nextStatus === 'active' ? 'activated' : 'deactivated'} by Admin`
    });

    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 5. DELETE /api/users/:id - Delete user account
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const client = db.session.client;

    if (req.params.id === req.user.id) {
      return res.status(400).json({ error: 'You cannot delete your own admin account.' });
    }

    const check = await client.query('SELECT * FROM users WHERE id = $1', [req.params.id]);
    if (!check.rows.length) return res.status(404).json({ error: 'User not found.' });

    await client.query('DELETE FROM users WHERE id = $1', [req.params.id]);

    await logAuditEvent(req, {
      actionType: 'USER_DELETED',
      tableAffected: 'users',
      recordId: req.params.id,
      previousValue: { username: check.rows[0].username, email: check.rows[0].email },
      newValue: null,
      reason: `User account deleted by Admin`
    });

    res.json({ message: 'User deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
