const { initDb } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

async function seedDiverseLeaves() {
  console.log('--- Seeding Full Range of Driver Leave & Off Statuses ---');
  const { client } = await initDb();

  const driversRes = await client.query(`SELECT id, full_name, driver_code FROM drivers WHERE is_active = true ORDER BY full_name ASC`);
  const drivers = driversRes.rows;

  if (drivers.length < 10) {
    console.log('Not enough drivers to seed diverse leaves.');
    return;
  }

  // Clear existing leaves for clean slate
  await client.query(`DELETE FROM driver_availability`);

  const leavesToSeed = [
    {
      driver: drivers.find(d => d.full_name.toLowerCase().includes('patiyala')) || drivers[2],
      status: 'Annual Leave',
      notes: 'Approved Annual Leave (2 Weeks Summer Vacation)',
      start: '2026-08-20',
      end: '2026-09-02'
    },
    {
      driver: drivers.find(d => d.full_name.toLowerCase().includes('andrie')) || drivers[3],
      status: 'Sick Leave',
      notes: 'Medical Doctor Note Submitted (Flu Recovery)',
      start: '2026-08-24',
      end: '2026-08-31'
    },
    {
      driver: drivers.find(d => d.full_name.toLowerCase().includes('ankit')) || drivers[4],
      status: 'Day Off',
      notes: 'Scheduled Rota Rest Day',
      start: '2026-08-25',
      end: '2026-08-30'
    },
    {
      driver: drivers.find(d => d.full_name.toLowerCase().includes('arshpreet')) || drivers[5],
      status: 'Training',
      notes: 'Depot Health & Safety / Courier Parcel Scanning Induction',
      start: '2026-08-26',
      end: '2026-08-30'
    },
    {
      driver: drivers.find(d => d.full_name.toLowerCase().includes('ashutosh')) || drivers[6],
      status: 'Personal Leave',
      notes: 'Family Emergency Leave (Authorized)',
      start: '2026-08-27',
      end: '2026-08-31'
    },
    {
      driver: drivers.find(d => d.full_name.toLowerCase().includes('baljinder')) || drivers[7],
      status: 'Vehicle Issue',
      notes: 'Contractor Van in Garage for Clutch Replacement',
      start: '2026-08-28',
      end: '2026-08-31'
    },
    {
      driver: drivers.find(d => d.full_name.toLowerCase().includes('basanta')) || drivers[8],
      status: 'Day Off',
      notes: 'Weekend Off Duty',
      start: '2026-08-29',
      end: '2026-08-30'
    }
  ];

  for (const l of leavesToSeed) {
    if (l.driver) {
      await client.query(`
        INSERT INTO driver_availability (id, driver_id, start_date, end_date, status, notes, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
      `, [uuidv4(), l.driver.id, l.start, l.end, l.status, l.notes]);
      console.log(`✓ Seeded ${l.status} for ${l.driver.full_name}: "${l.notes}" (${l.start} to ${l.end})`);
    }
  }

  console.log('✓ All leave categories seeded successfully.');
}

seedDiverseLeaves().then(() => process.exit(0)).catch(err => {
  console.error(err);
  process.exit(1);
});