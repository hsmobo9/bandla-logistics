import React, { useState, useEffect } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Calendar as CalendarIcon, 
  Package, 
  CheckCircle, 
  AlertCircle,
  Truck,
  Filter,
  DollarSign,
  Search,
  LayoutGrid,
  ListFilter,
  TrendingUp,
  AlertTriangle,
  Clock,
  MapPin
} from 'lucide-react';
import { getShifts, getDrivers, getDepots, getRouteRates, createShift, updateShift, deleteShift } from '../services/api';
import Modal from '../components/Modal';
import { formatCurrency, formatNumber, formatDate } from '../utils/formatters';

export default function ShiftCalendar() {
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'table'
  const [rangePreset, setRangePreset] = useState('1m'); // '1m' | '2m' | '3m' | '6m' | '12m' | 'custom' | 'all'
  
  // Custom Date Pickers
  const [customStartDate, setCustomStartDate] = useState('2026-07-01');
  const [customEndDate, setCustomEndDate] = useState('2026-08-31');

  // Single Month Navigator (for Grid Mode)
  const [currentDate, setCurrentDate] = useState(new Date(2026, 7, 1)); // Default Aug 2026

  const [shifts, setShifts] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [depots, setDepots] = useState([]);
  const [routeRates, setRouteRates] = useState([]);
  const [search, setSearch] = useState('');
  const [depotFilter, setDepotFilter] = useState('');
  const [driverFilter, setDriverFilter] = useState('');
  const [selectedMonthTab, setSelectedMonthTab] = useState('ALL'); // 'ALL' | 'YYYY-MM'

  const [selectedDateShifts, setSelectedDateShifts] = useState([]);
  const [activeDateStr, setActiveDateStr] = useState(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [modalError, setModalError] = useState('');

  // New Shift Form State
  const [formData, setFormData] = useState({
    shiftDate: new Date().toISOString().split('T')[0],
    driverId: '',
    depotId: '',
    routeCode: '',
    fdNumber: '',
    dispatchedStops: 120,
    paidStops: 120,
    totalParcels: 135,
    appliedBaseRate: 1.00,
    appliedExcessRate: 0.05,
    topUpCancelled: false,
    notes: ''
  });

  // Filter available drivers by selected depot (cascade)
  const availableDrivers = React.useMemo(() => {
    if (!depotFilter) return drivers;
    return drivers.filter(d => 
      d.default_depot_id === depotFilter || 
      d.depot_id === depotFilter
    );
  }, [drivers, depotFilter]);

  const handleDepotChange = (newDepotId) => {
    setDepotFilter(newDepotId);
    if (newDepotId && driverFilter) {
      const isDriverInDepot = availableDrivers.some(d => d.id === driverFilter);
      if (!isDriverInDepot) {
        setDriverFilter('');
      }
    }
  };

  useEffect(() => {
    loadPrerequisites();
  }, []);

  useEffect(() => {
    loadShiftsData();
  }, [currentDate, rangePreset, customStartDate, customEndDate, depotFilter, driverFilter, viewMode]);

  const loadPrerequisites = async () => {
    try {
      const [dList, depList, rList] = await Promise.all([
        getDrivers({ includeInactive: 'false' }),
        getDepots(),
        getRouteRates()
      ]);
      setDrivers(dList);
      setDepots(depList);
      setRouteRates(rList);

      if (dList.length > 0) {
        setFormData(prev => ({
          ...prev,
          driverId: prev.driverId || dList[0].id,
          depotId: prev.depotId || dList[0].default_depot_id || depList[0]?.id || '',
          routeCode: prev.routeCode || dList[0].driver_code || 'LEI-101',
          fdNumber: prev.fdNumber || dList[0].assigned_fd_number || 'FD74030'
        }));
      }
    } catch (err) {
      console.error('Error loading prerequisites:', err);
    }
  };

  const loadShiftsData = async () => {
    try {
      setLoading(true);
      let startDateStr = '';
      let endDateStr = '';

      if (viewMode === 'grid') {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        startDateStr = `${year}-${String(month + 1).padStart(2, '0')}-01`;
        const lastDay = new Date(year, month + 1, 0).getDate();
        endDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
      } else {
        if (rangePreset === '1m') {
          startDateStr = '2026-08-01';
          endDateStr = '2026-08-31';
        } else if (rangePreset === '2m') {
          startDateStr = '2026-07-01';
          endDateStr = '2026-08-31';
        } else if (rangePreset === '3m') {
          startDateStr = '2026-06-01';
          endDateStr = '2026-08-31';
        } else if (rangePreset === '6m') {
          startDateStr = '2026-03-01';
          endDateStr = '2026-08-31';
        } else if (rangePreset === '12m') {
          startDateStr = '2026-01-01';
          endDateStr = '2026-12-31';
        } else if (rangePreset === 'custom') {
          startDateStr = customStartDate;
          endDateStr = customEndDate;
        } else if (rangePreset === 'all') {
          startDateStr = '';
          endDateStr = '';
        }
      }

      const params = {
        startDate: startDateStr || undefined,
        endDate: endDateStr || undefined,
        depotId: depotFilter || undefined,
        driverId: driverFilter || undefined
      };

      const data = await getShifts(params);
      setShifts(data);
    } catch (err) {
      console.error('Error loading shifts:', err);
    } finally {
      setLoading(false);
    }
  };

  const handlePrevMonth = () => {
    const prev = new Date(currentDate);
    prev.setMonth(prev.getMonth() - 1);
    setCurrentDate(prev);
  };

  const handleNextMonth = () => {
    const next = new Date(currentDate);
    next.setMonth(next.getMonth() + 1);
    setCurrentDate(next);
  };

  const handleDateClick = (dateStr) => {
    const dateShifts = shifts.filter(s => String(s.shift_date).startsWith(dateStr));
    setSelectedDateShifts(dateShifts);
    setActiveDateStr(dateStr);
    setIsDetailModalOpen(true);
  };

  const handleOpenAddModal = (initialDate = '') => {
    setModalError('');
    setSaving(false);
    const selectedDriver = drivers[0];
    const defaultDepotId = selectedDriver?.default_depot_id || depots[0]?.id || '';
    setFormData({
      shiftDate: initialDate || new Date().toISOString().split('T')[0],
      driverId: selectedDriver?.id || '',
      depotId: defaultDepotId,
      routeCode: selectedDriver?.driver_code || 'LEI-101',
      fdNumber: selectedDriver?.assigned_fd_number || 'FD74030',
      dispatchedStops: 120,
      paidStops: 120,
      totalParcels: 135,
      appliedBaseRate: 1.00,
      appliedExcessRate: 0.05,
      topUpCancelled: false,
      notes: ''
    });
    setIsAddModalOpen(true);
  };

  const handleSaveShift = async (e) => {
    e.preventDefault();
    if (!formData.shiftDate || !formData.driverId) {
      setModalError('Please select both a Route Date and a Courier Driver.');
      return;
    }
    setModalError('');
    setSaving(true);
    try {
      await createShift(formData);
      setIsAddModalOpen(false);
      await loadShiftsData();
    } catch (err) {
      setModalError(err.response?.data?.error || err.message);
    } finally {
      setSaving(false);
    }
  };

  // Filtered Shifts
  const filteredShifts = shifts.filter(s => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      s.driver_name?.toLowerCase().includes(q) ||
      s.driver_code?.toLowerCase().includes(q) ||
      s.route_code?.toLowerCase().includes(q) ||
      s.fd_number?.toLowerCase().includes(q) ||
      s.depot_name?.toLowerCase().includes(q)
    );
  });

  // Rollup KPI Metrics
  const totalShiftsCount = filteredShifts.length;
  const totalDispatchedStops = filteredShifts.reduce((acc, s) => acc + parseInt(s.dispatched_stops || 0, 10), 0);
  const totalPaidStops = filteredShifts.reduce((acc, s) => acc + parseInt(s.paid_stops || 0, 10), 0);
  const totalGrossPay = filteredShifts.reduce((acc, s) => acc + parseFloat(s.gross_shift_total || 0), 0);
  const totalParcelBonus = filteredShifts.reduce((acc, s) => acc + parseFloat(s.calculated_parcel_pay || 0), 0);
  const totalTopUpSubsidy = filteredShifts.reduce((acc, s) => acc + parseFloat(s.top_up_pay || 0), 0);
  const avgSpr = totalShiftsCount > 0 ? Math.round(totalPaidStops / totalShiftsCount) : 0;
  const overallFailPct = totalDispatchedStops > 0 ? (((totalDispatchedStops - totalPaidStops) / totalDispatchedStops) * 100).toFixed(2) : '0.00';

  // Distinct months in loaded dataset with count
  const distinctMonths = React.useMemo(() => {
    const map = {};
    filteredShifts.forEach(s => {
      if (!s.shift_date) return;
      const key = String(s.shift_date).substring(0, 7); // e.g. "2026-08"
      if (!map[key]) {
        const dateObj = new Date(`${key}-01T00:00:00`);
        const label = dateObj.toLocaleString('en-US', { month: 'long', year: 'numeric' });
        map[key] = { key, label, count: 0 };
      }
      map[key].count += 1;
    });
    return Object.values(map).sort((a, b) => b.key.localeCompare(a.key));
  }, [filteredShifts]);

  // Displayed shifts in table view (respects selectedMonthTab)
  const displayedTableShifts = React.useMemo(() => {
    if (selectedMonthTab === 'ALL') return filteredShifts;
    return filteredShifts.filter(s => String(s.shift_date).startsWith(selectedMonthTab));
  }, [filteredShifts, selectedMonthTab]);

  // Month Grid Calculation Variables
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstDayIndex = new Date(year, month, 1).getDay();
  const totalDays = new Date(year, month + 1, 0).getDate();
  const monthName = currentDate.toLocaleString('en-US', { month: 'long', year: 'numeric' });

  // Map shifts by date for month grid
  const shiftsByDate = {};
  filteredShifts.forEach(s => {
    const dateKey = String(s.shift_date).substring(0, 10);
    if (!shiftsByDate[dateKey]) shiftsByDate[dateKey] = [];
    shiftsByDate[dateKey].push(s);
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-sky-500/10 text-sky-600 dark:text-sky-400 rounded-xl">
            <CalendarIcon className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Daily Route Logs & Multi-Month Aggregator</h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                {viewMode === 'grid' ? monthName : 
                 rangePreset === '1m' ? monthName : 
                 rangePreset === '2m' ? '2 Months (Jul - Aug 2026)' :
                 rangePreset === '3m' ? '3 Months / Q3 (Jun - Aug 2026)' :
                 rangePreset === '6m' ? '6 Months / H1-H2 (Mar - Aug 2026)' :
                 rangePreset === '12m' ? 'Full Year 2026 (Annual)' :
                 rangePreset === 'custom' ? `Custom (${formatDate(customStartDate)} - ${formatDate(customEndDate)})` :
                 'All Time Records'}
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">View 1, 2, 3, 6, or 12 months dispatch records with Stops-Per-Route analytics</p>
          </div>
        </div>

        {/* View Mode & Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Grid vs Table View Mode Switcher */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-1 rounded-xl">
            <button
              onClick={() => { setViewMode('grid'); setRangePreset('1m'); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                viewMode === 'grid'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" /> Month Calendar
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-600 dark:text-slate-400 hover:text-white'
              }`}
            >
              <ListFilter className="w-3.5 h-3.5" /> Route Ledger & Rota
            </button>
          </div>

          <button
            onClick={() => handleOpenAddModal()}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 flex items-center gap-1.5 transition cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Record Route
          </button>
        </div>
      </div>

      {/* Control Bar: Time Horizon in Table Mode, Month Navigator in Grid Mode */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm dark:shadow-lg flex flex-wrap gap-4 items-center justify-between">
        {viewMode === 'grid' ? (
          /* Grid View Month Navigator */
          <div className="flex flex-wrap items-center justify-between w-full gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">Viewing Month:</span>
              <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-2 py-1 rounded-lg">
                <button
                  onClick={handlePrevMonth}
                  className="p-1 rounded bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 transition cursor-pointer"
                  title="Previous Month"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-xs font-bold text-slate-900 dark:text-white px-3">{monthName}</span>
                <button
                  onClick={handleNextMonth}
                  className="p-1 rounded bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 transition cursor-pointer"
                  title="Next Month"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Quick Month Jump Buttons */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-slate-500 font-medium mr-1">Quick Jump:</span>
              <button
                onClick={() => setCurrentDate(new Date(2026, 7, 1))}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  currentDate.getMonth() === 7 && currentDate.getFullYear() === 2026
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                August 2026 (453)
              </button>
              <button
                onClick={() => setCurrentDate(new Date(2026, 6, 1))}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  currentDate.getMonth() === 6 && currentDate.getFullYear() === 2026
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                July 2026 (342)
              </button>
              <button
                onClick={() => setCurrentDate(new Date(2026, 5, 1))}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  currentDate.getMonth() === 5 && currentDate.getFullYear() === 2026
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                June 2026 (324)
              </button>
            </div>
          </div>
        ) : (
          /* Table View Multi-Month Horizon Bar */
          <div className="flex flex-wrap items-center justify-between w-full gap-4">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400 mr-1">Time Horizon:</span>
              
              <button
                onClick={() => { setRangePreset('1m'); setSelectedMonthTab('ALL'); }}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  rangePreset === '1m'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm font-bold'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                1 Month (August 2026)
              </button>

              <button
                onClick={() => { setRangePreset('2m'); setSelectedMonthTab('ALL'); }}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  rangePreset === '2m'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm font-bold'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                2 Months (Jul - Aug)
              </button>

              <button
                onClick={() => { setRangePreset('3m'); setSelectedMonthTab('ALL'); }}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  rangePreset === '3m'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm font-bold'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                3 Months (Quarterly)
              </button>

              <button
                onClick={() => { setRangePreset('6m'); setSelectedMonthTab('ALL'); }}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  rangePreset === '6m'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm font-bold'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                6 Months (Half-Year)
              </button>

              <button
                onClick={() => { setRangePreset('12m'); setSelectedMonthTab('ALL'); }}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  rangePreset === '12m'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm font-bold'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                12 Months (2026 Annual)
              </button>

              <button
                onClick={() => { setRangePreset('all'); setSelectedMonthTab('ALL'); }}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  rangePreset === 'all'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm font-bold'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                All Records
              </button>

              <button
                onClick={() => { setRangePreset('custom'); setSelectedMonthTab('ALL'); }}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition cursor-pointer ${
                  rangePreset === 'custom'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm font-bold'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                Custom Range...
              </button>
            </div>

            {/* Custom Date Pickers */}
            {rangePreset === 'custom' && (
              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-900 dark:text-white"
                />
                <span className="text-slate-500 text-xs">to</span>
                <input
                  type="date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-900 dark:text-white"
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Aggregate KPI Summary Rollup Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
          <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 uppercase">Total Routes</span>
          <p className="text-xl font-bold text-slate-900 dark:text-white mt-1">{formatNumber(totalShiftsCount)}</p>
          <span className="text-[10px] text-slate-500">In selected period</span>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
          <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 uppercase">Paid Stops</span>
          <p className="text-xl font-bold text-sky-600 dark:text-sky-400 mt-1">{formatNumber(totalPaidStops)}</p>
          <span className="text-[10px] text-slate-500">of {formatNumber(totalDispatchedStops)} disp</span>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
          <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 uppercase">Avg Stops/Route</span>
          <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">{avgSpr} SPR</p>
          <span className="text-[10px] text-emerald-500/80">Courier efficiency</span>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
          <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 uppercase">Gross Revenue</span>
          <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">{formatCurrency(totalGrossPay)}</p>
          <span className="text-[10px] text-slate-500">Total route payout</span>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
          <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 uppercase">Parcel Bonuses</span>
          <p className="text-xl font-bold text-indigo-600 dark:text-indigo-400 mt-1">{formatCurrency(totalParcelBonus)}</p>
          <span className="text-[10px] text-slate-500">£0.05 excess parcel pay</span>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-none">
          <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 uppercase">Top-Up Subsidies</span>
          <p className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-1">{formatCurrency(totalTopUpSubsidy)}</p>
          <span className="text-[10px] text-amber-500/80">£100 guarantee support</span>
        </div>
      </div>

      {/* --- VIEW 1: MONTH CALENDAR GRID --- */}
      {viewMode === 'grid' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl p-5 space-y-4">
          {/* Days of Week Header */}
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-slate-500 uppercase tracking-wider">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>

          {/* Month Day Cells */}
          <div className="grid grid-cols-7 gap-2">
            {/* Empty padding days before month starts */}
            {Array.from({ length: firstDayIndex }).map((_, i) => (
              <div key={`empty-${i}`} className="h-28 rounded-xl bg-slate-50/50 dark:bg-slate-950/20 border border-dashed border-slate-200/50 dark:border-slate-800/40" />
            ))}

            {/* Actual Days of Month */}
            {Array.from({ length: totalDays }).map((_, i) => {
              const dayNum = i + 1;
              const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
              const dayShifts = shiftsByDate[dateStr] || [];
              const hasShifts = dayShifts.length > 0;
              const totalStops = dayShifts.reduce((acc, s) => acc + parseInt(s.paid_stops || 0, 10), 0);
              const avgSprDay = hasShifts ? Math.round(totalStops / dayShifts.length) : 0;

              return (
                <div
                  key={`day-${dayNum}`}
                  onClick={() => {
                    if (hasShifts) {
                      setSelectedDateShifts(dayShifts);
                      setActiveDateStr(dateStr);
                      setIsDetailModalOpen(true);
                    } else {
                      handleOpenAddModal(dateStr);
                    }
                  }}
                  className={`h-28 p-2 rounded-xl border transition cursor-pointer flex flex-col justify-between group ${
                    hasShifts
                      ? 'bg-slate-50 dark:bg-slate-950/60 border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 hover:shadow-md'
                      : 'bg-slate-50/30 dark:bg-slate-950/20 border-slate-200/50 dark:border-slate-800/40 hover:bg-slate-100/50 dark:hover:bg-slate-900/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-bold ${hasShifts ? 'text-slate-900 dark:text-white' : 'text-slate-400'}`}>
                      {dayNum}
                    </span>
                    {hasShifts && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                        {dayShifts.length} {dayShifts.length === 1 ? 'Route' : 'Routes'}
                      </span>
                    )}
                  </div>

                  {hasShifts ? (
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[10px] text-slate-600 dark:text-slate-400">
                        <span>{totalStops} Stops</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold">{avgSprDay} SPR</span>
                      </div>
                    </div>
                  ) : (
                    <div className="text-[10px] text-slate-400 text-center italic opacity-0 group-hover:opacity-100">
                      + Add Route
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* --- VIEW 2: MULTI-MONTH SHIFT LEDGER & TABLE --- */}
      {viewMode === 'table' && (
        <div className="space-y-4">
          {/* Search & Cascaded Filter Bar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm dark:shadow-lg flex flex-wrap gap-4 items-center justify-between">
            <div className="relative flex-1 min-w-[260px]">
              <Search className="w-4 h-4 text-slate-600 dark:text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search across all months by driver, route, FD number, or depot..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-800 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500 shadow-sm dark:shadow-none"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {/* Cascaded Depot Select */}
              <select
                value={depotFilter}
                onChange={(e) => handleDepotChange(e.target.value)}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500 min-w-[180px]"
              >
                <option value="">All Depots (6 Depots • {drivers.length} Drivers)</option>
                {depots.map(d => {
                  const dCount = drivers.filter(dr => dr.default_depot_id === d.id || dr.depot_id === d.id).length;
                  return (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.code}) • {dCount} Drivers
                    </option>
                  );
                })}
              </select>

              {/* Cascaded Driver Select */}
              <select
                value={driverFilter}
                onChange={(e) => setDriverFilter(e.target.value)}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-blue-500 min-w-[200px]"
              >
                <option value="">
                  {depotFilter 
                    ? `All ${depots.find(d => d.id === depotFilter)?.name || ''} Drivers (${availableDrivers.length})` 
                    : `All Drivers (${drivers.length})`}
                </option>
                {availableDrivers.map(d => (
                  <option key={d.id} value={d.id}>{d.full_name} ({d.driver_code || 'DR'})</option>
                ))}
              </select>
            </div>
          </div>

          {/* Multi-Month Slicer Tab Bar */}
          {distinctMonths.length > 1 && (
            <div className="flex flex-wrap items-center gap-2 p-2.5 bg-slate-100/80 dark:bg-slate-950/80 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold">
              <span className="text-slate-500 text-[11px] px-1">Month Slicer:</span>
              <button
                type="button"
                onClick={() => setSelectedMonthTab('ALL')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                  selectedMonthTab === 'ALL'
                    ? 'bg-blue-600 text-white shadow-sm font-bold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                All In Range ({filteredShifts.length} Routes)
              </button>
              {distinctMonths.map(m => (
                <button
                  key={m.key}
                  type="button"
                  onClick={() => setSelectedMonthTab(m.key)}
                  className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                    selectedMonthTab === m.key
                      ? 'bg-sky-600 text-white shadow-sm font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <span>{m.label}</span>
                  <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-slate-800/40 text-sky-300 font-mono">
                    {m.count}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Shifts Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
            {loading ? (
              <div className="p-12 text-center text-slate-600 dark:text-slate-400">Loading multi-month route data...</div>
            ) : displayedTableShifts.length === 0 ? (
              <div className="p-12 text-center text-slate-500 space-y-2">
                <CheckCircle className="w-8 h-8 mx-auto text-slate-600" />
                <p>No routes recorded for the selected month or driver filter.</p>
                {selectedMonthTab !== 'ALL' && (
                  <button
                    onClick={() => setSelectedMonthTab('ALL')}
                    className="text-xs text-blue-500 font-bold hover:underline"
                  >
                    View all months in range
                  </button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="p-3.5">Route Date</th>
                      <th className="p-3.5">Driver / Courier</th>
                      <th className="p-3.5">Depot & Route</th>
                      <th className="p-3.5 text-right">Stops (Paid / Disp)</th>
                      <th className="p-3.5 text-center">Fail (%)</th>
                      <th className="p-3.5 text-right">Parcel Bonus (£0.05)</th>
                      <th className="p-3.5 text-right">Top-Up Subsidy</th>
                      <th className="p-3.5 text-right">Gross Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                    {displayedTableShifts.map((s) => {
                      const failNum = parseFloat(s.fail_percentage || 0);
                      return (
                        <tr key={s.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                          <td className="p-3.5 font-mono text-slate-700 dark:text-slate-300">
                            <span className="font-bold text-slate-900 dark:text-white block">{formatDate(s.shift_date)}</span>
                            <span className="text-[11px] text-slate-500 font-mono">{s.fd_number || '-'}</span>
                          </td>
                          <td className="p-3.5 font-semibold text-slate-900 dark:text-white">
                            {s.driver_name}
                            <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-normal">{s.driver_code}</span>
                          </td>
                          <td className="p-3.5 text-slate-700 dark:text-slate-300">
                            <span className="font-bold text-blue-600 dark:text-blue-400 block">{s.route_code || 'General'}</span>
                            <span className="text-[11px] text-slate-600 dark:text-slate-400">{s.depot_name || 'Regional Hub'}</span>
                          </td>
                          <td className="p-3.5 text-right font-mono font-bold text-slate-700 dark:text-slate-300">
                            {s.paid_stops} <span className="text-slate-500 font-normal">/ {s.dispatched_stops}</span>
                          </td>
                          <td className="p-3.5 text-center">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              failNum > 10 ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-500/30' :
                              failNum < 0 ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30' :
                              'bg-slate-800 text-slate-600 dark:text-slate-400'
                            }`}>
                              {failNum}%
                            </span>
                          </td>
                          <td className="p-3.5 text-right font-mono text-indigo-600 dark:text-indigo-400 font-medium">
                            {parseFloat(s.calculated_parcel_pay) > 0 ? formatCurrency(s.calculated_parcel_pay) : '-'}
                          </td>
                          <td className="p-3.5 text-right font-mono font-bold">
                            {parseFloat(s.top_up_pay) > 0 ? (
                              <span className="text-amber-600 dark:text-amber-400">+{formatCurrency(s.top_up_pay)}</span>
                            ) : s.top_up_cancelled ? (
                              <span className="text-slate-500 text-[10px]">Cancelled</span>
                            ) : '-'}
                          </td>
                          <td className="p-3.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                            {formatCurrency(s.gross_shift_total)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- DAY DETAIL MODAL --- */}
      <Modal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        title={`Route Dispatches for ${formatDate(activeDateStr)}`}
        maxWidth="max-w-2xl"
      >
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
            <span className="text-xs text-slate-600 dark:text-slate-400">Total Routes: <strong className="text-slate-900 dark:text-white">{selectedDateShifts.length}</strong></span>
            <span className="text-xs text-slate-600 dark:text-slate-400">Total Paid Stops: <strong className="text-slate-900 dark:text-white">{selectedDateShifts.reduce((a, s) => a + (s.paid_stops || 0), 0)}</strong></span>
            <button
              onClick={() => { setIsDetailModalOpen(false); handleOpenAddModal(activeDateStr); }}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg cursor-pointer"
            >
              + Add Route to Date
            </button>
          </div>

          <div className="divide-y divide-slate-200 dark:divide-slate-800/80 max-h-80 overflow-y-auto">
            {selectedDateShifts.map((s) => (
              <div key={s.id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">{s.driver_name}</span>
                  <span className="text-[11px] text-slate-600 dark:text-slate-400">{s.route_code} • {s.paid_stops} stops • {s.total_parcels} parcels</span>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 block">{formatCurrency(s.gross_shift_total)}</span>
                  <span className="text-[10px] text-slate-500">{s.top_up_pay > 0 ? `+${formatCurrency(s.top_up_pay)} top-up` : 'Standard'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Modal>

      {/* --- ADD SHIFT MODAL --- */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Record Daily Courier Route"
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleSaveShift} className="space-y-4">
          {modalError && (
            <div className="p-3 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/30 text-rose-700 dark:text-rose-600 dark:text-rose-400 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{modalError}</span>
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Route Date</label>
              <input
                type="date"
                value={formData.shiftDate}
                onChange={(e) => setFormData({ ...formData, shiftDate: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Driver *</label>
              <select
                value={formData.driverId || ''}
                onChange={(e) => {
                  const drvId = e.target.value;
                  const drv = drivers.find(d => d.id === drvId);
                  setFormData(prev => ({
                    ...prev,
                    driverId: drvId,
                    depotId: drv?.default_depot_id || prev.depotId,
                    routeCode: drv?.driver_code || prev.routeCode,
                    fdNumber: drv?.assigned_fd_number || prev.fdNumber
                  }));
                }}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="">-- Choose Courier Driver --</option>
                {drivers.map((d) => (
                  <option key={d.id} value={d.id}>{d.full_name} ({d.driver_code || 'DR'})</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Depot</label>
              <select
                value={formData.depotId || ''}
                onChange={(e) => setFormData({ ...formData, depotId: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
              >
                <option value="">Select Depot...</option>
                {depots.map((d) => (
                  <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Route Code</label>
              <input
                type="text"
                value={formData.routeCode || ''}
                onChange={(e) => setFormData({ ...formData, routeCode: e.target.value })}
                placeholder="e.g. LEI-101"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Dispatched Stops</label>
              <input
                type="number"
                value={formData.dispatchedStops}
                onChange={(e) => setFormData({ ...formData, dispatchedStops: parseInt(e.target.value || 0, 10) })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Paid Stops</label>
              <input
                type="number"
                value={formData.paidStops}
                onChange={(e) => setFormData({ ...formData, paidStops: parseInt(e.target.value || 0, 10) })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Total Parcels</label>
              <input
                type="number"
                value={formData.totalParcels}
                onChange={(e) => setFormData({ ...formData, totalParcels: parseInt(e.target.value || 0, 10) })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white font-mono"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 cursor-pointer disabled:opacity-50"
            >
              {saving ? 'Saving Route...' : 'Save Daily Route'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}