const express = require('express');
const router = express.Router();
const { getDb } = require('../config/db');

// Query audit logs (Admin Only)
router.get('/', async (req, res) => {
  try {
    const { actionType, tableAffected, recordId, startDate, endDate, limit } = req.query;
    const db = getDb();
    let query = `
      SELECT a.*
      FROM audit_logs a
      WHERE 1=1
    `;
    const params = [];

    if (actionType) {
      params.push(actionType);
      query += ` AND a.action_type = $${params.length}`;
    }
    if (tableAffected) {
      params.push(tableAffected);
      query += ` AND a.table_affected = $${params.length}`;
    }
    if (recordId) {
      params.push(recordId);
      query += ` AND a.record_id = $${params.length}`;
    }
    if (startDate) {
      params.push(startDate);
      query += ` AND a.created_at >= $${params.length}`;
    }
    if (endDate) {
      params.push(endDate);
      query += ` AND a.created_at <= $${params.length}`;
    }

    const rowLimit = parseInt(limit || 100, 10);
    params.push(rowLimit);
    query += ` ORDER BY a.created_at DESC LIMIT $${params.length}`;

    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;