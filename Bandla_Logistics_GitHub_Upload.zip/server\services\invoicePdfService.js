const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const env = require('../config/env');
const { getDb } = require('../config/db');

function formatPdfDate(val) {
  if (!val) return new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const d = new Date(val);
  if (isNaN(d.getTime())) return String(val).substring(0, 10);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

async function generateInvoicePdf(invoiceId) {
  const db = getDb();
  const client = db.session.client;

  // 1. Fetch invoice, driver, shifts, and charges
  const invRes = await client.query(`
    SELECT i.*, d.full_name, d.phone, d.email, d.assigned_vehicle_reg, d.is_vat_registered, d.vat_number, d.driver_code
    FROM payroll_invoices i
    JOIN drivers d ON i.driver_id = d.id
    WHERE i.id = $1
  `, [invoiceId]);

  if (!invRes.rows || invRes.rows.length === 0) {
    throw new Error('Invoice not found');
  }

  const invoice = invRes.rows[0];

  const shiftsRes = await client.query(`
    SELECT s.*, dep.name as depot_name
    FROM daily_shifts s
    LEFT JOIN depots dep ON s.depot_id = dep.id
    WHERE s.invoice_id = $1
    ORDER BY s.shift_date ASC
  `, [invoiceId]);
  const shifts = shiftsRes.rows || [];

  const chargesRes = await client.query(`
    SELECT * FROM charges_and_deductions
    WHERE invoice_id = $1
    ORDER BY charge_date ASC
  `, [invoiceId]);
  const charges = chargesRes.rows || [];

  // Ensure invoices directory exists
  const invoiceDir = path.join(env.DATA_DIR, 'invoices');
  if (!fs.existsSync(invoiceDir)) {
    fs.mkdirSync(invoiceDir, { recursive: true });
  }

  const pdfFileName = `${invoice.invoice_number}_${invoice.full_name.replace(/\s+/g, '_')}.pdf`;
  const pdfPath = path.join(invoiceDir, pdfFileName);

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 35, size: 'A4' });
    const writeStream = fs.createWriteStream(pdfPath);
    doc.pipe(writeStream);

    // --- Colors & Styling ---
    const primaryColor = '#1E3A8A'; // Deep Navy
    const accentColor = '#0284C7';  // Light Blue
    const darkGray = '#1F2937';
    const lightGray = '#F3F4F6';
    const tableBorder = '#E5E7EB';

    // --- Header with Official Legal Company Branding & Logo ---
    doc.rect(35, 35, 525, 75).fill(lightGray);

    const logoPath = path.join(__dirname, '../assets/logo.jpg');
    let textStartX = 45;

    if (fs.existsSync(logoPath)) {
      try {
        doc.image(logoPath, 45, 42, { fit: [58, 58] });
        textStartX = 112;
      } catch (e) {
        textStartX = 45;
      }
    }

    // Company Information (Left Side)
    doc.fillColor(primaryColor).fontSize(12).font('Helvetica-Bold').text('Bandla Logistics Limited', textStartX, 42);
    doc.fontSize(7.5).font('Helvetica').fillColor(darkGray)
      .text('128 City Road', textStartX, 55)
      .text('London, EC1V 2NX', textStartX, 65)
      .text('T: 07966 270270  |  E: Admin@Bandlalogistics.co.uk', textStartX, 75)
      .text('Company No. 13307245 | VAT No. GB376546166', textStartX, 85);

    // Contractor's Invoice Header & Meta (Right Side - cleanly formatted with ample spacing)
    doc.fillColor(primaryColor).fontSize(12).font('Helvetica-Bold')
      .text("CONTRACTOR'S INVOICE", 340, 42, { width: 210, align: 'right' });

    doc.fontSize(7.5).font('Helvetica').fillColor(darkGray);
    doc.text(`Invoice No: ${invoice.invoice_number}`, 340, 56, { width: 210, align: 'right' });
    doc.text(`Date: ${formatPdfDate(invoice.invoice_date || invoice.created_at)}`, 340, 67, { width: 210, align: 'right' });
    doc.text(`Period: ${invoice.billing_month || 'N/A'}`, 340, 78, { width: 210, align: 'right' });
    doc.text(`State: ${invoice.status || invoice.payment_status || 'Draft'}`, 340, 89, { width: 210, align: 'right' });

    // --- Contractor & Billing Info Grid ---
    const gridY = 120;
    doc.rect(35, gridY, 255, 60).strokeColor(tableBorder).stroke();
    doc.rect(300, gridY, 260, 60).strokeColor(tableBorder).stroke();

    doc.fillColor(primaryColor).fontSize(9).font('Helvetica-Bold').text('CONTRACTOR DETAILS', 45, gridY + 8);
    doc.fontSize(8).font('Helvetica').fillColor(darkGray)
      .text(`Driver Name: ${invoice.full_name}`, 45, gridY + 22)
      .text(`Driver Code: ${invoice.driver_code || 'N/A'}`, 45, gridY + 34)
      .text(`Assigned Reg: ${invoice.assigned_vehicle_reg || 'N/A'}`, 45, gridY + 46);

    doc.fillColor(primaryColor).fontSize(9).font('Helvetica-Bold').text('TAX & BILLING SUMMARY', 310, gridY + 8);
    doc.fontSize(8).font('Helvetica').fillColor(darkGray)
      .text(`VAT Registered: ${invoice.is_vat_registered ? 'YES (20%)' : 'NO (0%)'}`, 310, gridY + 22)
      .text(`VAT Number: ${invoice.vat_number || 'N/A'}`, 310, gridY + 34)
      .text(`Payment Status: ${invoice.payment_status || 'Draft'}`, 310, gridY + 46);

    // --- Shift Performance Table ---
    let y = 192;
    doc.fillColor(primaryColor).fontSize(10).font('Helvetica-Bold').text('DAILY DISPATCH LOGS', 35, y);
    y += 14;

    // Table Header
    doc.rect(35, y, 525, 18).fill(primaryColor);
    doc.fillColor('#FFFFFF').fontSize(7.5).font('Helvetica-Bold');
    doc.text('Date', 40, y + 5);
    doc.text('FD No.', 90, y + 5);
    doc.text('Route', 135, y + 5);
    doc.text('Stops (Act/Disp)', 175, y + 5);
    doc.text('Parcels (Tot/Exc)', 240, y + 5);
    doc.text('Stop Pay', 315, y + 5, { width: 50, align: 'right' });
    doc.text('Bonus (Â£0.05)', 368, y + 5, { width: 48, align: 'right' });
    doc.text('Top-Up', 420, y + 5, { width: 45, align: 'right' });
    doc.text('Day Total', 475, y + 5, { width: 75, align: 'right' });
    y += 18;

    // Table Rows
    doc.font('Helvetica').fontSize(7.5);
    shifts.forEach((s, idx) => {
      if (y > 700) {
        doc.addPage();
        y = 40;
      }
      const bg = idx % 2 === 0 ? '#FFFFFF' : '#F9FAFB';
      doc.rect(35, y, 525, 14).fill(bg);
      doc.fillColor(darkGray);

      doc.text(s.shift_date ? String(s.shift_date).substring(0, 10) : '', 40, y + 3);
      doc.text(s.fd_number || '-', 90, y + 3);
      doc.text(s.route_code || '-', 135, y + 3);
      doc.text(`${s.paid_stops} / ${s.dispatched_stops}`, 175, y + 3);
      doc.text(`${s.total_parcels} / ${s.excess_parcels}`, 240, y + 3);
      doc.text(`Â£${parseFloat(s.calculated_stop_pay || 0).toFixed(2)}`, 315, y + 3, { width: 50, align: 'right' });
      doc.text(`Â£${parseFloat(s.calculated_parcel_pay || 0).toFixed(2)}`, 368, y + 3, { width: 48, align: 'right' });
      doc.text(parseFloat(s.top_up_pay || 0) > 0 ? `Â£${parseFloat(s.top_up_pay).toFixed(2)}` : '-', 420, y + 3, { width: 45, align: 'right' });
      doc.text(`Â£${parseFloat(s.gross_shift_total || 0).toFixed(2)}`, 475, y + 3, { width: 75, align: 'right' });
      y += 14;
    });

    // Check space for summary section
    if (y > 600) {
      doc.addPage();
      y = 40;
    }

    y += 15;
    const summaryStartY = y;

    // Deductions Table (Left Side)
    doc.fillColor(primaryColor).fontSize(9).font('Helvetica-Bold').text('CHARGES & DEDUCTIONS', 35, y);
    y += 14;
    doc.rect(35, y, 260, 16).fill(lightGray);
    doc.fillColor(darkGray).fontSize(7.5).font('Helvetica-Bold')
      .text('Date', 40, y + 4)
      .text('Category', 90, y + 4)
      .text('Amount (Â£)', 220, y + 4, { align: 'right', width: 65 });
    y += 16;

    if (charges.length === 0) {
      doc.font('Helvetica').fontSize(7.5).fillColor('#6B7280')
        .text('No deductions applied for this billing period.', 40, y + 4);
      y += 16;
    } else {
      charges.forEach(c => {
        const amt = parseFloat(c.amount || 0);
        const isCredit = amt < 0;
        doc.font('Helvetica').fontSize(7.5).fillColor(darkGray)
          .text(String(c.charge_date).substring(0, 10), 40, y + 3)
          .text(c.cd_type || c.charge_type, 90, y + 3)
          .text(isCredit ? `+ Â£${Math.abs(amt).toFixed(2)}` : `- Â£${amt.toFixed(2)}`, 220, y + 3, { align: 'right', width: 65 });
        y += 14;
      });
    }

    // Totals Box (Right Side)
    const boxX = 310;
    let boxY = summaryStartY + 14;
    doc.rect(boxX, boxY, 250, 120).strokeColor(primaryColor).lineWidth(1).stroke();
    doc.rect(boxX, boxY, 250, 20).fill(primaryColor);
    doc.fillColor('#FFFFFF').fontSize(8.5).font('Helvetica-Bold').text('INVOICE TOTALS BREAKDOWN', boxX + 10, boxY + 6);
    boxY += 26;

    const printTotalRow = (label, val, isBold = false, isHighlight = false) => {
      if (isHighlight) {
        doc.rect(boxX + 2, boxY - 2, 246, 18).fill('#E0F2FE');
      }
      doc.font(isBold ? 'Helvetica-Bold' : 'Helvetica').fontSize(8).fillColor(darkGray)
        .text(label, boxX + 10, boxY)
        .text(val, boxX + 10, boxY, { align: 'right', width: 230 });
      boxY += 15;
    };

    printTotalRow('Gross Dispatches & Bonuses:', `Â£${parseFloat(invoice.gross_earnings || 0).toFixed(2)}`);
    printTotalRow('Total Deductions / Offsets:', `- Â£${parseFloat(invoice.total_deductions || 0).toFixed(2)}`);
    printTotalRow('Net Subtotal (Pre-VAT):', `Â£${parseFloat(invoice.subtotal || 0).toFixed(2)}`, true);
    printTotalRow(`VAT Applied (${(parseFloat(invoice.vat_rate || 0) * 100).toFixed(0)}%):`, `Â£${parseFloat(invoice.vat_applied || 0).toFixed(2)}`);
    printTotalRow('TOTAL NET PAYABLE:', `Â£${parseFloat(invoice.net_payable || 0).toFixed(2)}`, true, true);

    // --- Footer Notice ---
    doc.fontSize(7.5).font('Helvetica-Oblique').fillColor('#6B7280')
      .text('All queries regarding this invoice must be submitted to Admin@Bandlalogistics.co.uk within 7 days of receipt.', 35, 780, { align: 'center', width: 525 });

    doc.end();

    writeStream.on('finish', async () => {
      await client.query(`UPDATE payroll_invoices SET pdf_path = $1 WHERE id = $2`, [pdfFileName, invoiceId]);
      resolve({ pdfPath, pdfFileName });
    });

    writeStream.on('error', (err) => {
      reject(err);
    });
  });
}

module.exports = { generateInvoicePdf };