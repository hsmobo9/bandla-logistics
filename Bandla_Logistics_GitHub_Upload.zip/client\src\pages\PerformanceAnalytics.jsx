import React, { useState, useEffect, useMemo } from 'react';
import { 
  BarChart, Bar, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine
} from 'recharts';
import { 
  TrendingUp, Gauge, Fuel, Wrench, Users, Truck, Filter, 
  Download, Search, SlidersHorizontal, ArrowUpRight, ArrowDownRight,
  DollarSign, CheckCircle2, AlertTriangle, Layers, Zap, Calendar, Building2
} from 'lucide-react';
import { getPerformanceAnalytics } from '../services/api';
import ColumnVisibilityToggle from '../components/ColumnVisibilityToggle';
import { formatCurrency, formatNumber, formatDate } from '../utils/formatters';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4', '#f97316', '#64748b'];

const VEHICLE_PERF_COLUMNS = [
  { key: 'vehicle', label: 'Vehicle Reg & Model' },
  { key: 'category', label: 'Van Category' },
  { key: 'depot', label: 'Depot Location' },
  { key: 'distance', label: 'Total Distance' },
  { key: 'fuel_spend', label: 'Fuel Spend (£ & L)' },
  { key: 'maint_spend', label: 'Maintenance Spend (£)' },
  { key: 'total_cost', label: 'Total Running Cost (£)' },
  { key: 'cost_per_unit', label: 'Cost / Distance (£/km or £/mi)' },
  { key: 'fuel_economy', label: 'Fuel Economy (MPL / L-100km)' },
  { key: 'status', label: 'Status' }
];

const DRIVER_PERF_COLUMNS = [
  { key: 'driver', label: 'Driver Name & DR Code' },
  { key: 'depot', label: 'Depot' },
  { key: 'vehicle', label: 'Assigned Vehicle' },
  { key: 'shifts', label: 'Total Shifts' },
  { key: 'stops', label: 'Total Paid Stops' },
  { key: 'spr', label: 'Stops Per Route (SPR)' },
  { key: 'completion', label: 'Route Completion %' },
  { key: 'earnings', label: 'Gross Pay (£)' },
  { key: 'pay_per_stop', label: 'Avg Pay / Stop (£)' },
  { key: 'status', label: 'Status' }
];

export default function PerformanceAnalytics() {
  const [data, setData] = useState({ vehicles: [], drivers: [], monthlyFuel: [], monthlyMaint: [], monthlyShifts: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Slicers State (Excel-style interactive filters)
  const [activeSlicerView, setActiveSlicerView] = useState('vehicles'); // 'vehicles' | 'drivers' | 'trends'
  const [unitSlicer, setUnitSlicer] = useState('km'); // 'km' | 'mi'
  const [selectedDepot, setSelectedDepot] = useState('ALL');
  const [selectedModel, setSelectedModel] = useState('ALL');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [timePeriod, setTimePeriod] = useState('ALL'); // 'ALL' | '30d' | '90d' | '2026'
  const [searchQuery, setSearchQuery] = useState('');

  // Column Visibility States
  const [vehicleVisibleCols, setVehicleVisibleCols] = useState(() => {
    try {
      const s = localStorage.getItem('perf_vehicle_cols');
      return s ? JSON.parse(s) : {};
    } catch (e) { return {}; }
  });

  const [driverVisibleCols, setDriverVisibleCols] = useState(() => {
    try {
      const s = localStorage.getItem('perf_driver_cols');
      return s ? JSON.parse(s) : {};
    } catch (e) { return {}; }
  });

  useEffect(() => {
    loadPerformanceData();
  }, []);

  const loadPerformanceData = async () => {
    try {
      setLoading(true);
      setError('');
      const res = await getPerformanceAnalytics();
      setData(res);
    } catch (err) {
      setError(err.response?.data?.error || err.message || 'Failed to load performance analytics');
    } finally {
      setLoading(false);
    }
  };

  // Chart Customizer Controls
  const [vehicleMetric, setVehicleMetric] = useState('costPerUnit'); // 'costPerUnit' | 'totalCost' | 'fuelCost' | 'maintCost'
  const [trendHorizon, setTrendHorizon] = useState('active'); // 'active' | 'last12' | 'all'
  const [trendChartType, setTrendChartType] = useState('bar'); // 'bar' | 'area'
  const [driverChartMode, setDriverChartMode] = useState('spr_zoomed'); // 'spr_zoomed' | 'variance' | 'totalStops'
  const [earningsChartMode, setEarningsChartMode] = useState('precision'); // 'precision' | 'variance' | 'stops' | 'rate'
  const [depotChartMode, setDepotChartMode] = useState('precision'); // 'precision' | 'variance' | 'stops'
  const [pieDimension, setPieDimension] = useState('vehicle'); // 'vehicle' | 'depot' | 'model' | 'component'

  // Extract unique depots, models, and categories for slicers
  const availableDepots = useMemo(() => {
    const set = new Set();
    data.vehicles.forEach(v => { if (v.depot_location) set.add(v.depot_location); });
    data.drivers.forEach(d => { if (d.depot_name) set.add(d.depot_name); });
    return Array.from(set).sort();
  }, [data]);

  const availableModels = useMemo(() => {
    const set = new Set();
    data.vehicles.forEach(v => { if (v.model_number) set.add(v.model_number); });
    return Array.from(set).sort();
  }, [data]);

  const availableCategories = useMemo(() => {
    const set = new Set();
    data.vehicles.forEach(v => { if (v.category) set.add(v.category); });
    return Array.from(set).sort();
  }, [data]);

  // Processed and Sliced Vehicles
  const processedVehicles = useMemo(() => {
    return data.vehicles.map(v => {
      const mileage = parseFloat(v.current_mileage || 0);
      const km = mileage * 1.60934;
      const fuelCost = parseFloat(v.total_fuel_cost || 0);
      const fuelLiters = parseFloat(v.total_fuel_liters || 0);
      const maintCost = parseFloat(v.total_maint_cost || 0);
      const totalCost = fuelCost + maintCost;

      const costPerMile = mileage > 0 ? (totalCost / mileage) : 0;
      const costPerKm = km > 0 ? (totalCost / km) : 0;
      const fuelCostPerMile = mileage > 0 ? (fuelCost / mileage) : 0;
      const fuelCostPerKm = km > 0 ? (fuelCost / km) : 0;
      const maintCostPerMile = mileage > 0 ? (maintCost / mileage) : 0;
      const maintCostPerKm = km > 0 ? (maintCost / km) : 0;

      const milesPerLiter = fuelLiters > 0 ? (mileage / fuelLiters) : 0;
      const litersPer100Km = km > 0 && fuelLiters > 0 ? ((fuelLiters / km) * 100) : 0;

      return {
        ...v,
        mileage,
        km,
        fuelCost,
        fuelLiters,
        maintCost,
        totalCost,
        costPerMile,
        costPerKm,
        fuelCostPerMile,
        fuelCostPerKm,
        maintCostPerMile,
        maintCostPerKm,
        milesPerLiter,
        litersPer100Km
      };
    });
  }, [data.vehicles]);

  // Filtered Vehicles by Slicers
  const filteredVehicles = useMemo(() => {
    return processedVehicles.filter(v => {
      if (selectedDepot !== 'ALL' && v.depot_location !== selectedDepot) return false;
      if (selectedModel !== 'ALL' && v.model_number !== selectedModel) return false;
      if (selectedCategory !== 'ALL' && v.category !== selectedCategory) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchReg = (v.registration_number || '').toLowerCase().includes(q);
        const matchModel = (v.model_number || '').toLowerCase().includes(q);
        const matchDepot = (v.depot_location || '').toLowerCase().includes(q);
        if (!matchReg && !matchModel && !matchDepot) return false;
      }
      return true;
    });
  }, [processedVehicles, selectedDepot, selectedModel, selectedCategory, searchQuery]);

  // Processed and Sliced Drivers
  const processedDrivers = useMemo(() => {
    return data.drivers.map(d => {
      const shifts = parseInt(d.total_shifts || 0, 10);
      const dispatched = parseInt(d.total_dispatched_stops || 0, 10);
      const paidStops = parseInt(d.total_paid_stops || 0, 10);
      const grossPay = parseFloat(d.total_gross_pay || 0);
      const driverFuel = parseFloat(d.total_driver_fuel_cost || 0);

      const spr = shifts > 0 ? (paidStops / shifts) : 0;
      const completionRate = dispatched > 0 ? ((paidStops / dispatched) * 100) : 100;
      const payPerStop = paidStops > 0 ? (grossPay / paidStops) : 0;
      const fuelPerStop = paidStops > 0 ? (driverFuel / paidStops) : 0;

      return {
        ...d,
        shifts,
        dispatched,
        paidStops,
        grossPay,
        driverFuel,
        spr,
        completionRate,
        payPerStop,
        fuelPerStop
      };
    });
  }, [data.drivers]);

  // Filtered Drivers by Slicers
  const filteredDrivers = useMemo(() => {
    return processedDrivers.filter(d => {
      if (selectedDepot !== 'ALL' && d.depot_name !== selectedDepot) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchName = (d.full_name || '').toLowerCase().includes(q);
        const matchCode = (d.driver_code || '').toLowerCase().includes(q);
        const matchDepot = (d.depot_name || '').toLowerCase().includes(q);
        if (!matchName && !matchCode && !matchDepot) return false;
      }
      return true;
    });
  }, [processedDrivers, selectedDepot, searchQuery]);

  // Fleet Aggregations
  const fleetSummary = useMemo(() => {
    const totalVans = filteredVehicles.length;
    const totalMileage = filteredVehicles.reduce((acc, v) => acc + v.mileage, 0);
    const totalKm = filteredVehicles.reduce((acc, v) => acc + v.km, 0);
    const totalFuelSpend = filteredVehicles.reduce((acc, v) => acc + v.fuelCost, 0);
    const totalMaintSpend = filteredVehicles.reduce((acc, v) => acc + v.maintCost, 0);
    const totalFleetCost = totalFuelSpend + totalMaintSpend;

    const avgCostPerMile = totalMileage > 0 ? (totalFleetCost / totalMileage) : 0;
    const avgCostPerKm = totalKm > 0 ? (totalFleetCost / totalKm) : 0;

    const totalStops = filteredDrivers.reduce((acc, d) => acc + d.paidStops, 0);
    const totalShifts = filteredDrivers.reduce((acc, d) => acc + d.shifts, 0);
    const fleetSpr = totalShifts > 0 ? (totalStops / totalShifts) : 0;

    return {
      totalVans,
      totalMileage,
      totalKm,
      totalFuelSpend,
      totalMaintSpend,
      totalFleetCost,
      avgCostPerMile,
      avgCostPerKm,
      totalStops,
      totalShifts,
      fleetSpr
    };
  }, [filteredVehicles, filteredDrivers]);

  // Chart Data 1: Top 15 Vehicles by Selected Metric
  const vehicleCostChartData = useMemo(() => {
    const sorted = [...filteredVehicles].filter(v => v.totalCost > 0);
    if (vehicleMetric === 'costPerUnit') {
      sorted.sort((a, b) => (unitSlicer === 'km' ? b.costPerKm - a.costPerKm : b.costPerMile - a.costPerMile));
    } else if (vehicleMetric === 'totalCost') {
      sorted.sort((a, b) => b.totalCost - a.totalCost);
    } else if (vehicleMetric === 'fuelCost') {
      sorted.sort((a, b) => b.fuelCost - a.fuelCost);
    } else if (vehicleMetric === 'maintCost') {
      sorted.sort((a, b) => b.maintCost - a.maintCost);
    }

    return sorted.slice(0, 15).map(v => {
      const val = vehicleMetric === 'costPerUnit' 
        ? parseFloat((unitSlicer === 'km' ? v.costPerKm : v.costPerMile).toFixed(3))
        : vehicleMetric === 'fuelCost' ? v.fuelCost
        : vehicleMetric === 'maintCost' ? v.maintCost
        : v.totalCost;

      return {
        name: v.registration_number || v.equipment_code,
        displayValue: val,
        costPerUnit: parseFloat((unitSlicer === 'km' ? v.costPerKm : v.costPerMile).toFixed(3)),
        fuelCost: v.fuelCost,
        maintCost: v.maintCost,
        totalCost: v.totalCost,
        distance: unitSlicer === 'km' ? Math.round(v.km) : Math.round(v.mileage),
        category: v.category
      };
    });
  }, [filteredVehicles, vehicleMetric, unitSlicer]);

  // Precision Zoomed Domain for Vehicle Cost per Unit
  const vehicleCostDomain = useMemo(() => {
    if (vehicleCostChartData.length === 0) return [0, 0.1];
    if (vehicleMetric !== 'costPerUnit') return ['auto', 'auto'];
    const costs = vehicleCostChartData.map(v => v.costPerUnit);
    const min = Math.min(...costs);
    const max = Math.max(...costs);
    const pad = Math.max(0.003, (max - min) * 0.25);
    return [Math.max(0, parseFloat((min - pad).toFixed(3))), parseFloat((max + pad).toFixed(3))];
  }, [vehicleCostChartData, vehicleMetric]);

  // Chart Data 2: Monthly Fuel vs Maintenance Spend Trends (with Active Horizon filter)
  const monthlyTrendData = useMemo(() => {
    const monthMap = {};
    data.monthlyFuel.forEach(f => {
      if (!monthMap[f.month]) monthMap[f.month] = { month: f.month, fuelCost: 0, maintCost: 0, totalCost: 0 };
      monthMap[f.month].fuelCost += parseFloat(f.fuel_cost || 0);
    });
    data.monthlyMaint.forEach(m => {
      if (!monthMap[m.month]) monthMap[m.month] = { month: m.month, fuelCost: 0, maintCost: 0, totalCost: 0 };
      monthMap[m.month].maintCost += parseFloat(m.total_cost || 0);
    });
    let list = Object.values(monthMap).sort((a, b) => a.month.localeCompare(b.month));

    if (trendHorizon === 'active') {
      // Focus on active operational months where fuel or maintenance was actively booked
      list = list.filter(m => m.fuelCost > 0 || m.maintCost > 200);
    } else if (trendHorizon === 'last12') {
      list = list.slice(-12);
    }

    return list.map(item => ({
      ...item,
      totalCost: item.fuelCost + item.maintCost
    }));
  }, [data.monthlyFuel, data.monthlyMaint, trendHorizon]);

  // Chart Data 3: Top Drivers by Stops Per Route (SPR) with Zoomed / Variance support
  const driverSprChartData = useMemo(() => {
    const sorted = [...filteredDrivers].filter(d => d.shifts > 0);
    if (driverChartMode === 'totalStops') {
      sorted.sort((a, b) => b.paidStops - a.paidStops);
    } else {
      sorted.sort((a, b) => b.spr - a.spr);
    }

    return sorted.slice(0, 15).map(d => {
      const shortName = d.full_name.split(' ')[0] + ' ' + (d.full_name.split(' ')[1]?.[0] || '') + '.';
      const variance = parseFloat((d.spr - fleetSummary.fleetSpr).toFixed(1));
      return {
        fullName: d.full_name,
        code: d.driver_code || 'DR',
        displayName: `${shortName} (${d.driver_code || 'DR'})`,
        spr: parseFloat(d.spr.toFixed(1)),
        variance: variance,
        completion: parseFloat(d.completionRate.toFixed(1)),
        stops: d.paidStops,
        shifts: d.shifts
      };
    });
  }, [filteredDrivers, driverChartMode, fleetSummary.fleetSpr]);

  // Compute Zoomed Domain for Driver SPR
  const driverSprDomain = useMemo(() => {
    if (driverSprChartData.length === 0) return [100, 140];
    const sprs = driverSprChartData.map(d => d.spr);
    const min = Math.min(...sprs);
    const max = Math.max(...sprs);
    return [Math.max(0, Math.floor(min - 4)), Math.ceil(max + 2)];
  }, [driverSprChartData]);

  // Chart Data 4: Distribution Breakdown (By Vehicle, Depot, Model, or Component)
  const distributionChartData = useMemo(() => {
    if (pieDimension === 'vehicle') {
      const sorted = [...filteredVehicles].filter(v => v.totalCost > 0).sort((a, b) => b.totalCost - a.totalCost);
      const topVans = sorted.slice(0, 6);
      const otherVans = sorted.slice(6);
      const list = topVans.map(v => ({
        name: v.registration_number || v.equipment_code,
        label: `${v.registration_number || v.equipment_code} (${v.model_number?.split(' ')[0] || 'Van'})`,
        totalCost: v.totalCost,
        count: 1
      }));
      if (otherVans.length > 0) {
        const otherTotal = otherVans.reduce((acc, v) => acc + v.totalCost, 0);
        list.push({
          name: `Other Vans (${otherVans.length})`,
          label: `Other ${otherVans.length} Vans Combined`,
          totalCost: otherTotal,
          count: otherVans.length
        });
      }
      return list;
    }

    if (pieDimension === 'depot') {
      const depotMap = {};
      filteredVehicles.forEach(v => {
        const d = v.depot_location || 'Central / Unassigned';
        if (!depotMap[d]) depotMap[d] = { name: d, count: 0, totalCost: 0 };
        depotMap[d].count += 1;
        depotMap[d].totalCost += v.totalCost;
      });
      return Object.values(depotMap).filter(d => d.totalCost > 0);
    }

    if (pieDimension === 'model') {
      const modelMap = {};
      filteredVehicles.forEach(v => {
        const m = v.model_number || 'Standard Fleet Van';
        if (!modelMap[m]) modelMap[m] = { name: m, count: 0, totalCost: 0 };
        modelMap[m].count += 1;
        modelMap[m].totalCost += v.totalCost;
      });
      return Object.values(modelMap).filter(m => m.totalCost > 0);
    }

    if (pieDimension === 'component') {
      const fuelTotal = filteredVehicles.reduce((acc, v) => acc + v.fuelCost, 0);
      const laborTotal = filteredVehicles.reduce((acc, v) => acc + parseFloat(v.total_labor_cost || 0), 0);
      const partsTotal = filteredVehicles.reduce((acc, v) => acc + parseFloat(v.total_parts_cost || 0), 0);
      return [
        { name: 'Fuel Card Spend', totalCost: fuelTotal, count: filteredVehicles.length },
        { name: 'Garage Labour Invoices', totalCost: laborTotal > 0 ? laborTotal : fleetSummary.totalMaintSpend * 0.7, count: filteredVehicles.length },
        { name: 'Workshop Parts', totalCost: partsTotal > 0 ? partsTotal : fleetSummary.totalMaintSpend * 0.3, count: filteredVehicles.length }
      ].filter(c => c.totalCost > 0);
    }

    // Category breakdown
    const catMap = {};
    filteredVehicles.forEach(v => {
      const cat = v.category || 'Standard Van';
      if (!catMap[cat]) catMap[cat] = { name: cat, count: 0, totalCost: 0 };
      catMap[cat].count += 1;
      catMap[cat].totalCost += v.totalCost;
    });
    return Object.values(catMap);
  }, [filteredVehicles, pieDimension, fleetSummary]);

  // Average Driver Gross Earnings Benchmark
  const driverAvgEarnings = useMemo(() => {
    if (filteredDrivers.length === 0) return 0;
    const valid = filteredDrivers.filter(d => d.paidStops > 0);
    if (valid.length === 0) return 0;
    const total = valid.reduce((acc, d) => acc + d.grossPay, 0);
    return parseFloat((total / valid.length).toFixed(2));
  }, [filteredDrivers]);

  // Depot Driver SPR and Delivery Benchmark Data
  const depotDriverStats = useMemo(() => {
    const map = {};
    filteredDrivers.forEach(d => {
      const dep = d.depot_name || 'Central Hub';
      if (!map[dep]) map[dep] = { name: dep, stops: 0, shifts: 0, drivers: 0, grossPay: 0 };
      map[dep].stops += d.paidStops;
      map[dep].shifts += d.shifts;
      map[dep].drivers += 1;
      map[dep].grossPay += d.grossPay;
    });
    const list = Object.values(map).map(dp => {
      const spr = dp.shifts > 0 ? parseFloat((dp.stops / dp.shifts).toFixed(1)) : 0;
      const variance = parseFloat((spr - fleetSummary.fleetSpr).toFixed(1));
      return {
        ...dp,
        spr,
        variance,
        avgEarnings: dp.shifts > 0 ? parseFloat((dp.grossPay / dp.shifts).toFixed(2)) : 0
      };
    });
    if (depotChartMode === 'stops') {
      list.sort((a, b) => b.stops - a.stops);
    } else {
      list.sort((a, b) => b.spr - a.spr);
    }
    return list;
  }, [filteredDrivers, fleetSummary.fleetSpr, depotChartMode]);

  // Zoomed domain for Depot Driver SPR
  const depotSprDomain = useMemo(() => {
    if (depotDriverStats.length === 0) return [125, 136];
    if (depotChartMode === 'variance') {
      const vars = depotDriverStats.map(d => d.variance);
      const maxAbs = Math.max(...vars.map(Math.abs), 1);
      return [-Math.ceil((maxAbs + 0.5) * 2) / 2, Math.ceil((maxAbs + 0.5) * 2) / 2];
    }
    if (depotChartMode === 'stops') return ['auto', 'auto'];
    const sprs = depotDriverStats.map(d => d.spr);
    const min = Math.min(...sprs);
    const max = Math.max(...sprs);
    return [Math.max(0, Math.floor(min - 0.8)), Math.ceil(max + 0.8)];
  }, [depotDriverStats, depotChartMode]);

  // Driver Earnings vs Output Data (with Zoomed Precision & Variance)
  const driverEarningsChartData = useMemo(() => {
    const list = [...filteredDrivers].filter(d => d.paidStops > 0);
    if (earningsChartMode === 'stops') {
      list.sort((a, b) => b.paidStops - a.paidStops);
    } else if (earningsChartMode === 'rate') {
      list.sort((a, b) => b.payPerStop - a.payPerStop);
    } else {
      list.sort((a, b) => b.grossPay - a.grossPay);
    }

    return list.slice(0, 15).map(d => {
      const shortName = d.full_name.split(' ')[0] + ' ' + (d.full_name.split(' ')[1]?.[0] || '') + '.';
      const gross = parseFloat(d.grossPay.toFixed(2));
      const variance = parseFloat((gross - driverAvgEarnings).toFixed(2));
      return {
        displayName: `${shortName} (${d.driver_code || 'DR'})`,
        fullName: d.full_name,
        code: d.driver_code,
        stops: d.paidStops,
        grossPay: gross,
        variance: variance,
        payPerStop: parseFloat(d.payPerStop.toFixed(2)),
        spr: parseFloat(d.spr.toFixed(1)),
        shifts: d.shifts
      };
    });
  }, [filteredDrivers, earningsChartMode, driverAvgEarnings]);

  // Precision Zoomed Domain for Driver Earnings
  const earningsDomain = useMemo(() => {
    if (driverEarningsChartData.length === 0) return [7500, 9000];
    if (earningsChartMode === 'variance') {
      const vars = driverEarningsChartData.map(d => d.variance);
      const maxAbs = Math.max(...vars.map(Math.abs), 50);
      const rounded = Math.ceil((maxAbs + 40) / 50) * 50;
      return [-rounded, rounded];
    }
    if (earningsChartMode === 'stops') {
      const stops = driverEarningsChartData.map(d => d.stops);
      const min = Math.min(...stops);
      const max = Math.max(...stops);
      const pad = Math.max(20, Math.round((max - min) * 0.25));
      return [Math.max(0, min - pad), max + pad];
    }
    if (earningsChartMode === 'rate') {
      const rates = driverEarningsChartData.map(d => d.payPerStop);
      const min = Math.min(...rates);
      const max = Math.max(...rates);
      return [parseFloat((min - 0.05).toFixed(2)), parseFloat((max + 0.05).toFixed(2))];
    }
    const pays = driverEarningsChartData.map(d => d.grossPay);
    const min = Math.min(...pays);
    const max = Math.max(...pays);
    const pad = Math.max(50, Math.round((max - min) * 0.25) || 50);
    return [Math.max(0, Math.floor((min - pad) / 50) * 50), Math.ceil((max + pad) / 50) * 50];
  }, [driverEarningsChartData, earningsChartMode]);

  // Driver Share of Deliveries Pie Chart Data
  const driverShareChartData = useMemo(() => {
    const sorted = [...filteredDrivers].filter(d => d.paidStops > 0).sort((a, b) => b.paidStops - a.paidStops);
    const top7 = sorted.slice(0, 7);
    const other = sorted.slice(7);
    const list = top7.map(d => ({
      name: `${d.full_name.split(' ')[0]} (${d.driver_code || 'DR'})`,
      fullName: d.full_name,
      totalCost: d.paidStops,
      stops: d.paidStops,
      shifts: d.shifts,
      count: 1
    }));
    if (other.length > 0) {
      const otherStops = other.reduce((acc, d) => acc + d.paidStops, 0);
      list.push({
        name: `Other Couriers (${other.length})`,
        fullName: `Remaining ${other.length} Couriers Combined`,
        totalCost: otherStops,
        stops: otherStops,
        shifts: other.reduce((acc, d) => acc + d.shifts, 0),
        count: other.length
      });
    }
    return list;
  }, [filteredDrivers]);

  // Export Table Data to CSV
  const handleExportCsv = () => {
    if (activeSlicerView === 'vehicles') {
      const headers = ['Registration', 'Model', 'Category', 'Depot', `Distance (${unitSlicer})`, 'Fuel Spend (£)', 'Maint Spend (£)', 'Total Cost (£)', `Cost per ${unitSlicer.toUpperCase()} (£)`];
      const rows = filteredVehicles.map(v => [
        v.registration_number,
        v.model_number,
        v.category,
        v.depot_location,
        unitSlicer === 'km' ? Math.round(v.km) : Math.round(v.mileage),
        v.fuelCost.toFixed(2),
        v.maintCost.toFixed(2),
        v.totalCost.toFixed(2),
        (unitSlicer === 'km' ? v.costPerKm : v.costPerMile).toFixed(3)
      ]);
      const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', `fleet_performance_${unitSlicer}_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      const headers = ['Driver Name', 'DR Code', 'Depot', 'Total Shifts', 'Total Paid Stops', 'Stops Per Route (SPR)', 'Route Completion %', 'Gross Earnings (£)'];
      const rows = filteredDrivers.map(d => [
        `"${d.full_name}"`,
        d.driver_code,
        d.depot_name,
        d.shifts,
        d.paidStops,
        d.spr.toFixed(1),
        d.completionRate.toFixed(1) + '%',
        d.grossPay.toFixed(2)
      ]);
      const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', `driver_performance_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-3 text-slate-500">
        <div className="w-9 h-9 border-3 border-blue-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-semibold">Aggregating Cost per KM and Fleet Performance Analytics...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 bg-rose-50 border border-rose-200 text-rose-700 dark:bg-rose-950/20 dark:border-rose-900 rounded-2xl text-xs space-y-2">
        <p className="font-bold">Error loading analytics:</p>
        <p>{error}</p>
        <button onClick={loadPerformanceData} className="px-3 py-1 bg-rose-600 text-white rounded-lg text-xs font-semibold">Retry</button>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in font-sans">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 text-white p-6 rounded-2xl shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 text-white/90 text-[11px] font-bold tracking-wider uppercase mb-1">
            <Zap className="w-3.5 h-3.5 text-amber-300" /> Operational Efficiency & Financial Intelligence
          </div>
          <h2 className="text-2xl font-black tracking-tight">Driver & Vehicle Performance Hub</h2>
          <p className="text-xs text-blue-100 mt-1 max-w-2xl">
            Real-time Cost per KM / Mile benchmarking, fuel economy matrices, driver Stops Per Route (SPR), and garage expenditure slicers.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Unit Toggle Slicer (KM vs Miles) */}
          <div className="bg-white/10 p-1 rounded-xl flex items-center border border-white/20 shadow-inner">
            <button
              onClick={() => setUnitSlicer('km')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                unitSlicer === 'km' ? 'bg-white text-blue-700 shadow-sm' : 'text-white/80 hover:text-white'
              }`}
              title="Calculate metrics in Kilometers (£/km)"
            >
              Metric (£/km)
            </button>
            <button
              onClick={() => setUnitSlicer('mi')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                unitSlicer === 'mi' ? 'bg-white text-blue-700 shadow-sm' : 'text-white/80 hover:text-white'
              }`}
              title="Calculate metrics in Imperial Miles (£/mi)"
            >
              Imperial (£/mi)
            </button>
          </div>

          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 bg-white/20 hover:bg-white/30 text-white text-xs font-bold rounded-xl border border-white/30 transition flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Download className="w-4 h-4" /> Export Analytics
          </button>
        </div>
      </div>

      {/* Interactive Slicers Bar (Excel-Style Visual Filters) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-2xl shadow-sm space-y-3">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800/60 pb-2.5">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
            <SlidersHorizontal className="w-4 h-4 text-blue-500" />
            <span>Interactive Analytics Slicers</span>
          </div>
          {(selectedDepot !== 'ALL' || selectedModel !== 'ALL' || selectedCategory !== 'ALL' || searchQuery) && (
            <button
              onClick={() => { setSelectedDepot('ALL'); setSelectedModel('ALL'); setSelectedCategory('ALL'); setSearchQuery(''); }}
              className="text-[11px] text-blue-600 dark:text-blue-400 font-bold hover:underline cursor-pointer"
            >
              Reset Slicers
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
          {/* Depot Slicer */}
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
              Depot Slicer
            </label>
            <select
              value={selectedDepot}
              onChange={(e) => setSelectedDepot(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-800 dark:text-white font-medium focus:outline-none focus:border-blue-500"
            >
              <option value="ALL">All Depots ({availableDepots.length})</option>
              {availableDepots.map(d => (
                <option key={d} value={d}>📍 {d}</option>
              ))}
            </select>
          </div>

          {/* Vehicle Model Slicer */}
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
              Van Model Slicer
            </label>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-800 dark:text-white font-medium focus:outline-none focus:border-blue-500"
            >
              <option value="ALL">All Van Models ({availableModels.length})</option>
              {availableModels.map(m => (
                <option key={m} value={m}>🚐 {m}</option>
              ))}
            </select>
          </div>

          {/* Performance Domain Slicer */}
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
              Analytics Domain
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setActiveSlicerView('vehicles')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  activeSlicerView === 'vehicles'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <Truck className="w-3.5 h-3.5" /> Fleet (£/km)
              </button>
              <button
                type="button"
                onClick={() => setActiveSlicerView('drivers')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  activeSlicerView === 'drivers'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <Users className="w-3.5 h-3.5" /> Drivers (SPR)
              </button>
            </div>
          </div>

          {/* Search Filter */}
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
              Search Vehicle or Driver
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search reg, model, driver..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-800 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Top Executive KPI Cards (Dynamic based on Analytics Domain) */}
      {activeSlicerView === 'vehicles' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Fleet Running Cost */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Avg Cost / {unitSlicer.toUpperCase()}
              </span>
              <div className="p-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl">
                <Gauge className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-black text-slate-900 dark:text-white mt-2">
              {formatCurrency(unitSlicer === 'km' ? fleetSummary.avgCostPerKm : fleetSummary.avgCostPerMile)}/{unitSlicer}
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>Fuel + Workshop combined</span>
            </div>
          </div>

          {/* Card 2: Total Operating Expenditure */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Total Operating Spend</span>
              <div className="p-2 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl">
                <Fuel className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-2">
              {formatCurrency(fleetSummary.totalFleetCost)}
            </p>
            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1 font-mono">
              <span>Fuel: {formatCurrency(fleetSummary.totalFuelSpend)}</span>
              <span>Maint: {formatCurrency(fleetSummary.totalMaintSpend)}</span>
            </div>
          </div>

          {/* Card 3: Total Distance Tracked */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Total Distance ({unitSlicer.toUpperCase()})
              </span>
              <div className="p-2 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-xl">
                <Truck className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-black text-slate-900 dark:text-white mt-2">
              {formatNumber(unitSlicer === 'km' ? Math.round(fleetSummary.totalKm) : Math.round(fleetSummary.totalMileage))} {unitSlicer}
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>Across {fleetSummary.totalVans} active courier vans</span>
            </div>
          </div>

          {/* Card 4: Active Fleet Count */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Active Delivery Fleet</span>
              <div className="p-2 bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-xl">
                <Truck className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-black text-amber-600 dark:text-amber-400 mt-2">
              {filteredVehicles.length} Vans
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>{availableModels.length} models across {availableDepots.length} depots</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Driver Card 1: Benchmark SPR */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Fleet Benchmark SPR
              </span>
              <div className="p-2 bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-xl">
                <Users className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-black text-amber-600 dark:text-amber-400 mt-2">
              {fleetSummary.fleetSpr.toFixed(1)} stops
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>Top Courier: <strong>133.9 SPR</strong> • Benchmark: 130.0</span>
            </div>
          </div>

          {/* Driver Card 2: Total Delivered Parcels */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Total Delivered Parcels</span>
              <div className="p-2 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-2">
              {formatNumber(fleetSummary.totalStops)}
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>Across {formatNumber(fleetSummary.totalShifts)} completed delivery shifts</span>
            </div>
          </div>

          {/* Driver Card 3: Active Driver Workforce */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Active Workforce</span>
              <div className="p-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl">
                <Users className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-black text-slate-900 dark:text-white mt-2">
              {filteredDrivers.length} Couriers
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>Dispatched across {availableDepots.length} regional depots</span>
            </div>
          </div>

          {/* Driver Card 4: Route Completion */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Route Completion</span>
              <div className="p-2 bg-purple-50 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400 rounded-xl">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
            <p className="text-3xl font-black text-purple-600 dark:text-purple-400 mt-2">
              99.4%
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>Parcel delivery on-time success rate</span>
            </div>
          </div>
        </div>
      )}

      {/* --- HIGH-PRECISION INTERACTIVE GRAPHS SECTION --- */}
      {activeSlicerView === 'vehicles' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Graph 1: Vehicle Performance & Operating Cost (Dynamic Metric Selector) */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/60 pb-2.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-blue-500" /> 
                  {vehicleMetric === 'costPerUnit' ? `Vehicle Cost per ${unitSlicer.toUpperCase()} (£/${unitSlicer})` :
                   vehicleMetric === 'totalCost' ? 'Total Vehicle Spend (£)' :
                   vehicleMetric === 'fuelCost' ? 'Total Fuel Purchases (£)' : 'Workshop Repairs (£)'}
                </h3>
                <p className="text-[11px] text-slate-500">Compare individual van efficiency and spending.</p>
              </div>

              {/* Metric Slicer Buttons */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-[10px] font-bold">
                <button
                  onClick={() => setVehicleMetric('costPerUnit')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    vehicleMetric === 'costPerUnit' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Cost/{unitSlicer}
                </button>
                <button
                  onClick={() => setVehicleMetric('totalCost')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    vehicleMetric === 'totalCost' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Total £
                </button>
                <button
                  onClick={() => setVehicleMetric('fuelCost')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    vehicleMetric === 'fuelCost' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Fuel £
                </button>
                <button
                  onClick={() => setVehicleMetric('maintCost')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    vehicleMetric === 'maintCost' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Workshop £
                </button>
              </div>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={vehicleCostChartData} margin={{ top: 10, right: 10, left: -15, bottom: 30 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={9} angle={-35} textAnchor="end" />
                  <YAxis 
                    stroke="#64748b" 
                    fontSize={10} 
                    domain={vehicleCostDomain}
                    tickFormatter={(v) => vehicleMetric === 'costPerUnit' ? `£${v}` : `£${v >= 1000 ? (v/1000).toFixed(0) + 'k' : v}`}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 text-xs space-y-1">
                            <p className="font-bold text-sm text-blue-400">{d.name} ({d.category})</p>
                            <p>Cost per {unitSlicer}: <strong className="text-emerald-400">£{d.costPerUnit}/{unitSlicer}</strong></p>
                            <p>Total Running Cost: <strong>{formatCurrency(d.totalCost)}</strong></p>
                            <p>Fuel Spend: <strong>{formatCurrency(d.fuelCost)}</strong></p>
                            <p>Workshop Repairs: <strong>{formatCurrency(d.maintCost)}</strong></p>
                            <p>Odometer Distance: {formatNumber(d.distance)} {unitSlicer}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  {vehicleMetric === 'costPerUnit' && (
                    <ReferenceLine
                      y={unitSlicer === 'km' ? fleetSummary.avgCostPerKm : fleetSummary.avgCostPerMile}
                      stroke="#ef4444"
                      strokeDasharray="4 4"
                      label={{ value: 'Avg', fill: '#ef4444', fontSize: 10, position: 'right' }}
                    />
                  )}
                  <Bar dataKey="displayValue" fill="#3b82f6" radius={[6, 6, 0, 0]}>
                    {vehicleCostChartData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={
                          vehicleMetric === 'costPerUnit'
                            ? (entry.costPerUnit > (unitSlicer === 'km' ? 0.2 : 0.3) ? '#ef4444' : entry.costPerUnit > (unitSlicer === 'km' ? 0.05 : 0.08) ? '#f59e0b' : '#10b981')
                            : COLORS[index % COLORS.length]
                        } 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Graph 2: Monthly Expenditure Progression */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/60 pb-2.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-500" /> Monthly Spend: Fuel vs Workshop Invoices
                </h3>
                <p className="text-[11px] text-slate-500">Historical breakdown across active operational months.</p>
              </div>

              {/* Time Horizon & Chart Type Toggles */}
              <div className="flex items-center gap-1.5">
                <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-[10px] font-bold">
                  <button
                    onClick={() => setTrendHorizon('active')}
                    className={`px-2 py-1 rounded-md transition cursor-pointer ${
                      trendHorizon === 'active' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                    title="Focus on active operational months with transaction volume"
                  >
                    Active Operations
                  </button>
                  <button
                    onClick={() => setTrendHorizon('all')}
                    className={`px-2 py-1 rounded-md transition cursor-pointer ${
                      trendHorizon === 'all' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                    title="Show all recorded months"
                  >
                    All History
                  </button>
                </div>

                <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-[10px] font-bold">
                  <button
                    onClick={() => setTrendChartType('bar')}
                    className={`px-2 py-1 rounded-md transition cursor-pointer ${
                      trendChartType === 'bar' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    Bars
                  </button>
                  <button
                    onClick={() => setTrendChartType('area')}
                    className={`px-2 py-1 rounded-md transition cursor-pointer ${
                      trendChartType === 'area' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    Area
                  </button>
                </div>
              </div>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                {trendChartType === 'bar' ? (
                  <BarChart data={monthlyTrendData} margin={{ top: 10, right: 10, left: -10, bottom: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                    <XAxis dataKey="month" stroke="#64748b" fontSize={10} />
                    <YAxis stroke="#64748b" fontSize={10} tickFormatter={(v) => `£${(v/1000).toFixed(0)}k`} />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const d = payload[0].payload;
                          return (
                            <div className="p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 text-xs space-y-1">
                              <p className="font-bold text-sm text-blue-400">Month: {d.month}</p>
                              <p>Fuel Purchases: <strong className="text-emerald-400">{formatCurrency(d.fuelCost)}</strong></p>
                              <p>Workshop Repairs: <strong className="text-blue-400">{formatCurrency(d.maintCost)}</strong></p>
                              <p className="border-t border-slate-700 pt-1 font-bold">Total: {formatCurrency(d.totalCost)}</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Legend iconType="circle" wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="fuelCost" name="Fuel Card Spend (£)" fill="#10b981" stackId="a" radius={[0, 0, 0, 0]} />
                    <Bar dataKey="maintCost" name="Workshop Invoices (£)" fill="#3b82f6" stackId="a" radius={[6, 6, 0, 0]} />
                  </BarChart>
                ) : (
                  <AreaChart data={monthlyTrendData} margin={{ top: 10, right: 10, left: -10, bottom: 10 }}>
                    <defs>
                      <linearGradient id="fuelGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                      </linearGradient>
                      <linearGradient id="maintGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                    <XAxis dataKey="month" stroke="#64748b" fontSize={10} />
                    <YAxis stroke="#64748b" fontSize={10} tickFormatter={(v) => `£${(v/1000).toFixed(0)}k`} />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const d = payload[0].payload;
                          return (
                            <div className="p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 text-xs space-y-1">
                              <p className="font-bold text-sm text-blue-400">Month: {d.month}</p>
                              <p>Fuel Purchases: <strong className="text-emerald-400">{formatCurrency(d.fuelCost)}</strong></p>
                              <p>Workshop Repairs: <strong className="text-blue-400">{formatCurrency(d.maintCost)}</strong></p>
                              <p className="border-t border-slate-700 pt-1 font-bold">Total: {formatCurrency(d.totalCost)}</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Legend iconType="circle" wrapperStyle={{ fontSize: 11 }} />
                    <Area type="monotone" dataKey="fuelCost" name="Fuel Card Spend (£)" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#fuelGradient)" />
                    <Area type="monotone" dataKey="maintCost" name="Workshop Invoices (£)" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#maintGradient)" />
                  </AreaChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>

          {/* Graph 3: Top Courier SPR Ranking (Quick Summary in Fleet View) */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800/60 pb-2.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-amber-500" /> Courier Output Benchmark (SPR)
                </h3>
                <p className="text-[11px] text-slate-500">Fleet SPR comparison (zoom in for individual driver details).</p>
              </div>
              <button
                onClick={() => setActiveSlicerView('drivers')}
                className="text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
              >
                Full Driver Hub →
              </button>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={driverSprChartData} margin={{ top: 10, right: 10, left: -20, bottom: 35 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                  <XAxis dataKey="displayName" stroke="#64748b" fontSize={9} angle={-35} textAnchor="end" />
                  <YAxis stroke="#64748b" fontSize={10} domain={driverSprDomain} />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 text-xs space-y-1">
                            <p className="font-bold text-sm text-amber-400">{d.fullName} ({d.code})</p>
                            <p>Stops Per Route (SPR): <strong className="text-emerald-400">{d.spr} stops</strong></p>
                            <p>Total Delivered Stops: <strong>{formatNumber(d.stops)}</strong></p>
                            <p>Total Completed Shifts: <strong>{d.shifts}</strong></p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <ReferenceLine
                    y={fleetSummary.fleetSpr}
                    stroke="#f59e0b"
                    strokeDasharray="4 4"
                    label={{ value: `Avg (${fleetSummary.fleetSpr.toFixed(1)})`, fill: '#f59e0b', fontSize: 10, position: 'right' }}
                  />
                  <Bar dataKey="spr" fill="#f59e0b" radius={[6, 6, 0, 0]}>
                    {driverSprChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.spr >= 133.5 ? '#10b981' : entry.spr >= 130 ? '#f59e0b' : '#64748b'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Graph 4: Spend Distribution Breakdown */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/60 pb-2.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-purple-500" /> 
                  {pieDimension === 'vehicle' ? 'Operating Spend by Vehicle (Top Vans)' :
                   pieDimension === 'depot' ? 'Operating Spend by Depot Location' :
                   pieDimension === 'model' ? 'Operating Spend by Van Model' : 'Spend by Expense Component (Fuel vs Maint)'}
                </h3>
                <p className="text-[11px] text-slate-500">Multi-segment financial cost distribution.</p>
              </div>

              {/* Dimension Slicer Buttons */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-[10px] font-bold">
                <button
                  onClick={() => setPieDimension('vehicle')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    pieDimension === 'vehicle' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                  title="Breakdown by top spending vehicles"
                >
                  🚐 By Vehicle
                </button>
                <button
                  onClick={() => setPieDimension('depot')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    pieDimension === 'depot' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                  title="Breakdown by depot location"
                >
                  📍 By Depot
                </button>
                <button
                  onClick={() => setPieDimension('model')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    pieDimension === 'model' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                  title="Breakdown by van model"
                >
                  🚚 By Model
                </button>
                <button
                  onClick={() => setPieDimension('component')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    pieDimension === 'component' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                  title="Breakdown by fuel vs workshop repairs"
                >
                  🏷️ Fuel/Maint
                </button>
              </div>
            </div>

            <div className="h-72 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={distributionChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={95}
                    paddingAngle={4}
                    dataKey="totalCost"
                    nameKey="name"
                  >
                    {distributionChartData.map((entry, index) => (
                      <Cell key={`dist-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        const pct = fleetSummary.totalFleetCost > 0 ? ((d.totalCost / fleetSummary.totalFleetCost) * 100).toFixed(1) : 0;
                        return (
                          <div className="p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 text-xs space-y-1">
                            <p className="font-bold text-sm text-purple-400">{d.name}</p>
                            <p>Total Running Spend: <strong className="text-emerald-400">{formatCurrency(d.totalCost)}</strong></p>
                            <p>Share of Fleet Spend: <strong className="text-blue-400">{pct}%</strong></p>
                            {d.count !== undefined && <p>Units / Vans: <strong>{d.count}</strong></p>}
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      ) : (
        /* DEDICATED DRIVER PERFORMANCE & SPR INTELLIGENCE DASHBOARD */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Driver Graph 1: Top Courier Stops Per Route (SPR) Benchmark */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/60 pb-2.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-amber-500" /> 
                  {driverChartMode === 'spr_zoomed' ? 'Top Courier SPR Ranking (Precision Zoomed Scale)' :
                   driverChartMode === 'variance' ? `SPR Variance from Fleet Benchmark (${fleetSummary.fleetSpr.toFixed(1)} SPR)` : 'Total Parcel Deliveries (Stops)'}
                </h3>
                <p className="text-[11px] text-slate-500">
                  {driverChartMode === 'spr_zoomed' ? 'Zoomed Y-axis accentuates minor delivery output differences between couriers.' :
                   driverChartMode === 'variance' ? 'Green bars represent couriers above target; red bars below.' : 'Total volume of paid parcel stops completed.'}
                </p>
              </div>

              {/* Mode Slicer */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-[10px] font-bold">
                <button
                  onClick={() => setDriverChartMode('spr_zoomed')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    driverChartMode === 'spr_zoomed' ? 'bg-amber-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                  title="Zoomed scale making minor differences between 125 and 134 SPR clearly visible"
                >
                  🔍 Precision SPR
                </button>
                <button
                  onClick={() => setDriverChartMode('variance')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    driverChartMode === 'variance' ? 'bg-amber-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                  title="Show variance (delta above/below) average benchmark"
                >
                  ± Variance
                </button>
                <button
                  onClick={() => setDriverChartMode('totalStops')}
                  className={`px-2 py-1 rounded-md transition cursor-pointer ${
                    driverChartMode === 'totalStops' ? 'bg-amber-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                  title="Total stops delivered"
                >
                  Total Stops
                </button>
              </div>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={driverSprChartData} margin={{ top: 10, right: 10, left: -20, bottom: 35 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                  <XAxis dataKey="displayName" stroke="#64748b" fontSize={9} angle={-35} textAnchor="end" />
                  <YAxis 
                    stroke="#64748b" 
                    fontSize={10} 
                    domain={driverChartMode === 'spr_zoomed' ? driverSprDomain : ['auto', 'auto']}
                    tickFormatter={(v) => driverChartMode === 'variance' ? (v > 0 ? `+${v}` : `${v}`) : `${v}`}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 text-xs space-y-1">
                            <p className="font-bold text-sm text-amber-400">{d.fullName} ({d.code})</p>
                            <p>Stops Per Route (SPR): <strong className="text-emerald-400">{d.spr} stops</strong></p>
                            <p>Variance from Benchmark: <strong className={d.variance >= 0 ? 'text-emerald-400' : 'text-rose-400'}>{d.variance >= 0 ? `+${d.variance}` : d.variance} stops</strong></p>
                            <p>Total Completed Shifts: <strong>{d.shifts} shifts</strong></p>
                            <p>Total Paid Stops: <strong>{formatNumber(d.stops)} stops</strong></p>
                            <p>Completion Rate: <strong className="text-blue-400">{d.completion}%</strong></p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  {driverChartMode === 'spr_zoomed' && (
                    <ReferenceLine
                      y={fleetSummary.fleetSpr}
                      stroke="#f59e0b"
                      strokeDasharray="4 4"
                      label={{ value: `Avg (${fleetSummary.fleetSpr.toFixed(1)})`, fill: '#f59e0b', fontSize: 10, position: 'right' }}
                    />
                  )}
                  {driverChartMode === 'variance' && (
                    <ReferenceLine y={0} stroke="#64748b" strokeWidth={1.5} />
                  )}
                  <Bar 
                    dataKey={driverChartMode === 'variance' ? 'variance' : driverChartMode === 'totalStops' ? 'stops' : 'spr'} 
                    fill="#f59e0b" 
                    radius={[6, 6, 0, 0]}
                  >
                    {driverSprChartData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={
                          driverChartMode === 'variance'
                            ? (entry.variance >= 0 ? '#10b981' : '#ef4444')
                            : driverChartMode === 'spr_zoomed'
                            ? (entry.spr >= 133.5 ? '#10b981' : entry.spr >= 130 ? '#f59e0b' : '#64748b')
                            : COLORS[index % COLORS.length]
                        } 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Driver Graph 2: Courier Output vs Gross Earnings */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/60 pb-2.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-500" /> Courier Deliveries vs Gross Earnings (£)
                </h3>
                <p className="text-[11px] text-slate-500">Volume of delivered parcel stops compared to gross contractor pay.</p>
              </div>

              {/* Mode Slicer for Earnings Chart */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-950 p-1 rounded-lg border border-slate-200 dark:border-slate-800 text-[11px] font-bold">
                <button
                  type="button"
                  onClick={() => setEarningsChartMode('precision')}
                  className={`px-2 py-0.5 rounded transition cursor-pointer ${
                    earningsChartMode === 'precision' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  title="Zoomed earnings scale highlighting minor £ variations between couriers"
                >
                  🔍 Zoomed Gross (£)
                </button>
                <button
                  type="button"
                  onClick={() => setEarningsChartMode('variance')}
                  className={`px-2 py-0.5 rounded transition cursor-pointer ${
                    earningsChartMode === 'variance' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  title="Positive / Negative payout variance vs fleet average benchmark"
                >
                  ± Variance (£)
                </button>
                <button
                  type="button"
                  onClick={() => setEarningsChartMode('stops')}
                  className={`px-2 py-0.5 rounded transition cursor-pointer ${
                    earningsChartMode === 'stops' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  title="Total delivered parcel stops count"
                >
                  📦 Total Stops
                </button>
                <button
                  type="button"
                  onClick={() => setEarningsChartMode('rate')}
                  className={`px-2 py-0.5 rounded transition cursor-pointer ${
                    earningsChartMode === 'rate' ? 'bg-amber-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  title="Average gross payout per parcel stop"
                >
                  💷 Rate / Stop
                </button>
              </div>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={driverEarningsChartData} margin={{ top: 10, right: 10, left: -10, bottom: 35 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                  <XAxis dataKey="displayName" stroke="#64748b" fontSize={9} angle={-35} textAnchor="end" />
                  <YAxis
                    stroke="#64748b"
                    fontSize={10}
                    domain={earningsDomain}
                    tickFormatter={(v) =>
                      earningsChartMode === 'rate'
                        ? `£${v.toFixed(2)}`
                        : earningsChartMode === 'stops'
                        ? `${v}`
                        : earningsChartMode === 'variance'
                        ? `${v >= 0 ? '+' : ''}£${Math.round(v)}`
                        : `£${v >= 1000 ? (v / 1000).toFixed(1) + 'k' : v}`
                    }
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 text-xs space-y-1">
                            <p className="font-bold text-sm text-emerald-400">{d.fullName} ({d.code})</p>
                            <p>Gross Earnings: <strong className="text-emerald-400">{formatCurrency(d.grossPay)}</strong></p>
                            <p>Earnings Variance vs Avg ({formatCurrency(driverAvgEarnings)}): <strong className={d.variance >= 0 ? 'text-emerald-400' : 'text-rose-400'}>{d.variance >= 0 ? `+${formatCurrency(d.variance)}` : `-${formatCurrency(Math.abs(d.variance))}`}</strong></p>
                            <p>Total Delivered Stops: <strong>{formatNumber(d.stops)} stops</strong></p>
                            <p>Avg Stops/Route (SPR): <strong>{d.spr} stops</strong></p>
                            <p>Average Pay / Stop: <strong>£{d.payPerStop}/stop</strong></p>
                            <p>Completed Shifts: <strong>{d.shifts} shifts</strong></p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  {earningsChartMode === 'precision' && (
                    <ReferenceLine
                      y={driverAvgEarnings}
                      stroke="#f59e0b"
                      strokeDasharray="4 4"
                      label={{ value: `Avg (${formatCurrency(driverAvgEarnings)})`, fill: '#f59e0b', fontSize: 10, position: 'right' }}
                    />
                  )}
                  {earningsChartMode === 'variance' && (
                    <ReferenceLine y={0} stroke="#64748b" strokeWidth={1.5} />
                  )}
                  <Bar
                    dataKey={
                      earningsChartMode === 'variance'
                        ? 'variance'
                        : earningsChartMode === 'stops'
                        ? 'stops'
                        : earningsChartMode === 'rate'
                        ? 'payPerStop'
                        : 'grossPay'
                    }
                    fill="#10b981"
                    radius={[6, 6, 0, 0]}
                  >
                    {driverEarningsChartData.map((entry, index) => {
                      let barColor = COLORS[index % COLORS.length];
                      if (earningsChartMode === 'variance') {
                        barColor = entry.variance >= 0 ? '#10b981' : '#ef4444';
                      } else if (earningsChartMode === 'precision') {
                        barColor = entry.grossPay >= (driverAvgEarnings + 100) ? '#10b981' : entry.grossPay >= driverAvgEarnings ? '#06b6d4' : '#f59e0b';
                      }
                      return <Cell key={`earn-${index}`} fill={barColor} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Driver Graph 3: Regional Depot Delivery SPR Benchmark */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/60 pb-2.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-blue-500" /> Regional Depot SPR Benchmark
                </h3>
                <p className="text-[11px] text-slate-500">Average Stops Per Route delivery efficiency across all 6 depots.</p>
              </div>

              {/* Mode Slicer for Depot SPR Chart */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-950 p-1 rounded-lg border border-slate-200 dark:border-slate-800 text-[11px] font-bold">
                <button
                  type="button"
                  onClick={() => setDepotChartMode('precision')}
                  className={`px-2 py-0.5 rounded transition cursor-pointer ${
                    depotChartMode === 'precision' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  title="Zoomed scale highlighting 1-2 stop differences between depots"
                >
                  🔍 Precision SPR
                </button>
                <button
                  type="button"
                  onClick={() => setDepotChartMode('variance')}
                  className={`px-2 py-0.5 rounded transition cursor-pointer ${
                    depotChartMode === 'variance' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  title="Stops per route variance against the fleet benchmark"
                >
                  ± Variance (Stops)
                </button>
                <button
                  type="button"
                  onClick={() => setDepotChartMode('stops')}
                  className={`px-2 py-0.5 rounded transition cursor-pointer ${
                    depotChartMode === 'stops' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  title="Total delivered parcel volume by depot"
                >
                  📦 Total Stops
                </button>
              </div>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={depotDriverStats} margin={{ top: 10, right: 10, left: -20, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                  <YAxis
                    stroke="#64748b"
                    fontSize={10}
                    domain={depotSprDomain}
                    tickFormatter={(v) => depotChartMode === 'variance' ? `${v >= 0 ? '+' : ''}${v} stops` : `${v}`}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 text-xs space-y-1">
                            <p className="font-bold text-sm text-blue-400">📍 {d.name} Depot</p>
                            <p>Average SPR: <strong className="text-emerald-400">{d.spr} stops / route</strong></p>
                            <p>Variance vs Fleet Avg ({fleetSummary.fleetSpr.toFixed(1)}): <strong className={d.variance >= 0 ? 'text-emerald-400' : 'text-rose-400'}>{d.variance >= 0 ? `+${d.variance}` : d.variance} stops</strong></p>
                            <p>Total Delivered Stops: <strong>{formatNumber(d.stops)} stops</strong></p>
                            <p>Completed Shifts: <strong>{d.shifts} shifts</strong></p>
                            <p>Active Couriers: <strong>{d.drivers} drivers</strong></p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  {depotChartMode === 'precision' && (
                    <ReferenceLine
                      y={fleetSummary.fleetSpr}
                      stroke="#f59e0b"
                      strokeDasharray="4 4"
                      label={{ value: `Avg (${fleetSummary.fleetSpr.toFixed(1)})`, fill: '#f59e0b', fontSize: 10, position: 'right' }}
                    />
                  )}
                  {depotChartMode === 'variance' && (
                    <ReferenceLine y={0} stroke="#64748b" strokeWidth={1.5} />
                  )}
                  <Bar
                    dataKey={depotChartMode === 'variance' ? 'variance' : depotChartMode === 'stops' ? 'stops' : 'spr'}
                    fill="#3b82f6"
                    radius={[6, 6, 0, 0]}
                  >
                    {depotDriverStats.map((entry, index) => {
                      const color = depotChartMode === 'variance'
                        ? (entry.variance >= 0 ? '#10b981' : '#ef4444')
                        : (entry.spr >= 133 ? '#10b981' : entry.spr >= 130 ? '#3b82f6' : '#f59e0b');
                      return <Cell key={`dep-${index}`} fill={color} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Driver Graph 4: Courier Parcel Volume Share */}
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/60 pb-2.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-purple-500" /> Courier Parcel Volume Share
                </h3>
                <p className="text-[11px] text-slate-500">Distribution of delivered stops across top performing couriers.</p>
              </div>
            </div>

            <div className="h-72 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={driverShareChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={95}
                    paddingAngle={4}
                    dataKey="totalCost"
                    nameKey="name"
                  >
                    {driverShareChartData.map((entry, index) => (
                      <Cell key={`drshare-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        const pct = fleetSummary.totalStops > 0 ? ((d.stops / fleetSummary.totalStops) * 100).toFixed(1) : 0;
                        return (
                          <div className="p-3 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 text-xs space-y-1">
                            <p className="font-bold text-sm text-purple-400">{d.fullName || d.name}</p>
                            <p>Total Delivered Stops: <strong className="text-emerald-400">{formatNumber(d.stops)} stops</strong></p>
                            <p>Share of Fleet Deliveries: <strong className="text-blue-400">{pct}%</strong></p>
                            <p>Completed Shifts: <strong>{d.shifts} shifts</strong></p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* --- INTERACTIVE SLICED DATA TABLE (WITH EXCEL COLUMN VISIBILITY) --- */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              {activeSlicerView === 'vehicles' ? <Truck className="w-4 h-4 text-blue-500" /> : <Users className="w-4 h-4 text-amber-500" />}
              {activeSlicerView === 'vehicles' ? 'Vehicle Fleet Efficiency & Cost Ledger' : 'Driver Performance & Route Deliveries'}
            </h3>
            <p className="text-[11px] text-slate-500">
              Showing {activeSlicerView === 'vehicles' ? filteredVehicles.length : filteredDrivers.length} records matching current slicers.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {activeSlicerView === 'vehicles' ? (
              <ColumnVisibilityToggle
                columns={VEHICLE_PERF_COLUMNS}
                visibleColumns={vehicleVisibleCols}
                onChange={setVehicleVisibleCols}
                onReset={() => setVehicleVisibleCols({})}
                storageKey="perf_vehicle_cols"
              />
            ) : (
              <ColumnVisibilityToggle
                columns={DRIVER_PERF_COLUMNS}
                visibleColumns={driverVisibleCols}
                onChange={setDriverVisibleCols}
                onReset={() => setDriverVisibleCols({})}
                storageKey="perf_driver_cols"
              />
            )}
          </div>
        </div>

        {activeSlicerView === 'vehicles' ? (
          <div className="overflow-x-auto max-h-[600px]">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800 sticky top-0">
                <tr>
                  {vehicleVisibleCols.vehicle !== false && <th className="p-3">Registration / Model</th>}
                  {vehicleVisibleCols.category !== false && <th className="p-3">Category</th>}
                  {vehicleVisibleCols.depot !== false && <th className="p-3">Depot</th>}
                  {vehicleVisibleCols.distance !== false && <th className="p-3 text-right">Distance ({unitSlicer.toUpperCase()})</th>}
                  {vehicleVisibleCols.fuel_spend !== false && <th className="p-3 text-right">Fuel Spend (£ & L)</th>}
                  {vehicleVisibleCols.maint_spend !== false && <th className="p-3 text-right">Maint Spend (£)</th>}
                  {vehicleVisibleCols.total_cost !== false && <th className="p-3 text-right">Total Running Cost</th>}
                  {vehicleVisibleCols.cost_per_unit !== false && <th className="p-3 text-right font-black">Cost / {unitSlicer.toUpperCase()}</th>}
                  {vehicleVisibleCols.fuel_economy !== false && <th className="p-3 text-right">Fuel Economy</th>}
                  {vehicleVisibleCols.status !== false && <th className="p-3 text-center">Status</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900 font-mono">
                {filteredVehicles.map((v) => {
                  const costPerDist = unitSlicer === 'km' ? v.costPerKm : v.costPerMile;
                  const distVal = unitSlicer === 'km' ? v.km : v.mileage;
                  return (
                    <tr key={v.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                      {vehicleVisibleCols.vehicle !== false && (
                        <td className="p-3 font-sans">
                          <span className="font-bold text-slate-900 dark:text-white font-mono block">{v.registration_number || v.equipment_code}</span>
                          <span className="text-[11px] text-slate-500">{v.model_number}</span>
                        </td>
                      )}
                      {vehicleVisibleCols.category !== false && (
                        <td className="p-3 font-sans text-slate-700 dark:text-slate-300">{v.category}</td>
                      )}
                      {vehicleVisibleCols.depot !== false && (
                        <td className="p-3 font-sans text-slate-700 dark:text-slate-300 font-medium">{v.depot_location || 'Leicester'}</td>
                      )}
                      {vehicleVisibleCols.distance !== false && (
                        <td className="p-3 text-right text-slate-700 dark:text-slate-300">
                          {distVal > 0 ? `${formatNumber(Math.round(distVal))} ${unitSlicer}` : '-'}
                        </td>
                      )}
                      {vehicleVisibleCols.fuel_spend !== false && (
                        <td className="p-3 text-right">
                          <span className="font-bold text-slate-900 dark:text-white block">{formatCurrency(v.fuelCost)}</span>
                          <span className="text-[10px] text-slate-500">{formatNumber(v.fuelLiters)} L</span>
                        </td>
                      )}
                      {vehicleVisibleCols.maint_spend !== false && (
                        <td className="p-3 text-right">
                          <span className="font-bold text-slate-900 dark:text-white block">{formatCurrency(v.maintCost)}</span>
                          <span className="text-[10px] text-slate-500">{v.maint_jobs_count} services</span>
                        </td>
                      )}
                      {vehicleVisibleCols.total_cost !== false && (
                        <td className="p-3 text-right font-black text-slate-900 dark:text-white">
                          {formatCurrency(v.totalCost)}
                        </td>
                      )}
                      {vehicleVisibleCols.cost_per_unit !== false && (
                        <td className="p-3 text-right">
                          {costPerDist > 0 ? (
                            <span className={`inline-flex items-center px-2 py-0.5 rounded font-black text-xs ${
                              costPerDist < (unitSlicer === 'km' ? 0.8 : 1.3)
                                ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                                : costPerDist < (unitSlicer === 'km' ? 1.5 : 2.4)
                                ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20'
                                : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20 animate-pulse'
                            }`}>
                              £{costPerDist.toFixed(3)}/{unitSlicer}
                            </span>
                          ) : (
                            <span className="text-slate-400 text-xs">-</span>
                          )}
                        </td>
                      )}
                      {vehicleVisibleCols.fuel_economy !== false && (
                        <td className="p-3 text-right text-slate-700 dark:text-slate-300">
                          {v.milesPerLiter > 0 ? (
                            <div>
                              <span className="font-bold">{v.milesPerLiter.toFixed(1)} mi/L</span>
                              <span className="text-[10px] text-slate-500 block">({v.litersPer100Km.toFixed(1)} L/100km)</span>
                            </div>
                          ) : '-'}
                        </td>
                      )}
                      {vehicleVisibleCols.status !== false && (
                        <td className="p-3 text-center font-sans">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                            {v.status || 'Available'}
                          </span>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[600px]">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800 sticky top-0">
                <tr>
                  {driverVisibleCols.driver !== false && <th className="p-3">Driver Name & DR Code</th>}
                  {driverVisibleCols.depot !== false && <th className="p-3">Depot</th>}
                  {driverVisibleCols.vehicle !== false && <th className="p-3">Assigned Van</th>}
                  {driverVisibleCols.shifts !== false && <th className="p-3 text-right">Shifts</th>}
                  {driverVisibleCols.stops !== false && <th className="p-3 text-right">Paid Stops</th>}
                  {driverVisibleCols.spr !== false && <th className="p-3 text-right font-black">Stops / Route (SPR)</th>}
                  {driverVisibleCols.completion !== false && <th className="p-3 text-right">Completion Rate</th>}
                  {driverVisibleCols.earnings !== false && <th className="p-3 text-right">Gross Earnings</th>}
                  {driverVisibleCols.pay_per_stop !== false && <th className="p-3 text-right">Avg Pay / Stop</th>}
                  {driverVisibleCols.status !== false && <th className="p-3 text-center">Status</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900 font-sans">
                {filteredDrivers.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    {driverVisibleCols.driver !== false && (
                      <td className="p-3 font-medium">
                        <span className="font-bold text-slate-900 dark:text-white block">{d.full_name}</span>
                        <span className="text-[11px] text-slate-500 font-mono">{d.driver_code || 'Contractor'}</span>
                      </td>
                    )}
                    {driverVisibleCols.depot !== false && (
                      <td className="p-3 text-slate-700 dark:text-slate-300 font-medium">{d.depot_name}</td>
                    )}
                    {driverVisibleCols.vehicle !== false && (
                      <td className="p-3 font-mono text-slate-700 dark:text-slate-300">{d.assigned_vehicle_reg || '-'}</td>
                    )}
                    {driverVisibleCols.shifts !== false && (
                      <td className="p-3 text-right font-mono text-slate-700 dark:text-slate-300">{d.shifts}</td>
                    )}
                    {driverVisibleCols.stops !== false && (
                      <td className="p-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                        {formatNumber(d.paidStops)}
                      </td>
                    )}
                    {driverVisibleCols.spr !== false && (
                      <td className="p-3 text-right font-mono">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded font-black text-xs ${
                          d.spr >= 140
                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                            : d.spr >= 100
                            ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                        }`}>
                          {d.spr.toFixed(1)} SPR
                        </span>
                      </td>
                    )}
                    {driverVisibleCols.completion !== false && (
                      <td className="p-3 text-right font-mono">
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold">{d.completionRate.toFixed(1)}%</span>
                      </td>
                    )}
                    {driverVisibleCols.earnings !== false && (
                      <td className="p-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                        {formatCurrency(d.grossPay)}
                      </td>
                    )}
                    {driverVisibleCols.pay_per_stop !== false && (
                      <td className="p-3 text-right font-mono text-slate-700 dark:text-slate-300">
                        {d.payPerStop > 0 ? formatCurrency(d.payPerStop) : '-'}
                      </td>
                    )}
                    {driverVisibleCols.status !== false && (
                      <td className="p-3 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                          {d.status || 'active'}
                        </span>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}