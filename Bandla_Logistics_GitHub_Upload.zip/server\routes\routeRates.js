const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

// List all route rates
router.get('/', async (req, res) => {
  try {
    const { depotId } = req.query;
    const db = getDb();
    let query = `
      SELECT r.*, dep.name as depot_name, dep.code as depot_code
      FROM route_rates r
      LEFT JOIN depots dep ON r.depot_id = dep.id
      WHERE 1=1
    `;
    const params = [];
    if (depotId) {
      params.push(depotId);
      query += ` AND r.depot_id = $${params.length}`;
    }
    query += ` ORDER BY r.route_code ASC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create or update route rate
router.post('/', async (req, res) => {
  try {
    const { routeCode, depotId, baseRatePerStop, excessParcelRate, minStopGuarantee, notes } = req.body;
    if (!routeCode || baseRatePerStop === undefined) {
      return res.status(400).json({ error: 'Route code and base rate per stop are required' });
    }
    const db = getDb();
    const id = uuidv4();
    const { rows } = await db.session.client.query(`
      INSERT INTO route_rates (
        id, route_code, depot_id, base_rate_per_stop, excess_parcel_rate, min_stop_guarantee, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      ON CONFLICT (route_code, depot_id) DO UPDATE SET
        base_rate_per_stop = EXCLUDED.base_rate_per_stop,
        excess_parcel_rate = EXCLUDED.excess_parcel_rate,
        min_stop_guarantee = EXCLUDED.min_stop_guarantee,
        notes = EXCLUDED.notes,
        updated_at = NOW()
      RETURNING *
    `, [
      id, routeCode.trim(), depotId || null, parseFloat(baseRatePerStop).toFixed(4),
      parseFloat(excessParcelRate || 0.05).toFixed(4), parseInt(minStopGuarantee || 100, 10), notes || null
    ]);
    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update single route rate
router.put('/:id', async (req, res) => {
  try {
    const { routeCode, depotId, baseRatePerStop, excessParcelRate, minStopGuarantee, notes } = req.body;
    const db = getDb();
    const { rows } = await db.session.client.query(`
      UPDATE route_rates SET
        route_code = COALESCE($1, route_code),
        depot_id = $2,
        base_rate_per_stop = COALESCE($3, base_rate_per_stop),
        excess_parcel_rate = COALESCE($4, excess_parcel_rate),
        min_stop_guarantee = COALESCE($5, min_stop_guarantee),
        notes = $6,
        updated_at = NOW()
      WHERE id = $7
      RETURNING *
    `, [
      routeCode, depotId, baseRatePerStop ? parseFloat(baseRatePerStop).toFixed(4) : undefined,
      excessParcelRate ? parseFloat(excessParcelRate).toFixed(4) : undefined,
      minStopGuarantee ? parseInt(minStopGuarantee, 10) : undefined,
      notes, req.params.id
    ]);
    if (!rows.length) return res.status(404).json({ error: 'Route rate not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete route rate
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    await db.session.client.query(`DELETE FROM route_rates WHERE id = $1`, [req.params.id]);
    res.json({ message: 'Route rate deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
