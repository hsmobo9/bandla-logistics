import React, { useState, useEffect } from 'react';
import { CreditCard, Plus, Search, Filter, Trash2, Edit, CheckCircle, Info } from 'lucide-react';
import { getCharges, getDrivers, createCharge, updateCharge, deleteCharge } from '../services/api';
import Modal from '../components/Modal';
import { formatCurrency, formatDate } from '../utils/formatters';

export default function Charges() {
  const [charges, setCharges] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('August 2026');
  const [selectedType, setSelectedType] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCharge, setEditingCharge] = useState(null);

  const [formData, setFormData] = useState({
    billingPeriod: 'August 2026',
    chargeDate: '2026-08-15',
    driverId: '',
    chargeType: 'Van Hire',
    amount: '135.00',
    notes: '',
    reason: ''
  });

  useEffect(() => {
    loadPrerequisites();
    loadCharges();
  }, [selectedMonth, selectedType]);

  const loadPrerequisites = async () => {
    try {
      const dList = await getDrivers();
      setDrivers(dList);
      if (dList.length > 0 && !formData.driverId) {
        setFormData(prev => ({ ...prev, driverId: dList[0].id }));
      }
    } catch (err) {
      console.error('Error loading drivers:', err);
    }
  };

  const loadCharges = async () => {
    try {
      setLoading(true);
      const params = {};
      if (selectedMonth) params.billingPeriod = selectedMonth;
      if (selectedType) params.chargeType = selectedType;
      const data = await getCharges(params);
      setCharges(data);
    } catch (err) {
      console.error('Error loading charges:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenAdd = () => {
    setEditingCharge(null);
    setFormData({
      billingPeriod: selectedMonth || 'August 2026',
      chargeDate: new Date().toISOString().split('T')[0],
      driverId: drivers[0]?.id || '',
      chargeType: 'Van Hire',
      amount: '135.00',
      notes: '',
      reason: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (charge) => {
    setEditingCharge(charge);
    setFormData({
      billingPeriod: charge.billing_period || charge.billing_month || 'August 2026',
      chargeDate: charge.charge_date ? charge.charge_date.split('T')[0] : new Date().toISOString().split('T')[0],
      driverId: charge.driver_id || '',
      chargeType: charge.charge_type || charge.cd_type || 'Van Hire',
      amount: String(Math.abs(parseFloat(charge.amount || 0))),
      notes: charge.notes || '',
      reason: ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        ...formData,
        amount: parseFloat(formData.amount)
      };
      if (editingCharge) {
        await updateCharge(editingCharge.id, payload);
      } else {
        await createCharge(payload);
      }
      setIsModalOpen(false);
      loadCharges();
    } catch (err) {
      console.warn('Error saving deduction/credit: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteCharge(id, 'Deduction record removed by Admin');
      loadCharges();
    } catch (err) {
      console.warn('Error deleting charge: ' + (err.response?.data?.error || err.message));
    }
  };

  const filtered = charges.filter(c => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      c.driver_name?.toLowerCase().includes(q) ||
      c.charge_type?.toLowerCase().includes(q) ||
      c.notes?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-rose-500/10 text-rose-600 dark:text-rose-400 rounded-xl">
            <CreditCard className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Charges, Deductions & Manual Credits</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">Manage Van Hire, Mobile Rentals, Fuel Repayments & Manual Credit Reimbursements (-£)</p>
          </div>
        </div>
        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-rose-600/20 flex items-center gap-1.5 transition cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Add Deduction / Credit
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm dark:shadow-lg flex flex-wrap gap-4 items-center justify-between">
        <div className="relative flex-1 min-w-[280px]">
          <Search className="w-4 h-4 text-slate-500 dark:text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by driver, deduction category, or notes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-rose-500"
          >
            <option value="">All Periods</option>
            <option value="August 2026">August 2026</option>
            <option value="July 2026">July 2026</option>
            <option value="June 2026">June 2026</option>
            <option value="May 2026">May 2026</option>
          </select>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-rose-500"
          >
            <option value="">All Categories</option>
            <option value="Van Hire">Van Hire</option>
            <option value="Mobile Rental">Mobile Rental</option>
            <option value="Advance Payment">Advance Payment</option>
            <option value="Vehicle Damage">Vehicle Damage</option>
            <option value="Property Damage">Property Damage</option>
            <option value="Parcel Claim">Parcel Claim</option>
            <option value="Fuel">Fuel Repayment</option>
            <option value="Manual Credit">Manual Credit / Reimbursement</option>
          </select>
        </div>
      </div>

      {/* Charges Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500 dark:text-slate-400">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-rose-500 mx-auto mb-2"></div>
            <span>Loading charges...</span>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center text-slate-500 dark:text-slate-400">
            <CreditCard className="w-10 h-10 mx-auto mb-2 text-slate-600" />
            <p className="font-semibold text-slate-900 dark:text-white">No Deductions or Credits Recorded</p>
            <p className="text-xs text-slate-500 mt-1">Add a new deduction or manual credit reimbursement above.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="p-3.5">Date / Billing Period</th>
                  <th className="p-3.5">Contractor Driver</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Notes & Description</th>
                  <th className="p-3.5 text-right">Amount (£)</th>
                  <th className="p-3.5 text-center">Invoice Lock Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                {filtered.map((c) => {
                  const amt = parseFloat(c.amount || 0);
                  const isCredit = amt < 0;
                  return (
                    <tr key={c.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                      <td className="p-3.5 text-slate-700 dark:text-slate-300 font-medium">
                        <span className="font-bold text-slate-900 dark:text-white block">{formatDate(c.charge_date)}</span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400">{c.billing_period || c.billing_month}</span>
                      </td>
                      <td className="p-3.5">
                        <span className="font-bold text-slate-900 dark:text-white block">{c.driver_name}</span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400">{c.driver_code || ''}</span>
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${
                          isCredit 
                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20' 
                            : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                        }`}>
                          {c.cd_type || c.charge_type}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-500 dark:text-slate-400 max-w-xs truncate">{c.notes || '-'}</td>
                      <td className="p-3.5 text-right font-bold text-sm">
                        {isCredit ? (
                          <span className="text-emerald-600 dark:text-emerald-400 font-black">+ £{Math.abs(amt).toFixed(2)} (Credit)</span>
                        ) : (
                          <span className="text-rose-600 dark:text-rose-400">- £{amt.toFixed(2)}</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {c.invoice_id ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                            Locked ({c.invoice_number})
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                            Pending Next Invoice
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {!c.invoice_id ? (
                            <>
                              <button
                                onClick={() => handleOpenEdit(c)}
                                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                                title="Edit Deduction/Credit"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDelete(c.id)}
                                className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-500/10 dark:hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-500/20 transition cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : (
                            <span className="text-[10px] text-slate-500 font-medium inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                              🔒 Locked
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCharge ? 'Edit Deduction / Credit Reimbursement' : 'Record Deduction or Credit Reimbursement'}
        maxWidth="max-w-md"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Contractor Driver</label>
            <select
              value={formData.driverId}
              onChange={(e) => setFormData({ ...formData, driverId: e.target.value })}
              required
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
            >
              {drivers.map(d => (
                <option key={d.id} value={d.id}>{d.full_name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Charge Date</label>
              <input
                type="date"
                value={formData.chargeDate}
                onChange={(e) => setFormData({ ...formData, chargeDate: e.target.value })}
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Billing Period</label>
              <input
                type="text"
                value={formData.billingPeriod}
                onChange={(e) => setFormData({ ...formData, billingPeriod: e.target.value })}
                placeholder="e.g. August 2026"
                required
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Category</label>
              <select
                value={formData.chargeType}
                onChange={(e) => setFormData({ ...formData, chargeType: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
              >
                <option value="Van Hire">Van Hire</option>
                <option value="Mobile Rental">Mobile Rental</option>
                <option value="Advance Payment">Advance Payment</option>
                <option value="Vehicle Damage">Vehicle Damage</option>
                <option value="Property Damage">Property Damage</option>
                <option value="Parcel Claim">Parcel Claim</option>
                <option value="Fuel">Fuel Repayment</option>
                <option value="Manual Credit">Manual Credit / Reimbursement (-)</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Amount (£)</label>
              <input
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
                placeholder="e.g. 135.00 or -50.00"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 rounded-xl text-[11px] text-slate-500 dark:text-slate-400 flex items-start gap-2">
            <Info className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0 mt-0.5" />
            <span>
              <strong>Tip:</strong> Use positive numbers (e.g. <span className="text-rose-600 dark:text-rose-400 font-mono">135.00</span>) for deductions, and negative numbers (e.g. <span className="text-emerald-600 dark:text-emerald-400 font-mono">-50.00</span>) for driver credits/reimbursements.
            </span>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">Notes / Description</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="e.g. Tool allowance reimbursement or weekly equipment charge"
              rows={2}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-rose-600/20 transition cursor-pointer"
            >
              Save Record
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}