const express = require('express');
const cors = require('cors');
const path = require('path');
const env = require('./config/env');
const { initDb } = require('./config/db');
const { migrate } = require('./db/migrate');
const { seedUsers } = require('./db/seedUsers');
const { seedDatabase } = require('./scripts/seed');
const { seedEdgeCases } = require('./scripts/seed_edge_cases');
const { seedRichPayrollData } = require('./scripts/seed_rich_payroll_data');
const { ingestHarishDatabase } = require('./scripts/ingestHarishDatabase');
const { authenticateToken, requireAdmin, requirePrivilege, shiftManagerRestricted } = require('./middleware/auth');

// Routers
const authRouter = require('./routes/auth');
const depotsRouter = require('./routes/depots');
const driversRouter = require('./routes/drivers');
const driverAvailabilityRouter = require('./routes/driverAvailability');
const routeRatesRouter = require('./routes/routeRates');
const vehiclesRouter = require('./routes/vehicles');
const shiftsRouter = require('./routes/shifts');
const chargesRouter = require('./routes/charges');
const invoicesRouter = require('./routes/invoices');
const maintenanceRouter = require('./routes/maintenance');
const suppliersRouter = require('./routes/suppliers');
const accidentsRouter = require('./routes/accidents');
const fuelRouter = require('./routes/fuel');
const auditLogsRouter = require('./routes/auditLogs');
const dashboardRouter = require('./routes/dashboard');
const analyticsRouter = require('./routes/analytics');
const systemRouter = require('./routes/system');
const usersRouter = require('./routes/users');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Static route for generated invoice PDFs (Authenticated)
app.use('/invoices/download', express.static(env.INVOICES_DIR));

// Public Routes
app.use('/api/auth', authRouter);

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '2.0.0',
    mode: 'cloud-web-app',
    database: 'postgresql',
    timestamp: new Date().toISOString()
  });
});

// ====================================================================
// RBAC PROTECTED API ROUTES
// ====================================================================

// 1. Shift Manager & Admin Routes (ShiftManager restricted to GET & POST)
app.use('/api/shifts', authenticateToken, shiftManagerRestricted, shiftsRouter);
app.use('/api/vehicles', authenticateToken, shiftManagerRestricted, vehiclesRouter);
app.use('/api/fuel', authenticateToken, fuelRouter);

// 2. Driver Availability (GET open to Shift Managers for Route Planning; modifications require Admin)
app.use('/api/driver-availability', authenticateToken, (req, res, next) => {
  if (req.method === 'GET') return next();
  return requireAdmin(req, res, next);
}, driverAvailabilityRouter);

// 3. Depots (GET allowed for selection, modifications restricted to Admin)
app.use('/api/depots', authenticateToken, (req, res, next) => {
  if (req.method === 'GET') return next();
  return requireAdmin(req, res, next);
}, depotsRouter);

// 4. Admin-Only Executive, Fleet CRM, Financial & Audit Routes
app.use('/api/dashboard', authenticateToken, requireAdmin, dashboardRouter);
app.use('/api/invoices', authenticateToken, requirePrivilege('view_payroll'), invoicesRouter);
app.use('/api/charges', authenticateToken, requirePrivilege('manage_deductions'), chargesRouter);
app.use('/api/route-rates', authenticateToken, requirePrivilege('manage_rate_cards'), routeRatesRouter);
app.use('/api/drivers', authenticateToken, requirePrivilege('manage_drivers'), driversRouter);
app.use('/api/suppliers', authenticateToken, requirePrivilege('manage_maintenance'), suppliersRouter);
app.use('/api/accidents', authenticateToken, requirePrivilege('manage_maintenance'), accidentsRouter);
app.use('/api/maintenance', authenticateToken, requirePrivilege('manage_maintenance'), maintenanceRouter);
app.use('/api/analytics', authenticateToken, analyticsRouter);
app.use(['/api/audit-logs', '/api/audit'], authenticateToken, requireAdmin, auditLogsRouter);
app.use('/api/system', authenticateToken, requireAdmin, systemRouter);
app.use('/api/users', authenticateToken, requireAdmin, usersRouter);

// Serve frontend build if present
const clientDistPath = path.join(__dirname, '../client/dist');
app.use(express.static(clientDistPath));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/invoices')) return next();
  const indexPath = path.join(clientDistPath, 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) res.status(404).send('Bandla Logistics Web App running. Client build pending.');
  });
});

async function startServer(preferredPort = env.PORT) {
  try {
    console.log('Initializing PostgreSQL connection & schema migrations...');
    await initDb();
    await migrate();
    await seedUsers();
    await seedDatabase();
    await seedEdgeCases();
    await seedRichPayrollData();
    await ingestHarishDatabase();

    return new Promise((resolve, reject) => {
      let currentPort = Number(preferredPort);
      const tryListen = () => {
        const server = app.listen(currentPort, () => {
          const boundPort = server.address().port;
          console.log(`====================================================`);
          console.log(`🚀 Bandla Logistics Cloud Web App running on port ${boundPort}`);
          console.log(`ðŸŒ Environment: ${env.NODE_ENV}`);
          console.log(`ðŸ“ Invoices Directory: ${env.INVOICES_DIR}`);
          console.log(`====================================================`);
          resolve({ server, port: boundPort });
        });

        server.on('error', (err) => {
          if (err.code === 'EADDRINUSE') {
            console.warn(`Port ${currentPort} is in use. Trying port ${currentPort + 1}...`);
            currentPort += 1;
            tryListen();
          } else {
            reject(err);
          }
        });
      };

      tryListen();
    });
  } catch (err) {
    console.error('Fatal Error starting server:', err);
    process.exit(1);
  }
}

if (require.main === module) {
  startServer();
}

module.exports = { app, startServer };