const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');
const { logAuditEvent } = require('../services/auditService');

// Helper: Check if month is locked for a driver
async function isChargeMonthLocked(client, driverId, billingMonth) {
  const check = await client.query(`
    SELECT id, invoice_number, status, payment_status
    FROM payroll_invoices
    WHERE driver_id = $1 
      AND (status = 'Locked' OR payment_status = 'Locked')
      AND billing_month = $2
    LIMIT 1
  `, [driverId, billingMonth]);

  return check.rows.length > 0 ? check.rows[0] : null;
}

// List charges & deductions
router.get('/', async (req, res) => {
  try {
    const { driverId, billingPeriod, billingMonth, chargeType, cdType, invoiceStatus } = req.query;
    const db = getDb();
    let query = `
      SELECT c.*, 
        COALESCE(c.billing_month, c.billing_period) as billing_month,
        COALESCE(c.cd_type, c.charge_type) as cd_type,
        d.full_name as driver_name, d.driver_code, v.model_number as vehicle_model, inv.invoice_number
      FROM charges_and_deductions c
      JOIN drivers d ON c.driver_id = d.id
      LEFT JOIN vehicles v ON c.vehicle_id = v.id
      LEFT JOIN payroll_invoices inv ON c.invoice_id = inv.id
      WHERE 1=1
    `;
    const params = [];
    if (driverId) {
      params.push(driverId);
      query += ` AND c.driver_id = $${params.length}`;
    }
    const targetPeriod = billingMonth || billingPeriod;
    if (targetPeriod) {
      params.push(targetPeriod);
      query += ` AND (c.billing_month = $${params.length} OR c.billing_period = $${params.length})`;
    }
    const targetType = cdType || chargeType;
    if (targetType) {
      params.push(targetType);
      query += ` AND (c.cd_type = $${params.length} OR c.charge_type = $${params.length})`;
    }
    if (invoiceStatus === 'unbilled') {
      query += ` AND c.invoice_id IS NULL`;
    } else if (invoiceStatus === 'billed') {
      query += ` AND c.invoice_id IS NOT NULL`;
    }

    query += ` ORDER BY c.charge_date DESC, d.full_name ASC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create charge or credit (Signed Decimal: (+) deduction, (-) credit/reimbursement)
router.post('/', async (req, res) => {
  try {
    const {
      billingMonth, billingPeriod, chargeDate, date, driverId,
      cdType, chargeType, amount, vehicleId, notes, reason
    } = req.body;

    const monthVal = (billingMonth || billingPeriod || '').trim();
    const dateVal = chargeDate || date;
    const typeVal = (cdType || chargeType || '').trim();

    if (!monthVal || !dateVal || !driverId || !typeVal || amount === undefined || isNaN(parseFloat(amount))) {
      return res.status(400).json({ error: 'Billing month, date, driver, charge type and valid numeric amount are required.' });
    }

    const db = getDb();
    const client = db.session.client;

    // Check if month is locked
    const lockedInv = await isChargeMonthLocked(client, driverId, monthVal);
    if (lockedInv) {
      return res.status(403).json({ error: `Cannot add deduction/credit: Invoice #${lockedInv.invoice_number} for ${monthVal} is LOCKED.` });
    }

    const signedAmount = parseFloat(amount).toFixed(2);
    const id = uuidv4();

    const { rows } = await client.query(`
      INSERT INTO charges_and_deductions (
        id, billing_month, billing_period, charge_date, driver_id, cd_type, charge_type, amount, vehicle_id, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *
    `, [
      id, monthVal, monthVal, dateVal, driverId, typeVal, typeVal,
      signedAmount, vehicleId || null, notes || null
    ]);

    // Record Audit Log
    await logAuditEvent(req, {
      actionType: 'CREATE_CHARGE',
      tableAffected: 'charges_and_deductions',
      recordId: id,
      newValue: { billing_month: monthVal, cd_type: typeVal, amount: signedAmount, notes },
      reason: reason || `Created ${parseFloat(signedAmount) < 0 ? 'Credit/Reimbursement' : 'Deduction'} of £${signedAmount}`
    });

    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update charge or credit
router.put('/:id', async (req, res) => {
  try {
    const {
      billingMonth, billingPeriod, chargeDate, date, driverId,
      cdType, chargeType, amount, vehicleId, notes, reason
    } = req.body;

    const db = getDb();
    const client = db.session.client;

    const check = await client.query(`SELECT * FROM charges_and_deductions WHERE id = $1`, [req.params.id]);
    if (!check.rows.length) return res.status(404).json({ error: 'Charge record not found' });
    const existing = check.rows[0];

    const monthVal = billingMonth || billingPeriod || existing.billing_month;
    const targetDriver = driverId || existing.driver_id;

    // Check if month is locked
    const lockedInv = await isChargeMonthLocked(client, targetDriver, monthVal);
    if (lockedInv) {
      return res.status(403).json({ error: `Cannot modify deduction/credit: Invoice #${lockedInv.invoice_number} for ${monthVal} is LOCKED.` });
    }

    const dateVal = chargeDate || date || existing.charge_date;
    const typeVal = cdType || chargeType || existing.cd_type;
    const signedAmount = amount !== undefined && !isNaN(parseFloat(amount)) ? parseFloat(amount).toFixed(2) : parseFloat(existing.amount).toFixed(2);

    const { rows } = await client.query(`
      UPDATE charges_and_deductions SET
        billing_month = COALESCE($1, billing_month),
        billing_period = COALESCE($1, billing_period),
        charge_date = COALESCE($2, charge_date),
        driver_id = COALESCE($3, driver_id),
        cd_type = COALESCE($4, cd_type),
        charge_type = COALESCE($4, charge_type),
        amount = COALESCE($5, amount),
        vehicle_id = $6,
        notes = $7,
        updated_at = NOW()
      WHERE id = $8
      RETURNING *
    `, [
      monthVal, dateVal, targetDriver, typeVal, signedAmount,
      vehicleId || null, notes, req.params.id
    ]);

    // Record Audit Log
    await logAuditEvent(req, {
      actionType: 'EDIT_CHARGE',
      tableAffected: 'charges_and_deductions',
      recordId: req.params.id,
      previousValue: { cd_type: existing.cd_type, amount: existing.amount, notes: existing.notes },
      newValue: { cd_type: typeVal, amount: signedAmount, notes },
      reason: reason || 'Updated deduction/credit details'
    });

    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete charge
router.delete('/:id', async (req, res) => {
  try {
    const { reason } = req.body || {};
    const db = getDb();
    const client = db.session.client;

    const check = await client.query(`SELECT * FROM charges_and_deductions WHERE id = $1`, [req.params.id]);
    if (!check.rows.length) return res.status(404).json({ error: 'Charge record not found' });
    const existing = check.rows[0];

    // Check if month is locked
    const lockedInv = await isChargeMonthLocked(client, existing.driver_id, existing.billing_month);
    if (lockedInv) {
      return res.status(403).json({ error: `Cannot delete deduction/credit: Invoice #${lockedInv.invoice_number} for ${existing.billing_month} is LOCKED.` });
    }

    await client.query(`DELETE FROM charges_and_deductions WHERE id = $1`, [req.params.id]);

    // Record Audit Log
    await logAuditEvent(req, {
      actionType: 'DELETE_CHARGE',
      tableAffected: 'charges_and_deductions',
      recordId: req.params.id,
      previousValue: { cd_type: existing.cd_type, amount: existing.amount, notes: existing.notes },
      reason: reason || `Deleted charge: ${existing.cd_type} (£${existing.amount})`
    });

    res.json({ message: 'Charge record deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;