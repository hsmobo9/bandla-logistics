const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

/**
 * Inserts an audit trail event into the audit_logs table.
 * @param {object} req - Express request object (contains req.user from auth middleware)
 * @param {object} param1 - Audit metadata
 */
async function logAuditEvent(req, { actionType, tableAffected, recordId, previousValue, newValue, reason }) {
  try {
    const db = getDb();
    const id = uuidv4();
    const userId = req?.user?.id || null;
    const userName = req?.user?.fullName || req?.user?.username || 'Admin (System)';
    const userEmail = req?.user?.email || 'admin@bandlalogistics.co.uk';

    const prevStr = typeof previousValue === 'object' ? JSON.stringify(previousValue) : (previousValue !== undefined ? String(previousValue) : null);
    const newStr = typeof newValue === 'object' ? JSON.stringify(newValue) : (newValue !== undefined ? String(newValue) : null);

    await db.session.client.query(`
      INSERT INTO audit_logs (
        id, user_id, user_name, user_email, action_type, table_affected, record_id, previous_value, new_value, reason, created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
    `, [
      id, userId, userName, userEmail,
      actionType, tableAffected, recordId || null,
      prevStr, newStr, reason || null
    ]);
  } catch (err) {
    console.error('[AuditService] Failed to record audit log:', err.message);
  }
}

module.exports = {
  logAuditEvent
};