const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

// List all depots
router.get('/', async (req, res) => {
  try {
    const db = getDb();
    const { rows } = await db.session.client.query(`SELECT * FROM depots ORDER BY name ASC`);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create depot
router.post('/', async (req, res) => {
  try {
    const { code, name, address } = req.body;
    if (!code || !name) return res.status(400).json({ error: 'Code and Name are required' });
    const db = getDb();
    const id = uuidv4();
    const { rows } = await db.session.client.query(
      `INSERT INTO depots (id, code, name, address) VALUES ($1, $2, $3, $4) RETURNING *`,
      [id, code.toUpperCase(), name, address || '']
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update depot
router.put('/:id', async (req, res) => {
  try {
    const { code, name, address } = req.body;
    const db = getDb();
    const { rows } = await db.session.client.query(
      `UPDATE depots SET code = COALESCE($1, code), name = COALESCE($2, name), address = COALESCE($3, address), updated_at = NOW() WHERE id = $4 RETURNING *`,
      [code, name, address, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Depot not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
