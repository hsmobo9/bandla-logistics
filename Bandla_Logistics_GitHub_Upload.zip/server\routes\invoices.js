const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const env = require('../config/env');
const { getDb } = require('../config/db');
const { generateMonthlyInvoice } = require('../services/calculationService');
const { generateInvoicePdf } = require('../services/invoicePdfService');
const { logAuditEvent } = require('../services/auditService');

// List invoices
router.get('/', async (req, res) => {
  try {
    const { billingMonth, driverId, status } = req.query;
    const db = getDb();
    let query = `
      SELECT i.*, 
        COALESCE(i.status, i.payment_status) as status,
        d.full_name as driver_name, d.driver_code, d.assigned_vehicle_reg, d.is_vat_registered, d.vat_number, d.phone as driver_phone
      FROM payroll_invoices i
      JOIN drivers d ON i.driver_id = d.id
      WHERE 1=1
    `;
    const params = [];
    if (billingMonth) {
      params.push(billingMonth);
      query += ` AND i.billing_month = $${params.length}`;
    }
    if (driverId) {
      params.push(driverId);
      query += ` AND i.driver_id = $${params.length}`;
    }
    if (status) {
      params.push(status);
      query += ` AND (i.status = $${params.length} OR i.payment_status = $${params.length})`;
    }

    query += ` ORDER BY i.billing_end_date DESC, i.created_at DESC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single invoice with itemized shift breakdowns and deductions
router.get('/:id', async (req, res) => {
  try {
    const db = getDb();
    const invRes = await db.session.client.query(`
      SELECT i.*, 
        COALESCE(i.status, i.payment_status) as status,
        d.full_name as driver_name, d.driver_code, d.assigned_vehicle_reg, d.is_vat_registered, d.vat_number, d.phone as driver_phone
      FROM payroll_invoices i
      JOIN drivers d ON i.driver_id = d.id
      WHERE i.id = $1
    `, [req.params.id]);

    if (!invRes.rows.length) return res.status(404).json({ error: 'Invoice not found' });
    const invoice = invRes.rows[0];

    const shiftsRes = await db.session.client.query(`
      SELECT s.*, dep.name as depot_name,
        CASE 
          WHEN s.dispatched_stops > 0 THEN ROUND(((s.dispatched_stops - s.paid_stops)::numeric / s.dispatched_stops) * 100, 2)
          ELSE 0 
        END as fail_percentage
      FROM daily_shifts s
      LEFT JOIN depots dep ON s.depot_id = dep.id
      WHERE s.invoice_id = $1
      ORDER BY s.shift_date ASC
    `, [req.params.id]);

    const chargesRes = await db.session.client.query(`
      SELECT * FROM charges_and_deductions
      WHERE invoice_id = $1
      ORDER BY charge_date ASC
    `, [req.params.id]);

    res.json({
      ...invoice,
      shifts: shiftsRes.rows || [],
      charges: chargesRes.rows || []
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Generate monthly invoice
router.post(['/generate', '/generate-monthly'], async (req, res) => {
  try {
    const { driverId, billingMonth, billingStartDate, billingEndDate, invoiceDate } = req.body;
    if (!driverId || !billingMonth || !billingStartDate || !billingEndDate) {
      return res.status(400).json({ error: 'driverId, billingMonth, billingStartDate, and billingEndDate are required.' });
    }

    const result = await generateMonthlyInvoice({
      driverId,
      billingMonth,
      billingStartDate,
      billingEndDate,
      invoiceDate
    });

    // Generate PDF
    try {
      await generateInvoicePdf(result.id);
    } catch (pdfErr) {
      console.warn('PDF generation deferred:', pdfErr.message);
    }

    // Log Audit Event
    await logAuditEvent(req, {
      actionType: 'INVOICE_GENERATED',
      tableAffected: 'payroll_invoices',
      recordId: result.id,
      newValue: { invoiceNumber: result.invoiceNumber, netPayable: result.netPayable, status: 'Draft' },
      reason: `Generated ${billingMonth} invoice for driver`
    });

    res.status(201).json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Generate/Regenerate PDF for an invoice
router.post('/:id/pdf', async (req, res) => {
  try {
    const pdfResult = await generateInvoicePdf(req.params.id);
    res.json({ message: 'PDF generated successfully', ...pdfResult });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Download PDF invoice (always fresh generation)
router.get('/:id/pdf/download', async (req, res) => {
  try {
    const result = await generateInvoicePdf(req.params.id);
    res.download(result.pdfPath, result.pdfFileName);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update invoice state machine: Draft -> Checked -> Approved -> Locked (or Paid / Cancelled)
router.put('/:id/lock', async (req, res) => {
  try {
    const db = getDb();
    const { rows } = await db.session.client.query(
      "UPDATE payroll_invoices SET status = 'Locked', payment_status = 'Locked', updated_at = NOW() WHERE id = $1 RETURNING *",
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Invoice not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/:id/status', async (req, res) => {
  try {
    const { status, reason } = req.body;
    const validStates = ['Draft', 'Checked', 'Approved', 'Locked', 'Paid', 'Cancelled'];
    if (!validStates.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Valid states are: ${validStates.join(', ')}` });
    }

    const db = getDb();
    const client = db.session.client;

    const existing = await client.query(`
      SELECT i.*, d.full_name as driver_name
      FROM payroll_invoices i
      JOIN drivers d ON i.driver_id = d.id
      WHERE i.id = $1
    `, [req.params.id]);

    if (!existing.rows.length) return res.status(404).json({ error: 'Invoice not found' });
    const inv = existing.rows[0];

    if (status === 'Cancelled') {
      // Unlock all associated shifts and charges
      await client.query(`UPDATE daily_shifts SET invoice_id = NULL WHERE invoice_id = $1`, [req.params.id]);
      await client.query(`UPDATE charges_and_deductions SET invoice_id = NULL, is_settled = FALSE WHERE invoice_id = $1`, [req.params.id]);
    }

    const { rows } = await client.query(`
      UPDATE payroll_invoices SET
        status = $1,
        payment_status = $1,
        updated_at = NOW()
      WHERE id = $2
      RETURNING *
    `, [status, req.params.id]);

    // Record Audit Log
    await logAuditEvent(req, {
      actionType: 'INVOICE_STATUS_CHANGE',
      tableAffected: 'payroll_invoices',
      recordId: inv.id,
      previousValue: { status: inv.status || inv.payment_status },
      newValue: { status },
      reason: reason || `Invoice status changed from ${inv.status || inv.payment_status} to ${status}`
    });

    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// WhatsApp Share URL Generator
router.get('/:id/whatsapp-url', async (req, res) => {
  try {
    const db = getDb();
    const invRes = await db.session.client.query(`
      SELECT i.*, d.full_name as driver_name, d.phone as driver_phone
      FROM payroll_invoices i
      JOIN drivers d ON i.driver_id = d.id
      WHERE i.id = $1
    `, [req.params.id]);

    if (!invRes.rows.length) return res.status(404).json({ error: 'Invoice not found' });
    const inv = invRes.rows[0];

    const cleanPhone = (inv.driver_phone || '').replace(/[^0-9]/g, '');
    const phoneWithCountry = cleanPhone.startsWith('0') ? `44${cleanPhone.slice(1)}` : cleanPhone;

    const message = `*Bandla Logistics - Payroll Statement*\n\n` +
      `Hello ${inv.driver_name},\n` +
      `Your payroll statement for *${inv.billing_month}* is ready.\n\n` +
      `📄 *Invoice No:* ${inv.invoice_number}\n` +
      `🗓️ *Days Worked:* ${inv.days_worked} shifts\n` +
      `📦 *Paid Stops:* ${inv.total_paid_stops} stops\n` +
      `💷 *Gross Earnings:* £${parseFloat(inv.gross_earnings).toFixed(2)}\n` +
      `➖ *Deductions / Credits:* £${parseFloat(inv.total_deductions).toFixed(2)}\n` +
      `💰 *Net Payable:* £${parseFloat(inv.net_payable).toFixed(2)}\n\n` +
      `Please contact Head Office for any inquiries. Thank you!`;

    const encoded = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${phoneWithCountry}?text=${encoded}`;

    res.json({
      driverPhone: inv.driver_phone,
      formattedPhone: phoneWithCountry,
      message,
      whatsappUrl
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// ==========================================
// BATCH INVOICE ZIP DOWNLOAD & BULK ACTIONS
// ==========================================
const archiverPkg = require('archiver');
const archiver = archiverPkg.default || ((type, opt) => new archiverPkg.ZipArchive(opt));

// Batch ZIP download (POST with body or GET with query params)
router.all('/batch/download-zip', async (req, res) => {
  try {
    const db = getDb();
    let targetIds = [];
    let billingMonth = req.body?.billingMonth || req.query?.billingMonth;

    if (req.body?.invoiceIds && Array.isArray(req.body.invoiceIds) && req.body.invoiceIds.length) {
      targetIds = req.body.invoiceIds;
    } else if (req.query?.ids) {
      targetIds = req.query.ids.split(',').map(s => s.trim()).filter(Boolean);
    }

    if (!targetIds.length) {
      let q = `SELECT id FROM payroll_invoices WHERE 1=1`;
      const params = [];
      if (billingMonth && billingMonth !== 'all' && billingMonth !== 'ALL') {
        params.push(billingMonth);
        q += ` AND billing_month = $${params.length}`;
      }
      const allRes = await db.session.client.query(q, params);
      targetIds = allRes.rows.map(r => r.id);
    }

    if (!targetIds.length) {
      return res.status(404).json({ error: 'No invoices found for the selected criteria' });
    }

    const cleanMonth = (billingMonth && billingMonth !== 'all') ? billingMonth.replace(/[^a-zA-Z0-9]/g, '_') : 'Batch';
    const zipFileName = `Bandla_Invoices_${cleanMonth}_${Date.now()}.zip`;

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${zipFileName}"`);

    const archive = archiver('zip', { zlib: { level: 9 } });

    archive.on('error', (err) => {
      console.error('Archive error:', err);
      if (!res.headersSent) res.status(500).json({ error: err.message });
    });

    archive.pipe(res);

    for (const invId of targetIds) {
      try {
        const pdfData = await generateInvoicePdf(invId);
        if (pdfData && fs.existsSync(pdfData.pdfPath)) {
          archive.file(pdfData.pdfPath, { name: pdfData.pdfFileName });
        }
      } catch (pdfErr) {
        console.warn(`Could not generate PDF for invoice ${invId}:`, pdfErr.message);
      }
    }

    await archive.finalize();
  } catch (err) {
    console.error('Batch zip download fatal error:', err);
    if (!res.headersSent) {
      res.status(500).json({ error: err.message });
    }
  }
});

// Batch Status Update
router.post('/batch/status', async (req, res) => {
  try {
    const { invoiceIds, status, reason } = req.body;
    if (!invoiceIds || !Array.isArray(invoiceIds) || !invoiceIds.length) {
      return res.status(400).json({ error: 'No invoice IDs provided' });
    }
    const validStates = ['Draft', 'Checked', 'Approved', 'Locked', 'Paid', 'Cancelled'];
    if (!validStates.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Valid states: ${validStates.join(', ')}` });
    }

    const db = getDb();
    const client = db.session.client;
    let updatedCount = 0;

    for (const id of invoiceIds) {
      if (status === 'Cancelled') {
        await client.query(`UPDATE daily_shifts SET invoice_id = NULL WHERE invoice_id = $1`, [id]);
        await client.query(`UPDATE charges_and_deductions SET invoice_id = NULL, is_settled = FALSE WHERE invoice_id = $1`, [id]);
      }
      const updateRes = await client.query(`
        UPDATE payroll_invoices SET status = $1, payment_status = $1, updated_at = NOW() WHERE id = $2 RETURNING id
      `, [status, id]);
      if (updateRes.rows.length) {
        updatedCount++;
        await logAuditEvent(req, {
          actionType: 'BATCH_INVOICE_STATUS_CHANGE',
          tableAffected: 'payroll_invoices',
          recordId: id,
          newValue: { status },
          reason: reason || `Batch status updated to ${status}`
        });
      }
    }

    res.json({ message: `Successfully updated ${updatedCount} invoices to ${status}`, updatedCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;