const { startServer } = require('../index');
const { initDb, getDb } = require('../config/db');
const { v4: uuidv4 } = require('uuid');

async function apiRequest(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    data = null;
  }
  return { status: res.status, data };
}

async function runOperationsTestSuite() {
  console.log('========================================================================');
  console.log('PHASE 2 VERIFICATION: OPERATIONS, DISPATCH, FLEET & CRM');
  console.log('========================================================================\n');

  const { server, port } = await startServer(4007);
  const baseURL = `http://localhost:${port}`;
  const testResults = [];
  const recordTest = (name, passed, details = '') => {
    testResults.push({ Test: name, Status: passed ? 'PASSED ✅' : 'FAILED ❌', Details: details });
    console.log(`[${passed ? 'PASS' : 'FAIL'}] ${name} ${details ? '(' + details + ')' : ''}`);
  };

  try {
    // 1. Auth Logins
    const adminLoginRes = await apiRequest(`${baseURL}/api/auth/login`, {
      method: 'POST',
      body: { emailOrUsername: 'admin@bandlalogistics.co.uk', password: 'AdminPass123!' }
    });
    const adminToken = adminLoginRes.data?.token;

    const managerLoginRes = await apiRequest(`${baseURL}/api/auth/login`, {
      method: 'POST',
      body: { emailOrUsername: 'manager@bandlalogistics.co.uk', password: 'ManagerPass123!' }
    });
    const managerToken = managerLoginRes.data?.token;

    recordTest('Authentication Tokens Issued', adminToken && managerToken, 'Admin & ShiftManager Tokens Active');

    // 2. Step 1: Driver Register & Soft Delete
    const driverRes = await apiRequest(`${baseURL}/api/drivers`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        driverCode: 'DR8801',
        fullName: 'Marcus Vance (Compliance Test)',
        phone: '07123456789',
        licenseNumber: 'VANCE901015AB123',
        licenseExpiry: '2028-12-31',
        passDate: '2015-06-15',
        dvlaPoints: 3,
        isVatRegistered: true,
        vatNumber: 'GB987654321',
        status: 'active'
      }
    });
    const createdDriver = driverRes.data;
    recordTest('Step 1: Driver Created with License & DVLA Points', driverRes.status === 201 && createdDriver?.license_number === 'VANCE901015AB123' && createdDriver?.dvla_points === 3, `ID: ${createdDriver?.id}`);

    // Soft delete toggle test
    const softDelDriverRes = await apiRequest(`${baseURL}/api/drivers/${createdDriver.id}/toggle-active`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    recordTest('Step 1: Driver Soft Delete Toggle (Active -> Inactive)', softDelDriverRes.status === 200 && softDelDriverRes.data?.driver?.is_active === false, 'is_active: false');

    // Reactivate driver
    await apiRequest(`${baseURL}/api/drivers/${createdDriver.id}/toggle-active`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${adminToken}` }
    });

    // 3. Step 1: Holiday & Unavailability Planner
    const holidayRes = await apiRequest(`${baseURL}/api/driver-availability`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        driverId: createdDriver.id,
        startDate: '2026-09-01',
        endDate: '2026-09-07',
        status: 'Holiday',
        notes: 'Annual summer vacation'
      }
    });
    const holidayId = holidayRes.data?.id;
    recordTest('Step 1: Log Driver Holiday Block', holidayRes.status === 201 && holidayRes.data?.status === 'Holiday', `Dates: 2026-09-01 to 2026-09-07`);

    // Check holiday availability endpoint (used by Weekly Planner)
    const checkAvailRes = await apiRequest(`${baseURL}/api/driver-availability/check?date=2026-09-03`, {
      headers: { Authorization: `Bearer ${managerToken}` }
    });
    const isDriverBlocked = checkAvailRes.data?.unavailableDriverIds?.includes(createdDriver.id);
    recordTest('Step 1 & 3: Weekly Planner Driver Availability Filter', checkAvailRes.status === 200 && isDriverBlocked, `Driver blocked on 2026-09-03`);

    // 4. Step 2: Fleet Compliance & Countdown Badges
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + 15); // Amber (15 days left)
    const amberMotDate = futureDate.toISOString().split('T')[0];

    const vehicleRes = await apiRequest(`${baseURL}/api/vehicles`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        modelNumber: 'Mercedes Sprinter 314 CDI',
        registrationNumber: 'DS74 COMP',
        category: 'Van',
        motExpiry: amberMotDate,
        taxExpiry: '2027-01-01',
        insuranceExpiry: '2027-01-01',
        currentMileage: 54200,
        nextServiceMileage: 54800, // 600 miles remaining -> Amber
        depotLocation: 'Leicester Depot'
      }
    });
    const createdVehicle = vehicleRes.data;
    const isAmberMOT = createdVehicle?.compliance?.mot?.status === 'amber';
    const isAmberService = createdVehicle?.compliance?.service?.status === 'amber';
    recordTest('Step 2: Fleet MOT & Service Amber Warning Badges', vehicleRes.status === 201 && isAmberMOT && isAmberService, `MOT: ${createdVehicle?.compliance?.mot?.days}d, Service: ${createdVehicle?.compliance?.service?.milesRemaining}mi`);

    // Soft delete vehicle toggle
    const toggleVehRes = await apiRequest(`${baseURL}/api/vehicles/${createdVehicle.id}/toggle-active`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    recordTest('Step 2: Vehicle Soft Delete Toggle', toggleVehRes.status === 200 && toggleVehRes.data?.vehicle?.is_active === false, 'Decommissioned soft toggle');

    // Reactivate vehicle
    await apiRequest(`${baseURL}/api/vehicles/${createdVehicle.id}/toggle-active`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${adminToken}` }
    });

    // 5. Step 3: Multi-Depot Weekly Route Planner Shift Allocation
    const shiftRes = await apiRequest(`${baseURL}/api/shifts`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${managerToken}` },
      body: {
        shiftDate: '2026-08-31',
        driverId: createdDriver.id,
        vehicleId: createdVehicle.id,
        routeCode: 'LEI-101',
        dispatchedStops: 125,
        paidStops: 125,
        totalParcels: 140,
        appliedBaseRate: 2.15,
        notes: 'Weekly planner rota assignment'
      }
    });
    recordTest('Step 3: Shift Manager Route Allocation in Planner', shiftRes.status === 201 && shiftRes.data?.route_code === 'LEI-101', `Shift ID: ${shiftRes.data?.id}`);

    // 6. Step 4: Suppliers Master CRM
    const supplierRes = await apiRequest(`${baseURL}/api/suppliers`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        name: 'Midlands Commercial Fleet Garage Ltd',
        contactDetails: '0116 288 9900 / service@midlandsfleet.co.uk',
        servicesProvided: 'Class 7 MOT, Commercial Brake Servicing & Tyres',
        isActive: true
      }
    });
    const createdSupplier = supplierRes.data;
    recordTest('Step 4: Garage Supplier Created', supplierRes.status === 201 && createdSupplier?.name?.includes('Midlands Commercial'), `Supplier ID: ${createdSupplier?.id}`);

    // 7. Step 4: Maintenance Logs
    const maintRes = await apiRequest(`${baseURL}/api/maintenance`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        vehicleId: createdVehicle.id,
        supplierId: createdSupplier.id,
        date: '2026-08-25',
        laborCost: 150.00,
        partsCost: 220.50,
        issueCategory: 'Scheduled Maintenance',
        notes: 'Full service inspection and oil/filter change'
      }
    });
    recordTest('Step 4: Maintenance Log with Labor & Parts Tracking', maintRes.status === 201 && parseFloat(maintRes.data?.total_cost) === 370.50, `Total Cost: £${maintRes.data?.total_cost}`);

    // 8. Step 4: Accident & Claims Register
    const accidentRes = await apiRequest(`${baseURL}/api/accidents`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        vehicleId: createdVehicle.id,
        driverId: createdDriver.id,
        date: '2026-08-24',
        description: 'Minor wing mirror clip with delivery gate in Leicester',
        insuranceClaimStatus: 'Under Investigation',
        estimatedDamageCost: 185.00,
        thirdPartyDetails: 'Depot Gate #2'
      }
    });
    recordTest('Step 4: Accident & Claim Status Recorded', accidentRes.status === 201 && accidentRes.data?.insurance_claim_status === 'Under Investigation', `Claim ID: ${accidentRes.data?.id}`);

    // 9. RBAC Boundary Enforcement
    const unauthorizedMaint = await apiRequest(`${baseURL}/api/maintenance`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${managerToken}` },
      body: { vehicleId: createdVehicle.id, date: '2026-08-25' }
    });
    recordTest('RBAC: ShiftManager BLOCKED from Maintenance Ledger', unauthorizedMaint.status === 403, `Status: ${unauthorizedMaint.status}`);

    const unauthorizedSupplier = await apiRequest(`${baseURL}/api/suppliers`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${managerToken}` },
      body: { name: 'Illegal Supplier' }
    });
    recordTest('RBAC: ShiftManager BLOCKED from Supplier CRM', unauthorizedSupplier.status === 403, `Status: ${unauthorizedSupplier.status}`);

    // Cleanup test records
    const db = getDb();
    const client = db.session.client;
    await client.query('DELETE FROM accident_logs WHERE id = $1', [accidentRes.data?.id]);
    await client.query('DELETE FROM maintenance_logs WHERE id = $1', [maintRes.data?.id]);
    await client.query('DELETE FROM suppliers WHERE id = $1', [createdSupplier?.id]);
    await client.query('DELETE FROM daily_shifts WHERE id = $1', [shiftRes.data?.id]);
    await client.query('DELETE FROM driver_availability WHERE id = $1', [holidayId]);
    await client.query('DELETE FROM vehicles WHERE id = $1', [createdVehicle?.id]);
    await client.query('DELETE FROM drivers WHERE id = $1', [createdDriver?.id]);

    console.log('\n========================================================================');
    console.log('COMPLETE PHASE 2 VERIFICATION TABLE');
    console.log('========================================================================');
    console.table(testResults);

  } finally {
    server.close();
  }
}

runOperationsTestSuite().then(() => process.exit(0)).catch(err => {
  console.error('Fatal Error in Test Suite:', err);
  process.exit(1);
});