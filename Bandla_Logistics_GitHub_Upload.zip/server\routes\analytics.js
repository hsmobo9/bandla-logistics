const express = require('express');
const router = express.Router();
const { getDb } = require('../config/db');

router.get('/performance', async (req, res) => {
  try {
    const db = getDb();
    const client = db.session.client;

    // 1. Vehicles Performance & Running Cost per Mile/KM
    const vehiclePerfRes = await client.query(`
      WITH fuel_stats AS (
        SELECT 
          vehicle_id,
          COUNT(*) as fuel_entries_count,
          COALESCE(SUM(liters_filled), 0) as total_liters,
          COALESCE(SUM(total_cost), 0) as total_fuel_cost,
          COALESCE(MAX(odometer_reading), 0) as max_odometer,
          COALESCE(MIN(odometer_reading), 0) as min_odometer
        FROM fuel_logs
        GROUP BY vehicle_id
      ),
      maint_stats AS (
        SELECT 
          vehicle_id,
          COUNT(id) as maint_jobs_count,
          COALESCE(SUM(total_cost), 0) as total_maint_cost,
          COALESCE(SUM(labor_cost), 0) as total_labor_cost,
          COALESCE(SUM(parts_cost), 0) as total_parts_cost
        FROM maintenance_logs
        GROUP BY vehicle_id
      )
      SELECT 
        v.id,
        v.registration_number,
        v.equipment_code,
        v.model_number,
        v.category,
        v.depot_location,
        v.status,
        v.is_active,
        COALESCE(v.current_mileage, 0) as current_mileage,
        COALESCE(f.fuel_entries_count, 0) as fuel_entries_count,
        COALESCE(f.total_liters, 0) as total_fuel_liters,
        COALESCE(f.total_fuel_cost, 0) as total_fuel_cost,
        COALESCE(f.max_odometer, 0) as max_odometer,
        COALESCE(f.min_odometer, 0) as min_odometer,
        COALESCE(m.maint_jobs_count, 0) as maint_jobs_count,
        COALESCE(m.total_maint_cost, 0) as total_maint_cost,
        COALESCE(m.total_labor_cost, 0) as total_labor_cost,
        COALESCE(m.total_parts_cost, 0) as total_parts_cost
      FROM vehicles v
      LEFT JOIN fuel_stats f ON f.vehicle_id = v.id
      LEFT JOIN maint_stats m ON m.vehicle_id = v.id
      WHERE v.is_active = true
      ORDER BY (COALESCE(f.total_fuel_cost, 0) + COALESCE(m.total_maint_cost, 0)) DESC
    `);

    // 2. Drivers Performance & Stops per Route / Pay Efficiency
    const driverPerfRes = await client.query(`
      WITH shift_stats AS (
        SELECT 
          driver_id,
          COUNT(*) as total_shifts,
          COALESCE(SUM(dispatched_stops), 0) as total_dispatched_stops,
          COALESCE(SUM(paid_stops), 0) as total_paid_stops,
          COALESCE(SUM(gross_shift_total), 0) as total_gross_pay,
          COALESCE(SUM(top_up_pay), 0) as total_top_up_pay
        FROM daily_shifts
        GROUP BY driver_id
      ),
      driver_fuel AS (
        SELECT 
          driver_id,
          COUNT(*) as refuel_count,
          COALESCE(SUM(liters_filled), 0) as total_liters,
          COALESCE(SUM(total_cost), 0) as total_fuel_cost
        FROM fuel_logs
        WHERE driver_id IS NOT NULL
        GROUP BY driver_id
      )
      SELECT 
        d.id,
        d.driver_code,
        d.full_name,
        d.phone,
        d.status,
        d.is_active,
        d.assigned_vehicle_reg,
        COALESCE(dep.name, 'Leicester') as depot_name,
        COALESCE(s.total_shifts, 0) as total_shifts,
        COALESCE(s.total_dispatched_stops, 0) as total_dispatched_stops,
        COALESCE(s.total_paid_stops, 0) as total_paid_stops,
        COALESCE(s.total_gross_pay, 0) as total_gross_pay,
        COALESCE(s.total_top_up_pay, 0) as total_top_up_pay,
        COALESCE(df.total_liters, 0) as total_driver_liters,
        COALESCE(df.total_fuel_cost, 0) as total_driver_fuel_cost
      FROM drivers d
      LEFT JOIN depots dep ON d.default_depot_id = dep.id
      LEFT JOIN shift_stats s ON s.driver_id = d.id
      LEFT JOIN driver_fuel df ON df.driver_id = d.id
      WHERE d.is_active = true
      ORDER BY COALESCE(s.total_paid_stops, 0) DESC
    `);

    // 3. Monthly Trends
    const monthlyFuelRes = await client.query(`
      SELECT 
        TO_CHAR(refuel_date, 'YYYY-MM') as month,
        COUNT(*) as refuel_count,
        COALESCE(SUM(total_cost), 0) as fuel_cost,
        COALESCE(SUM(liters_filled), 0) as fuel_liters
      FROM fuel_logs
      WHERE refuel_date IS NOT NULL
      GROUP BY TO_CHAR(refuel_date, 'YYYY-MM')
      ORDER BY month ASC
    `);

    const monthlyMaintRes = await client.query(`
      SELECT 
        TO_CHAR(date, 'YYYY-MM') as month,
        COUNT(*) as maint_count,
        COALESCE(SUM(total_cost), 0) as maint_cost
      FROM maintenance_logs
      WHERE date IS NOT NULL
      GROUP BY TO_CHAR(date, 'YYYY-MM')
      ORDER BY month ASC
    `);

    const monthlyShiftsRes = await client.query(`
      SELECT 
        TO_CHAR(shift_date, 'YYYY-MM') as month,
        COUNT(*) as shifts_count,
        COALESCE(SUM(paid_stops), 0) as paid_stops,
        COALESCE(SUM(gross_shift_total), 0) as gross_pay
      FROM daily_shifts
      WHERE shift_date IS NOT NULL
      GROUP BY TO_CHAR(shift_date, 'YYYY-MM')
      ORDER BY month ASC
    `);

    res.json({
      vehicles: vehiclePerfRes.rows,
      drivers: driverPerfRes.rows,
      monthlyFuel: monthlyFuelRes.rows,
      monthlyMaint: monthlyMaintRes.rows,
      monthlyShifts: monthlyShiftsRes.rows
    });
  } catch (err) {
    console.error('Performance analytics error:', err);
    res.status(500).json({ error: 'Failed to aggregate performance analytics: ' + err.message });
  }
});

module.exports = router;