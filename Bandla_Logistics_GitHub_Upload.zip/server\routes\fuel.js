const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

// List fuel logs
router.get('/', async (req, res) => {
  try {
    const { vehicleId, driverId, startDate, endDate, search } = req.query;
    const db = getDb();
    let query = `
      SELECT f.*,
        v.registration_number as vehicle_reg,
        v.model_number as vehicle_model,
        d.full_name as driver_name,
        d.driver_code
      FROM fuel_logs f
      JOIN vehicles v ON f.vehicle_id = v.id
      LEFT JOIN drivers d ON f.driver_id = d.id
      WHERE 1=1
    `;
    const params = [];

    if (vehicleId) {
      params.push(vehicleId);
      query += ` AND f.vehicle_id = $${params.length}`;
    }
    if (driverId) {
      params.push(driverId);
      query += ` AND f.driver_id = $${params.length}`;
    }
    if (startDate) {
      params.push(startDate);
      query += ` AND f.refuel_date >= $${params.length}`;
    }
    if (endDate) {
      params.push(endDate);
      query += ` AND f.refuel_date <= $${params.length}`;
    }
    if (search) {
      params.push(`%${search}%`);
      query += ` AND (f.station_name ILIKE $${params.length} OR v.registration_number ILIKE $${params.length} OR d.full_name ILIKE $${params.length} OR f.fuel_card_ref ILIKE $${params.length})`;
    }

    query += ` ORDER BY f.refuel_date DESC, f.created_at DESC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create fuel log entry
router.post('/', async (req, res) => {
  try {
    const {
      refuelDate, date, vehicleId, driverId, stationName,
      litersFilled, totalCost, odometerReading, fuelCardRef, notes
    } = req.body;

    const targetDate = refuelDate || date || new Date().toISOString().split('T')[0];
    if (!vehicleId) {
      return res.status(400).json({ error: 'Vehicle selection is required.' });
    }

    const station = (stationName || 'Shell Leicester Hub').trim();
    const liters = parseFloat(litersFilled || 0);
    const cost = parseFloat(totalCost || 0);

    const db = getDb();
    const id = uuidv4();
    const { rows } = await db.session.client.query(`
      INSERT INTO fuel_logs (
        id, refuel_date, vehicle_id, driver_id, station_name,
        liters_filled, total_cost, odometer_reading, fuel_card_ref, notes, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW())
      RETURNING *
    `, [
      id, targetDate, vehicleId, driverId || null, station,
      liters.toFixed(2), cost.toFixed(2),
      odometerReading ? parseFloat(odometerReading) : null,
      fuelCardRef ? fuelCardRef.trim() : null,
      notes || null
    ]);

    // Update vehicle mileage if odometer provided
    if (odometerReading && parseFloat(odometerReading) > 0) {
      await db.session.client.query(`
        UPDATE vehicles SET 
          current_mileage = GREATEST(COALESCE(current_mileage, 0), $1),
          updated_at = NOW()
        WHERE id = $2
      `, [parseFloat(odometerReading), vehicleId]);
    }

    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update fuel log entry
router.put('/:id', async (req, res) => {
  try {
    const {
      refuelDate, date, vehicleId, driverId, stationName,
      litersFilled, totalCost, odometerReading, fuelCardRef, notes
    } = req.body;

    const targetDate = refuelDate || date;
    const db = getDb();

    const { rows } = await db.session.client.query(`
      UPDATE fuel_logs SET
        refuel_date = COALESCE($1, refuel_date),
        vehicle_id = COALESCE($2, vehicle_id),
        driver_id = $3,
        station_name = COALESCE($4, station_name),
        liters_filled = COALESCE($5, liters_filled),
        total_cost = COALESCE($6, total_cost),
        odometer_reading = $7,
        fuel_card_ref = $8,
        notes = $9,
        updated_at = NOW()
      WHERE id = $10
      RETURNING *
    `, [
      targetDate, vehicleId, driverId || null,
      stationName ? stationName.trim() : null,
      litersFilled !== undefined ? parseFloat(litersFilled) : null,
      totalCost !== undefined ? parseFloat(totalCost) : null,
      odometerReading !== undefined ? (odometerReading ? parseFloat(odometerReading) : null) : null,
      fuelCardRef !== undefined ? (fuelCardRef ? fuelCardRef.trim() : null) : null,
      notes !== undefined ? notes : null,
      req.params.id
    ]);

    if (!rows.length) return res.status(404).json({ error: 'Fuel log not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete fuel log entry
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const { rowCount } = await db.session.client.query(`DELETE FROM fuel_logs WHERE id = $1`, [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: 'Fuel log not found' });
    res.json({ message: 'Fuel log deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
