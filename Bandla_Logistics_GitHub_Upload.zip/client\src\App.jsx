import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import Login from './pages/Login';
import Layout from './components/Layout';
import ErrorBoundary from './components/ErrorBoundary';
import Dashboard from './pages/Dashboard';
import WeeklyRoutePlanner from './pages/WeeklyRoutePlanner';
import ShiftCalendar from './pages/ShiftCalendar';
import PayrollInvoices from './pages/PayrollInvoices';
import Drivers from './pages/Drivers';
import FleetInventory from './pages/FleetInventory';
import Charges from './pages/Charges';
import RouteRates from './pages/RouteRates';
import Maintenance from './pages/Maintenance';
import PerformanceAnalytics from './pages/PerformanceAnalytics';
import AuditTrails from './pages/AuditTrails';
import MigrationBackup from './pages/MigrationBackup';
import UserManager from './pages/UserManager';

function MainApp() {
  const { user, isAuthenticated, isShiftManager, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  const userPerms = Array.isArray(user?.permissions) ? user.permissions : [];

  useEffect(() => {
    if (isShiftManager && activeTab === 'dashboard' && !userPerms.includes('view_dashboard')) {
      setActiveTab('planner');
    }
  }, [isShiftManager]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-slate-600 dark:text-slate-400">
          <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-medium">Verifying Session...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Login />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard setActiveTab={setActiveTab} />;
      case 'planner':
        return <WeeklyRoutePlanner />;
      case 'shifts':
        return <ShiftCalendar />;
      case 'invoices':
        return <PayrollInvoices />;
      case 'drivers':
        return <Drivers />;
      case 'fleet':
        return <FleetInventory />;
      case 'charges':
        return <Charges />;
      case 'audit':
        return <AuditTrails />;
      case 'routes':
        return <RouteRates />;
      case 'maintenance':
        return <Maintenance />;
      case 'analytics':
      case 'performance':
        return <PerformanceAnalytics />;
      case 'users':
        return <UserManager />;
      case 'system':
        return <MigrationBackup />;
      default:
        return isShiftManager ? <WeeklyRoutePlanner /> : <Dashboard setActiveTab={setActiveTab} />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      <ErrorBoundary onReset={() => setActiveTab('dashboard')}>
        {renderContent()}
      </ErrorBoundary>
    </Layout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/*" element={<MainApp />} />
          </Routes>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}