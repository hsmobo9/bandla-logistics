const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

const cleanDate = (d) => (!d || String(d).trim() === '' ? null : String(d).trim());
const cleanStr = (s) => (!s || String(s).trim() === '' ? null : String(s).trim());

// List drivers with rich filtering
router.get('/', async (req, res) => {
  try {
    const { status, search, depotId, includeInactive } = req.query;
    const db = getDb();
    let query = `
      SELECT d.*, dep.name as default_depot_name,
        (SELECT COUNT(*) FROM daily_shifts s WHERE s.driver_id = d.id) as total_shifts_count,
        (SELECT COALESCE(SUM(i.net_payable), 0) FROM payroll_invoices i WHERE i.driver_id = d.id) as total_earnings_sum,
        EXISTS (
          SELECT 1 FROM driver_availability a 
          WHERE a.driver_id = d.id AND CURRENT_DATE >= a.start_date AND CURRENT_DATE <= a.end_date
        ) as is_on_leave,
        (
          SELECT a.status FROM driver_availability a 
          WHERE a.driver_id = d.id AND CURRENT_DATE >= a.start_date AND CURRENT_DATE <= a.end_date
          ORDER BY a.start_date DESC LIMIT 1
        ) as current_leave_type,
        (
          SELECT a.end_date FROM driver_availability a 
          WHERE a.driver_id = d.id AND CURRENT_DATE >= a.start_date AND CURRENT_DATE <= a.end_date
          ORDER BY a.start_date DESC LIMIT 1
        ) as leave_until
      FROM drivers d
      LEFT JOIN depots dep ON d.default_depot_id = dep.id
      WHERE 1=1
    `;
    const params = [];

    if (includeInactive !== 'true') {
      query += ` AND d.is_active = TRUE`;
    }

    if (status) {
      if (status === 'on_leave' || status === 'On Leave') {
        query += ` AND d.id IN (
          SELECT a.driver_id FROM driver_availability a
          WHERE CURRENT_DATE >= a.start_date AND CURRENT_DATE <= a.end_date
        )`;
      } else {
        params.push(status);
        query += ` AND (d.status = $${params.length} OR ($${params.length} = 'active' AND d.is_active = TRUE))`;
      }
    }
    if (depotId) {
      params.push(depotId);
      query += ` AND d.default_depot_id = $${params.length}`;
    }
    if (search) {
      params.push(`%${search}%`);
      query += ` AND (d.full_name ILIKE $${params.length} OR d.driver_code ILIKE $${params.length} OR d.assigned_vehicle_reg ILIKE $${params.length} OR d.license_number ILIKE $${params.length})`;
    }

    query += ` ORDER BY d.is_active DESC, d.full_name ASC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single driver
router.get('/:id', async (req, res) => {
  try {
    const db = getDb();
    const { rows } = await db.session.client.query(`
      SELECT d.*, dep.name as default_depot_name
      FROM drivers d
      LEFT JOIN depots dep ON d.default_depot_id = dep.id
      WHERE d.id = $1
    `, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Driver not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create driver (Admin Only)
router.post('/', async (req, res) => {
  try {
    const {
      driverCode, fullName, phone, email, defaultDepotId,
      assignedVehicleReg, assignedFdNumber, isVatRegistered, vatNumber,
      status, licenseNumber, licenseExpiry, passDate, dvlaPoints, isActive, notes,
      niNumber, address, dob, passportNumber, passportExpiry,
      rightToWorkStatus, rightToWorkExpiry, sponsorRequired
    } = req.body;

    if (!fullName) return res.status(400).json({ error: 'Full name is required' });
    const db = getDb();
    const id = uuidv4();

    const { rows } = await db.session.client.query(`
      INSERT INTO drivers (
        id, driver_code, full_name, phone, email, default_depot_id,
        assigned_vehicle_reg, assigned_fd_number, is_vat_registered, vat_number,
        status, license_number, license_expiry, pass_date, dvla_points, is_active, notes,
        ni_number, address, dob, passport_number, passport_expiry,
        right_to_work_status, right_to_work_expiry, sponsor_required
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25)
      RETURNING *
    `, [
      id, cleanStr(driverCode), fullName.trim(), cleanStr(phone), cleanStr(email), cleanStr(defaultDepotId),
      cleanStr(assignedVehicleReg), cleanStr(assignedFdNumber), Boolean(isVatRegistered), cleanStr(vatNumber),
      status || 'active', cleanStr(licenseNumber), cleanDate(licenseExpiry), cleanDate(passDate),
      parseInt(dvlaPoints || 0, 10), isActive !== undefined ? Boolean(isActive) : true, cleanStr(notes),
      cleanStr(niNumber), cleanStr(address), cleanDate(dob), cleanStr(passportNumber), cleanDate(passportExpiry),
      cleanStr(rightToWorkStatus), cleanDate(rightToWorkExpiry), Boolean(sponsorRequired)
    ]);

    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update driver (Admin Only)
router.put('/:id', async (req, res) => {
  try {
    const {
      driverCode, fullName, phone, email, defaultDepotId,
      assignedVehicleReg, assignedFdNumber, isVatRegistered, vatNumber,
      status, licenseNumber, licenseExpiry, passDate, dvlaPoints, isActive, notes,
      niNumber, address, dob, passportNumber, passportExpiry,
      rightToWorkStatus, rightToWorkExpiry, sponsorRequired
    } = req.body;

    const db = getDb();
    const { rows } = await db.session.client.query(`
      UPDATE drivers SET
        driver_code = COALESCE($1, driver_code),
        full_name = COALESCE($2, full_name),
        phone = COALESCE($3, phone),
        email = COALESCE($4, email),
        default_depot_id = $5,
        assigned_vehicle_reg = COALESCE($6, assigned_vehicle_reg),
        assigned_fd_number = COALESCE($7, assigned_fd_number),
        is_vat_registered = COALESCE($8, is_vat_registered),
        vat_number = $9,
        status = COALESCE($10, status),
        license_number = $11,
        license_expiry = $12,
        pass_date = $13,
        dvla_points = COALESCE($14, dvla_points),
        is_active = COALESCE($15, is_active),
        notes = $16,
        ni_number = $17,
        address = $18,
        dob = $19,
        passport_number = $20,
        passport_expiry = $21,
        right_to_work_status = $22,
        right_to_work_expiry = $23,
        sponsor_required = COALESCE($24, sponsor_required),
        updated_at = NOW()
      WHERE id = $25
      RETURNING *
    `, [
      cleanStr(driverCode), fullName ? fullName.trim() : undefined, cleanStr(phone), cleanStr(email), cleanStr(defaultDepotId),
      cleanStr(assignedVehicleReg), cleanStr(assignedFdNumber), isVatRegistered !== undefined ? Boolean(isVatRegistered) : undefined,
      cleanStr(vatNumber), status, cleanStr(licenseNumber), cleanDate(licenseExpiry), cleanDate(passDate),
      dvlaPoints !== undefined ? parseInt(dvlaPoints, 10) : undefined,
      isActive !== undefined ? Boolean(isActive) : undefined,
      cleanStr(notes),
      cleanStr(niNumber), cleanStr(address), cleanDate(dob), cleanStr(passportNumber), cleanDate(passportExpiry),
      cleanStr(rightToWorkStatus), cleanDate(rightToWorkExpiry), sponsorRequired !== undefined ? Boolean(sponsorRequired) : undefined,
      req.params.id
    ]);

    if (!rows.length) return res.status(404).json({ error: 'Driver not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Soft Delete / Toggle Active (Strictly Soft Deletes to preserve historical invoices/shifts)
router.patch('/:id/toggle-active', async (req, res) => {
  try {
    const db = getDb();
    const { rows } = await db.session.client.query(`
      UPDATE drivers 
      SET is_active = NOT is_active, 
          status = CASE WHEN is_active = TRUE THEN 'inactive' ELSE 'active' END,
          updated_at = NOW() 
      WHERE id = $1 
      RETURNING *
    `, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Driver not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update specific operational status
router.patch('/:id/status', async (req, res) => {
  try {
    const { status, isActive } = req.body;
    const db = getDb();
    const newIsActive = isActive !== undefined ? Boolean(isActive) : (status !== 'inactive');
    const { rows } = await db.session.client.query(`
      UPDATE drivers 
      SET status = $1,
          is_active = $2,
          updated_at = NOW() 
      WHERE id = $3 
      RETURNING *
    `, [status || 'active', newIsActive, req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Driver not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete Driver (Permanently purges if unlinked or requested; deactivates if historical records exist)
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const client = db.session.client;
    const { id } = req.params;
    const force = req.query.force === 'true';

    // Check if driver exists
    const driverRes = await client.query(`SELECT id, full_name, driver_code FROM drivers WHERE id = $1`, [id]);
    if (!driverRes.rows.length) return res.status(404).json({ error: 'Driver not found' });

    // Check for locked invoices
    const lockedInvRes = await client.query(`SELECT id, invoice_number FROM payroll_invoices WHERE driver_id = $1 AND status = 'Locked'`, [id]);
    if (lockedInvRes.rows.length > 0 && !force) {
      await client.query(`UPDATE drivers SET is_active = FALSE, status = 'inactive', updated_at = NOW() WHERE id = $1`, [id]);
      return res.json({ 
        message: `Driver has locked invoices (#${lockedInvRes.rows[0].invoice_number}). Deactivated to preserve statutory audit trail.`, 
        deactivated: true 
      });
    }

    // Clean up dependent records safely
    await client.query(`DELETE FROM driver_availability WHERE driver_id = $1`, [id]);
    await client.query(`DELETE FROM daily_shifts WHERE driver_id = $1`, [id]);
    await client.query(`DELETE FROM charges_and_deductions WHERE driver_id = $1`, [id]);
    await client.query(`DELETE FROM payroll_invoices WHERE driver_id = $1`, [id]);
    await client.query(`UPDATE accident_logs SET driver_id = NULL WHERE driver_id = $1`, [id]);
    await client.query(`UPDATE fuel_logs SET driver_id = NULL WHERE driver_id = $1`, [id]);
    const { rows } = await client.query(`DELETE FROM drivers WHERE id = $1 RETURNING *`, [id]);

    res.json({ 
      message: `Driver "${driverRes.rows[0].full_name}" permanently removed from system.`, 
      deleted: true, 
      driver: rows[0] 
    });
  } catch (err) {
    console.error('Delete driver error:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
