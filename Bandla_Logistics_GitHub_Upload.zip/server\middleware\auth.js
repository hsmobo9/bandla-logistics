const jwt = require('jsonwebtoken');
const env = require('../config/env');

function parsePerms(val) {
  if (!val) return [];
  if (Array.isArray(val)) return val;
  try {
    const parsed = JSON.parse(val);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

/**
 * Verifies JWT token from Authorization header or query param
 */
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  let token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : null;

  if (!token && (req.query.token || req.query.auth)) {
    token = req.query.token || req.query.auth;
  }

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. No token provided.' });
  }

  jwt.verify(token, env.JWT_SECRET, (err, user) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ error: 'Session expired. Please log in again.' });
      }
      return res.status(403).json({ error: 'Invalid authentication token.' });
    }
    req.user = {
      ...user,
      permissions: parsePerms(user.permissions)
    };
    next();
  });
}

/**
 * Restricts route strictly to Admin role
 */
function requireAdmin(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthenticated.' });
  }
  if (String(req.user.role).toLowerCase() !== 'admin') {
    return res.status(403).json({
      error: 'Access Denied: Admin role required for system operations and privilege management.'
    });
  }
  next();
}

/**
 * Granular Privilege Checker:
 * Admins ALWAYS pass.
 * Shift Managers pass IF they have the specific privilege granted by Admin.
 */
function requirePrivilege(privilegeKey) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthenticated.' });
    }

    // Admins have universal privileges
    if (String(req.user.role).toLowerCase() === 'admin') {
      return next();
    }

    // Check delegated privileges for ShiftManager / custom roles
    const userPerms = Array.isArray(req.user.permissions) ? req.user.permissions : [];
    if (userPerms.includes(privilegeKey) || userPerms.includes('all') || userPerms.includes('*')) {
      return next();
    }

    return res.status(403).json({
      error: `Access Denied: You do not have the '${privilegeKey}' privilege. Contact Head Office for access.`
    });
  };
}

/**
 * Restricts route to specified allowed roles
 */
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthenticated.' });
    }
    if (!allowedRoles.map(r => r.toLowerCase()).includes(String(req.user.role).toLowerCase())) {
      return res.status(403).json({
        error: `Access Denied: Required role: ${allowedRoles.join(' or ')}. Your role: ${req.user.role}`
      });
    }
    next();
  };
}

function shiftManagerRestricted(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthenticated.' });
  }

  if (String(req.user.role).toLowerCase() === 'admin') {
    return next();
  }

  const userPerms = Array.isArray(req.user.permissions) ? req.user.permissions : [];
  if (userPerms.includes('manage_shifts') || userPerms.includes('manage_vehicles') || userPerms.includes('all')) {
    return next();
  }

  if (req.user.role === 'ShiftManager') {
    if (req.method === 'GET' || req.method === 'POST') {
      return next();
    }
    return res.status(403).json({
      error: `Access Denied: Shift Managers cannot perform ${req.method} modifications. Contact Head Office.`
    });
  }

  return res.status(403).json({ error: 'Access Denied: Unknown role permissions.' });
}

module.exports = {
  authenticateToken,
  requireAdmin,
  requirePrivilege,
  requireRole,
  shiftManagerRestricted
};
