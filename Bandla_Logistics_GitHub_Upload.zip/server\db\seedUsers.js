const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { initDb, getDb } = require('../config/db');

async function seedUsers() {
  console.log('Seeding initial RBAC user accounts...');
  await initDb();
  const db = getDb();
  const client = db.session.client;

  const defaultUsers = [
    {
      username: 'admin',
      email: 'admin@bandlalogistics.co.uk',
      fullName: 'Head Office Administrator',
      role: 'Admin',
      passwordPlain: 'AdminPass123!'
    },
    {
      username: 'manager_leicester',
      email: 'manager@bandlalogistics.co.uk',
      fullName: 'Regional Route & Operations Manager',
      role: 'RouteManager',
      passwordPlain: 'ManagerPass123!'
    }
  ];

  for (const u of defaultUsers) {
    const existing = await client.query('SELECT id FROM users WHERE email = $1 OR username = $2', [u.email, u.username]);
    if (existing.rows.length === 0) {
      const salt = await bcrypt.genSalt(10);
      const hash = await bcrypt.hash(u.passwordPlain, salt);
      const userId = uuidv4();
      await client.query(`
        INSERT INTO users (id, username, email, password_hash, full_name, role, status)
        VALUES ($1, $2, $3, $4, $5, $6, 'active')
      `, [userId, u.username, u.email, hash, u.fullName, u.role]);
      console.log(`✓ Created user: ${u.username} (${u.email}) [Role: ${u.role}]`);
    } else {
      await client.query('UPDATE users SET full_name = $1, role = $2 WHERE id = $3', [u.fullName, u.role, existing.rows[0].id]);
      console.log(`• User updated: ${u.username} (${u.email})`);
    }
  }

  console.log('User seeding completed.');
}

if (require.main === module) {
  seedUsers().then(() => process.exit(0)).catch(err => {
    console.error('User seeding failed:', err);
    process.exit(1);
  });
}

module.exports = { seedUsers };