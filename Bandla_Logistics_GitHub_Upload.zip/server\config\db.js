const { Pool } = require('pg');
const { drizzle: drizzlePg } = require('drizzle-orm/node-postgres');
const { drizzle: drizzlePglite } = require('drizzle-orm/pglite');
const { PGlite } = require('@electric-sql/pglite');
const path = require('path');
const fs = require('fs');
const schema = require('../db/schema');
const env = require('./env');

let activeDb = null;
let activeClient = null;

function cleanStaleLocks(dir) {
  try {
    const postmasterPid = path.join(dir, 'postmaster.pid');
    const pgsqlLock = path.join(dir, '.s.PGSQL.5432.lock.out');
    if (fs.existsSync(postmasterPid)) fs.unlinkSync(postmasterPid);
    if (fs.existsSync(pgsqlLock)) fs.unlinkSync(pgsqlLock);
  } catch (e) {}
}

async function initDb() {
  if (activeDb) return { db: activeDb, client: activeClient };

  const isRemotePostgres = env.DATABASE_URL && 
    !env.DATABASE_URL.includes('localhost') && 
    !env.DATABASE_URL.includes('127.0.0.1');

  // 1. Cloud/Managed PostgreSQL Connection (Supabase, Neon, AWS RDS, Railway, etc.)
  if (isRemotePostgres) {
    try {
      console.log(`[Database] Connecting to Cloud PostgreSQL at: ${env.DATABASE_URL.replace(/\/\/.*@/, '//***:***@')}`);
      const pool = new Pool({
        connectionString: env.DATABASE_URL,
        ssl: { rejectUnauthorized: false },
        max: 20,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 10000
      });
      const client = await pool.connect();
      const res = await client.query('SELECT NOW() as current_time, version()');
      console.log(`✓ Cloud PostgreSQL Connected: ${res.rows[0].version.split(' ')[0]} at ${res.rows[0].current_time}`);
      client.release();

      activeClient = pool;
      activeDb = drizzlePg(pool, { schema });
      return { db: activeDb, client: activeClient };
    } catch (cloudErr) {
      console.warn('[Database] Cloud PostgreSQL connection failed:', cloudErr.message);
    }
  }

  // 2. Try Local standard PostgreSQL server on port 5432
  try {
    const localPool = new Pool({
      connectionString: env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/bandla_logistics',
      max: 10,
      connectionTimeoutMillis: 1000
    });
    const client = await localPool.connect();
    const res = await client.query('SELECT NOW() as current_time, version()');
    console.log(`✓ Local PostgreSQL Server Connected: ${res.rows[0].version.split(' ')[0]} at ${res.rows[0].current_time}`);
    client.release();

    activeClient = localPool;
    activeDb = drizzlePg(localPool, { schema });
    return { db: activeDb, client: activeClient };
  } catch (localErr) {
    // 3. Fallback to Local Persistent PostgreSQL Engine for offline/local development
    console.log('[Database] Standard PostgreSQL service unavailable. Initializing local persistent PostgreSQL adapter for development...');
    const appData = process.env.APPDATA || process.env.LOCALAPPDATA || 'C:\\ProgramData';
    const baseDir = path.join(appData, 'BandlaLogistics');
    const localDbPath = path.join(baseDir, 'db_cloud');

    try {
      if (!fs.existsSync(path.dirname(localDbPath))) {
        fs.mkdirSync(path.dirname(localDbPath), { recursive: true });
      }
      cleanStaleLocks(localDbPath);

      const pgliteInstance = new PGlite(localDbPath);
      await pgliteInstance.waitReady;
      activeClient = pgliteInstance;
      activeDb = drizzlePglite(pgliteInstance, { schema });
      console.log(`✓ Local PostgreSQL Adapter Ready at: ${localDbPath}`);
      return { db: activeDb, client: activeClient };
    } catch (pgliteErr) {
      console.warn('[Database] Directory storage failed, falling back to in-memory PostgreSQL:', pgliteErr.message);
      const memInstance = new PGlite();
      await memInstance.waitReady;
      activeClient = memInstance;
      activeDb = drizzlePglite(memInstance, { schema });
      console.log('✓ In-Memory PostgreSQL Ready');
      return { db: activeDb, client: activeClient };
    }
  }
}

module.exports = {
  initDb,
  getDb: () => activeDb,
  getClient: () => activeClient
};