import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Filter, 
  RefreshCw, 
  History, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight,
  User,
  Clock,
  Database,
  Lock,
  FileText,
  CreditCard,
  Percent,
  Calendar,
  Eye,
  Info
} from 'lucide-react';
import { getAuditLogs } from '../services/api';
import { formatDate } from '../utils/formatters';
import Modal from '../components/Modal';

export default function AuditTrails() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('');
  const [tableFilter, setTableFilter] = useState('');
  const [inspectLog, setInspectLog] = useState(null);

  useEffect(() => {
    loadLogs();
  }, [actionFilter, tableFilter]);

  const loadLogs = async () => {
    try {
      setLoading(true);
      const params = {};
      if (actionFilter) params.actionType = actionFilter;
      if (tableFilter) params.tableAffected = tableFilter;
      const data = await getAuditLogs(params);
      setLogs(data);
    } catch (err) {
      console.error('Error loading audit logs:', err);
    } finally {
      setLoading(false);
    }
  };

  const parseJsonSafe = (str) => {
    if (!str) return null;
    try {
      return JSON.parse(str);
    } catch (e) {
      return str;
    }
  };

  // Human-friendly formatters for State Transitions
  const renderReadableState = (actionType, obj, isNew = false) => {
    if (!obj) return <span className="text-slate-500 dark:text-slate-400 italic">None / Initial</span>;
    if (typeof obj === 'string') {
      try {
        obj = JSON.parse(obj);
      } catch (e) {
        return <span>{obj}</span>;
      }
    }

    if (actionType === 'TOP_UP_OVERRIDE') {
      if (isNew) {
        return (
          <span className="font-semibold text-rose-600 dark:text-rose-400">
            Subsidy Docked (£0.00)
          </span>
        );
      }
      return (
        <span className="font-semibold text-slate-700 dark:text-slate-300">
          £{parseFloat(obj.applied_top_up || 25).toFixed(2)} Top-Up Active
        </span>
      );
    }

    if (actionType === 'INVOICE_VAULT_LOCK') {
      if (isNew) {
        return (
          <span className="inline-flex items-center gap-1 font-bold text-amber-600 dark:text-amber-300">
            <Lock className="w-3 h-3" /> Locked & Sealed
          </span>
        );
      }
      return <span>Status: {obj.status || 'Approved'}</span>;
    }

    if (actionType === 'VAT_STATUS_ALTERED') {
      if (isNew) {
        return (
          <span className="font-bold text-blue-600 dark:text-blue-400">
            20% VAT ({obj.vat_number || 'Registered'})
          </span>
        );
      }
      return <span className="text-slate-500">0% Non-VAT</span>;
    }

    if (actionType === 'DEDUCTION_CREDIT_APPLIED') {
      if (isNew) {
        return (
          <span className="font-bold text-emerald-600 dark:text-emerald-400">
            Credit: £{Math.abs(parseFloat(obj.amount || 50)).toFixed(2)}
          </span>
        );
      }
      return <span className="text-slate-500 dark:text-slate-400 italic">No Prior Deduction</span>;
    }

    if (actionType === 'RATE_CARD_UPDATED') {
      if (isNew) {
        return (
          <span className="font-bold text-indigo-600 dark:text-indigo-400">
            Base: £{parseFloat(obj.base_rate_per_stop || 1.20).toFixed(2)} / stop
          </span>
        );
      }
      return <span>Base: £{parseFloat(obj.base_rate_per_stop || 1.10).toFixed(2)} / stop</span>;
    }

    if (actionType === 'BATCH_INVOICES_APPROVED') {
      if (isNew) {
        return (
          <span className="font-bold text-emerald-600 dark:text-emerald-400">
            {obj.count || 'Batch'} Invoices: Approved
          </span>
        );
      }
      return <span>Status: {obj.status || 'Checked'}</span>;
    }

    if (actionType === 'HOLIDAY_OVERRIDE_APPROVED') {
      if (isNew) {
        return (
          <span className="font-bold text-rose-600 dark:text-rose-400">
            🌴 {obj.status || 'Holiday'} (Locked Rota)
          </span>
        );
      }
      return <span>Status: {obj.status || 'Available'}</span>;
    }

    // Default Fallback: Clean key-values instead of raw JSON string
    if (typeof obj === 'object') {
      const keys = Object.keys(obj);
      if (keys.length === 1) return <span>{keys[0]}: <strong>{String(obj[keys[0]])}</strong></span>;
      return (
        <span className="truncate max-w-[150px] inline-block font-mono text-[10px]">
          {keys.slice(0, 2).map(k => `${k}: ${obj[k]}`).join(', ')}
        </span>
      );
    }

    return <span>{String(obj)}</span>;
  };

  // Table names humanized
  const formatTableLabel = (tbl) => {
    switch (tbl) {
      case 'daily_shifts': return 'Daily Route Ledger';
      case 'payroll_invoices': return 'Payroll Invoices';
      case 'drivers': return 'Driver Workforce';
      case 'charges_and_deductions': return 'Charges & Deductions';
      case 'route_rates': return 'Route Rate Cards';
      case 'driver_availability': return 'Holiday & Leave Roster';
      default: return tbl || 'System Ledger';
    }
  };

  // Action Badge Color Styler
  const getActionBadgeStyle = (act) => {
    if (act?.includes('LOCK')) return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30';
    if (act?.includes('OVERRIDE')) return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30';
    if (act?.includes('VAT')) return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30';
    if (act?.includes('CREDIT') || act?.includes('APPROVED')) return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30';
    return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/30';
  };

  const filteredLogs = logs.filter(l => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      l.action_type?.toLowerCase().includes(q) ||
      l.user_name?.toLowerCase().includes(q) ||
      l.reason?.toLowerCase().includes(q) ||
      l.record_id?.toLowerCase().includes(q) ||
      l.table_affected?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 rounded-2xl shadow-sm dark:shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-purple-500/10 text-purple-600 dark:text-purple-400 rounded-xl">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Financial Controls & Audit Trails</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Tamper-evident chronological ledger of Top-Up overrides, VAT alterations, manual credits, and invoice locking
            </p>
          </div>
        </div>

        <button
          onClick={loadLogs}
          className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition cursor-pointer"
        >
          <RefreshCw className="w-4 h-4" /> Refresh Audit Trail
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-4 rounded-xl shadow-sm dark:shadow-lg flex flex-wrap gap-4 items-center justify-between">
        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 dark:text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by action, manager name, or override justification..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <Filter className="w-3.5 h-3.5" />
            <span>Action Type:</span>
          </div>
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-purple-500 font-medium"
          >
            <option value="">All Action Types</option>
            <option value="TOP_UP_OVERRIDE">Top-Up Override</option>
            <option value="INVOICE_VAULT_LOCK">Invoice Vault Lock</option>
            <option value="VAT_STATUS_ALTERED">VAT Status Altered</option>
            <option value="DEDUCTION_CREDIT_APPLIED">Deduction / Credit Applied</option>
            <option value="RATE_CARD_UPDATED">Rate Card Updated</option>
            <option value="BATCH_INVOICES_APPROVED">Batch Invoices Approved</option>
            <option value="HOLIDAY_OVERRIDE_APPROVED">Holiday Override</option>
          </select>

          <select
            value={tableFilter}
            onChange={(e) => setTableFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:border-purple-500 font-medium"
          >
            <option value="">All Ledgers</option>
            <option value="daily_shifts">Daily Route Ledger</option>
            <option value="payroll_invoices">Payroll Invoices</option>
            <option value="drivers">Driver Workforce</option>
            <option value="charges_and_deductions">Charges & Deductions</option>
            <option value="route_rates">Route Rate Cards</option>
            <option value="driver_availability">Holiday & Leave Roster</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-sm dark:shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500 mx-auto mb-2"></div>
            <span>Verifying audit cryptographic seals...</span>
          </div>
        ) : filteredLogs.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <History className="w-10 h-10 mx-auto mb-2 text-slate-400" />
            <p className="font-semibold text-slate-900 dark:text-white">No Audit Records Found</p>
            <p className="text-xs text-slate-500 mt-1">Financial and operational overrides will automatically be logged here.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="p-3.5">Timestamp</th>
                  <th className="p-3.5">Authorized User</th>
                  <th className="p-3.5">Action Type</th>
                  <th className="p-3.5">Ledger & Record</th>
                  <th className="p-3.5">State Transition (Prev ➔ New)</th>
                  <th className="p-3.5">Manager Justification</th>
                  <th className="p-3.5 text-right">Inspect</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60 bg-white dark:bg-slate-900">
                {filteredLogs.map((log) => {
                  const prevObj = parseJsonSafe(log.previous_value);
                  const newObj = parseJsonSafe(log.new_value);

                  return (
                    <tr key={log.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                      <td className="p-3.5 text-slate-600 dark:text-slate-400 font-mono text-[11px] whitespace-nowrap">
                        {formatDate(log.created_at)}
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                          <span className="font-bold text-slate-900 dark:text-white">{log.user_name || 'System Administrator'}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 block font-mono">{log.user_email}</span>
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2.5 py-1 rounded-md text-[10px] font-black border shadow-sm ${getActionBadgeStyle(log.action_type)}`}>
                          {log.action_type}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <span className="font-bold text-slate-800 dark:text-slate-200 block">
                          {formatTableLabel(log.table_affected)}
                        </span>
                        {log.record_id && (
                          <span className="font-mono text-[10px] text-slate-500 truncate max-w-[140px] block">
                            Ref: {log.record_id}
                          </span>
                        )}
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-2 text-xs">
                          <div className="px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 text-slate-700 dark:text-slate-300 text-[11px]">
                            {renderReadableState(log.action_type, prevObj, false)}
                          </div>
                          <ArrowRight className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400 shrink-0" />
                          <div className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-slate-700 dark:text-slate-300 text-[11px]">
                            {renderReadableState(log.action_type, newObj, true)}
                          </div>
                        </div>
                      </td>
                      <td className="p-3.5 text-slate-700 dark:text-slate-300 max-w-[280px]">
                        <p className="line-clamp-2 text-xs leading-relaxed">
                          {log.reason || <span className="text-slate-500 dark:text-slate-400 italic">No justification recorded</span>}
                        </p>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => setInspectLog(log)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-[11px] font-semibold transition cursor-pointer flex items-center gap-1 ml-auto"
                        >
                          <Eye className="w-3.5 h-3.5 text-slate-500" /> View
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Detailed Audit Event Inspector Modal */}
      <Modal
        isOpen={!!inspectLog}
        onClose={() => setInspectLog(null)}
        title="Audit Event Cryptographic Inspector"
        maxWidth="max-w-xl"
      >
        {inspectLog && (
          <div className="space-y-4 text-xs">
            <div className="p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[10px] uppercase font-bold text-slate-500">Action Type</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getActionBadgeStyle(inspectLog.action_type)}`}>
                  {inspectLog.action_type}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Authorized User:</span>
                <strong className="text-slate-900 dark:text-white">{inspectLog.user_name} ({inspectLog.user_email})</strong>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Timestamp:</span>
                <span className="font-mono text-slate-700 dark:text-slate-300">{new Date(inspectLog.created_at).toUTCString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Ledger & Record:</span>
                <span className="font-mono text-slate-700 dark:text-slate-300">{inspectLog.table_affected} • {inspectLog.record_id}</span>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">State Transition</label>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-rose-50/60 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/60 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-rose-600 dark:text-rose-400 block mb-1">Previous State</span>
                  <div className="text-slate-800 dark:text-slate-200">
                    {renderReadableState(inspectLog.action_type, parseJsonSafe(inspectLog.previous_value), false)}
                  </div>
                  {inspectLog.previous_value && (
                    <pre className="mt-2 p-1.5 bg-white/80 dark:bg-black/40 rounded text-[9px] font-mono text-slate-600 dark:text-slate-400 overflow-x-auto">
                      {inspectLog.previous_value}
                    </pre>
                  )}
                </div>

                <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 rounded-xl">
                  <span className="text-[10px] uppercase font-bold text-emerald-600 dark:text-emerald-400 block mb-1">New State</span>
                  <div className="text-slate-800 dark:text-slate-200">
                    {renderReadableState(inspectLog.action_type, parseJsonSafe(inspectLog.new_value), true)}
                  </div>
                  {inspectLog.new_value && (
                    <pre className="mt-2 p-1.5 bg-white/80 dark:bg-black/40 rounded text-[9px] font-mono text-slate-600 dark:text-slate-400 overflow-x-auto">
                      {inspectLog.new_value}
                    </pre>
                  )}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">Manager Justification Trail</label>
              <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-800 dark:text-slate-200 leading-relaxed text-xs">
                {inspectLog.reason || 'No justification provided.'}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setInspectLog(null)}
                className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-lg transition"
              >
                Close Inspector
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
