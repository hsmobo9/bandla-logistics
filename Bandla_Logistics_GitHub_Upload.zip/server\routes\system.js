const express = require('express');
const router = express.Router();
const { getDb } = require('../config/db');
const env = require('../config/env');
const { ingestHarishDatabase } = require('../scripts/ingestHarishDatabase');

// Get Cloud Database Status & Table Counts (Admin Only)
router.get('/status', async (req, res) => {
  try {
    const db = getDb();
    const client = db.session.client;

    const [userRes, driverRes, vehicleRes, shiftRes, invRes, chargeRes, fuelRes, maintRes] = await Promise.all([
      client.query('SELECT COUNT(*) as count FROM users'),
      client.query('SELECT COUNT(*) as count FROM drivers'),
      client.query('SELECT COUNT(*) as count FROM vehicles'),
      client.query('SELECT COUNT(*) as count FROM daily_shifts'),
      client.query('SELECT COUNT(*) as count FROM payroll_invoices'),
      client.query('SELECT COUNT(*) as count FROM charges_and_deductions'),
      client.query('SELECT COUNT(*) as count FROM fuel_logs'),
      client.query('SELECT COUNT(*) as count FROM maintenance_logs')
    ]);

    res.json({
      environment: env.NODE_ENV,
      mode: 'cloud-web-app',
      database: 'PostgreSQL',
      counts: {
        users: parseInt(userRes.rows[0].count, 10),
        drivers: parseInt(driverRes.rows[0].count, 10),
        vehicles: parseInt(vehicleRes.rows[0].count, 10),
        shifts: parseInt(shiftRes.rows[0].count, 10),
        invoices: parseInt(invRes.rows[0].count, 10),
        charges: parseInt(chargeRes.rows[0].count, 10),
        fuel: parseInt(fuelRes.rows[0].count, 10),
        maintenance: parseInt(maintRes.rows[0].count, 10)
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Trigger zero-duplicate Harish Transport Database migration (Admin Only)
router.post('/migrate-legacy', async (req, res) => {
  try {
    console.log('[System] Zero-duplicate Harish database ingestion triggered via API...');
    const results = await ingestHarishDatabase();
    res.json({ message: 'Harish Transport database synchronized successfully with zero duplicates', results });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;