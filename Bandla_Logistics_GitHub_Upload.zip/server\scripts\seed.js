const path = require('path');
const fs = require('fs');
const xlsx = require('xlsx');
const { v4: uuidv4 } = require('uuid');
const { initDb, getDb } = require('../config/db');
const { migrate } = require('../db/migrate');
const bcrypt = require('bcryptjs');

async function seedDatabase() {
  console.log('========================================================================');
  console.log('BANDLA LOGISTICS DATABASE SEEDING ENGINE');
  console.log('========================================================================\n');

  // 1. Initialize DB & Run Migrations (enforces courier categories & purges heavy machinery)
  const { client } = await initDb();
  await migrate();

  // 2. Seed Depots: 'Leicester', 'Peterborough', 'Raunds', 'Hinckley', 'Lincoln', 'Nottingham'
  const depotSpecs = [
    { name: 'Leicester', code: 'LEI', address: 'Bandla Central Hub, Leicester, LE1 1AA' },
    { name: 'Peterborough', code: 'PET', address: 'Peterborough Distribution Center, PE1 1AA' },
    { name: 'Raunds', code: 'RAU', address: 'Raunds Logistics Depot, NN9 6AA' },
    { name: 'Hinckley', code: 'HIN', address: 'Hinckley Regional Depot, LE10 1AA' },
    { name: 'Lincoln', code: 'LIN', address: 'Lincoln Parcel Hub, LN1 1AA' },
    { name: 'Nottingham', code: 'NOT', address: 'Nottingham Express Depot, NG1 1AA' }
  ];

  const depotMap = new Map();
  console.log('\n--- 1. Seeding Depots ---');
  for (const dep of depotSpecs) {
    const existing = await client.query(`SELECT id, name FROM depots WHERE LOWER(name) = LOWER($1) OR code = $2`, [dep.name, dep.code]);
    let depotId;
    if (existing.rows.length > 0) {
      depotId = existing.rows[0].id;
      console.log(`• Depot already exists: ${dep.name} (${dep.code}) [${depotId}]`);
    } else {
      depotId = uuidv4();
      await client.query(`
        INSERT INTO depots (id, code, name, address, created_at, updated_at)
        VALUES ($1, $2, $3, $4, NOW(), NOW())
      `, [depotId, dep.code, dep.name, dep.address]);
      console.log(`✓ Created Depot: ${dep.name} (${dep.code}) [${depotId}]`);
    }
    depotMap.set(dep.name.toLowerCase(), depotId);
  }

  // 3. Seed Default RBAC Users (Admin & ShiftManager)
  console.log('\n--- 2. Seeding RBAC Users ---');
  const leicesterId = depotMap.get('leicester');
  const defaultUsers = [
    {
      username: 'admin',
      email: 'admin@bandlalogistics.co.uk',
      fullName: 'System Administrator (Head Office)',
      role: 'Admin',
      depotId: null,
      password: 'AdminPass123!'
    },
    {
      username: 'manager_leicester',
      email: 'manager@bandlalogistics.co.uk',
      fullName: 'Leicester Depot Shift Manager',
      role: 'ShiftManager',
      depotId: leicesterId,
      password: 'ManagerPass123!'
    }
  ];

  for (const u of defaultUsers) {
    const userCheck = await client.query(`SELECT id FROM users WHERE email = $1 OR username = $2`, [u.email, u.username]);
    if (userCheck.rows.length === 0) {
      const passwordHash = await bcrypt.hash(u.password, 10);
      const uid = uuidv4();
      await client.query(`
        INSERT INTO users (id, username, email, password_hash, full_name, role, depot_id, status, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7, 'active', NOW(), NOW())
      `, [uid, u.username, u.email, passwordHash, u.fullName, u.role, u.depotId]);
      console.log(`✓ Created user: ${u.username} (${u.role})`);
    } else {
      console.log(`• User already exists: ${u.username} (${u.role})`);
    }
  }

  // 4. Parse Excel Workbook: importatn data.xlsx
  const excelPath = path.resolve(__dirname, '../../importatn data.xlsx');
  if (!fs.existsSync(excelPath)) {
    throw new Error(`Excel file not found at: ${excelPath}`);
  }

  console.log(`\n--- 3. Reading DATA Sheet from: ${excelPath} ---`);
  const wb = xlsx.readFile(excelPath, { sheets: ['DATA'] });
  if (!wb.Sheets['DATA']) {
    throw new Error('DATA sheet not found in importatn data.xlsx');
  }

  const rawRows = xlsx.utils.sheet_to_json(wb.Sheets['DATA'], { header: 1 });
  console.log(`Total raw rows in DATA sheet: ${rawRows.length}`);

  // 5. Seed Vehicles Strictly from Column B (Live 53 Courier Vans)
  console.log('\n--- 4. Seeding Fleet Vehicles (Column B) ---');
  const vehicleRegs = new Set();
  rawRows.forEach((r, idx) => {
    const reg = (r[1] || '').toString().trim().toUpperCase();
    if (reg && reg.length >= 5 && reg !== 'REG' && reg !== 'REGISTRATION' && reg !== 'VEHICLE') {
      vehicleRegs.add(reg);
    }
  });

  let vehiclesInserted = 0;
  let vehiclesUpdated = 0;
  for (const reg of vehicleRegs) {
    const vCheck = await client.query(`SELECT id FROM vehicles WHERE registration_number = $1`, [reg]);
    if (vCheck.rows.length === 0) {
      const vid = uuidv4();
      const eqCode = `VEH-${reg.replace(/\s+/g, '')}`;
      await client.query(`
        INSERT INTO vehicles (
          id, equipment_code, model_number, registration_number, category,
          ownership_type, hourly_rate, daily_rate, monthly_rate, weekly_rental_cost,
          current_meter_hours, status, mot_expiry, tax_expiry, insurance_expiry,
          current_mileage, next_service_mileage, is_active, notes, created_at, updated_at
        ) VALUES (
          $1, $2, 'Mercedes Sprinter / Luton (Bandla)', $3, 'Standard Van',
          'Company', 0, 0, 0, 185.00,
          0, 'Available', '2027-03-31', '2027-03-31', '2027-06-30',
          45000, 55000, true, 'Seeded from DATA workbook', NOW(), NOW()
        )
      `, [vid, eqCode, reg]);
      vehiclesInserted++;
    } else {
      // Ensure category is updated to Standard Van
      await client.query(`
        UPDATE vehicles 
        SET category = 'Standard Van', updated_at = NOW() 
        WHERE id = $1
      `, [vCheck.rows[0].id]);
      vehiclesUpdated++;
    }
  }
  console.log(`✓ Vehicles Seeding Complete: ${vehiclesInserted} inserted, ${vehiclesUpdated} updated (Total ${vehicleRegs.size} Courier Vans).`);

  // 6. Seed Drivers (Column A: Names, Column C: FD Courier Codes, Column D: Depots)
  console.log('\n--- 5. Seeding Drivers & Couriers (Columns A & C) ---');
  let driversInserted = 0;
  let driversUpdated = 0;
  let driverSeq = 1001;

  for (let idx = 0; idx < rawRows.length; idx++) {
    const row = rawRows[idx];
    const name = (row[0] || '').toString().trim();
    const assignedReg = (row[1] || '').toString().trim();
    const fdCode = (row[2] || '').toString().trim();
    const depotName = (row[3] || '').toString().trim().toLowerCase();

    // Skip empty or header rows
    if (!name || name.toLowerCase() === 'name' || name.toLowerCase() === 'driver name' || name.toLowerCase() === 'courier') {
      continue;
    }

    const defaultDepotId = depotMap.get(depotName) || null;
    const cleanFd = (fdCode && fdCode.toLowerCase() !== 'courier' && fdCode.toLowerCase() !== 'fd') ? fdCode : null;
    const cleanReg = (assignedReg && assignedReg.length >= 5) ? assignedReg : null;
    const driverCode = `DR${driverSeq++}`;

    const existingDriver = await client.query(`SELECT id, driver_code, assigned_fd_number FROM drivers WHERE LOWER(full_name) = LOWER($1)`, [name]);

    if (existingDriver.rows.length === 0) {
      const did = uuidv4();
      await client.query(`
        INSERT INTO drivers (
          id, driver_code, full_name, phone, email, default_depot_id,
          assigned_vehicle_reg, assigned_fd_number, is_vat_registered,
          status, dvla_points, is_active, notes, created_at, updated_at
        ) VALUES (
          $1, $2, $3, '07966 270000', $4, $5,
          $6, $7, false,
          'active', 0, true, 'Seeded from DATA workbook', NOW(), NOW()
        )
      `, [
        did, driverCode, name,
        `${name.toLowerCase().replace(/[^a-z0-9]/g, '.')}@contractor.bandlalogistics.co.uk`,
        defaultDepotId, cleanReg, cleanFd
      ]);
      driversInserted++;
    } else {
      const did = existingDriver.rows[0].id;
      await client.query(`
        UPDATE drivers SET
          assigned_vehicle_reg = COALESCE($1, assigned_vehicle_reg),
          assigned_fd_number = COALESCE($2, assigned_fd_number),
          default_depot_id = COALESCE($3, default_depot_id),
          updated_at = NOW()
        WHERE id = $4
      `, [cleanReg, cleanFd, defaultDepotId, did]);
      driversUpdated++;
    }
  }

  console.log(`✓ Drivers Seeding Complete: ${driversInserted} inserted, ${driversUpdated} updated.`);

  console.log('\n========================================================================');
  console.log('DATABASE SEEDING & PURGE SUCCESSFUL! ALL MASTERS POPULATED.');
  console.log('========================================================================\n');
}

module.exports = { seedDatabase };

if (require.main === module) {
  seedDatabase()
    .then(() => process.exit(0))
    .catch(err => {
      console.error('Fatal Error during database seed:', err);
      process.exit(1);
    });
}