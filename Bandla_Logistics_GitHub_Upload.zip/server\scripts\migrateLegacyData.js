const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { initDb, getDb } = require('../config/db');
const env = require('../config/env');

const BASE_DIR = path.join(__dirname, '../../');
const ANOMALY_LOG_PATH = path.join(env.DATA_DIR, 'migration_anomalies.log');

/**
 * Anomaly Logger: Appends formatted error details to migration_anomalies.log
 */
function logAnomaly(source, rowNumber, reason, rawData) {
  const timestamp = new Date().toISOString();
  const entry = `[${timestamp}] [${source}] Row ${rowNumber}: ${reason} | Raw: ${JSON.stringify(rawData)}\n`;
  try {
    fs.appendFileSync(ANOMALY_LOG_PATH, entry, 'utf8');
  } catch (err) {
    console.warn('Failed to write anomaly log:', err.message);
  }
}

/**
 * Helper: Convert Excel date serials or strings to YYYY-MM-DD
 */
function excelDateToString(val) {
  if (val === null || val === undefined || val === '') return null;
  const str = String(val).trim();
  if (str.startsWith('#') || str === 'NaN' || str === 'null') return null;

  const num = Number(val);
  if (!isNaN(num) && num > 30000 && num < 60000) {
    try {
      const utc_days = Math.floor(num - 25569);
      const d = new Date(utc_days * 86400 * 1000);
      return !isNaN(d.getTime()) ? d.toISOString().split('T')[0] : null;
    } catch (e) {
      return null;
    }
  }

  if (str.includes('/') || str.includes('-')) {
    if (str.includes('/')) {
      const parts = str.split('/');
      if (parts.length === 3) {
        const d = parts[0].padStart(2, '0');
        const m = parts[1].padStart(2, '0');
        const y = parts[2].length === 2 ? `20${parts[2]}` : parts[2];
        const constructed = `${y}-${m}-${d}`;
        if (!isNaN(new Date(constructed).getTime())) return constructed;
      }
    }
    const parsed = new Date(str);
    if (!isNaN(parsed.getTime())) return parsed.toISOString().split('T')[0];
  }

  return null;
}

function sanitizeNumber(val, defaultVal = 0) {
  if (val === null || val === undefined || val === '') return defaultVal;
  if (typeof val === 'number') return isNaN(val) ? defaultVal : val;
  const str = String(val).replace(/[^0-9.-]/g, '').trim();
  if (!str || str.startsWith('#') || str === 'NaN') return defaultVal;
  const num = parseFloat(str);
  return isNaN(num) ? defaultVal : num;
}

function sanitizeString(val) {
  if (val === null || val === undefined) return '';
  const str = String(val).trim();
  if (str.startsWith('#') || str === 'NaN' || str === 'null') return '';
  return str.replace(/\s+/g, ' ');
}

// =========================================================================
// 1. EXTRACT OPERATIONS & DEDUCTIONS DATA (Payroll Workbook)
// =========================================================================
function extractPortalData(filePath) {
  if (!fs.existsSync(filePath)) return { operations: [], charges: [] };
  const wb = XLSX.readFile(filePath);

  // A. Portal Data Tab
  const pdSheet = wb.Sheets['Portal Data'];
  let operations = [];
  if (pdSheet) {
    const rawData = XLSX.utils.sheet_to_json(pdSheet, { header: 1, defval: '' });
    for (let i = 1; i < rawData.length; i++) {
      const row = rawData[i];
      const fdNumber = sanitizeString(row[0]);
      const dateStr = excelDateToString(row[1]);
      const stops = parseInt(sanitizeNumber(row[2], 0), 10);
      const parcels = parseInt(sanitizeNumber(row[3], 0), 10);
      const excess = sanitizeNumber(row[4], Math.max(0, parcels - stops));
      const stopPay = sanitizeNumber(row[5], 0);
      const parcelPay = sanitizeNumber(row[6], excess * 0.05);
      const totalPay = sanitizeNumber(row[7], stopPay + parcelPay);
      const route = sanitizeString(row[8]);
      const mileage = sanitizeNumber(row[9], 0);
      const rawDriver = sanitizeString(row[10]);
      const topUpCancelled = Boolean(row[11]);

      if (dateStr && rawDriver) {
        let driverCode = null;
        let driverName = rawDriver;
        const codeMatch = rawDriver.match(/^(DR\d+)\s+(.+)$/i);
        if (codeMatch) {
          driverCode = codeMatch[1].toUpperCase();
          driverName = codeMatch[2].trim();
        }

        operations.push({
          fdNumber,
          date: dateStr,
          driverCode,
          driverName,
          routeId: route,
          totalStops: stops,
          totalParcels: parcels,
          excessParcels: excess,
          stopPay,
          parcelPay,
          totalPay,
          mileage,
          topUpCancelled
        });
      }
    }
  }

  // B. Charges & Deductions Tab
  const cdSheet = wb.Sheets['Charges & Deductions'];
  let charges = [];
  if (cdSheet) {
    const rawCharges = XLSX.utils.sheet_to_json(cdSheet, { header: 1, defval: '' });
    for (let i = 7; i < rawCharges.length; i++) {
      const row = rawCharges[i];
      const billingPeriod = sanitizeString(row[0]);
      const chargeDate = excelDateToString(row[1]);
      const driverName = sanitizeString(row[2]);
      const chargeType = sanitizeString(row[3]);
      const amount = sanitizeNumber(row[4], null);
      const notes = sanitizeString(row[5]);

      if (billingPeriod && chargeDate && driverName && chargeType && amount !== null) {
        charges.push({
          billingPeriod,
          chargeDate,
          driverName,
          chargeType,
          amount,
          notes
        });
      }
    }
  }

  return { operations, charges };
}

// =========================================================================
// 2. EXTRACT FLEET & MACHINERY DATA (Fleet Management Workbook)
// =========================================================================
function extractFleetData(filePath) {
  if (!fs.existsSync(filePath)) return { fleetInventory: [], maintenanceLogs: [] };
  const wb = XLSX.readFile(filePath);

  // A. Equipment Master
  const eqSheet = wb.Sheets['Equipment_Master'];
  let fleetInventory = [];
  if (eqSheet) {
    const rawData = XLSX.utils.sheet_to_json(eqSheet, { header: 1, defval: '' });
    for (let i = 2; i < rawData.length; i++) {
      const row = rawData[i];
      const eqCode = sanitizeString(row[0]);
      const modelNo = sanitizeString(row[3]);
      const category = sanitizeString(row[2]) || 'Machinery';
      if (!modelNo) continue;

      const hourly = sanitizeNumber(row[4], 0);
      const daily = sanitizeNumber(row[5], 0);
      const monthly = sanitizeNumber(row[6], 0);
      const lastService = excelDateToString(row[7]);
      const meterHrs = sanitizeNumber(row[10], 0);
      const status = sanitizeString(row[13]) || 'Available';

      fleetInventory.push({
        equipmentCode: eqCode || modelNo,
        modelNumber: modelNo,
        category,
        hourlyRate: hourly,
        dailyRate: daily,
        monthlyRate: monthly,
        currentMeterHours: meterHrs,
        lastServiceDate: lastService,
        status
      });
    }
  }

  // B. Maintenance & Breakdown Logs
  const maintSheet = wb.Sheets['Breakdown_&_Maintenance'];
  let maintenanceLogs = [];
  if (maintSheet) {
    const rawMaint = XLSX.utils.sheet_to_json(maintSheet, { header: 1, defval: '' });
    for (let i = 2; i < rawMaint.length; i++) {
      const row = rawMaint[i];
      const logDate = excelDateToString(row[0]);
      const modelNo = sanitizeString(row[2]).toUpperCase();
      const category = sanitizeString(row[4]) || 'Spare Part Replacement';
      if (!logDate || !modelNo) continue;

      const idle = sanitizeNumber(row[5], 0);
      const parts = sanitizeNumber(row[6], 0);
      const fees = sanitizeNumber(row[7], 0);
      const labor = sanitizeNumber(row[8], 0);
      const total = sanitizeNumber(row[9], parts + fees + labor);
      const site = sanitizeString(row[3]);

      maintenanceLogs.push({
        logDate,
        modelNumber: modelNo,
        issueCategory: category,
        idleHours: idle,
        sparePartsCost: parts,
        workshopFees: fees,
        laborCost: labor,
        totalCost: total,
        siteLocation: site
      });
    }
  }

  return { fleetInventory, maintenanceLogs };
}

// =========================================================================
// 3. EXTRACT & FLATTEN VISUAL DRIVER REGISTER CALENDAR SHEETS
// =========================================================================
function extractVisualDriverRegister(filePath) {
  if (!fs.existsSync(filePath)) return { masterDrivers: [], masterVehicles: [], flattenedShifts: [] };
  const wb = XLSX.readFile(filePath);

  let masterDrivers = [];
  let masterVehicles = [];

  // A. Master Lists from DATA Tab
  const dataSheet = wb.Sheets['DATA'];
  if (dataSheet) {
    const dataRows = XLSX.utils.sheet_to_json(dataSheet, { header: 1, defval: '' });
    for (const r of dataRows) {
      const v0 = sanitizeString(r[0]);
      const v1 = sanitizeString(r[1]);
      const v2 = sanitizeString(r[2]);
      if (!v0) continue;

      if (/^[A-Z]{2}[0-9]{2}\s?[A-Z]{3}$/i.test(v0)) {
        masterVehicles.push({ registrationNumber: v0.toUpperCase(), category: 'Van' });
      } else if (v0.length > 2 && isNaN(Number(v0))) {
        masterDrivers.push({
          fullName: v0,
          defaultDepotName: v2,
          isVatRegistered: v0.toLowerCase().includes('doru andrei mitroi')
        });
      }
    }
  }

  // B. Flatten Visual Monthly Calendar Grids (Jan 26 -> Dec 26)
  const monthSheets = ['Jan 26', 'Feb 26', 'Mar 26', 'Apr 26', 'May 26', 'Jun 26', 'Jul 26', 'Aug 26', 'Dec 26'];
  const flattenedShifts = [];

  monthSheets.forEach(sheetName => {
    const ws = wb.Sheets[sheetName];
    if (!ws) return;
    const data = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

    // Find all Week table blocks
    const weekRows = [];
    for (let r = 0; r < data.length; r++) {
      const rowStr = JSON.stringify(data[r]);
      if (rowStr.includes('Week ') && rowStr.includes(':')) {
        weekRows.push(r);
      }
    }

    weekRows.forEach((wRow, wIdx) => {
      const nextWRow = weekRows[wIdx + 1] || (wRow + 120);
      const dateRow = data[wRow + 1] || [];

      // Extract 7 date serials for Monday -> Sunday
      const dayDates = [];
      for (let day = 0; day < 7; day++) {
        const c = day * 6;
        let dateVal = null;
        for (let offset = 0; offset < 6; offset++) {
          const val = Number(dateRow[c + offset]);
          if (!isNaN(val) && val > 45000 && val < 47000) {
            dateVal = excelDateToString(val);
            break;
          }
        }
        dayDates.push(dateVal);
      }

      // Read driver rows within this week block
      for (let r = wRow + 11; r < nextWRow && r < data.length; r++) {
        const row = data[r] || [];
        const baseDriverName = sanitizeString(row[0]);
        if (!baseDriverName || baseDriverName.toLowerCase().includes('total') || baseDriverName.toLowerCase().includes('depot')) continue;

        for (let day = 0; day < 7; day++) {
          const c = day * 6;
          const shiftDate = dayDates[day];
          if (!shiftDate) continue;

          const specificDriver = sanitizeString(row[c]) || baseDriverName;
          const depot = sanitizeString(row[c + 1]);
          const reg = sanitizeString(row[c + 2]);
          const fd = sanitizeString(row[c + 3]);
          const route = sanitizeString(row[c + 4]);
          const stops = parseInt(sanitizeNumber(row[c + 5], 0), 10);

          if (depot || reg || route || stops > 0) {
            flattenedShifts.push({
              sheet: sheetName,
              driverName: specificDriver,
              date: shiftDate,
              depotName: depot,
              vehicleReg: reg ? reg.toUpperCase() : null,
              fdNumber: fd || null,
              routeCode: route || null,
              stops
            });
          }
        }
      }
    });
  });

  return { masterDrivers, masterVehicles, flattenedShifts };
}

// =========================================================================
// 4. DATABASE SEEDING EXECUTION (Drizzle ORM & PostgreSQL)
// =========================================================================
async function seedDatabase() {
  console.log('====================================================');
  console.log('STARTING PHASE 3: COMPREHENSIVE LEGACY DATA SEEDING');
  console.log(`Anomaly Audit Log: ${ANOMALY_LOG_PATH}`);
  console.log('====================================================');

  fs.writeFileSync(ANOMALY_LOG_PATH, `--- Bandla Logistics Legacy Seeding Log (${new Date().toISOString()}) ---\n`, 'utf8');

  await initDb();
  const db = getDb();
  const client = db.session.client;

  const results = {
    depotsCreated: 0,
    driversCreated: 0,
    vehiclesCreated: 0,
    routeRatesCreated: 0,
    calendarShiftsFlattened: 0,
    portalShiftsImported: 0,
    chargesImported: 0,
    maintenanceImported: 0
  };

  // 1. Seed Depots
  console.log('\n[1/5] Seeding Depots Master...');
  const defaultDepots = [
    { code: 'HIN', name: 'Hinckley', address: 'Hinckley Hub, Leicestershire' },
    { code: 'LEI', name: 'Leicester', address: 'Leicester Depot, Leicestershire' },
    { code: 'LIN', name: 'Lincoln', address: 'Lincoln Central Hub' },
    { code: 'NOT', name: 'Nottingham', address: 'Nottingham East Hub' },
    { code: 'PET', name: 'Peterborough', address: 'Peterborough Distribution Centre' },
    { code: 'RAU', name: 'Raunds', address: 'Raunds Fulfillment Centre' }
  ];

  const depotMap = new Map();
  for (const d of defaultDepots) {
    const check = await client.query(`SELECT id FROM depots WHERE name = $1`, [d.name]);
    let dId;
    if (check.rows.length > 0) {
      dId = check.rows[0].id;
    } else {
      dId = uuidv4();
      await client.query(`INSERT INTO depots (id, code, name, address) VALUES ($1, $2, $3, $4)`, [dId, d.code, d.name, d.address]);
      results.depotsCreated++;
    }
    depotMap.set(d.name.toLowerCase(), dId);
    depotMap.set(d.code.toLowerCase(), dId);
  }

  // 2. Extract Data from all 3 workbooks
  const payrollPath = path.join(BASE_DIR, 'Copy of Bandla Logistics Payroll 2026.xlsx');
  const fleetPath = path.join(BASE_DIR, 'FLEET MANAGEMENT OPERATORS & EQUIPMENTS (1).xlsx');
  const registerPath = path.join(BASE_DIR, 'Copy of Bandla Logistics Driver Register 2026.xlsx');

  console.log('\n[2/5] Extracting Workbooks...');
  const { operations, charges } = extractPortalData(payrollPath);
  const { fleetInventory, maintenanceLogs } = extractFleetData(fleetPath);
  const { masterDrivers, masterVehicles, flattenedShifts } = extractVisualDriverRegister(registerPath);

  console.log(`  ✓ Extracted ${operations.length} portal operations records.`);
  console.log(`  ✓ Extracted ${charges.length} deductions records.`);
  console.log(`  ✓ Extracted ${fleetInventory.length} machinery & fleet records.`);
  console.log(`  ✓ Extracted ${masterDrivers.length} driver profiles.`);
  console.log(`  ✓ Flattened ${flattenedShifts.length} visual calendar shifts across 9 monthly sheets.`);

  results.calendarShiftsFlattened = flattenedShifts.length;

  // 3. Seed Drivers & Vehicles
  console.log('\n[3/5] Seeding Drivers & Fleet Master...');
  const driverMap = new Map();
  const vehicleMap = new Map();

  // Seed Vehicles from Register & Fleet Inventory
  for (const mv of masterVehicles) {
    if (!vehicleMap.has(mv.registrationNumber)) {
      const vId = uuidv4();
      await client.query(`
        INSERT INTO vehicles (id, model_number, registration_number, category, status)
        VALUES ($1, $2, $3, 'Van', 'Available')
        ON CONFLICT (equipment_code) DO NOTHING
      `, [vId, mv.registrationNumber, mv.registrationNumber]);
      vehicleMap.set(mv.registrationNumber, vId);
      results.vehiclesCreated++;
    }
  }

  for (const f of fleetInventory) {
    const modelKey = f.modelNumber.toUpperCase();
    if (!vehicleMap.has(modelKey)) {
      const vId = uuidv4();
      await client.query(`
        INSERT INTO vehicles (
          id, equipment_code, model_number, category, hourly_rate, daily_rate, monthly_rate,
          current_meter_hours, last_service_date, status
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        ON CONFLICT (equipment_code) DO NOTHING
      `, [vId, f.equipmentCode, f.modelNumber, f.category, f.hourlyRate, f.dailyRate, f.monthlyRate, f.currentMeterHours, f.lastServiceDate, f.status]);
      vehicleMap.set(modelKey, vId);
      results.vehiclesCreated++;
    }
  }

  // Seed Drivers from Master list & Portal Data
  for (const md of masterDrivers) {
    const key = md.fullName.toLowerCase();
    if (!driverMap.has(key)) {
      const dId = uuidv4();
      const depotId = depotMap.get((md.defaultDepotName || '').toLowerCase()) || null;
      await client.query(`
        INSERT INTO drivers (id, full_name, default_depot_id, is_vat_registered, status)
        VALUES ($1, $2, $3, $4, 'active')
      `, [dId, md.fullName, depotId, md.isVatRegistered]);
      driverMap.set(key, dId);
      results.driversCreated++;
    }
  }

  // 4. Seed Route Rates & Shifts
  console.log('\n[4/5] Seeding Route Rates & Shifts...');
  const routeRateMap = new Map();

  for (const op of operations) {
    const driverKey = op.driverName.toLowerCase();
    let driverId = driverMap.get(driverKey);
    if (!driverId) {
      driverId = uuidv4();
      const isVat = op.driverName.toLowerCase().includes('doru andrei mitroi');
      await client.query(`
        INSERT INTO drivers (id, driver_code, full_name, is_vat_registered, status)
        VALUES ($1, $2, $3, $4, 'active')
      `, [driverId, op.driverCode, op.driverName, isVat]);
      driverMap.set(driverKey, driverId);
      results.driversCreated++;
    }

    const ratePerStop = op.totalStops > 0 ? (op.stopPay / op.totalStops) : 2.1000;
    if (op.routeId && !routeRateMap.has(op.routeId)) {
      routeRateMap.set(op.routeId, ratePerStop);
      const rrId = uuidv4();
      await client.query(`
        INSERT INTO route_rates (id, route_code, base_rate_per_stop, excess_parcel_rate, min_stop_guarantee)
        VALUES ($1, $2, $3, 0.0500, 100)
        ON CONFLICT (route_code, depot_id) DO NOTHING
      `, [rrId, op.routeId, ratePerStop.toFixed(4)]);
      results.routeRatesCreated++;
    }

    let topUpStops = 0;
    let topUpPay = 0;
    if (op.totalStops > 0 && op.totalStops < 100 && !op.topUpCancelled) {
      topUpStops = 100 - op.totalStops;
      topUpPay = parseFloat((topUpStops * ratePerStop).toFixed(2));
    }

    const shiftId = uuidv4();
    try {
      await client.query(`
        INSERT INTO daily_shifts (
          id, shift_date, driver_id, route_code, fd_number,
          dispatched_stops, paid_stops, total_parcels, excess_parcels, mileage,
          applied_base_rate, applied_excess_rate, calculated_stop_pay, calculated_parcel_pay,
          top_up_stops, top_up_pay, top_up_cancelled, gross_shift_total
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
      `, [
        shiftId, op.date, driverId, op.routeId || null, op.fdNumber || null,
        op.totalStops, op.totalStops, op.totalParcels, op.excessParcels, op.mileage,
        ratePerStop.toFixed(4), '0.0500', op.stopPay.toFixed(2), op.parcelPay.toFixed(2),
        topUpStops, topUpPay.toFixed(2), op.topUpCancelled, (op.totalPay + topUpPay).toFixed(2)
      ]);
      results.portalShiftsImported++;
    } catch (sErr) {
      logAnomaly('Portal Shift Insert', 0, sErr.message, op);
    }
  }

  // 5. Seed Charges & Maintenance
  console.log('\n[5/5] Seeding Charges, Deductions & Maintenance Logs...');
  for (const c of charges) {
    let driverId = driverMap.get(c.driverName.toLowerCase());
    if (!driverId) {
      driverId = uuidv4();
      await client.query(`INSERT INTO drivers (id, full_name, status) VALUES ($1, $2, 'active')`, [driverId, c.driverName]);
      driverMap.set(c.driverName.toLowerCase(), driverId);
      results.driversCreated++;
    }

    const cId = uuidv4();
    try {
      await client.query(`
        INSERT INTO charges_and_deductions (
          id, billing_period, charge_date, driver_id, charge_type, amount, notes
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      `, [cId, c.billingPeriod, c.chargeDate, driverId, c.chargeType, c.amount.toFixed(2), c.notes || null]);
      results.chargesImported++;
    } catch (cErr) {
      logAnomaly('Charges Insert', 0, cErr.message, c);
    }
  }

  for (const m of maintenanceLogs) {
    const vId = vehicleMap.get(m.modelNumber) || null;
    if (vId) {
      const mId = uuidv4();
      try {
        await client.query(`
          INSERT INTO maintenance_records (
            id, log_date, vehicle_id, issue_category, idle_hours, spare_parts_cost, workshop_fees, labor_cost, total_cost, site_location
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        `, [mId, m.logDate, vId, m.issueCategory, m.idleHours, m.sparePartsCost, m.workshopFees, m.laborCost, m.totalCost, m.siteLocation]);
        results.maintenanceImported++;
      } catch (mErr) {
        logAnomaly('Maintenance Insert', 0, mErr.message, m);
      }
    }
  }

  console.log('\n====================================================');
  console.log('PHASE 3: LEGACY SEEDING COMPLETED SUCCESSFULLY!');
  console.log('====================================================');
  console.table(results);
  return results;
}

if (require.main === module) {
  seedDatabase().then(() => process.exit(0)).catch(err => {
    console.error('Fatal Seeding Error:', err);
    process.exit(1);
  });
}

module.exports = {
  extractPortalData,
  extractFleetData,
  extractVisualDriverRegister,
  seedDatabase
};