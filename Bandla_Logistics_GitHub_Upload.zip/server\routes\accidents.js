const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

// List accident records
router.get('/', async (req, res) => {
  try {
    const { vehicleId, driverId, status, startDate, endDate } = req.query;
    const db = getDb();
    let query = `
      SELECT a.*,
        a.date as incident_date,
        a.insurance_claim_status as claim_status,
        a.estimated_damage_cost as cost_estimate,
        v.registration_number, v.model_number as vehicle_model,
        d.full_name as driver_name, d.driver_code
      FROM accident_logs a
      JOIN vehicles v ON a.vehicle_id = v.id
      LEFT JOIN drivers d ON a.driver_id = d.id
      WHERE 1=1
    `;
    const params = [];

    if (vehicleId) {
      params.push(vehicleId);
      query += ` AND a.vehicle_id = $${params.length}`;
    }
    if (driverId) {
      params.push(driverId);
      query += ` AND a.driver_id = $${params.length}`;
    }
    if (status) {
      params.push(status);
      query += ` AND a.insurance_claim_status = $${params.length}`;
    }
    if (startDate) {
      params.push(startDate);
      query += ` AND a.date >= $${params.length}`;
    }
    if (endDate) {
      params.push(endDate);
      query += ` AND a.date <= $${params.length}`;
    }

    query += ` ORDER BY a.date DESC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create accident log
router.post('/', async (req, res) => {
  try {
    const {
      vehicleId, driverId, date, incidentDate,
      description, notes,
      claimStatus, insuranceClaimStatus,
      costEstimate, actualCost, estimatedDamageCost,
      claimNumber, insuranceCompany, policeReportRef, thirdPartyDetails
    } = req.body;

    const targetDate = incidentDate || date || new Date().toISOString().split('T')[0];
    if (!vehicleId) {
      return res.status(400).json({ error: 'Vehicle selection is required.' });
    }

    const desc = (description || notes || 'Incident reported').trim();
    const status = claimStatus || insuranceClaimStatus || 'Reported';
    const cost = parseFloat(costEstimate || actualCost || estimatedDamageCost || 0);

    let thirdParty = (thirdPartyDetails || '').trim();
    const extraParts = [];
    if (insuranceCompany) extraParts.push(`Insurer: ${insuranceCompany}`);
    if (claimNumber) extraParts.push(`Claim #: ${claimNumber}`);
    if (policeReportRef) extraParts.push(`Police Ref: ${policeReportRef}`);
    if (extraParts.length > 0) {
      thirdParty = thirdParty ? `${thirdParty} | ${extraParts.join(' | ')}` : extraParts.join(' | ');
    }

    const db = getDb();
    const id = uuidv4();

    const { rows } = await db.session.client.query(`
      INSERT INTO accident_logs (
        id, vehicle_id, driver_id, date, description, insurance_claim_status, estimated_damage_cost, third_party_details, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
      RETURNING *
    `, [
      id, vehicleId, driverId || null, targetDate, desc,
      status, cost.toFixed(2), thirdParty || null
    ]);

    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update accident log
router.put('/:id', async (req, res) => {
  try {
    const {
      vehicleId, driverId, date, incidentDate,
      description, notes,
      claimStatus, insuranceClaimStatus,
      costEstimate, actualCost, estimatedDamageCost,
      claimNumber, insuranceCompany, policeReportRef, thirdPartyDetails
    } = req.body;

    const targetDate = incidentDate || date;
    const desc = description || notes;
    const status = claimStatus || insuranceClaimStatus;
    const cost = (costEstimate !== undefined || actualCost !== undefined || estimatedDamageCost !== undefined)
      ? parseFloat(costEstimate || actualCost || estimatedDamageCost || 0)
      : undefined;

    let thirdParty = thirdPartyDetails;
    const extraParts = [];
    if (insuranceCompany) extraParts.push(`Insurer: ${insuranceCompany}`);
    if (claimNumber) extraParts.push(`Claim #: ${claimNumber}`);
    if (policeReportRef) extraParts.push(`Police Ref: ${policeReportRef}`);
    if (extraParts.length > 0) {
      thirdParty = thirdParty ? `${thirdParty} | ${extraParts.join(' | ')}` : extraParts.join(' | ');
    }

    const db = getDb();
    const { rows } = await db.session.client.query(`
      UPDATE accident_logs SET
        vehicle_id = COALESCE($1, vehicle_id),
        driver_id = $2,
        date = COALESCE($3, date),
        description = COALESCE($4, description),
        insurance_claim_status = COALESCE($5, insurance_claim_status),
        estimated_damage_cost = COALESCE($6, estimated_damage_cost),
        third_party_details = COALESCE($7, third_party_details),
        updated_at = NOW()
      WHERE id = $8
      RETURNING *
    `, [
      vehicleId, driverId || null, targetDate, desc,
      status, cost !== undefined ? cost.toFixed(2) : null, thirdParty, req.params.id
    ]);

    if (!rows.length) return res.status(404).json({ error: 'Accident record not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete accident log
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const { rowCount } = await db.session.client.query(`DELETE FROM accident_logs WHERE id = $1`, [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: 'Record not found' });
    res.json({ message: 'Accident record deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
