import React, { useState, useRef, useEffect } from 'react';
import { Columns, RotateCcw, SlidersHorizontal } from 'lucide-react';

/**
 * ColumnVisibilityToggle
 * Allows admin to hide/unhide table columns dynamically like in Excel.
 */
export default function ColumnVisibilityToggle({
  columns = [],
  visibleColumns = {},
  onChange,
  onReset,
  storageKey
}) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const toggleColumn = (key) => {
    const next = {
      ...visibleColumns,
      [key]: visibleColumns[key] === false ? true : false
    };
    if (storageKey) {
      try {
        localStorage.setItem(storageKey, JSON.stringify(next));
      } catch (e) {}
    }
    if (onChange) onChange(next);
  };

  const showAll = () => {
    const next = {};
    columns.forEach((c) => { next[c.key] = true; });
    if (storageKey) {
      try {
        localStorage.setItem(storageKey, JSON.stringify(next));
      } catch (e) {}
    }
    if (onChange) onChange(next);
  };

  const hiddenCount = columns.filter((c) => visibleColumns[c.key] === false).length;

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition cursor-pointer shadow-sm ${
          hiddenCount > 0
            ? 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30 hover:bg-amber-500/20'
            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
        }`}
        title="Hide / Unhide Columns (Excel Column Mode)"
      >
        <Columns className="w-3.5 h-3.5" />
        <span>Columns {hiddenCount > 0 ? `(${hiddenCount} Hidden)` : ''}</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 rounded-xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 z-50 p-3 space-y-3 animate-fade-in text-xs font-sans">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
              <SlidersHorizontal className="w-3.5 h-3.5 text-blue-500" />
              <span>Hide / Show Columns</span>
            </div>
            <button
              type="button"
              onClick={showAll}
              className="text-[10px] text-blue-600 dark:text-blue-400 hover:underline font-bold cursor-pointer"
            >
              Show All
            </button>
          </div>

          <p className="text-[10px] text-slate-500">
            Uncheck any column to hide it from view (just like Hide Column in Excel).
          </p>

          <div className="max-h-60 overflow-y-auto space-y-1.5 pr-1 divide-y divide-slate-100 dark:divide-slate-800/40">
            {columns.map((col) => {
              const isVisible = visibleColumns[col.key] !== false;
              return (
                <label
                  key={col.key}
                  className="flex items-center justify-between pt-1.5 pb-0.5 px-1.5 rounded hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer transition select-none"
                >
                  <span className={`text-xs ${isVisible ? 'text-slate-800 dark:text-slate-200 font-medium' : 'text-slate-400 line-through'}`}>
                    {col.label}
                  </span>
                  <input
                    type="checkbox"
                    checked={isVisible}
                    onChange={() => toggleColumn(col.key)}
                    className="rounded bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-0 cursor-pointer w-3.5 h-3.5"
                  />
                </label>
              );
            })}
          </div>

          {onReset && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  onReset();
                  if (storageKey) {
                    try { localStorage.removeItem(storageKey); } catch (e) {}
                  }
                }}
                className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" /> Reset View
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
