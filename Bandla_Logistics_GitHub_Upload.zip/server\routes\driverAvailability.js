const cleanDate = (d) => (!d || String(d).trim() === '' ? null : String(d).trim());
const cleanStr = (s) => (!s || String(s).trim() === '' ? null : String(s).trim());
const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/db');

// List driver availability blocks
router.get('/', async (req, res) => {
  try {
    const { driverId, startDate, endDate, status } = req.query;
    const db = getDb();
    let query = `
      SELECT a.*, d.full_name as driver_name, d.driver_code, dep.name as default_depot_name
      FROM driver_availability a
      JOIN drivers d ON a.driver_id = d.id
      LEFT JOIN depots dep ON d.default_depot_id = dep.id
      WHERE 1=1
    `;
    const params = [];

    if (driverId) {
      params.push(driverId);
      query += ` AND a.driver_id = $${params.length}`;
    }
    if (cleanDate(startDate)) {
      params.push(cleanDate(startDate));
      query += ` AND a.end_date >= $${params.length}`;
    }
    if (cleanDate(endDate)) {
      params.push(cleanDate(endDate));
      query += ` AND a.start_date <= $${params.length}`;
    }
    if (status) {
      params.push(status);
      query += ` AND a.status = $${params.length}`;
    }

    query += ` ORDER BY a.start_date ASC`;
    const { rows } = await db.session.client.query(query, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Check unavailable / holiday drivers for a specific date (for Weekly Route Planner)
router.get('/check', async (req, res) => {
  try {
    const { date } = req.query;
    if (!date) {
      return res.status(400).json({ error: 'Date query parameter (YYYY-MM-DD) is required.' });
    }

    const db = getDb();
    const { rows } = await db.session.client.query(`
      SELECT a.driver_id, a.status, a.notes, d.full_name as driver_name
      FROM driver_availability a
      JOIN drivers d ON a.driver_id = d.id
      WHERE a.start_date <= $1 AND a.end_date >= $1
    `, [date]);

    res.json({
      date,
      unavailableDriverIds: rows.map(r => r.driver_id),
      details: rows
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create availability block (Admin Only)
router.post('/', async (req, res) => {
  try {
    const { driverId, startDate, endDate, status, notes } = req.body;
    if (!driverId || !cleanDate(startDate) || !cleanDate(endDate)) {
      return res.status(400).json({ error: 'Driver, start date, and end date are required.' });
    }

    const db = getDb();
    const id = uuidv4();

    const { rows } = await db.session.client.query(`
      INSERT INTO driver_availability (id, driver_id, start_date, end_date, status, notes)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `, [id, driverId, cleanDate(startDate), cleanDate(endDate), status || 'Holiday', notes || null]);

    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update availability block
router.put('/:id', async (req, res) => {
  try {
    const { driverId, startDate, endDate, status, notes } = req.body;
    const db = getDb();

    const { rows } = await db.session.client.query(`
      UPDATE driver_availability SET
        driver_id = COALESCE($1, driver_id),
        start_date = COALESCE($2, start_date),
        end_date = COALESCE($3, end_date),
        status = COALESCE($4, status),
        notes = $5,
        updated_at = NOW()
      WHERE id = $6
      RETURNING *
    `, [driverId, cleanDate(startDate), cleanDate(endDate), status, notes, req.params.id]);

    if (!rows.length) return res.status(404).json({ error: 'Availability record not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete availability block
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const { rowCount } = await db.session.client.query(`DELETE FROM driver_availability WHERE id = $1`, [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: 'Record not found' });
    res.json({ message: 'Availability record deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;