const { app } = require('../server/index');
const { initDb } = require('../server/config/db');
const { migrate } = require('../server/db/migrate');
const { seedUsers } = require('../server/db/seedUsers');
const { seedDatabase } = require('../server/scripts/seed');
const { seedEdgeCases } = require('../server/scripts/seed_edge_cases');
const { seedRichPayrollData } = require('../server/scripts/seed_rich_payroll_data');
const { ingestHarishDatabase } = require('../server/scripts/ingestHarishDatabase');

let isInitialized = false;

module.exports = async (req, res) => {
  if (!isInitialized) {
    try {
      await initDb();
      await migrate();
      await seedUsers();
      await seedDatabase();
      await seedEdgeCases();
      await seedRichPayrollData();
      await ingestHarishDatabase();
      isInitialized = true;
    } catch (e) {
      console.warn('Initialization note in serverless:', e.message);
      isInitialized = true;
    }
  }
  return app(req, res);
};
