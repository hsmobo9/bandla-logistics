import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Truck, 
  Receipt, 
  AlertTriangle, 
  TrendingUp, 
  Calendar, 
  CheckCircle2, 
  ArrowRight,
  ShieldAlert,
  Clock,
  Package,
  Wrench,
  ChevronRight,
  Gauge
} from 'lucide-react';
import { getDashboardKpi } from '../services/api';
import { formatCurrency, formatNumber, formatDate } from '../utils/formatters';

export default function Dashboard({ setActiveTab }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      setLoading(true);
      const data = await getDashboardKpi();
      setStats(data);
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3 text-slate-500 dark:text-slate-400">
          <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-medium">Aggregating Executive Metrics...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 bg-rose-50 border border-rose-200 text-rose-700 dark:bg-rose-500/10 dark:border-rose-500/30 dark:text-rose-600 dark:text-rose-400 rounded-2xl text-xs">
        <p className="font-bold">Error loading dashboard stats:</p>
        <p className="mt-1">{error}</p>
      </div>
    );
  }

  const kpi = stats || {
    drivers: { total: 0, active: 0 },
    vehicles: { total: 0, operational: 0, inMaintenance: 0 },
    shifts: { totalShifts: 0, totalDispatchedStops: 0, totalPaidStops: 0, totalGrossShiftPay: 0, totalTopUpPay: 0 },
    invoices: { totalGrossEarnings: 0, totalDeductions: 0, totalNetPayable: 0, count: 0 },
    recentShifts: [],
    fleetAlerts: []
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-50 via-white to-indigo-50 border border-slate-200 dark:from-blue-950/60 dark:via-slate-900 dark:to-indigo-950/60 dark:border-slate-800 p-6 rounded-2xl shadow-md dark:shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors duration-200">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Operations Control Center</span>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight mt-0.5">Bandla Executive Dashboard</h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">Multi-depot courier operations, fleet readiness & payroll financial performance.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setActiveTab('analytics')}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-emerald-600/20 flex items-center gap-1.5 transition cursor-pointer"
          >
            <Gauge className="w-4 h-4" /> Performance & Cost/KM
          </button>
          <button
            onClick={() => setActiveTab('invoices')}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-lg shadow-blue-600/20 flex items-center gap-1.5 transition cursor-pointer"
          >
            <Receipt className="w-4 h-4" /> Open Payroll Hub
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Driver Workforce */}
        <div className="bg-white border border-slate-200 dark:bg-slate-900 dark:border-slate-800 p-5 rounded-xl shadow-sm dark:shadow-lg relative overflow-hidden group hover:border-slate-300 dark:hover:border-slate-700 transition duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Driver Workforce</span>
            <div className="p-2 bg-sky-50 text-sky-600 dark:bg-sky-500/10 dark:text-sky-600 dark:text-sky-400 rounded-lg">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 dark:text-white">{kpi.drivers.active} Active</div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">of {kpi.drivers.total} registered contractors</p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-emerald-600 dark:text-emerald-400 font-medium"> 100% On-Duty Status</span>
            <button onClick={() => setActiveTab('drivers')} className="text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-slate-900 dark:text-white flex items-center gap-1">
              Manage <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Card 2: Active Courier Fleet */}
        <div className="bg-white border border-slate-200 dark:bg-slate-900 dark:border-slate-800 p-5 rounded-xl shadow-sm dark:shadow-lg relative overflow-hidden group hover:border-slate-300 dark:hover:border-slate-700 transition duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Active Fleet</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-600 dark:text-emerald-400 rounded-lg">
              <Truck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 dark:text-white">{kpi.vehicles.operational} Vans</div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {kpi.vehicles.inMaintenance > 0 ? `${kpi.vehicles.inMaintenance} in garage maintenance` : 'Full fleet operational'}
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-blue-600 dark:text-blue-400 font-medium">MOT / Tax Monitored</span>
            <button onClick={() => setActiveTab('fleet')} className="text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-slate-900 dark:text-white flex items-center gap-1">
              Inspect <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Card 3: Shift Dispatches & Stop Pay */}
        <div className="bg-white border border-slate-200 dark:bg-slate-900 dark:border-slate-800 p-5 rounded-xl shadow-sm dark:shadow-lg relative overflow-hidden group hover:border-slate-300 dark:hover:border-slate-700 transition duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Route Stop Pay</span>
            <div className="p-2 bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-600 dark:text-indigo-400 rounded-lg">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 dark:text-white">{formatCurrency(kpi.shifts.totalGrossShiftPay)}</div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {formatNumber(kpi.shifts.totalPaidStops)} stops ({formatNumber(kpi.shifts.totalShifts)} routes)
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-indigo-600 dark:text-indigo-400 font-medium">+{formatCurrency(kpi.shifts.totalTopUpPay)} Top-Up Guarantee</span>
            <button onClick={() => setActiveTab('shifts')} className="text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-slate-900 dark:text-white flex items-center gap-1">
              Details <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Card 4: Net Invoiced Payroll */}
        <div className="bg-white border border-slate-200 dark:bg-slate-900 dark:border-slate-800 p-5 rounded-xl shadow-sm dark:shadow-lg relative overflow-hidden group hover:border-slate-300 dark:hover:border-slate-700 transition duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">Net Payroll Invoiced</span>
            <div className="p-2 bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-600 dark:text-amber-400 rounded-lg">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{formatCurrency(kpi.invoices.totalNetPayable)}</div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {kpi.invoices.count} monthly contractor invoices
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-slate-500 dark:text-slate-400">Deductions: {formatCurrency(kpi.invoices.totalDeductions)}</span>
            <button onClick={() => setActiveTab('invoices')} className="text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-slate-900 dark:text-white flex items-center gap-1">
              View <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Split Sections: Live Shifts & Compliance Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Recent Shift Performance */}
        <div className="lg:col-span-2 bg-white border border-slate-200 dark:bg-slate-900 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-lg p-5 space-y-4 transition-colors duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Recent Route Dispatches & Fail Rate</h3>
            </div>
            <button 
              onClick={() => setActiveTab('shifts')}
              className="text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 font-medium"
            >
              View All Routes <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-400 uppercase font-bold text-[11px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="p-2.5">Date</th>
                  <th className="p-2.5">Driver</th>
                  <th className="p-2.5">Route</th>
                  <th className="p-2.5 text-right">Stops</th>
                  <th className="p-2.5 text-center">Fail %</th>
                  <th className="p-2.5 text-right">Gross Pay</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {kpi.recentShifts && kpi.recentShifts.length > 0 ? (
                  kpi.recentShifts.map((s, idx) => {
                    const failNum = parseFloat(s.fail_percentage || 0);
                    return (
                      <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition">
                        <td className="p-2.5 text-slate-600 dark:text-slate-300 font-mono">{formatDate(s.shift_date)}</td>
                        <td className="p-2.5 font-semibold text-slate-900 dark:text-white">{s.driver_name}</td>
                        <td className="p-2.5 text-blue-600 dark:text-blue-400 font-mono font-medium">{s.route_code || 'General'}</td>
                        <td className="p-2.5 text-right font-mono text-slate-700 dark:text-slate-300">{s.paid_stops} / {s.dispatched_stops}</td>
                        <td className="p-2.5 text-center">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            failNum > 10 ? 'bg-rose-100 text-rose-700 dark:bg-rose-500/20 dark:text-rose-600 dark:text-rose-400' :
                            failNum < 0 ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-600 dark:text-emerald-400' :
                            'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                          }`}>
                            {failNum}%
                          </span>
                        </td>
                        <td className="p-2.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">{formatCurrency(s.gross_shift_total)}</td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan="6" className="p-4 text-center text-slate-600 dark:text-slate-400">No recent shifts recorded.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Fleet Compliance Countdown Alerts */}
        <div className="bg-white border border-slate-200 dark:bg-slate-900 dark:border-slate-800 rounded-xl shadow-sm dark:shadow-lg p-5 space-y-4 transition-colors duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Fleet Compliance Alerts</h3>
            </div>
            <button 
              onClick={() => setActiveTab('fleet')}
              className="text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 font-medium"
            >
              Fleet Hub <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-2.5 max-h-72 overflow-y-auto">
            {kpi.fleetAlerts && kpi.fleetAlerts.length > 0 ? (
              kpi.fleetAlerts.map((v, idx) => (
                <div key={idx} className="p-3 bg-slate-50 border border-slate-200 dark:bg-slate-950 dark:border-slate-800/80 rounded-lg flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono font-bold text-slate-900 dark:text-white block">{v.registration_number}</span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">{v.model_number}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-500/20 dark:text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-500/30">
                      MOT / Tax Due
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 block mt-0.5">{formatDate(v.mot_expiry)}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-6 text-center text-slate-500 dark:text-slate-400">
                <CheckCircle2 className="w-6 h-6 mx-auto text-emerald-500 mb-1" />
                <p className="font-semibold text-xs text-slate-700 dark:text-slate-200">Fleet Compliant</p>
                <p className="text-[10px] text-slate-500">All 53 delivery vans within safe MOT/Tax windows.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}