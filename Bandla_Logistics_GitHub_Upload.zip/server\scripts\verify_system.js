const { initDb, getDb } = require('../config/db');
const { calculateShift, generateMonthlyInvoice } = require('../services/calculationService');
const { generateInvoicePdf } = require('../services/invoicePdfService');
const { performBackup, listBackups } = require('../services/backupService');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

async function verifyAll() {
  console.log('====================================================');
  console.log('RUNNING FULL SYSTEM INTEGRATION TESTS & VERIFICATION');
  console.log('====================================================\n');

  // Test 1: DB & Tables
  console.log('[Test 1] Initializing DB & Verifying Tables...');
  await initDb();
  const db = getDb();
  const client = db.session.client;
  const tables = ['depots', 'drivers', 'route_rates', 'vehicles', 'daily_shifts', 'charges_and_deductions', 'payroll_invoices', 'maintenance_records', 'app_settings'];
  for (const tbl of tables) {
    const res = await client.query(`SELECT COUNT(*) FROM ${tbl}`);
    console.log(`  ✓ Table '${tbl}': ${res.rows[0].count} records found`);
  }

  // Test 2: Rate Calculation Engine & Rate Snapshotting
  console.log('\n[Test 2] Testing Rate Calculation Engine & Rate Snapshotting...');
  const testShiftData = {
    shiftDate: '2026-08-25',
    driverId: uuidv4(),
    routeCode: '114',
    appliedBaseRate: 2.2300,
    appliedExcessRate: 0.0500,
    paidStops: 85, // < 100 -> triggers top-up of 15 stops
    totalParcels: 120, // excess parcels = 120 - 85 = 35
    topUpCancelled: false
  };
  const computed = await calculateShift(testShiftData);
  console.log('  Calculated Shift Output:', {
    paidStops: computed.paidStops,
    stopPay: computed.calculatedStopPay,
    excessParcels: computed.excessParcels,
    parcelPay: computed.calculatedParcelPay,
    topUpStops: computed.topUpStops,
    topUpPay: computed.topUpPay,
    grossShiftTotal: computed.grossShiftTotal
  });

  // Verify math
  const expectedStopPay = (85 * 2.2300).toFixed(2); // 189.55
  const expectedParcelPay = (35 * 0.0500).toFixed(2); // 1.75
  const expectedTopUpPay = (15 * 2.2300).toFixed(2); // 33.45
  const expectedGross = (189.55 + 1.75 + 33.45).toFixed(2); // 224.75

  if (computed.calculatedStopPay === expectedStopPay &&
      computed.calculatedParcelPay === expectedParcelPay &&
      computed.topUpPay === expectedTopUpPay &&
      computed.grossShiftTotal === expectedGross) {
    console.log('  ✓ Rate calculation math matches specifications EXACTLY!');
  } else {
    throw new Error('Rate calculation math mismatch!');
  }

  // Test 3: Invoice Generation, VAT & Invoice Locking
  console.log('\n[Test 3] Testing Monthly Invoicing, VAT (20%) on Net Subtotal & Invoice Locking...');
  const vatDriverRes = await client.query(`SELECT * FROM drivers WHERE is_vat_registered = TRUE LIMIT 1`);
  let testDriverId;
  if (vatDriverRes.rows.length > 0) {
    testDriverId = vatDriverRes.rows[0].id;
    console.log(`  Using VAT-registered driver: ${vatDriverRes.rows[0].full_name}`);
  } else {
    testDriverId = uuidv4();
    await client.query(`INSERT INTO drivers (id, full_name, is_vat_registered, status) VALUES ($1, 'Test VAT Contractor', TRUE, 'active')`, [testDriverId]);
  }

  // Insert 2 unbilled test shifts for this driver
  const s1 = uuidv4();
  const s2 = uuidv4();
  await client.query(`
    INSERT INTO daily_shifts (id, shift_date, driver_id, route_code, dispatched_stops, paid_stops, total_parcels, excess_parcels, applied_base_rate, calculated_stop_pay, calculated_parcel_pay, top_up_stops, top_up_pay, gross_shift_total)
    VALUES 
      ($1, '2026-08-01', $3, '114', 120, 120, 150, 30, 2.2300, 267.60, 1.50, 0, 0.00, 269.10),
      ($2, '2026-08-02', $3, '115', 110, 110, 140, 30, 2.1800, 239.80, 1.50, 0, 0.00, 241.30)
  `, [s1, s2, testDriverId]);

  // Insert 1 unbilled deduction
  const c1 = uuidv4();
  await client.query(`
    INSERT INTO charges_and_deductions (id, billing_period, charge_date, driver_id, charge_type, amount, notes)
    VALUES ($1, 'August 2026', '2026-08-01', $2, 'Van Hire', 135.00, 'Weekly Van Hire Deduction')
  `, [c1, testDriverId]);

  // Generate Invoice
  const invoice = await generateMonthlyInvoice({
    driverId: testDriverId,
    billingMonth: 'August 2026',
    billingStartDate: '2026-08-01',
    billingEndDate: '2026-08-31'
  });

  console.log('  Generated Invoice Record:', {
    invoiceNumber: invoice.invoiceNumber,
    daysWorked: invoice.daysWorked,
    grossEarnings: invoice.grossEarnings,
    totalDeductions: invoice.totalDeductions,
    subtotal: invoice.subtotal,
    vatRate: invoice.vatRate,
    vatApplied: invoice.vatApplied,
    netPayable: invoice.netPayable
  });

  // Verify VAT & Locking
  const grossNum = 269.10 + 241.30; // 510.40
  const subtotalNum = (510.40 - 135.00).toFixed(2); // 375.40
  const expectedVat = (375.40 * 0.20).toFixed(2); // 75.08
  const expectedNet = (375.40 * 1.20).toFixed(2); // 450.48

  console.log(`  Expected Subtotal: ${subtotalNum}, Expected VAT: ${expectedVat}, Expected Net: ${expectedNet}`);
  if (parseFloat(invoice.vatApplied) === parseFloat(expectedVat) &&
      parseFloat(invoice.netPayable) === parseFloat(expectedNet)) {
    console.log('  ✓ VAT on Net Subtotal calculated accurately!');
  }

  // Verify Invoice Locking on DB
  const lockedShifts = await client.query(`SELECT invoice_id FROM daily_shifts WHERE id IN ('${s1}', '${s2}')`);
  const lockedCharges = await client.query(`SELECT invoice_id, is_settled FROM charges_and_deductions WHERE id = '${c1}'`);
  if (lockedShifts.rows.every(r => r.invoice_id === invoice.id) && lockedCharges.rows[0].invoice_id === invoice.id) {
    console.log('  ✓ INVOICE LOCKING VERIFIED: Shifts and deductions are locked to invoice ID', invoice.id);
  } else {
    throw new Error('Invoice locking check failed!');
  }

  // Test 4: PDF Generation
  console.log('\n[Test 4] Testing PDFKit Invoice Generation...');
  const pdfResult = await generateInvoicePdf(invoice.id);
  console.log('  ✓ PDF generated successfully at:', pdfResult.pdfPath);
  if (fs.existsSync(pdfResult.pdfPath)) {
    const stat = fs.statSync(pdfResult.pdfPath);
    console.log(`  ✓ PDF file exists and is valid (${stat.size} bytes)`);
  }

  // Test 5: Automated Database Backup
  console.log('\n[Test 5] Testing Automated Database Backup Utility...');
  const backupResult = await performBackup();
  console.log('  ✓ Backup created:', backupResult.backupFileName);
  const backups = listBackups();
  console.log(`  ✓ Total available backups in retention storage: ${backups.length}`);

  console.log('\n====================================================');
  console.log('ALL VERIFICATIONS & TESTS PASSED WITH 100% SUCCESS!');
  console.log('====================================================');
}

verifyAll().then(() => process.exit(0)).catch(err => {
  console.error('Verification Error:', err);
  process.exit(1);
});